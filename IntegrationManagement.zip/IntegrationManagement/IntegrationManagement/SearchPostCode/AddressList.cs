﻿using Newtonsoft.Json;
using SAPbouiCOM;
using Shared;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace SearchPostCode
{
	internal class AddressList:IBForm
	{
		Form oForm;
		public Grid Grid0;
		DataTable dt;
		AddressCont addressbld;
		public AddressList(string postcode ) {
			try
			{
				var task = Task.Run(async () => await GetDataAsync(postcode));
				SAPbouiCOM.FormCreationParams oCP = null;
				oCP = ((SAPbouiCOM.FormCreationParams)(ProgData.B1Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)));
				string uid = "lst" + Guid.NewGuid().ToString().Substring(0, 6);
				
				oCP.UniqueID = uid;

				oCP.FormType = "lst";
				oCP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable;

				oForm = ProgData.B1Application.Forms.AddEx(oCP);
				ProgData.Forms.Add(oForm.UniqueID, this);
				oForm.Title = "Adddress List";
				oForm.Top = 10;
				oForm.Left = 10;
				oForm.Width = 900;
				oForm.Height = 980;
				oForm.AutoManaged = true;
				Grid0 =  (Grid)oForm.Items.Add("grd", SAPbouiCOM.BoFormItemTypes.it_GRID).Specific;
				Grid0.Item.Width = 500;
				Grid0.Item.Height = 800;
				dt = oForm.DataSources.DataTables.Add("DT0");
				dt.Columns.Add("UDPRN", BoFieldsType.ft_AlphaNumeric, 10);
				dt.Columns.Add("PostTown", BoFieldsType.ft_AlphaNumeric, 20);
				dt.Columns.Add("fare", BoFieldsType.ft_AlphaNumeric, 50);
				dt.Columns.Add("build", BoFieldsType.ft_AlphaNumeric, 7);
				dt.Columns.Add("addr", BoFieldsType.ft_AlphaNumeric, 200);
				Grid0.DataTable = dt;
			    task = Task.Run(async () => await LoaddtAsync());
				
				Item oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
				oItem.Left = 5;
				oItem.Width = 65;
				oItem.Top = 920;
				oItem.Height = 19;

				oItem = oForm.Items.Add("sbtn", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
				oItem.Left = 80;
				oItem.Width = 85;
				oItem.Top = 920;
				oItem.Height = 19;
				oForm.Freeze(false);
				oForm.Visible = true;

			}
			catch (Exception err)
			{
				Logger.Log(err);
			}

		}
		private async Task LoaddtAsync()
		{
			Task t = Task.Delay(500);
			await t;
			while (addressbld==null)
			{
				Task t1 = Task.Delay(500);
				await t1;
			}
			for (int ix = 0; ix < addressbld.Addresses.Count;ix++)
			{
				dt.Rows.Add();
				dt.SetValue("UDPRN",ix, addressbld.Addresses[ix].Raw.UDPRN);
				dt.SetValue("PostTown", ix, addressbld.Addresses[ix].Raw.PostTown);
				dt.SetValue("fare", ix, addressbld.Addresses[ix].Raw.Thoroughfare);
				dt.SetValue("build", ix, addressbld.Addresses[ix].Raw.BuildingNumber);
				dt.SetValue("addr", ix, String.Join(",",addressbld.Addresses[ix].Printable));
			}
			

		}
		private async Task GetDataAsync(string postcode)
		{
			string content = string.Empty;
			try
			{
				HttpClient client = new HttpClient();
				client.BaseAddress = new Uri("https://pafdev.groupe-atlantic.co.uk");
				client.DefaultRequestHeaders.Accept.Clear();

				client.DefaultRequestHeaders.Accept.Add(
					new MediaTypeWithQualityHeaderValue("application/json"));
				ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
				var textbytes = System.Text.Encoding.UTF8.GetBytes("GAUK_PAF:gPY9nr!B=#");
				string val = System.Convert.ToBase64String(textbytes);
				client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);

				HttpResponseMessage response = client.GetAsync("/v2/addresses/by-postcode/" + postcode).Result;


				using (StreamReader stream = new StreamReader(response.Content.ReadAsStreamAsync().Result, Encoding.UTF8))
				{
					content = await stream.ReadToEndAsync();
					addressbld = JsonConvert.DeserializeObject<AddressCont>(content);
				}

			}
			catch (TaskCanceledException ex)
			{
				Logger.Log(ex);
			}
			catch (Exception er)
			{
				Logger.Log(er);
			}
			
		}


		public void EventAll(ItemEvent pVal)
		{
			throw new NotImplementedException();
		}

		public void Menu(ref MenuEvent pVal)
		{
			throw new NotImplementedException();
		}
	}
}
