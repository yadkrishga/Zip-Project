﻿
'' <summary>
'' SAP has set of different events For access the controls.
'' In this module particularly using to control events.
'' 1) Menu Event using for while the User choose the menus to select the patricular form 
'' 2) Item Event using for to pass the event Function while user doing process
'' 3) Form Data Event Using to Insert,Update,Delete data on Date Base 
'' 4) Status Bar Event will be call when display message to user, message may be will come 
''    Warring or Error
'' </summary>
'' <remarks></remarks>

Module EventHandler

#Region " ... Common Variables For SAP ..."
    Public WithEvents oApplication As SAPbouiCOM.Application
#End Region

#Region " ... 1) Menu Event ..."
    Private Sub oApplication_MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean) Handles oApplication.MenuEvent
        Try
            If pVal.BeforeAction Then
                '  oForm = oApplication.Forms.ActiveForm
                'Select Case pVal.MenuUID
                '    Case "1284"

                'End Select
            End If

            If pVal.BeforeAction = False Then
                Select Case pVal.MenuUID
                    Case ItemCreationFormID
                        If oGfun.FormExist(ItemCreationFormID) Then
                            oApplication.Forms.Item(ItemCreationFormID).Visible = True
                            oApplication.Forms.Item(ItemCreationFormID).Select()
                        Else
                            oItemCreation.LoadItemCreation()
                        End If
                    Case ColorSizeMasterFormID
                        If oGfun.FormExist(ColorSizeMasterFormID) Then
                            oApplication.Forms.Item(ColorSizeMasterFormID).Visible = True
                            oApplication.Forms.Item(ColorSizeMasterFormID).Select()
                        Else
                            oColorSizeMaster.LoadColorSizeMaster()
                        End If
                    Case LandedCostsFormID
                        If oGfun.FormExist(LandedCostsFormID) Then
                            oApplication.Forms.Item(LandedCostsFormID).Visible = True
                            oApplication.Forms.Item(LandedCostsFormID).Select()
                        Else
                            oLandedCosts.LoadLandedCosts()
                        End If

                    Case HSMasterFormID
                        If oGfun.FormExist(HSMasterFormID) Then
                            oApplication.Forms.Item(HSMasterFormID).Visible = True
                            oApplication.Forms.Item(HSMasterFormID).Select()
                        Else
                            oHSMaster.LoadHSMaster()
                        End If
                    Case SaleOrderNewFormID
                        If oGfun.FormExist(SaleOrderNewFormID) Then
                            oApplication.Forms.Item(SaleOrderNewFormID).Visible = True
                            oApplication.Forms.Item(SaleOrderNewFormID).Select()
                        Else
                            oSaleOrderNew.LoadSaleOrder()
                        End If

                    Case SalesInvoiceFormID
                        If oGfun.FormExist(SalesInvoiceFormID) Then
                            oApplication.Forms.Item(SalesInvoiceFormID).Visible = True
                            oApplication.Forms.Item(SalesInvoiceFormID).Select()
                        Else
                            oSalesInvoice.LoadSalesInvoice()
                        End If

                    Case InvoiceApprovalInterfaceFormID
                        If oGfun.FormExist(InvoiceApprovalInterfaceFormID) Then
                            oApplication.Forms.Item(InvoiceApprovalInterfaceFormID).Visible = True
                            oApplication.Forms.Item(InvoiceApprovalInterfaceFormID).Select()
                        Else
                            oInvoiceApprovalInterface.LoadInvoiceApprovalInterface()
                        End If

                    Case ApprovalInterfaceFormID
                        If oGfun.FormExist(ApprovalInterfaceFormID) Then
                            oApplication.Forms.Item(ApprovalInterfaceFormID).Visible = True
                            oApplication.Forms.Item(ApprovalInterfaceFormID).Select()
                        Else
                            oApprovalInterface.LoadApprovalInterface()
                        End If
                    Case ImportFormID
                        If oGfun.FormExist(ImportFormID) Then
                            oApplication.Forms.Item(ImportFormID).Visible = True
                            oApplication.Forms.Item(ImportFormID).Select()
                        Else
                            ImportCreation.ImportExcelLoad()
                        End If
                End Select
                oForm = oApplication.Forms.ActiveForm
                Select Case pVal.MenuUID
                    Case "1282", "1281", "1292", "1293", "1287", "519", "1284", "1286"
                        Select Case oForm.TypeEx

                        End Select
                End Select
                Select Case pVal.MenuUID
                    Case "1282", "1281", "1292", "1293", "1287", "519", "1284", "1286", "1290", "1288", "1289", "1291"
                        Select Case oForm.UniqueID
                            Case ItemCreationFormID
                                oItemCreation.MenuEvent(pVal, BubbleEvent)
                            Case ColorSizeMasterFormID
                                oColorSizeMaster.MenuEvent(pVal, BubbleEvent)
                            Case HSMasterFormID
                                oHSMaster.MenuEvent(pVal, BubbleEvent)
                            Case SaleOrderNewFormID
                                oSaleOrderNew.MenuEvent(pVal, BubbleEvent)
                            Case LandedCostsFormID
                                oLandedCosts.MenuEvent(pVal, BubbleEvent)
                            Case SalesInvoiceFormID
                                oSalesInvoice.MenuEvent(pVal, BubbleEvent)

                            Case InvoiceApprovalInterfaceFormID
                                oInvoiceApprovalInterface.MenuEvent(pVal, BubbleEvent)
                            Case ApprovalInterfaceFormID
                                oApprovalInterface.MenuEvent(pVal, BubbleEvent)

                        End Select
                End Select

                If pVal.MenuUID = "526" Then
                    oCompany.Disconnect()
                    oApplication.StatusBar.SetText(AddOnName & " AddOn is DisConnected . . .", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                    End
                End If
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Creation Menu Event Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
#End Region

    Private Sub oApplication_AppEvent(ByVal EventType As SAPbouiCOM.BoAppEventTypes) Handles oApplication.AppEvent
        Try
            Select Case EventType
                Case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged, SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged, SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition, SAPbouiCOM.BoAppEventTypes.aet_ShutDown
                    System.Windows.Forms.Application.Exit()
            End Select

        Catch ex As Exception
            oApplication.StatusBar.SetText("Application Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try


    End Sub

#Region " ... 2) Item Event ..."
    Private Sub oApplication_ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean) Handles oApplication.ItemEvent
        Try

            Select Case pVal.FormUID
                'SalesOrder

                Case ItemCreationFormID
                    oItemCreation.ItemEvent(ItemCreationFormID, pVal, BubbleEvent)
                Case ColorSizeMasterFormID
                    oColorSizeMaster.ItemEvent(ColorSizeMasterFormID, pVal, BubbleEvent)
                Case HSMasterFormID
                    oHSMaster.ItemEvent(HSMasterFormID, pVal, BubbleEvent)
                Case "SOItemList"
                    oSalesOrder.ItemEvent_ItemList(FormUID, pVal, BubbleEvent)
                Case "SODetails"
                    oSalesOrder.ItemEvent_SODetails(FormUID, pVal, BubbleEvent)
                Case SaleOrderNewFormID
                    oSaleOrderNew.ItemEvent(SaleOrderNewFormID, pVal, BubbleEvent)
                Case "ORDRItemList"
                    oSaleOrderNew.ItemEvent_ItemList(FormUID, pVal, BubbleEvent)
                Case LandedCostsFormID
                    oLandedCosts.ItemEvent(pVal.FormUID, pVal, BubbleEvent)
                Case "CopyFromAP"
                    oLandedCosts.ItemEvent_Copyfrom_ItemList(FormUID, pVal, BubbleEvent)

                Case ImportFormID
                    ImportCreation.ItemEvent(SaleOrderNewFormID, pVal, BubbleEvent)
                Case SalesInvoiceFormID
                    oSalesInvoice.ItemEvent(SaleOrderNewFormID, pVal, BubbleEvent)
                Case FrieghtChargesSubFormID
                    oSaleOrderNew.ItemEvent_FreightChargesSubGrid(pVal.FormUID, pVal, BubbleEvent)

                Case InvoiceApprovalInterfaceFormID
                    oInvoiceApprovalInterface.ItemEvent(InvoiceApprovalInterfaceFormID, pVal, BubbleEvent)
                Case ApprovalInterfaceFormID
                    oApprovalInterface.ItemEvent(ApprovalInterfaceFormID, pVal, BubbleEvent)

                Case "OINVCreated"
                    oSalesInvoice.ItemEvent_SOCeated(FormUID, pVal, BubbleEvent)
                Case "OINVDetails"
                    oSalesInvoice.ItemEvent_SODetails(FormUID, pVal, BubbleEvent)
                Case "ORDRSODetails"
                    oSaleOrderNew.ItemEvent_SODetails(FormUID, pVal, BubbleEvent)
            End Select

            Select Case pVal.FormTypeEx

                Case SalesOrderTypeEx
                    oSalesOrder.ItemEvent(pVal.FormUID, pVal, BubbleEvent)
                Case BPMasterTypeEx
                    oBPMaster.ItemEvent(pVal.FormUID, pVal, BubbleEvent)
                Case ItemMasterTypeEx
                    oItemMaster.ItemEvent(pVal.FormUID, pVal, BubbleEvent)
                Case AccountMasterTypeEx
                    oAccountMaster.ItemEvent(pVal.FormUID, pVal, BubbleEvent)
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("ItemEvent Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
#End Region

#Region " ... 3) FormDataEvent ..."
    Private Sub oApplication_FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean) Handles oApplication.FormDataEvent
        Try
            Select Case BusinessObjectInfo.FormTypeEx
                Case SalesOrderTypeEx
                    oSalesOrder.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case BPMasterTypeEx
                    oBPMaster.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case ItemMasterTypeEx
                    oItemMaster.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case AccountMasterTypeEx
                    oAccountMaster.FormDataEvent(BusinessObjectInfo, BubbleEvent)
            End Select

            Select Case BusinessObjectInfo.FormUID

                Case ItemCreationFormID
                    oItemCreation.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case ColorSizeMasterFormID
                    oColorSizeMaster.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case HSMasterFormID
                    oHSMaster.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case SaleOrderNewFormID
                    oSaleOrderNew.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case LandedCostsFormID
                    oLandedCosts.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case SalesInvoiceFormID
                    oSalesInvoice.FormDataEvent(BusinessObjectInfo, BubbleEvent)

                Case InvoiceApprovalInterfaceFormID
                    oInvoiceApprovalInterface.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                Case ApprovalInterfaceFormID
                    oApprovalInterface.FormDataEvent(BusinessObjectInfo, BubbleEvent)

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("student FormDataEvent Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
#End Region

#Region " ... 4) Status Bar Event ..."
    Public Sub oApplication_StatusBarEvent(ByVal Text As String, ByVal MessageType As SAPbouiCOM.BoStatusBarMessageType) Handles oApplication.StatusBarEvent
        Try
            If MessageType = SAPbouiCOM.BoStatusBarMessageType.smt_Warning Or MessageType = SAPbouiCOM.BoStatusBarMessageType.smt_Error Then
                System.Media.SystemSounds.Asterisk.Play()
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText(AddOnName & " StatusBarEvent Event Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
#End Region

#Region " ... 5) Set Event Filter ..."
    Public Sub SetEventFilter()
        Try
        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        Finally
        End Try
    End Sub
#End Region

#Region " ... 6) Right Click Event ..."
    Private Sub oApplication_RightClickEvent(ByRef eventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean) Handles oApplication.RightClickEvent
        Try
            'Delete the User Creation Menus from Main Menu ..
            'If oApplication.Menus.Item("1280").SubMenus.Exists("SizeBreakUp") = True Then oApplication.Menus.Item("1280").SubMenus.RemoveEx("SizeBreakUp")
            Select Case eventInfo.FormUID

                Case ItemCreationFormID
                    oItemCreation.RightClickEvent(eventInfo, BubbleEvent)
                Case HSMasterFormID
                    oHSMaster.RightClickEvent(eventInfo, BubbleEvent)
                Case SaleOrderNewFormID
                    oSaleOrderNew.RightClickEvent(eventInfo, BubbleEvent)
                Case LandedCostsFormID
                    oLandedCosts.RightClickEvent(eventInfo, BubbleEvent)
                Case SalesInvoiceFormID
                    oSalesInvoice.RightClickEvent(eventInfo, BubbleEvent)

                Case InvoiceApprovalInterfaceFormID
                    oInvoiceApprovalInterface.RightClickEvent(eventInfo, BubbleEvent)
                Case ApprovalInterfaceFormID
                    oApprovalInterface.RightClickEvent(eventInfo, BubbleEvent)

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText(AddOnName & " : Right Click Event Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
#End Region


End Module