Public Class LandedCosts

    Dim frmLandedCosts As SAPbouiCOM.Form
    Dim oMatrix1 As SAPbouiCOM.Matrix
    Dim oMatrix2 As SAPbouiCOM.Matrix

    Dim oDBDSHeader, oDBDSDetail1, oDBDSDetail2 As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "OIPF"
    Dim sDelRowMatrix As String = ""
    Dim row As Integer
    Dim boolFilterItem As Boolean = False
    Dim SubGridCurRow As Integer
  
    Dim GDays As Integer
    Public dtTemp As SAPbouiCOM.DataTable
    Dim TableCount As Integer = 0

    Sub LoadLandedCosts()
        Try
            oGfun.LoadXML(frmLandedCosts, LandedCostsFormID, LandedCostsXML)
            frmLandedCosts = oApplication.Forms.Item(LandedCostsFormID)
            oDBDSHeader = frmLandedCosts.DataSources.DBDataSources.Item("@INS_OIPF")
            oDBDSDetail1 = frmLandedCosts.DataSources.DBDataSources.Item("@INS_IPF1")
            oDBDSDetail2 = frmLandedCosts.DataSources.DBDataSources.Item("@INS_IPF2")


            oMatrix1 = frmLandedCosts.Items.Item("Matrix1").Specific
            oMatrix2 = frmLandedCosts.Items.Item("Matrix2").Specific
        

            oMatrix1.Columns.Item("Total").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
            oMatrix2.Columns.Item("CostSum").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto

            'oMatrix1.Columns.Item("ProjCust").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
            'oMatrix1.Columns.Item("CusValue").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
            'oMatrix1.Columns.Item("CosValue").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
            'oMatrix1.Columns.Item("Total").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto

            Me.DefineModesForFields()
            Me.InitForm()
        Catch ex As Exception
            oGfun.StatusBarWarningMsg("Load LandedCosts Form Failed")
        Finally
        End Try
    End Sub

    Sub DefineModesForFields()
        Try
            frmLandedCosts.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmLandedCosts.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmLandedCosts.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmLandedCosts.Items.Item("t_Docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmLandedCosts.Items.Item("t_Docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try
            frmLandedCosts.Freeze(True)
            oGfun.LoadComboBoxSeries(frmLandedCosts.Items.Item("c_series").Specific, UDOID, oDBDSHeader.GetValue("U_DocDate", 0), oCompany.UserSignature)
            oGfun.LoadDocumentDate(frmLandedCosts.Items.Item("t_Docdate").Specific)
            oGfun.LoadDocumentDate(frmLandedCosts.Items.Item("t_Duedate").Specific)
            oGfun.LoadDocumentDate(frmLandedCosts.Items.Item("t_CustDate").Specific)
            oGfun.setComboBoxValue(frmLandedCosts.Items.Item("Curency").Specific, "Select ""CurrCode"",""CurrName""  From OCRN ")

            oGfun.SetNewLine(oMatrix1, oDBDSDetail1)
            oGfun.SetNewLine(oMatrix2, oDBDSDetail2)

            oMatrix1.CommonSetting.EnableArrowKey = True
            oMatrix2.CommonSetting.EnableArrowKey = True

            frmLandedCosts.PaneLevel = 1
            Dim Str As String = " Select ""AlcName"", ""OhType"",""AlcCode"", ""LaCAllcAcc"" from OALC"
            Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
            If rset.RecordCount > 0 Then
                oMatrix2.Clear()
                oDBDSDetail2.Clear()
                rset.MoveFirst()
                For i As Integer = 1 To rset.RecordCount
                    oDBDSDetail2.InsertRecord(oDBDSDetail2.Size)
                    oDBDSDetail2.Offset = oDBDSDetail2.Size - 1
                    oDBDSDetail2.SetValue("LineID", oDBDSDetail2.Offset, oDBDSDetail2.Size)
                    oDBDSDetail2.SetValue("U_AlcName", oDBDSDetail2.Offset, rset.Fields.Item("AlcName").Value)
                    oDBDSDetail2.SetValue("U_Ohtype", oDBDSDetail2.Offset, rset.Fields.Item("OhType").Value)
                    oDBDSDetail2.SetValue("U_AlcCode", oDBDSDetail2.Offset, rset.Fields.Item("AlcCode").Value)
                    oDBDSDetail2.SetValue("U_LandAcc", oDBDSDetail2.Offset, rset.Fields.Item("LaCAllcAcc").Value)
                    rset.MoveNext()
                Next
                oMatrix2.LoadFromDataSource()
            End If
            oMatrix1.AutoResizeColumns()
            oMatrix2.AutoResizeColumns()

            frmLandedCosts.ActiveItem = "t_apinv1"

            Me.AddChooseFromList_Item(LandedCostsFormID, "AP_CFL1")
            Me.AddChooseFromList_Item(LandedCostsFormID, "AP_CFL")

            frmLandedCosts.Freeze(False)
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            frmLandedCosts.Freeze(False)
        Finally
        End Try
    End Sub
    Function ValidateAll() As Boolean
        Try
            Return True

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            ValidateAll = False
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False Then
                            Select Case pVal.ItemUID
                                Case "t_CardCode"
                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_Curency", 0, oDataTable.GetValue("Currency", 0))
                                Case "t_CardCod1"
                                    oDBDSHeader.SetValue("U_CardCod1", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardNam1", 0, oDataTable.GetValue("CardName", 0))

                                Case "t_apcrdt1"
                                    oDBDSHeader.SetValue("U_APCrtDocNo", 0, oDataTable.GetValue("DocNum", 0))
                                    oDBDSHeader.SetValue("U_APCrdtDoc", 0, oDataTable.GetValue("DocEntry", 0))
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_Curency", 0, oDataTable.GetValue("DocCur", 0))
                                    oDBDSHeader.SetValue("U_APDocNum", 0, "")
                                    oDBDSHeader.SetValue("U_APDocEntry", 0, "")

                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    Dim sQuery As String = "Select a.""ItemCode"",b.""WhsCode"",a.""INMPrice"",a.""StockSum"",a.""StockSumSc"",a.""Quantity"",a.""LineNum"",a.""UomCode"",a.""OcrCode"" from pch1 a inner join oitw b on a.""ItemCode""=b.""ItemCode"" and b.""WhsCode""=a.""WhsCode"""
                                    sQuery += " where ""DocEntry"" ='" & oDataTable.GetValue("DocEntry", 0) & "' "
                                    Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    rset.MoveFirst()
                                    If rset.RecordCount > 0 Then
                                        For j As Integer = 1 To rset.RecordCount
                                            oApplication.StatusBar.SetText("Please Wait System checking & Loading Data " & j & " Out Of " & rset.RecordCount & "......", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                                            oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                                            oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                                            oDBDSDetail1.SetValue("U_ItemCode", oDBDSDetail1.Offset, rset.Fields.Item("ItemCode").Value)
                                            oDBDSDetail1.SetValue("U_Quantity", oDBDSDetail1.Offset, rset.Fields.Item("Quantity").Value)
                                            oDBDSDetail1.SetValue("U_Docprice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_DocValue", oDBDSDetail1.Offset, rset.Fields.Item("StockSum").Value)
                                            oDBDSDetail1.SetValue("U_WhsPrice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_Total", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_BaseEntry", oDBDSDetail1.Offset, oDataTable.GetValue("DocEntry", 0))
                                            oDBDSDetail1.SetValue("U_BaseNum", oDBDSDetail1.Offset, oDataTable.GetValue("DocNum", 0))
                                            oDBDSDetail1.SetValue("U_BaseLine", oDBDSDetail1.Offset, rset.Fields.Item("LineNum").Value)
                                            oDBDSDetail1.SetValue("U_FobnLac", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_Warehous", oDBDSDetail1.Offset, rset.Fields.Item("WhsCode").Value)
                                            oDBDSDetail1.SetValue("U_DistrRule", oDBDSDetail1.Offset, rset.Fields.Item("OcrCode").Value)
                                            oDBDSDetail1.SetValue("U_UoMCode", oDBDSDetail1.Offset, rset.Fields.Item("UomCode").Value)
                                            rset.MoveNext()
                                        Next
                                    End If
                                    oMatrix1.LoadFromDataSource()
                                    oApplication.StatusBar.SetText("Operation completed....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                Case "t_apinv1"
                                    oDBDSHeader.SetValue("U_APDocNum", 0, oDataTable.GetValue("DocNum", 0))
                                    oDBDSHeader.SetValue("U_APDocEntry", 0, oDataTable.GetValue("DocEntry", 0))
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_Curency", 0, oDataTable.GetValue("DocCur", 0))
                                    oDBDSHeader.SetValue("U_APCrtDocNo", 0, "")
                                    oDBDSHeader.SetValue("U_APCrdtDoc", 0, "")

                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    Dim sQuery As String = "Select a.""ItemCode"",b.""WhsCode"",a.""INMPrice"",a.""StockSum"",a.""StockSumSc"",a.""Quantity"",a.""LineNum"",a.""UomCode"",a.""OcrCode"" from pch1 a inner join oitw b on a.""ItemCode""=b.""ItemCode"" and b.""WhsCode""=a.""WhsCode"""
                                    sQuery += " where ""DocEntry"" ='" & oDataTable.GetValue("DocEntry", 0) & "' "
                                    Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    rset.MoveFirst()
                                    If rset.RecordCount > 0 Then
                                        For j As Integer = 1 To rset.RecordCount
                                            oApplication.StatusBar.SetText("Please Wait System checking & Loading Data " & j & " Out Of " & rset.RecordCount & "......", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                                            oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                                            oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                                            oDBDSDetail1.SetValue("U_ItemCode", oDBDSDetail1.Offset, rset.Fields.Item("ItemCode").Value)
                                            oDBDSDetail1.SetValue("U_Quantity", oDBDSDetail1.Offset, rset.Fields.Item("Quantity").Value)
                                            oDBDSDetail1.SetValue("U_Docprice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_DocValue", oDBDSDetail1.Offset, rset.Fields.Item("StockSum").Value)
                                            oDBDSDetail1.SetValue("U_WhsPrice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_Total", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_BaseEntry", oDBDSDetail1.Offset, oDataTable.GetValue("DocEntry", 0))
                                            oDBDSDetail1.SetValue("U_BaseNum", oDBDSDetail1.Offset, oDataTable.GetValue("DocNum", 0))
                                            oDBDSDetail1.SetValue("U_BaseLine", oDBDSDetail1.Offset, rset.Fields.Item("LineNum").Value)
                                            oDBDSDetail1.SetValue("U_FobnLac", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_Warehous", oDBDSDetail1.Offset, rset.Fields.Item("WhsCode").Value)
                                            oDBDSDetail1.SetValue("U_DistrRule", oDBDSDetail1.Offset, rset.Fields.Item("OcrCode").Value)
                                            oDBDSDetail1.SetValue("U_UoMCode", oDBDSDetail1.Offset, rset.Fields.Item("UomCode").Value)
                                            rset.MoveNext()
                                        Next
                                    End If
                                    oMatrix1.LoadFromDataSource()
                                    oApplication.StatusBar.SetText("Operation completed....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                Case "Matrix1"
                                    Select Case pVal.ColUID
                                        Case "Project"
                                            oMatrix1.FlushToDataSource()
                                            oDBDSDetail1.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue("PrjCode", 0))
                                            'oDBDSDetail1.SetValue("U_Sizename", pVal.Row - 1, oDataTable.GetValue("U_Clrname", 0))
                                            oMatrix1.LoadFromDataSource()
                                            oMatrix1.AutoResizeColumns()
                                            oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End Select
                                    Select Case pVal.ColUID
                                        Case "DistrRule"
                                            oMatrix1.FlushToDataSource()
                                            oDBDSDetail1.SetValue("U_DistrRule", pVal.Row - 1, oDataTable.GetValue("OcrCode", 0))
                                            'oDBDSDetail1.SetValue("U_Sizename", pVal.Row - 1, oDataTable.GetValue("U_Clrname", 0))
                                            oMatrix1.LoadFromDataSource()
                                            oMatrix1.AutoResizeColumns()
                                            oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End Select
                            End Select
                        End If
                    Catch ex As Exception
                        frmLandedCosts.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            Case "Matrix1"
                                Select Case pVal.ColUID
                                    Case "ItemCode"
                                        If pVal.BeforeAction = False Then
                                            oGfun.SetNewLine(oMatrix1, oDBDSDetail1, pVal.Row, pVal.ColUID)
                                        End If
                                End Select
                            Case "Matrix2"
                                Select Case pVal.ColUID
                                    Case "AlcName"
                                        If pVal.BeforeAction = False Then
                                            oGfun.SetNewLine(oMatrix2, oDBDSDetail2, pVal.Row, pVal.ColUID)
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        frmLandedCosts.Freeze(False)
                        oApplication.StatusBar.SetText("Lost focus event fail", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "t_Vat1", "t_Vat2"
                                If pVal.BeforeAction = False Then
                                    Dim Vat2 As Double = 0.0
                                    Dim Vat1 As Double = 0.0
                                    Vat2 = CDbl(frmLandedCosts.Items.Item("t_Vat2").Specific.value)
                                    Vat1 = CDbl(frmLandedCosts.Items.Item("t_Vat1").Specific.value)
                                    Dim Sum1 As Double = 0.0
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        Dim a As Double = CDbl(oMatrix1.Columns.Item("Total").Cells.Item(i).Specific.value)
                                        Sum1 += a
                                    Next

                                    oDBDSHeader.SetValue("U_BeforeVat", 0, (Sum1))
                                    oDBDSHeader.SetValue("U_DocTotal", 0, (Sum1 + Vat1 + Vat2))
                                End If
                            Case "Matrix1"
                                Select Case pVal.ColUID
                                    Case "ProjCust", "Expendi"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmLandedCosts.Freeze(True)
                                            oMatrix1.FlushToDataSource()
                                            Dim ProjCust As Double = 0.0
                                            'Dim CusValue As Double = 0.0
                                            Dim Expendi As Double = 0.0
                                            ' Dim CosValue As Double = 0.0
                                            Dim WhsPrice As Double = 0.0
                                            Dim TotaCost As Double = 0.0
                                            Dim Quantity As Double = 0.0
                                            Dim DocValue As Double = 0.0

                                            DocValue = CDbl(oMatrix1.Columns.Item("DocValue").Cells.Item(pVal.Row).Specific.value)
                                            ProjCust = CDbl(oMatrix1.Columns.Item("ProjCust").Cells.Item(pVal.Row).Specific.value)
                                            Quantity = CDbl(oMatrix1.Columns.Item("Quantity").Cells.Item(pVal.Row).Specific.value)
                                            ' CusValue = CDbl(oMatrix1.Columns.Item("CusValue").Cells.Item(pVal.Row).Specific.value)
                                            Expendi = CDbl(oMatrix1.Columns.Item("Expendi").Cells.Item(pVal.Row).Specific.value)
                                            'CosValue = CDbl(oMatrix1.Columns.Item("CosValue").Cells.Item(pVal.Row).Specific.value)

                                            oDBDSDetail1.SetValue("U_CusValue", pVal.Row - 1, (Quantity * ProjCust))
                                            'oDBDSDetail1.SetValue("U_ProjCust", pVal.Row - 1, (CusValue / Quantity))
                                            oDBDSDetail1.SetValue("U_CosValue", pVal.Row - 1, (Quantity * Expendi))
                                            'oDBDSDetail1.SetValue("U_Expendi", pVal.Row - 1, (CosValue / Quantity))

                                            oDBDSDetail1.SetValue("U_WhsPrice", pVal.Row - 1, (DocValue + ((Quantity * ProjCust) + (Quantity * Expendi))))
                                            oDBDSDetail1.SetValue("U_Total", pVal.Row - 1, (DocValue + ((Quantity * ProjCust) + (Quantity * Expendi))))
                                            oDBDSDetail1.SetValue("U_TotaCost", pVal.Row - 1, ((Quantity * ProjCust) + (Quantity * Expendi)))
                                            oMatrix1.LoadFromDataSource()
                                            oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            frmLandedCosts.Freeze(False)
                                            Dim total As Double = 0.0
                                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                                Dim a As Double = CDbl(oMatrix1.Columns.Item("CosValue").Cells.Item(i).Specific.value)
                                                total += a
                                            Next

                                            oDBDSHeader.SetValue("U_CostSum", 0, (total))
                                            oDBDSHeader.SetValue("U_AmtBal", 0, (-total))
                                            Dim sum As Double = 0.0
                                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                                Dim a As Double = CDbl(oMatrix1.Columns.Item("CusValue").Cells.Item(i).Specific.value)
                                                sum += a
                                            Next

                                            oDBDSHeader.SetValue("U_ExpCustom", 0, (sum))
                                            oDBDSHeader.SetValue("U_ActCustom", 0, (sum))
                                            Dim Vat2 As Double = 0.0
                                            Dim Vat1 As Double = 0.0
                                            Vat2 = CDbl(frmLandedCosts.Items.Item("t_Vat2").Specific.value)
                                            Vat1 = CDbl(frmLandedCosts.Items.Item("t_Vat1").Specific.value)
                                            Dim Sum1 As Double = 0.0
                                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                                Dim a As Double = CDbl(oMatrix1.Columns.Item("Total").Cells.Item(i).Specific.value)
                                                Sum1 += a
                                            Next

                                            oDBDSHeader.SetValue("U_BeforeVat", 0, (Sum1))
                                            oDBDSHeader.SetValue("U_DocTotal", 0, (Sum1 + Vat1 + Vat2))
                                            'oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        frmLandedCosts.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            Case "t_apinv1"
                                If pVal.BeforeAction = False Then
                                    Me.AddChooseFromList_Item(LandedCostsFormID, "AP_CFL1")
                                    'sQuery = String.Empty
                                    'sQuery = "SELECT ""DocNum"" FROM OPCH WHERE ""DocType""='I' ORDER BY ""DocNum"""
                                    'oGfun.ChooseFromListFilteration(frmLandedCosts, "AP_CFL", "DocNum", sQuery)
                                End If
                            Case "t_apcrdt1"
                                If pVal.BeforeAction = False Then
                                    Me.AddChooseFromList_Item(LandedCostsFormID, "AP_CFL")
                                    'sQuery = String.Empty
                                    'sQuery = "SELECT ""DocNum"" FROM ORPC WHERE ""DocType""='I' ORDER BY ""DocNum"""
                                    'oGfun.ChooseFromListFilteration(frmLandedCosts, "AP_CFL1", "DocNum", sQuery)
                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try

                    'Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                    '    Try
                    '        Select Case pVal.ItemUID
                    '            Case "t_apinv1"
                    '                If pVal.BeforeAction = False Then
                    '                    sQuery = String.Empty
                    '                    sQuery = "SELECT ""DocNum"" FROM OPCH WHERE ""CardCode""='" & frmLandedCosts.Items.Item("t_CardCode").Specific.value & "' "
                    '                    oGfun.ChooseFromListFilteration(frmLandedCosts, "AP_CFL", "DocNum", sQuery)
                    '                End If
                    '        End Select
                    '    Catch ex As Exception
                    '        oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    '    Finally
                    '    End Try
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmLandedCosts.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmLandedCosts.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub
                                    End If
                                End If



                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Click Event Failed:" & ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK
                    Try
                        Select Case pVal.ItemUID
                            
                        End Select
                        Select Case pVal.ItemUID
                            Case "Matrix1"
                                If pVal.BeforeAction = False Then oGfun.OpenAttachment(oMatrix1, oDBDSDetail1, pVal.Row)
                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Item Double Click Event Failed : " & ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "c_series"
                                If frmLandedCosts.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    'Get the Serial Number Based On Series...
                                    Dim oCmbSerial As SAPbouiCOM.ComboBox = frmLandedCosts.Items.Item("c_series").Specific
                                    Dim strSerialCode As String = oCmbSerial.Selected.Value
                                    Dim strDocNum As Long = frmLandedCosts.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                                    oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                                End If
                            Case "t_type"
                                If frmLandedCosts.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    Dim oCmbType As SAPbouiCOM.ComboBox = frmLandedCosts.Items.Item("t_type").Specific
                                    Dim stroCmbType As String = oCmbType.Selected.Value
                                    If stroCmbType = "1" Then
                                        frmLandedCosts.Items.Item("t_apcrdt1").Enabled = False
                                        frmLandedCosts.Items.Item("t_apinv1").Enabled = True
                                        oDBDSHeader.SetValue("U_APDocEntry", 0, "")
                                        oDBDSHeader.SetValue("U_APDocNum", 0, "")
                                        oDBDSHeader.SetValue("U_APCrdtDoc", 0, "")
                                        oDBDSHeader.SetValue("U_APCrtDocNo", 0, "")
                                        oDBDSHeader.SetValue("U_CardCode", 0, "")
                                        oDBDSHeader.SetValue("U_CardName", 0, "")
                                        oDBDSHeader.SetValue("U_CardCod1", 0, "")
                                        oDBDSHeader.SetValue("U_CardNam1", 0, "")
                                        oDBDSHeader.SetValue("U_Curency", 0, "")

                                        oMatrix1.Clear()
                                        oDBDSDetail1.Clear()
                                    Else
                                        frmLandedCosts.Items.Item("t_apinv1").Enabled = False
                                        frmLandedCosts.Items.Item("t_apcrdt1").Enabled = True
                                        oDBDSHeader.SetValue("U_APDocEntry", 0, "")
                                        oDBDSHeader.SetValue("U_APDocNum", 0, "")
                                        oDBDSHeader.SetValue("U_APCrdtDoc", 0, "")
                                        oDBDSHeader.SetValue("U_APCrtDocNo", 0, "")
                                        oDBDSHeader.SetValue("U_CardCode", 0, "")
                                        oDBDSHeader.SetValue("U_CardName", 0, "")
                                        oDBDSHeader.SetValue("U_CardCod1", 0, "")
                                        oDBDSHeader.SetValue("U_CardNam1", 0, "")
                                        oDBDSHeader.SetValue("U_Curency", 0, "")

                                        oMatrix1.Clear()
                                        oDBDSDetail1.Clear()
                                    End If
                                End If
                        End Select
                    Catch ex As Exception
                        frmLandedCosts.Freeze(False)
                        oGfun.StatusBarErrorMsg("Combobox Event Failed")
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.ActionSuccess And frmLandedCosts.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If
                            Case "F_Item"
                                If pVal.ActionSuccess Then
                                    frmLandedCosts.Freeze(True)
                                    frmLandedCosts.PaneLevel = 1
                                    frmLandedCosts.Settings.MatrixUID = "Matrix1"
                                    oMatrix1.AutoResizeColumns()
                                    frmLandedCosts.Freeze(False)
                                End If

                            Case "F_Costs"
                                If pVal.ActionSuccess Then
                                    frmLandedCosts.Freeze(True)
                                    frmLandedCosts.PaneLevel = 2
                                    frmLandedCosts.Settings.MatrixUID = "Matrix2"
                                    oMatrix1.AutoResizeColumns()
                                    frmLandedCosts.Freeze(False)
                                End If
                            Case "b_Copy"
                                If pVal.Before_Action = False Then
                                    Me.CreateMySimpleForm()
                                End If
                            Case "b_Refresh"
                                If pVal.Before_Action = False Then
                                    Dim Str As String = " Select ""AlcName"", ""OhType"",""AlcCode"", ""LaCAllcAcc"" from OALC"
                                    Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                                    If rset.RecordCount > 0 Then
                                        oMatrix2.Clear()
                                        oDBDSDetail2.Clear()
                                        rset.MoveFirst()
                                        For i As Integer = 1 To rset.RecordCount
                                            oDBDSDetail2.InsertRecord(oDBDSDetail2.Size)
                                            oDBDSDetail2.Offset = oDBDSDetail2.Size - 1
                                            oDBDSDetail2.SetValue("LineID", oDBDSDetail2.Offset, oDBDSDetail2.Size)
                                            oDBDSDetail2.SetValue("U_AlcName", oDBDSDetail2.Offset, rset.Fields.Item("AlcName").Value)
                                            oDBDSDetail2.SetValue("U_Ohtype", oDBDSDetail2.Offset, rset.Fields.Item("OhType").Value)
                                            oDBDSDetail2.SetValue("U_AlcCode", oDBDSDetail2.Offset, rset.Fields.Item("AlcCode").Value)
                                            oDBDSDetail2.SetValue("U_LandAcc", oDBDSDetail2.Offset, rset.Fields.Item("LaCAllcAcc").Value)

                                            rset.MoveNext()
                                        Next
                                        oMatrix2.LoadFromDataSource()
                                    End If
                                End If
                        End Select
                    Catch ex As Exception
                        frmLandedCosts.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
            End Select

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1281"
                    frmLandedCosts.ActiveItem = ("t_docnum")
                Case "1293"
                    Select Case sDelRowMatrix
                        Case "Matrix1"
                            oGfun.DeleteRow(oMatrix1, oDBDSDetail1)
                        Case "Matrix2"
                            oGfun.DeleteRow(oMatrix2, oDBDSDetail2)

                        

                    End Select

                Case "1282"
                    Me.InitForm()
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub CreateMySimpleForm()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oEditText As SAPbouiCOM.EditText
            Dim oCombobox As SAPbouiCOM.ComboBox
            Dim ocheckbox As SAPbouiCOM.CheckBox

            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "CopyFromAP"
            CP.FormType = "201"


            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 

            oForm.Height = 300
            oForm.Width = 800
            oForm.Title = "AP invoices"

            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 10
            oItem.Top = 30
            oItem.Width = 760
            oItem.Height = 210
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 240
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Ok"

            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 240
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
         

            sQuery = String.Empty
            sQuery = "Select '' ""Chk"", ""DocEntry"",""DocNum"",""CardName"",""DocDueDate"",""DocDate"" from opch where  ""DocType""='I' and ""CardName""='" & oDBDSHeader.GetValue("U_CardName", 0).Trim & "'"

            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()
            oGrid.Columns.Item(0).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
            oGrid.Columns.Item(1).Editable = False
            oGrid.Columns.Item(2).Editable = False
            oGrid.Columns.Item(3).Editable = False
            oGrid.Columns.Item(4).Editable = False
            oGrid.Columns.Item(5).Editable = False
            'oGrid.Columns.Item(6).Editable = False

            oGrid.AutoResizeColumns()

            oForm.Visible = True
        Catch ex As Exception
            oForm.Visible = True
            oApplication.StatusBar.SetText("AP invoice List Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try

    End Sub
    Sub ItemEvent_Copyfrom_ItemList(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific

                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        oApplication.StatusBar.SetText("Please Wait System checking & Loading Data " & i & " Out Of " & oGrid.Rows.Count & "......", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        If oGrid.DataTable.Columns.Item("Chk").Cells.Item(i - 1).Value.Equals("Y") Then
                                            Dim sQuery As String = "Select a.""ItemCode"",b.""WhsCode"",a.""INMPrice"",a.""StockSum"",a.""StockSumSc"",a.""Quantity"",a.""LineNum"",a.""UomCode"",a.""OcrCode"" from pch1 a inner join oitw b on a.""ItemCode""=b.""ItemCode"" and b.""WhsCode""=a.""WhsCode"""
                                            sQuery += " where ""DocEntry"" ='" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "' "

                                            Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            rset.MoveFirst()
                                            If rset.RecordCount > 0 Then
                                                For j As Integer = 1 To rset.RecordCount
                                                    oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                                                    oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                                                    oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                                                    oDBDSDetail1.SetValue("U_ItemCode", oDBDSDetail1.Offset, rset.Fields.Item("ItemCode").Value)
                                                    oDBDSDetail1.SetValue("U_Quantity", oDBDSDetail1.Offset, rset.Fields.Item("Quantity").Value)
                                                    oDBDSDetail1.SetValue("U_Docprice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                                    oDBDSDetail1.SetValue("U_DocValue", oDBDSDetail1.Offset, rset.Fields.Item("StockSum").Value)
                                                    oDBDSDetail1.SetValue("U_WhsPrice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                                    oDBDSDetail1.SetValue("U_Total", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                                    oDBDSDetail1.SetValue("U_BaseEntry", oDBDSDetail1.Offset, oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value)
                                                    oDBDSDetail1.SetValue("U_BaseNum", oDBDSDetail1.Offset, oGrid.DataTable.Columns.Item("DocNum").Cells.Item(i - 1).Value)
                                                    oDBDSDetail1.SetValue("U_BaseLine", oDBDSDetail1.Offset, rset.Fields.Item("LineNum").Value) 
                                                    oDBDSDetail1.SetValue("U_FobnLac", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                                    oDBDSDetail1.SetValue("U_Warehous", oDBDSDetail1.Offset, rset.Fields.Item("WhsCode").Value)
                                                    oDBDSDetail1.SetValue("U_DistrRule", oDBDSDetail1.Offset, rset.Fields.Item("OcrCode").Value)
                                                    oDBDSDetail1.SetValue("U_UoMCode", oDBDSDetail1.Offset, rset.Fields.Item("UomCode").Value)
                                                    'Dim Discount As Double = 0.0
                                                    'If rset.Fields.Item("DiscPrcnt").Value <> 0 Then
                                                    '    Discount = ((rset.Fields.Item("Quantity").Value * rset.Fields.Item("Price").Value) * rset.Fields.Item("DiscPrcnt").Value) / 100
                                                    'End If

                                                    ' oDBDSDetail1.SetValue("U_Discount1", oDBDSDetail1.Offset, Discount)
                                                    ' oDBDSDetail1.SetValue("U_WhsPrice", oDBDSDetail1.Offset, (rset.Fields.Item("Quantity").Value * rset.Fields.Item("Price").Value) - Discount)

                                                    rset.MoveNext()
                                                Next
                                            End If
                                            oMatrix1.LoadFromDataSource()


                                        End If
                                    Next
                                    oApplication.StatusBar.SetText("Operation completed....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oForm.Close()
                                    'If frmGoodsIssue.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmGoodsIssue.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                    'frmGoodsIssue.Freeze(False)
                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            Case "c_select"
                                If pVal.BeforeAction = False Then
                                    '        oForm.Freeze(True)
                                    '        Dim oChk As SAPbouiCOM.CheckBox = oForm.Items.Item("c_select").Specific
                                    '        If oChk.Checked Then
                                    '            For i As Integer = 1 To oGrid.Rows.Count
                                    '                oGrid.DataTable.Columns.Item("chk").Cells.Item(i - 1).Value = "Y"
                                    '            Next
                                    '        Else
                                    '            For i As Integer = 1 To oGrid.Rows.Count
                                    '                oGrid.DataTable.Columns.Item("chk").Cells.Item(i - 1).Value = "N"
                                    '            Next
                                    '        End If

                                    oForm.Freeze(False)
                                End If



                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If ValidateAll() = False Then
                                BubbleEvent = False
                                Exit Sub
                            End If

                        End If
                        If BusinessObjectInfo.ActionSuccess Then
                            If oDBDSHeader.GetValue("U_APDocEntry", 0).Trim <> "" Then
                                sQuery = String.Empty
                                sQuery = "UPDATE OPCH SET ""U_LandedCost""='Y' WHERE ""DocEntry""='" & oDBDSHeader.GetValue("U_APDocEntry", 0).Trim & "'"
                                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                            End If
                            If oDBDSHeader.GetValue("U_APCrdtDoc", 0).Trim <> "" Then
                                sQuery = String.Empty
                                sQuery = "UPDATE ORPC SET ""U_LandedCost""='Y' WHERE ""DocEntry""='" & oDBDSHeader.GetValue("U_APCrdtDoc", 0).Trim & "'"
                                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    Try
                        If BusinessObjectInfo.ActionSuccess Then
                            If frmLandedCosts.Mode <> SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                frmLandedCosts.PaneLevel = 1
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form data load event fail...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    sDelRowMatrix = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                        Case "Matrix1"
                            If EventInfo.Row = oMatrix1.VisualRowCount Then
                                frmLandedCosts.EnableMenu("1293", False)
                            Else
                                frmLandedCosts.EnableMenu("1293", True)
                            End If
                        Case "Matrix2"
                            If EventInfo.Row = oMatrix2.VisualRowCount Then
                                frmLandedCosts.EnableMenu("1293", False)
                            Else
                                frmLandedCosts.EnableMenu("1293", True)
                            End If

                        
                    End Select
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub Calculation()
        Try
            frmLandedCosts.Freeze(True)

        Catch ex As Exception

            oApplication.StatusBar.SetText("Calculation failed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            frmLandedCosts.Freeze(False)
        End Try
    End Sub

    Private Sub AddChooseFromList_Item(ByVal FormUID As String, ByVal CFL_ID As String)
        Try
            Dim oConditions As SAPbouiCOM.Conditions
            Dim oCondition As SAPbouiCOM.Condition
            Dim oChooseFromList As SAPbouiCOM.ChooseFromList
            Dim emptyCon As New SAPbouiCOM.Conditions
            oChooseFromList = oApplication.Forms.Item(FormUID).ChooseFromLists.Item(CFL_ID)
            oChooseFromList.SetConditions(emptyCon)

            oConditions = oChooseFromList.GetConditions()
            oCondition = oConditions.Add()

            oCondition.BracketOpenNum = 2
            oCondition.Alias = "DocType"
            oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
            oCondition.CondVal = "I"
            oCondition.BracketCloseNum = 1
            oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
            oCondition = oConditions.Add
            oCondition.BracketOpenNum = 1
            oCondition.Alias = "CardCode"
            oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_NOT_CONTAIN
            oCondition.CondVal = "SBM"
            oCondition.BracketCloseNum = 1
            'oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
            'oCondition = oConditions.Add
            'oCondition.BracketOpenNum = 1
            'oCondition.Alias = "DocStatus"
            'oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
            'oCondition.CondVal = "O"
            'oCondition.BracketCloseNum = 1
            oCondition.Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND
            oCondition = oConditions.Add
            oCondition.BracketOpenNum = 1
            oCondition.Alias = "U_LandedCost"
            oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
            oCondition.CondVal = "N"
            oCondition.BracketCloseNum = 1
            oCondition.BracketCloseNum = 2

            'oCondition.BracketOpenNum = 2
            'oCondition.Alias = "DocType"
            'oCondition.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
            'oCondition.CondVal = "I"
            'oCondition.BracketCloseNum = 2

            oChooseFromList.SetConditions(oConditions)
        Catch ex As Exception
            oApplication.objApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub

End Class
