Public Class ItemMaster
    Dim frmItemMaster, frmGloItemMaster As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer

    Sub LoadItemMaster(ByVal FormUID As String)
        Try
            boolFormLoaded = False
            Dim oItem As SAPbouiCOM.Item
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oComboBox As SAPbouiCOM.ComboBox
            Dim oEditText As SAPbouiCOM.EditText


            frmItemMaster = oApplication.Forms.Item(FormUID)
            frmGloItemMaster = oApplication.Forms.Item(FormUID)

            'oMatrix = frmItemMaster.Items.Item("38").Specific
            oDBDSHeader = frmItemMaster.DataSources.DBDataSources.Item("OITM")
            'oDBDSDetail = frmItemMaster.DataSources.DBDataSources.Item("RDR1")


            frmItemMaster.Freeze(True)

            ' Purchase Indent Copy From Button ...
            '------------------------------------

            'oItem = frmItemMaster.Items.Add("b_loaddata", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = frmItemMaster.Items.Item("2").Left + frmItemMaster.Items.Item("2").Width + 5
            'oItem.Width = frmItemMaster.Items.Item("2").Width
            'oItem.Height = frmItemMaster.Items.Item("2").Height
            'oItem.Top = frmItemMaster.Items.Item("2").Top
            'oItem.Visible = True
            'oItem.Enabled = True
            'oButton = oItem.Specific
            'oButton.Caption = "Select Item"


            'oItem = frmItemMaster.Items.Add("b_cal", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = frmItemMaster.Items.Item("2").Left + frmItemMaster.Items.Item("2").Width + 5 + frmItemMaster.Items.Item("2").Width + 5
            'oItem.Width = frmItemMaster.Items.Item("2").Width + 20
            'oItem.Height = frmItemMaster.Items.Item("2").Height
            'oItem.Top = frmItemMaster.Items.Item("2").Top
            'oItem.Visible = True
            'oItem.Enabled = True
            'oButton = oItem.Specific
            'oButton.Caption = "Cal. CBM & Carton"

            'oItem = frmItemMaster.Items.Add("b_copy", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = frmItemMaster.Items.Item("2").Left + frmItemMaster.Items.Item("2").Width + 5 + frmItemMaster.Items.Item("2").Width + 5 + frmItemMaster.Items.Item("2").Width + 5 + 20
            'oItem.Width = frmItemMaster.Items.Item("2").Width + 20
            'oItem.Height = frmItemMaster.Items.Item("2").Height
            'oItem.Top = frmItemMaster.Items.Item("2").Top
            'oItem.Visible = True
            'oItem.Enabled = True
            'oButton = oItem.Specific
            'oButton.Caption = "Copy SO"
            'frmItemMaster.Items.Item("b_copy").LinkTo = "b_cal"

            'oItem = frmItemMaster.Items.Add("l_pickwhs", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            'oItem.Left = frmItemMaster.Items.Item("86").Left
            'oItem.Width = frmItemMaster.Items.Item("86").Width
            'oItem.Height = frmItemMaster.Items.Item("86").Height
            'oItem.Top = frmItemMaster.Items.Item("86").Top + 16
            'oLabel = oItem.Specific
            'oLabel.Caption = "Pick Whs"



            'oItem = frmItemMaster.Items.Add("t_pickwhs", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = frmItemMaster.Items.Item("46").Left
            'oItem.Width = frmItemMaster.Items.Item("46").Width
            'oItem.Height = frmItemMaster.Items.Item("46").Height
            'oItem.Top = frmItemMaster.Items.Item("46").Top + 16
            'oEditText = oItem.Specific
            'oEditText.DataBind.SetBound(True, "ORDR", "U_PickWhs")
            'frmItemMaster.Items.Item("l_pickwhs").LinkTo = "t_pickwhs"

            'Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            'ocfls = frmItemMaster.ChooseFromLists
            'Dim Whs_CFL As SAPbouiCOM.ChooseFromList
            'Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            'cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            'cflcrepa.MultiSelection = False
            'cflcrepa.ObjectType = "64"
            'cflcrepa.UniqueID = "Whs_CFL"
            'Whs_CFL = ocfls.Add(cflcrepa)
            'oEditText.ChooseFromListUID = "Whs_CFL"
            'oEditText.ChooseFromListAlias = "WhsCode"

            'oItem = frmItemMaster.Items.Add("l_sso", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            'oItem.Left = frmItemMaster.Items.Item("86").Left
            'oItem.Width = frmItemMaster.Items.Item("86").Width
            'oItem.Height = frmItemMaster.Items.Item("86").Height
            'oItem.Top = frmItemMaster.Items.Item("86").Top + 16 + 16
            'oLabel = oItem.Specific
            'oLabel.Caption = "Selected SO"

            'oItem = frmItemMaster.Items.Add("t_sso", SAPbouiCOM.BoFormItemTypes.it_EXTEDIT)
            'oItem.Left = frmItemMaster.Items.Item("46").Left
            'oItem.Width = frmItemMaster.Items.Item("46").Width
            'oItem.Height = frmItemMaster.Items.Item("46").Height + 10
            'oItem.Top = frmItemMaster.Items.Item("46").Top + 16 + 16
            'oEditText = oItem.Specific
            'oEditText.DataBind.SetBound(True, "ORDR", "U_SOList")
            'oItem.Enabled = False
            'frmItemMaster.Items.Item("l_sso").LinkTo = "t_sso"






            'oItem = frmItemMaster.Items.Add("l_cbm", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            'oItem.Left = frmItemMaster.Items.Item("230").Left
            'oItem.Width = frmItemMaster.Items.Item("230").Width
            'oItem.Height = frmItemMaster.Items.Item("230").Height
            'oItem.Top = frmItemMaster.Items.Item("230").Top + 16
            'oLabel = oItem.Specific
            'oLabel.Caption = "Total CBM"

            'oItem = frmItemMaster.Items.Add("t_cbm", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = frmItemMaster.Items.Item("222").Left
            'oItem.Width = frmItemMaster.Items.Item("222").Width
            'oItem.Height = frmItemMaster.Items.Item("222").Height
            'oItem.Top = frmItemMaster.Items.Item("222").Top + 16
            'oEditText = oItem.Specific
            'oEditText.DataBind.SetBound(True, "ORDR", "U_TotalCBM")
            'frmItemMaster.Items.Item("l_cbm").LinkTo = "t_cbm"
            'oItem.Enabled = False

            'oItem = frmItemMaster.Items.Add("l_carton", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            'oItem.Left = frmItemMaster.Items.Item("230").Left
            'oItem.Width = frmItemMaster.Items.Item("230").Width
            'oItem.Height = frmItemMaster.Items.Item("230").Height
            'oItem.Top = frmItemMaster.Items.Item("230").Top + 16 + 16
            'oLabel = oItem.Specific
            'oLabel.Caption = "Total Carton"

            'oItem = frmItemMaster.Items.Add("t_carton", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = frmItemMaster.Items.Item("222").Left
            'oItem.Width = frmItemMaster.Items.Item("222").Width
            'oItem.Height = frmItemMaster.Items.Item("222").Height
            'oItem.Top = frmItemMaster.Items.Item("222").Top + 16 + 16
            'oEditText = oItem.Specific
            'oEditText.DataBind.SetBound(True, "ORDR", "U_TotCartQty")
            'frmItemMaster.Items.Item("l_carton").LinkTo = "t_carton"
            'oItem.Enabled = False

            ''oItem = frmItemMaster.Items.Add("t_docno", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            ''oItem.Left = frmItemMaster.Items.Item("46").Left
            ''oItem.Width = frmItemMaster.Items.Item("46").Width
            ''oItem.Height = frmItemMaster.Items.Item("46").Height
            ''oItem.Top = frmItemMaster.Items.Item("46").Top + 32
            ''oEditText = oItem.Specific
            ''oEditText.DataBind.SetBound(True, "ORDR", "U_DocNum")
            ''oItem.Enabled = False

            ''oItem = frmItemMaster.Items.Add("t_grpname", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            ''oItem.Left = frmItemMaster.Items.Item("46").Left
            ''oItem.Width = frmItemMaster.Items.Item("46").Width
            ''oItem.Height = frmItemMaster.Items.Item("46").Height
            ''oItem.Top = frmItemMaster.Items.Item("46").Top + 32
            ''oEditText = oItem.Specific
            ''oEditText.DataBind.SetBound(True, "ORDR", "U_GrpName")
            ' ''oItem.Enabled = False

            ''frmItemMaster.Items.Item("l_docnum").LinkTo = "t_grpname"


            ''Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            ''ocfls = frmItemMaster.ChooseFromLists
            ''Dim ITMGRP_CFL As SAPbouiCOM.ChooseFromList
            ''Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            ''cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            ''cflcrepa.MultiSelection = False
            ''cflcrepa.ObjectType = "OITM"
            ''cflcrepa.UniqueID = "ITMGRP_CFL"
            ''ITMGRP_CFL = ocfls.Add(cflcrepa)
            ''oEditText.ChooseFromListUID = "ITMGRP_CFL"
            ''oEditText.ChooseFromListAlias = "U_ItmGrpName"
            ' ''frmItemMaster.Items.Item("4").Specific.value = ""


            ''oItem = frmItemMaster.Items.Add("lk_grp", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
            ''oItem.Left = frmItemMaster.Items.Item("t_grpname").Left - 13
            ''oItem.Width = 10
            ''oItem.Height = frmItemMaster.Items.Item("t_grpname").Height
            ''oItem.Top = frmItemMaster.Items.Item("t_grpname").Top
            ''frmItemMaster.Items.Item("lk_grp").LinkTo = "t_docentry"


            ''oItem = frmItemMaster.Items.Add("l_BLNo", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            ''oItem.Left = frmItemMaster.Items.Item("86").Left
            ''oItem.Width = frmItemMaster.Items.Item("86").Width
            ''oItem.Height = frmItemMaster.Items.Item("86").Height
            ''oItem.Top = frmItemMaster.Items.Item("86").Top + 32 + 16
            ''oLabel = oItem.Specific
            ''oLabel.Caption = "BL No."

            ''oItem = frmItemMaster.Items.Add("t_BLNo", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX)
            ''oItem.Left = frmItemMaster.Items.Item("46").Left
            ''oItem.Width = frmItemMaster.Items.Item("46").Width
            ''oItem.Height = frmItemMaster.Items.Item("46").Height
            ''oItem.Top = frmItemMaster.Items.Item("46").Top + 32 + 16
            ''oComboBox = oItem.Specific
            ''oComboBox.DataBind.SetBound(True, "ORDR", "U_BLNo")
            ''frmItemMaster.Items.Item("l_BLNo").LinkTo = "t_BLNo"



            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmItemMaster.Freeze(False)
        Catch ex As Exception
            frmItemMaster.Freeze(False)
            'oApplication.StatusBar.SetText("Load ItemMaster Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmItemMaster.Freeze(True)

            frmItemMaster.Freeze(False)
        Catch ex As Exception
            frmItemMaster.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmItemMaster.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Function Validation() As Boolean
        Try


            Return True
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validation Function Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmItemMaster = oApplication.Forms.Item(FormUID)
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = ItemMasterTypeEx Then
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                        Try
                            Dim oDataTable As SAPbouiCOM.DataTable
                            Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                            Dim Txt, txt1 As SAPbouiCOM.EditText
                            oDataTable = oCFLE.SelectedObjects
                            If Not oDataTable Is Nothing And pVal.Before_Action = False Then
                                Select Case pVal.ItemUID

                                End Select
                            End If
                        Catch ex As Exception
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadItemMaster(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.ActionSuccess And frmItemMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Me.InitForm()
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.BeforeAction = True And (frmItemMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmItemMaster.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                        If Me.Validation() = False Then
                                            System.Media.SystemSounds.Asterisk.Play()
                                            BubbleEvent = False
                                            Exit Sub
                                        End If
                                    Else

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID
                                Case "15"
                                    If pVal.BeforeAction = False Then

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmItemMaster = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            'If pVal.FormTypeEx = ItemMasterTypeEx Then
            Select Case pVal.MenuUID
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
            End Select
            'End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmItemMaster = frmGloItemMaster
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If Validation() = False Then
                                BubbleEvent = False
                                Exit Sub
                            End If
                        End If
                        If BusinessObjectInfo.ActionSuccess Then
                            If frmItemMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                sQuery = String.Empty
                                sQuery = "UPDATE  OITM SET ""U_Add1""='Y',""U_Add2""='Y', "
                                sQuery += " ""U_Update1""='N',""U_Update2""='N'"
                                sQuery += " WHERE ""ItemCode"" ='" & oDBDSHeader.GetValue("ItemCode", 0).Trim & "'"
                                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                            ElseIf frmItemMaster.Mode <> SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                sQuery = String.Empty
                                sQuery = "UPDATE  OITM SET ""U_Add1""='Y',""U_Add2""='Y', "
                                sQuery += " ""U_Update1""='Y',""U_Update2""='Y'"
                                sQuery += " WHERE ""ItemCode"" ='" & oDBDSHeader.GetValue("ItemCode", 0).Trim & "'"
                                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                            End If

                            sQuery = String.Empty
                            sQuery = "UPDATE OITM SET ""U_CusPosting""='O',""U_LogPosting""='O', "
                            sQuery += " ""U_CusErrorMsg""=NULL,""U_LogErrorMsg""=NULL"
                            sQuery += " WHERE ""ItemCode"" ='" & oDBDSHeader.GetValue("ItemCode", 0).Trim & "'"
                            Dim RstUpdate1 As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then

                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                    End Select
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
