﻿Public Class ReceiptProd
    Dim frmReceiptProd As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmReceiptProd = oApplication.Forms.Item(FormUID)
                '   oForm = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = ReceiptTypeEx Then
                Select Case pVal.EventType




                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.BeforeAction = True And (frmReceiptProd.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                        oMatrix = oForm.Items.Item("13").Specific
                                        For i As Integer = 1 To oMatrix.RowCount
                                            Dim EditItem As SAPbouiCOM.EditText
                                            EditItem = oMatrix.Columns.Item("1").Cells.Item(i).Specific

                                            If (EditItem.Value <> "") Then
                                                Dim EditWhse As SAPbouiCOM.EditText
                                                EditWhse = oMatrix.Columns.Item("15").Cells.Item(i).Specific
                                                Dim StrQry = "Select  U_GA_BINL FROM OWHS WHERE WhsCode='" & EditWhse.Value & "'"
                                                Dim RsBin As SAPbobsCOM.Recordset = oGfun.DoQuery(StrQry)

                                                If (RsBin.RecordCount > 0) Then
                                                    Dim Edit As SAPbouiCOM.EditText
                                                    Edit = oMatrix.Columns.Item("U_PMX_LOCO").Cells.Item(i).Specific
                                                    Edit.Value = RsBin.Fields.Item(0).Value.ToString()
                                                    Edit = oMatrix.Columns.Item("U_PMX_QYSC").Cells.Item(i).Specific
                                                    Edit.Value = "RELEASED"
                                                End If
                                                StrQry = "Select U_GA_ItemType From OITM WHERE ItemCode='" & EditItem.Value & "'"
                                                RsBin = oGfun.DoQuery(StrQry)
                                                If (RsBin.RecordCount > 0) Then
                                                    If (RsBin.Fields.Item(0).Value.ToString() = "102") Then
                                                        Dim Edit As SAPbouiCOM.EditText = oMatrix.Columns.Item("U_PMX_LUID").Cells.Item(i).Specific
                                                        Edit.Value = "-1"
                                                    End If
                                                End If
                                            End If
                                        Next


                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmReceiptProd = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
