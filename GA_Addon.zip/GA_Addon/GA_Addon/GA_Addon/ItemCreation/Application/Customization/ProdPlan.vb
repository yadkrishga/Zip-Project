﻿Public Class ProdPlan
    Dim frmProdPlan As SAPbouiCOM.Form
    Dim oMatrix, oMatrix2 As SAPbouiCOM.Matrix
    Dim DocEntryList As String = ""
    Dim LineList As String = ""
    Dim ChkAll As String = "N"

    Sub LoadProdPlanning()
        oGfun.LoadXML(frmProdPlan, ProdPlanFormID, ProdPlanXML)
        frmProdPlan = oApplication.Forms.Item(ProdPlanFormID)
        InitForm()

    End Sub
#Region "InitForm"
    Sub InitForm()
        Try
            frmProdPlan.Freeze(True)

            LineList = ""





            frmProdPlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("InitForm Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmProdPlan.Freeze(False)
        Finally
        End Try
    End Sub
#End Region
    Sub Filldata()
        Try
            frmProdPlan.Freeze(True)
            LineList = ""
            ChkAll = "N"
            Dim Grid0 As SAPbouiCOM.Grid = frmProdPlan.Items.Item("Grid0").Specific


            Dim dt0 As SAPbouiCOM.DataTable = frmProdPlan.DataSources.DataTables.Item("DT0")

            Dim ItemType As String = frmProdPlan.DataSources.UserDataSources.Item("GA_UD_IT").ValueEx.Trim()
            Dim ProdType2 As String = frmProdPlan.DataSources.UserDataSources.Item("GA_UD_PT2").ValueEx.Trim()
            If ItemType <> "" Then


                Dim Sql As String = "select  ROW_NUMBER() OVER(ORDER BY A.DocNum) AS ROW,'N' as [Select],CASE WHEN A.Type='S' THEN 'Standard' WHEN A.Type='P' THEN 'Special' WHEN A.Type='D' THEN 'Disassembly' END [Type] "
                Sql += ",CASE WHEN A.Status='P' THEN 'Planned' END [Document Status],A.DocEntry,A.DocNum,A.[ItemCode],A.[ProdName],A.[PlannedQty],A.PostDate,A.StartDate,A.[DueDate],A.[Priority],CASE WHEN ISNULL(A.U_GA_Cell,'') <>'' THEN ISNULL(A.U_GA_Cell,'')ELSE ISNULL(B.[U_GA_Cell],'') END[Cell]"
                Sql += ",CASE WHEN B.[U_GA_ItemType]='101' THEN 'Barrel' WHEN B.[U_GA_ItemType]='102' THEN 'Finished' WHEN B.[U_GA_ItemType]='103' THEN 'Sheet' END [ItemType] "
                Sql += " FROM OWOR A INNER JOIN OITM B ON A.[ItemCode]=B.[ItemCode]   "
                If (ItemType <> "-") Then
                    Sql += "Where A.[Status]='P' and  B.[U_GA_ItemType]='" + ItemType + "'"
                    If (ItemType <> "103" And (ProdType2 <> "" And ProdType2 <> "-")) Then
                        Sql += " and B.[U_GA_ProdType2]='" & ProdType2 & "'"
                    End If
                Else
                        Sql += "Where A.[Status]='P' and  B.[U_GA_ItemType] IN('101','102','103')"
                End If

                dt0.ExecuteQuery(Sql)
                Grid0.DataTable = dt0
                Dim ix As Integer = 0
                Dim oColumn As SAPbouiCOM.GridColumn = Grid0.Columns.Item(ix)
                oColumn.TitleObject.Caption = "#"
                oColumn.TitleObject.Sortable = True
                oColumn.Editable = False
                For i As Integer = 0 To Grid0.Columns.Count - 1



                    oColumn = Grid0.Columns.Item(i)
                    oColumn.TitleObject.Sortable = True
                    If (oColumn.UniqueID = "DocEntry") Then


                        oColumn = Grid0.Columns.Item(i)
                        oColumn.LinkedObjectType = "202"

                    End If
                    If (oColumn.UniqueID = "ItemCode") Then


                        oColumn = Grid0.Columns.Item(i)
                        oColumn.LinkedObjectType = "4"

                    End If

                    If (oColumn.UniqueID = "Select") Then


                        oColumn.Editable = True

                        oColumn.Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox


                    ElseIf (oColumn.UniqueID = "Cell") Then

                        oColumn.Type = SAPbouiCOM.BoGridColumnType.gct_ComboBox
                        oColumn.Editable = True
                        Dim oComboBox As SAPbouiCOM.ComboBoxColumn = Grid0.Columns.Item(i)
                        oGfun.SetComboBoxValueRefreshGrid(oComboBox, "Select Distinct FldValue ,Descr   from UFD1 WHERE FieldID  in( Select FieldID   from CUFD where AliasID ='GA_Cell' and TableID ='OITM')")
                    ElseIf (oColumn.UniqueID = "Priority") Then

                        oColumn.Editable = True
                    Else
                        oColumn.Editable = False
                    End If



                    Grid0.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single

                Next
            End If




            frmProdPlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("Fill Data Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmProdPlan.Freeze(False)
        Finally
        End Try
    End Sub

    Sub SelectData(ByRef pVal As SAPbouiCOM.ItemEvent)

        Dim i As Integer = pVal.Row
        Dim Grid0 As SAPbouiCOM.Grid = frmProdPlan.Items.Item("Grid0").Specific
        Dim dt0 As SAPbouiCOM.DataTable = frmProdPlan.DataSources.DataTables.Item("DT0")
        Dim Chk As String = dt0.GetValue("Select", i).ToString()
        Dim DocEntry As String = dt0.GetValue("DocEntry", i).ToString()
        Dim LineId As String = Convert.ToString(Convert.ToInt32(dt0.GetValue("ROW", i).ToString()) - 1)
        Dim ReplaceString As String = "@" + DocEntry + "~"
        Dim ReplaceStringLine As String = "@" + LineId + "~"
        If Chk = "Y" Then
            ''DocEntryList = DocEntryList + "@" + DocEntry + "~"
            LineList = LineList + "@" + LineId + "~"
        Else
            LineList = LineList.Replace(ReplaceStringLine, "")
        End If
    End Sub

    Sub UpdatePOOld()
        Try


            If (LineList <> "") Then


                Dim LineListPO As String = LineList.Replace("@", "")
                Dim ListArr As String() = LineListPO.Split({"~"}, StringSplitOptions.RemoveEmptyEntries)
                For Each ListLine As Integer In ListArr
                    Dim LineNo As Integer = ListLine
                    Dim Grid0 As SAPbouiCOM.Grid = frmProdPlan.Items.Item("Grid0").Specific
                    Dim dt0 As SAPbouiCOM.DataTable = frmProdPlan.DataSources.DataTables.Item("DT0")
                    Dim DocEntry As String = dt0.GetValue("DocEntry", LineNo).ToString()
                    Dim Cell As String = dt0.GetValue("Cell", LineNo).ToString()
                    Dim Priority As String = dt0.GetValue("Priority", LineNo).ToString()
                    Dim Qty As Integer = Convert.ToInt32(dt0.GetValue("PlannedQty", LineNo).ToString())
                    Dim StrQry = "Select [Status] from OWOR WHERE DocEntry='" + DocEntry + "'"
                    Dim rsResult As SAPbobsCOM.Recordset = oGfun.DoQuery(StrQry)
                    Dim Status As String = rsResult.Fields.Item(0).Value.ToString()
                    If (Status = "P") Then
                        Dim oPO As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
                        If oPO.GetByKey(CInt(DocEntry)) = True Then
                            oPO.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposReleased
                            oPO.Priority = CInt(Priority)
                            oPO.UserFields.Fields.Item("U_GA_Cell").Value = Cell
                            If oPO.Update() = 0 Then
                                oApplication.StatusBar.SetText("PO Updated", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                Dim SqlWipInsert As String = "Exec GA_SP_WIPINSERT" & " " & DocEntry & "," & Qty & ""
                                Dim RsWIPInsert As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                RsWIPInsert.DoQuery(SqlWipInsert)
                                oApplication.StatusBar.SetText("WIP Created successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                            End If
                        End If

                    End If
                Next
                LineList = ""
                frmProdPlan.Items.Item("btn_Fill").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            Else
                oApplication.StatusBar.SetText("Select Minimum one line", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub UpdatePO()
        Try


            Dim cnt As Integer = 0
            Dim Grid0 As SAPbouiCOM.Grid = frmProdPlan.Items.Item("Grid0").Specific
            Dim dt0 As SAPbouiCOM.DataTable = frmProdPlan.DataSources.DataTables.Item("DT0")

            For i As Integer = 0 To dt0.Rows.Count - 1
                oApplication.StatusBar.SetText("Please wait Production Order Processing", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                Dim LineNo As Integer = i
                Dim Chk As String = dt0.GetValue("Select", i).ToString()
                If (Chk = "Y") Then


                    Dim DocEntry As String = dt0.GetValue("DocEntry", LineNo).ToString()
                    Dim Cell As String = dt0.GetValue("Cell", LineNo).ToString()
                    Dim Priority As String = dt0.GetValue("Priority", LineNo).ToString()
                    Dim Qty As Integer = Convert.ToInt32(dt0.GetValue("PlannedQty", LineNo).ToString())
                    Dim StrQry = "Select [Status] from OWOR WHERE DocEntry='" + DocEntry + "'"
                    Dim rsResult As SAPbobsCOM.Recordset = oGfun.DoQuery(StrQry)
                    Dim Status As String = rsResult.Fields.Item(0).Value.ToString()
                    If (Status = "P") Then
                        Dim oPO As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
                        If oPO.GetByKey(CInt(DocEntry)) = True Then
                            oPO.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposReleased
                            oPO.Priority = CInt(Priority)
                            oPO.UserFields.Fields.Item("U_GA_Cell").Value = Cell
                            If oPO.Update() = 0 Then
                                oApplication.StatusBar.SetText("PO Updated", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                Dim SqlWipInsert As String = "Exec GA_SP_WIPINSERT" & " " & DocEntry & "," & Qty & ""
                                Dim RsWIPInsert As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                RsWIPInsert.DoQuery(SqlWipInsert)
                                oApplication.StatusBar.SetText("WIP Created successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                cnt = cnt + 1
                            End If
                        End If

                    End If
                End If
            Next
            If (cnt > 0) Then
                oApplication.StatusBar.SetText("Process Completed successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                frmProdPlan.Items.Item("btn_Fill").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            Else
                oApplication.StatusBar.SetText("Select Minimum one line", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            End If


        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub

    Sub UpdatePO2()
        Try

            Dim cnt As Integer = 0

            Dim Grid0 As SAPbouiCOM.Grid = frmProdPlan.Items.Item("Grid0").Specific
            Dim dt0 As SAPbouiCOM.DataTable = frmProdPlan.DataSources.DataTables.Item("DT0")

            For i As Integer = 0 To dt0.Rows.Count - 1
                oApplication.StatusBar.SetText("Please wait Production Order Processing", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                Dim LineNo As Integer = i
                Dim Chk As String = dt0.GetValue("Select", i).ToString()
                If (Chk = "Y") Then


                    Dim DocEntry As String = dt0.GetValue("DocEntry", LineNo).ToString()
                    Dim Cell As String = dt0.GetValue("Cell", LineNo).ToString()
                    Dim Priority As String = dt0.GetValue("Priority", LineNo).ToString()
                    Dim Qty As Integer = Convert.ToInt32(dt0.GetValue("PlannedQty", LineNo).ToString())
                    Dim StrQry = "Select [Status] from OWOR WHERE DocEntry='" + DocEntry + "'"
                    Dim rsResult As SAPbobsCOM.Recordset = oGfun.DoQuery(StrQry)
                    Dim Status As String = rsResult.Fields.Item(0).Value.ToString()
                    If (Status = "P") Then
                        Dim oPO As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
                        If oPO.GetByKey(CInt(DocEntry)) = True Then

                            oPO.Priority = CInt(Priority)
                            oPO.UserFields.Fields.Item("U_GA_Cell").Value = Cell
                            If oPO.Update() = 0 Then
                                oApplication.StatusBar.SetText("PO Updated", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                cnt = cnt + 1
                            End If


                        End If
                    End If
                End If
            Next
            If (cnt > 0) Then
                oApplication.StatusBar.SetText("Process Completed successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                frmProdPlan.Items.Item("btn_Fill").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            Else
                oApplication.StatusBar.SetText("Select minimum one line", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

            End If


        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub

    Sub SelectAll()
        Try
            frmProdPlan.Freeze(True)
            Dim cnt As Integer = 0
            If (ChkAll = "N") Then
                ChkAll = "Y"
            Else
                ChkAll = "N"
            End If
            Dim Grid0 As SAPbouiCOM.Grid = frmProdPlan.Items.Item("Grid0").Specific
            Dim dt0 As SAPbouiCOM.DataTable = frmProdPlan.DataSources.DataTables.Item("DT0")

            For i As Integer = 0 To dt0.Rows.Count - 1
                oApplication.StatusBar.SetText("Please wait Production Order Selection", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                '   Dim LineNo As Integer = i

                dt0.SetValue("Select", i, ChkAll)

            Next
            frmProdPlan.Freeze(False)
            '  oApplication.StatusBar.SetText("Please wait Production Order Selection", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

        Catch ex As Exception
            frmProdPlan.Freeze(False)
            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmProdPlan = oApplication.Forms.Item(FormUID)

                '   oForm = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = ProdPlanFormID Then
                Select Case pVal.EventType


                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "btn_Sel"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then

                                        Me.SelectAll()

                                        oApplication.StatusBar.SetText("Selection Completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                                Case "btn_Fill"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Filling Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.Filldata()

                                        oApplication.StatusBar.SetText("Filling Completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                                Case "btnPro"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        Me.UpdatePO()
                                    End If
                                Case "btnUp"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        Me.UpdatePO2()
                                    End If

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                'Case "Grid0"
                                '    Select Case pVal.ColUID
                                '        Case "Select"
                                '            Try
                                '                If pVal.BeforeAction = False And pVal.ActionSuccess = True And pVal.Row >= 0 Then
                                '                    SelectData(pVal)
                                '                End If
                                '            Catch ex As Exception

                                '            End Try
                                ' End Select
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try

                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
