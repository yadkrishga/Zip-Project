Public Class SalesOrder
    Dim frmSaleOrder, frmGloSaleOrder As SAPbouiCOM.Form
    Dim frmSOProd As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer
    Dim GblDocEntry As String = ""
    Dim GblDocNum As String = ""

    Dim GblSelRow As Integer = 0
    Dim GblSelRow1 As Integer = 0
    Dim GblItemCode As String = ""
    Dim GblPlanQty As Double = 0
    Dim GblActPlanQty As Double = 0
    Dim GblLineNum As Integer = 0
    Dim GblWhse As String = ""
    Dim GblModel As String = ""


    Sub LoadSaleOrder(ByVal FormUID As String)
        Try
            boolFormLoaded = False
            Dim oItem As SAPbouiCOM.Item
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oComboBox As SAPbouiCOM.ComboBox
            Dim oEditText As SAPbouiCOM.EditText


            frmSaleOrder = oApplication.Forms.Item(FormUID)
            frmGloSaleOrder = oApplication.Forms.Item(FormUID)

            oMatrix = frmSaleOrder.Items.Item("38").Specific
            oDBDSHeader = frmSaleOrder.DataSources.DBDataSources.Item("ORDR")
            oDBDSDetail = frmSaleOrder.DataSources.DBDataSources.Item("RDR1")


            frmSaleOrder.Freeze(True)

            ' Purchase Indent Copy From Button ...
            '------------------------------------

            oItem = frmSaleOrder.Items.Add("b_GA_PROD", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmSaleOrder.Items.Item("2").Left + frmSaleOrder.Items.Item("2").Width + 5
            oItem.Width = frmSaleOrder.Items.Item("2").Width + frmSaleOrder.Items.Item("2").Width + 5
            oItem.Height = frmSaleOrder.Items.Item("2").Height
            oItem.Top = frmSaleOrder.Items.Item("2").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "Create Production"







            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmSaleOrder.Freeze(False)
        Catch ex As Exception
            frmSaleOrder.Freeze(False)
            'oApplication.StatusBar.SetText("Load SalesOrder Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmSaleOrder.Freeze(True)
            frmSaleOrder.Items.Item("b_GA_PROD").Enabled = False
            frmSaleOrder.Freeze(False)
        Catch ex As Exception
            frmSaleOrder.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmSaleOrder.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub Calculation()
        Try
            Dim TotCBMQty As Double = 0.0
            Dim TotCartonQty As Double = 0.0
            'Dim CartonQty As Double = 0.0
            For i As Integer = 1 To oMatrix.VisualRowCount
                If oMatrix.Columns.Item("1").Cells.Item(i).Specific.value <> "" Then
                    sQuery = String.Empty
                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value & "'"
                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    Dim CBMQty As Double = Rst.Fields.Item("U_CBM").Value
                    Dim CartonQty As Double = Rst.Fields.Item("U_CartQty").Value
                    TotCBMQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value
                    TotCartonQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value / CartonQty
                End If
            Next

            frmSaleOrder.Items.Item("t_cbm").Enabled = True
            frmSaleOrder.Items.Item("t_carton").Enabled = True
            frmSaleOrder.Items.Item("t_cbm").Specific.value = TotCBMQty
            frmSaleOrder.Items.Item("t_carton").Specific.value = TotCartonQty
            frmSaleOrder.Items.Item("16").Specific.value = frmSaleOrder.Items.Item("16").Specific.value
            frmSaleOrder.Items.Item("t_cbm").Enabled = False
            frmSaleOrder.Items.Item("t_carton").Enabled = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("Calculation Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Function Validation() As Boolean
        Try
            Dim flag As Boolean = True
            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
            Dim Status As String = oDBDSHeader.GetValue("Status", 0)
            Dim SqlWipExist As String = "Select *  from [@GA_WIPN] WHERE U_GA_PoEnt='" & DocEntry & "'"
            Dim RsWIP As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RsWIP.DoQuery(SqlWipExist)
            If (RsWIP.RecordCount > 0 And Status = "P") Then
                flag = False
                oApplication.MessageBox("Saleuction order status change is not permitted after WIP number is generated", 1, "Ok")
            Else
                flag = True

            End If

            Return flag
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validation Function Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmSaleOrder = oApplication.Forms.Item(FormUID)
                '   oForm = frmSaleOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = SaleOrderTypeEx Then
                Select Case pVal.EventType

                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadSaleOrder(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.ActionSuccess And frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Me.InitForm()
                                    End If
                                    'Case "lk_grp"
                                    '    If pVal.BeforeAction = False Then
                                    '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", frmSaleOrder.Items.Item("t_docentry").Specific.value)
                                    '    End If


                                Case "b_GA_PROD"
                                    If pVal.BeforeAction = False Then
                                        If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                            ' Me.CreateMySimpleForm_ItemList()
                                            GblActPlanQty = 0
                                            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
                                            GblDocNum = oDBDSHeader.GetValue("DocNum", 0)
                                            GblDocEntry = oDBDSHeader.GetValue("DocEntry", 0)
                                            GblSelRow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                            GblSelRow1 = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_SelectionOrder)
                                            Dim Sqlstatus As String = "Select [DocStatus]  from [ORDR] WHERE DocEntry='" & DocEntry & "'"
                                            Dim RsStat As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                            RsStat.DoQuery(Sqlstatus)
                                            Dim Status As String = RsStat.Fields.Item(0).Value.ToString().Trim()
                                            Dim Rowsel = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                            If (DocEntry <> "" And Status = "O" And Rowsel > -1) Then
                                                Dim oEdit As SAPbouiCOM.EditText = oMatrix.Columns.Item("1").Cells.Item(Rowsel).Specific
                                                GblItemCode = oEdit.Value
                                                oEdit = oMatrix.Columns.Item("11").Cells.Item(Rowsel).Specific
                                                GblPlanQty = Convert.ToDouble(oEdit.Value.ToString())
                                                oEdit = oMatrix.Columns.Item("24").Cells.Item(Rowsel).Specific
                                                GblWhse = oEdit.Value.ToString()
                                                oEdit = oMatrix.Columns.Item("U_GA_MODEL").Cells.Item(Rowsel).Specific
                                                GblModel = oEdit.Value.ToString()
                                                Dim SqlWHse As String = "Select B.Name,B.[U_GA_SWhs]  from [OWHS] A Inner Join [@GA_LOCM] B ON A.Location=B.Name WHERE A.WhsCode='" & GblWhse & " '"
                                                Dim RsWhse As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                RsWhse.DoQuery(SqlWHse)
                                                Dim WhsCnt As Integer = RsWhse.RecordCount
                                                If (WhsCnt = 0) Then
                                                    oApplication.MessageBox("Location Mapping missing.", 1, "Ok")
                                                Else
                                                    Dim LocCode As String = RsWhse.Fields.Item(0).Value.ToString()
                                                    GblWhse = RsWhse.Fields.Item(1).Value.ToString()
                                                    Dim SqlWhse2 As String = "Select DISTINCT B.[U_GA_SWhs],B.[U_GA_SWhs]  from [OWHS] A Inner Join [@GA_LOCM] B ON A.Location=B.Name WHERE b.Name='" & LocCode & "'"
                                                    If (GblItemCode.ToUpper() = "CUST01") Then

                                                        Dim SqlWOR As String = "Select [ItemCode],ISNULL((Select SUM(PlannedQty) FROM OWOR WHERE  ItemCode='" & GblItemCode & "' and LinkToObj='17' and OriginAbs='" & DocEntry & "' and Status IN('P','R','L') and Type='P' ),0)[ComplQty]  from [OWOR] WHERE ItemCode='" & GblItemCode & "' and LinkToObj='17' and OriginAbs='" & DocEntry & "' and Status IN('P','R','L') and Type='P'"
                                                        Dim RsWOR As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                        RsWOR.DoQuery(SqlWOR)
                                                        If (RsWOR.RecordCount > 0) Then
                                                            GblActPlanQty = Convert.ToDouble(RsWOR.Fields.Item(1).Value.ToString())
                                                            Dim ithReturnValue As Integer
                                                            ithReturnValue = oApplication.MessageBox("Do you want to recreate Production Order ?", 1, "Continue", "Cancel", "")
                                                            If (ithReturnValue = 1) Then
                                                                If (WhsCnt > 1) Then
                                                                    If (GblPlanQty - GblActPlanQty > 0) Then
                                                                        CreateMySimpleForm_Whse(SqlWhse2)
                                                                    Else
                                                                        oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                    End If
                                                                Else


                                                                    If (GblPlanQty - GblActPlanQty > 0) Then
                                                                        oApplication.ActivateMenuItem("4369")
                                                                        frmSOProd = oApplication.Forms.ActiveForm
                                                                        Dim POEdit As SAPbouiCOM.EditText
                                                                        Dim POCombo As SAPbouiCOM.ComboBox
                                                                        POCombo = frmSOProd.Items.Item("20").Specific
                                                                        POCombo.Select("P", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                                        POEdit = frmSOProd.Items.Item("6").Specific
                                                                        POEdit.Value = GblItemCode
                                                                        POEdit = frmSOProd.Items.Item("12").Specific
                                                                        POEdit.Value = GblPlanQty - GblActPlanQty
                                                                        POEdit = frmSOProd.Items.Item("78").Specific
                                                                        POEdit.Value = RsWhse.Fields.Item(1).Value.ToString()
                                                                        POEdit = frmSOProd.Items.Item("32").Specific
                                                                        POEdit.Value = GblDocNum
                                                                        Dim MatrixAtc As SAPbouiCOM.Matrix = frmSOProd.Items.Item("234000009").Specific
                                                                        MatrixAtc.Clear()
                                                                        MatrixAtc.AddRow()
                                                                        Dim AtcEntry As String = oDBDSHeader.GetValue("AtcEntry", 0)
                                                                    Else
                                                                        oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                    End If
                                                                End If
                                                                ' Me.ProductionOrder(DocEntry, GblItemCode, GblPlanQty, GblWhse, GblModel)
                                                            End If
                                                        Else
                                                            If (WhsCnt > 1) Then
                                                                If (GblPlanQty - GblActPlanQty > 0) Then
                                                                    CreateMySimpleForm_Whse(SqlWhse2)
                                                                Else
                                                                    oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                End If
                                                            Else
                                                                If (GblPlanQty - GblActPlanQty > 0) Then
                                                                    oApplication.ActivateMenuItem("4369")
                                                                    frmSOProd = oApplication.Forms.ActiveForm
                                                                    Dim POEdit As SAPbouiCOM.EditText
                                                                    Dim POCombo As SAPbouiCOM.ComboBox
                                                                    POCombo = frmSOProd.Items.Item("20").Specific
                                                                    POCombo.Select("P", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                                    POEdit = frmSOProd.Items.Item("6").Specific
                                                                    POEdit.Value = GblItemCode
                                                                    POEdit = frmSOProd.Items.Item("12").Specific
                                                                    POEdit.Value = GblPlanQty - GblActPlanQty
                                                                    POEdit = frmSOProd.Items.Item("78").Specific
                                                                    POEdit.Value = RsWhse.Fields.Item(1).Value.ToString()
                                                                    POEdit = frmSOProd.Items.Item("32").Specific
                                                                    POEdit.Value = GblDocNum
                                                                Else
                                                                    oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                End If

                                                            End If

                                                            'Me.ProductionOrder(DocEntry, GblItemCode, GblPlanQty, GblWhse, GblModel)
                                                        End If
                                                    Else
                                                        Dim SqlBOM As String = "Select [Code]  from [OITT] WHERE Code='" & GblItemCode & "'"
                                                        Dim RsBOM As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                        RsBOM.DoQuery(SqlBOM)
                                                        If (RsBOM.RecordCount > 0) Then


                                                            Dim SqlWOR As String = "Select [ItemCode],ISNULL((Select SUM(PlannedQty) FROM OWOR WHERE  ItemCode='" & GblItemCode & "' and LinkToObj='17' and OriginAbs='" & DocEntry & "' and Status IN('P','R','L') and Type='P' ),0)[ComplQty]   from [OWOR] WHERE ItemCode='" & GblItemCode & "' and LinkToObj='17' and OriginAbs='" & DocEntry & "' and Status IN('P','R','L')  and Type='P'"
                                                            Dim RsWOR As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                        RsWOR.DoQuery(SqlWOR)
                                                            If (RsWOR.RecordCount > 0) Then
                                                                GblActPlanQty = Convert.ToDouble(RsWOR.Fields.Item(1).Value.ToString())
                                                                Dim ithReturnValue As Integer
                                                                ithReturnValue = oApplication.MessageBox("Do you want to recreate Production Order ?", 1, "Continue", "Cancel", "")
                                                                If (ithReturnValue = 1) Then

                                                                    If (WhsCnt > 1) Then
                                                                        If (GblPlanQty - GblActPlanQty > 0) Then
                                                                            CreateMySimpleForm_Whse(SqlWhse2)
                                                                        Else
                                                                            oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                        End If
                                                                    Else
                                                                        If (GblPlanQty - GblActPlanQty > 0) Then
                                                                            oApplication.ActivateMenuItem("4369")
                                                                            frmSOProd = oApplication.Forms.ActiveForm
                                                                            Dim POEdit As SAPbouiCOM.EditText
                                                                            Dim POCombo As SAPbouiCOM.ComboBox
                                                                            POCombo = frmSOProd.Items.Item("20").Specific
                                                                            POCombo.Select("P", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                                            POEdit = frmSOProd.Items.Item("6").Specific
                                                                            POEdit.Value = GblItemCode
                                                                            POEdit = frmSOProd.Items.Item("12").Specific
                                                                            POEdit.Value = GblPlanQty - GblActPlanQty
                                                                            POEdit = frmSOProd.Items.Item("78").Specific
                                                                            POEdit.Value = RsWhse.Fields.Item(1).Value.ToString()
                                                                            POEdit = frmSOProd.Items.Item("32").Specific
                                                                            POEdit.Value = GblDocNum
                                                                            If (GblItemCode.ToUpper() <> "CUST01") Then
                                                                                POEdit = frmSOProd.Items.Item("t_GA_BBOM").Specific
                                                                                POEdit.Value = GblItemCode
                                                                                frmSOProd.Items.Item("b_GA_COMP").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                                                                Dim SqlExt As String = "Select A.[ItemCode]  from [RDR1] A INNER JOIN [OITM] B ON A.[ItemCode]=B.[ItemCode] INNER JOIN OITB C ON B.[ItmsGrpCod]=C.[ItmsGrpCod] WHERE A.DocEntry='" & GblDocEntry & "' and C.[ItmsGrpNam]='Extras'"
                                                                                Dim RsExt As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                                                RsExt.DoQuery(SqlExt)

                                                                                If (RsExt.RecordCount > 0) Then
                                                                                    CreateMySimpleForm_ExtDetails(RsWhse.Fields.Item(1).Value.ToString(), RsWhse.Fields.Item(0).Value.ToString())
                                                                                End If
                                                                            End If
                                                                            Dim MatrixAtc As SAPbouiCOM.Matrix = frmSOProd.Items.Item("234000009").Specific
                                                                        Else
                                                                            oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                        End If
                                                                    End If

                                                                    ' Me.ProductionOrder(DocEntry, GblItemCode, GblPlanQty, GblWhse, GblModel)
                                                                End If
                                                            Else

                                                                If (WhsCnt > 1) Then
                                                                    If (GblPlanQty - GblActPlanQty > 0) Then
                                                                        CreateMySimpleForm_Whse(SqlWhse2)
                                                                    Else
                                                                        oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                    End If
                                                                Else
                                                                    If (GblPlanQty - GblActPlanQty > 0) Then
                                                                        oApplication.ActivateMenuItem("4369")
                                                                        frmSOProd = oApplication.Forms.ActiveForm
                                                                        Dim POEdit As SAPbouiCOM.EditText
                                                                        Dim POCombo As SAPbouiCOM.ComboBox
                                                                        POCombo = frmSOProd.Items.Item("20").Specific
                                                                        POCombo.Select("P", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                                        POEdit = frmSOProd.Items.Item("6").Specific
                                                                        POEdit.Value = GblItemCode
                                                                        POEdit = frmSOProd.Items.Item("12").Specific
                                                                        POEdit.Value = GblPlanQty - GblActPlanQty
                                                                        POEdit = frmSOProd.Items.Item("78").Specific
                                                                        POEdit.Value = RsWhse.Fields.Item(1).Value.ToString()
                                                                        POEdit = frmSOProd.Items.Item("32").Specific
                                                                        POEdit.Value = GblDocNum
                                                                        If (GblItemCode.ToUpper() <> "CUST01") Then
                                                                            POEdit = frmSOProd.Items.Item("t_GA_BBOM").Specific
                                                                            POEdit.Value = GblItemCode
                                                                            frmSOProd.Items.Item("b_GA_COMP").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                                                            Dim SqlExt As String = "Select A.[ItemCode]  from [RDR1] A INNER JOIN [OITM] B ON A.[ItemCode]=B.[ItemCode] INNER JOIN OITB C ON B.[ItmsGrpCod]=C.[ItmsGrpCod] WHERE A.DocEntry='" & GblDocEntry & "' and C.[ItmsGrpNam]='Extras'"
                                                                            Dim RsExt As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                                            RsExt.DoQuery(SqlExt)

                                                                            If (RsExt.RecordCount > 0) Then
                                                                                CreateMySimpleForm_ExtDetails(RsWhse.Fields.Item(1).Value.ToString(), RsWhse.Fields.Item(0).Value.ToString())
                                                                            End If
                                                                        End If
                                                                        Dim MatrixAtc As SAPbouiCOM.Matrix = frmSOProd.Items.Item("234000009").Specific
                                                                    Else
                                                                        oApplication.StatusBar.SetText("ProductionOrder Planned Qty against this sales Order exceeds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                                    End If
                                                                End If
                                                                'Me.ProductionOrder(DocEntry, GblItemCode, GblPlanQty, GblWhse, GblModel)
                                                            End If

                                                    Else
                                                        oApplication.MessageBox("Select a Finished Item", 1, "Ok")
                                                    End If

                                                End If
                                            End If
                                        Else
                                                oApplication.MessageBox("Document should be in Open Status/Select Minimum One Line.", 1, "Ok")
                                                ''oApplication.StatusBar.SetText("Check Saleuction Order in Released status,or Update the Document to Released", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_None)
                                            End If
                                        End If
                                    End If
                                Case "b_copy"
                                    If pVal.BeforeAction = False Then
                                        Me.CreateMySimpleForm_SODetails()
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.BeforeAction = True And (frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then

                                    Else

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID
                                Case "15"
                                    If pVal.BeforeAction = False Then

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmSaleOrder = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            'If pVal.FormTypeEx = SalesOrderTypeEx Then
            Select Case pVal.MenuUID
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
                Case "1281"
                    If pVal.BeforeAction = False Then
                        frmSaleOrder.Items.Item("b_GA_PROD").Enabled = False
                    End If
            End Select
            'End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmSaleOrder = frmGloSaleOrder
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then

                        End If
                        If BusinessObjectInfo.ActionSuccess Then

                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then
                        frmSaleOrder.Items.Item("b_GA_PROD").Enabled = True
                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                    End Select
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub ProductionOrder(ByVal DocEntry As String, ByVal ItemCode As String, ByVal Qty As Integer, ByVal Whse As String, ByVal Model As String)
        Try
            Dim Error1 As Integer = 0
            Dim Prod As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
            Prod.PostingDate = Now()
            Prod.ItemNo = ItemCode
            Prod.PlannedQuantity = Qty
            Prod.Warehouse = Whse
            Prod.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned
            Prod.ProductionOrderOrigin = SAPbobsCOM.BoProductionOrderOriginEnum.bopooSalesOrder
            Prod.ProductionOrderOriginEntry = DocEntry
            Prod.UserFields.Fields.Item("U_GA_MODEL").Value = Model
            Error1 = Prod.Add()
            If (Error1 <> 0) Then
                oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Else
                oApplication.MessageBox("Production Order Created successfully", 1, "Ok")
            End If
            'Dim ithReturnValue As Integer
            'ithReturnValue = oApplication.MessageBox("Do you want to Scrap the Item ?", 1, "Continue", "Cancel", "")
            'If (ithReturnValue = 1) Then
            '    CreateMySimpleForm_QtyScrap()
            'End If

        Catch ex As Exception

        End Try
    End Sub
    Sub CreateMySimpleForm_Whse(ByVal Qry As String)
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_WHSE"
            CP.FormType = "300"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 120
            oForm.Width = 300
            oForm.Title = "Warehouse"
            '' Add a Grid item to the form 


            ' Add OK Button 
            oItem = oForm.Items.Add("1", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Ok"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_Whse", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 85
            oItem.Height = 15
            oItem.LinkTo = "edtWhse"
            oLabel = oItem.Specific
            oLabel.Caption = "Enter Whse"


            '----------------------------------------




            oItem = oForm.Items.Add("edtWhse", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX)
            oItem.Left = 100
            oItem.Top = 10
            oItem.Width = 150
            oItem.Height = 15
            oCombo = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_Whse", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oCombo.DataBind.SetBound(True, "", "U_Whse")
            oItem.DisplayDesc = True
            oItem.Enabled = True
            oGfun.SetComboBoxValueRefresh(oCombo, Qry)

            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub CreateMySimpleForm_ExtDetails(ByVal WhseCode As String, ByVal Loccode As String)
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim ocheckbox As SAPbouiCOM.CheckBox
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_EXTLST"
            CP.FormType = "605"

            oForm = oApplication.Forms.AddEx(CP)
            oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE
            ' Set form width and height  
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Extra Material Mapping"
            '' Add a Grid item to the form  
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position  
            oItem.Left = 5
            oItem.Top = 25
            oItem.Width = 675
            oItem.Height = 240
            ' Set the grid data  
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button  
            oItem = oForm.Items.Add("1", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button  
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            sQuery = "Select 'Y' [Select] ,a.[ItemCode] as [Sales Item],a.[Dscription] [Sales ItemName],A.[Quantity] as [Sales Qty],ISNULL(D.[U_ItemCode],'No Data')[SAP ItemCode],D.[U_Description] as [SAP ItemName],A.[Quantity]*D.[U_Qty] [Total Qty],(SELECT MAX(U_GA_PWhs) FROM [@GA_LOCM] WHERE U_GA_SWhs='" + WhseCode + "'"
            If (Loccode <> "") Then
                sQuery += " and Name='" & Loccode & "'"
            End If
            sQuery += " ) as [WhsCode]  from [RDR1] A INNER JOIN [OITM] B ON A.[ItemCode]=B.[ItemCode] INNER JOIN OITB C ON B.[ItmsGrpCod]=C.[ItmsGrpCod] inner join [@GAU_EXMAP]  D ON A.[ItemCode]=D.[U_ExCode] WHERE A.DocEntry='" & GblDocEntry & "' and C.[ItmsGrpNam]='Extras'"

            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()

            For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                    oGrid.Columns.Item(i).Editable = True

                ElseIf i = 6 And i > 0 Then
                    oGrid.Columns.Item(i).Editable = True
                ElseIf i <> 6 And i > 0 Then
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Purchase Order Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    Sub CreateMySimpleForm_QtyScrap()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_SCRP"
            CP.FormType = "201"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 120
            oForm.Width = 200
            oForm.Title = "Scrap Qty"
            '' Add a Grid item to the form 


            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_Qty", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 85
            oItem.Height = 15
            oItem.LinkTo = "edtQty"
            oLabel = oItem.Specific
            oLabel.Caption = "Enter Quantity"


            '----------------------------------------




            oItem = oForm.Items.Add("edtQty", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 100
            oItem.Top = 10
            oItem.Width = 40
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_Qty", SAPbouiCOM.BoDataType.dt_SHORT_NUMBER)
            oEditBox.DataBind.SetBound(True, "", "U_Qty")
            oItem.Enabled = True


            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub CreateMySimpleForm_SODetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SODetails"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Sale Order Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 675
            oItem.Height = 260
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"

            sQuery = String.Empty
            sQuery = "CALL ""@INSPL_GET_SO_DETAILS""  ('" & oDBDSHeader.GetValue("U_PickWhs", 0).Trim & "')"
            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_Whse(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType




                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = False Then
                                    Dim Whse = oForm.DataSources.UserDataSources.Item("U_Whse").ValueEx
                                    If (Whse <> "") Then
                                        oForm.Close()
                                        oApplication.ActivateMenuItem("4369")
                                        frmSOProd = oApplication.Forms.ActiveForm
                                        Dim POEdit As SAPbouiCOM.EditText
                                        Dim POCombo As SAPbouiCOM.ComboBox
                                        POCombo = frmSOProd.Items.Item("20").Specific
                                        POCombo.Select("P", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                        POEdit = frmSOProd.Items.Item("6").Specific
                                        POEdit.Value = GblItemCode
                                        POEdit = frmSOProd.Items.Item("12").Specific
                                        POEdit.Value = GblPlanQty - GblActPlanQty
                                        POEdit = frmSOProd.Items.Item("78").Specific
                                        POEdit.Value = Whse
                                        POEdit = frmSOProd.Items.Item("32").Specific
                                        POEdit.Value = GblDocNum
                                        If (GblItemCode.ToUpper() <> "CUST01") Then
                                            POEdit = frmSOProd.Items.Item("t_GA_BBOM").Specific
                                            POEdit.Value = GblItemCode
                                            frmSOProd.Items.Item("b_GA_COMP").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            Dim SqlExt As String = "Select A.[ItemCode],(SELECT X.Location FROM OWHS X WHERE WhsCode='" & Whse & "') as [Location],'" & Whse & "' as [WhsCode]  from [RDR1] A INNER JOIN [OITM] B ON A.[ItemCode]=B.[ItemCode] INNER JOIN OITB C ON B.[ItmsGrpCod]=C.[ItmsGrpCod] INNER JOIN OWHS D ON A.[WhsCode]=D.[WhsCode] WHERE A.DocEntry='" & GblDocEntry & "' and C.[ItmsGrpNam]='Extras'"
                                            Dim RsExt As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                            RsExt.DoQuery(SqlExt)
                                            If (RsExt.RecordCount > 0) Then
                                                CreateMySimpleForm_ExtDetails(RsExt.Fields.Item(2).Value.ToString(), RsExt.Fields.Item(1).Value.ToString())
                                            End If
                                        End If
                                        '' Me.ProductionOrder(GblDocEntry, GblItemCode, GblPlanQty, Whse, GblModel)

                                    Else

                                            oApplication.MessageBox("Select One Whse", 1, "OK")
                                    End If


                                End If


                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try





            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub

    Sub ItemEvent_Scrap(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType




                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim Error1 As Integer = 0
                                    Dim EditText As SAPbouiCOM.EditText
                                    EditText = oMatrix.Columns.Item("4").Cells.Item(GblSelRow1).Specific
                                    Dim Getitem As String = EditText.Value

                                    Dim SqlLine As String = "Select [LineNum]  from [WOR1] WHERE DocEntry='" & GblDocEntry & "' and ItemCode='" & Getitem & "'"
                                    Dim RsLine As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                    RsLine.DoQuery(SqlLine)
                                    Dim Qty As Integer = Convert.ToInt32(oForm.DataSources.UserDataSources.Item("U_Qty").ValueEx)
                                    Dim Gissue As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit)
                                    Gissue.DocDate = Now()
                                    Gissue.Lines.BaseType = 202
                                    Gissue.Lines.BaseEntry = GblDocEntry
                                    Gissue.Lines.BaseLine = Convert.ToInt32(RsLine.Fields.Item(0).Value.ToString())
                                    Dim LineNum As Integer = Convert.ToInt32(RsLine.Fields.Item(0).Value.ToString())
                                    Gissue.Lines.Quantity = Qty
                                    Gissue.Lines.UserFields.Fields.Item("U_PMX_LOCO").Value = "DZ1"
                                    Gissue.Lines.UserFields.Fields.Item("U_PMX_QYSC").Value = "RELEASED"
                                    Error1 = Gissue.Add()
                                    If (Error1 <> 0) Then
                                        oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                    Else

                                        sQuery = "Update WOR1 SET PlannedQty=PlannedQty+" & Qty & " WHERE DocEntry='" & GblDocEntry & "' and LineNum='" & LineNum & "'"
                                        Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                        oApplication.StatusBar.SetText("Scrap posted successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                        oApplication.MessageBox("Scrap posted successfully", 1, "Ok")
                                        frmGloSaleOrder.Refresh()
                                    End If


                                    oForm.Close()
                                End If


                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try





            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub


    Sub ItemEvent_ExtDetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try

            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID

                            Case "1"
                                oForm = oApplication.Forms.Item(FormUID)
                                If pVal.BeforeAction = False And oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific

                                    For j As Integer = 1 To oGrid.Rows.Count
                                        Dim Chk As String = oGrid.DataTable.Columns.Item("Select").Cells.Item(j - 1).Value
                                        If Chk = "Y" Then
                                            If (oGrid.DataTable.Columns.Item("SAP ItemCode").Cells.Item(j - 1).Value <> "No Data") Then
                                                Dim MatrixP As SAPbouiCOM.Matrix = frmSOProd.Items.Item("37").Specific
                                                Dim Row As Integer = MatrixP.RowCount
                                                Dim EditP As SAPbouiCOM.EditText = MatrixP.Columns.Item("4").Cells.Item(Row).Specific
                                                EditP.Value = oGrid.DataTable.Columns.Item("SAP ItemCode").Cells.Item(j - 1).Value
                                                EditP = MatrixP.Columns.Item("14").Cells.Item(Row).Specific
                                                EditP.Value = oGrid.DataTable.Columns.Item("Total Qty").Cells.Item(j - 1).Value
                                                EditP = MatrixP.Columns.Item("10").Cells.Item(Row).Specific
                                                EditP.Value = oGrid.DataTable.Columns.Item("WhsCode").Cells.Item(j - 1).Value
                                            End If
                                        End If

                                    Next
                                    oApplication.StatusBar.SetText("Extra Items Updated", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oForm.Close()

                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID
                                    Case "SAP ItemCode"
                                        oForm = oApplication.Forms.Item(FormUID)
                                        If pVal.BeforeAction = False And pVal.ActionSuccess = True Then

                                            Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                            Dim oCombo As SAPbouiCOM.ComboBoxColumn
                                            oCombo = oGrid.Columns.Item("SAP ItemCode")

                                            Dim SapCode As String = oCombo.GetSelectedValue(pVal.Row).Value
                                            oGrid.DataTable.Columns.Item("SAP ItemCode").Cells.Item(oGrid.GetDataTableRowIndex(pVal.Row)).Value = SapCode

                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("ComboBox Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Validate Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    'Dim oCompanyService As SAPbobsCOM.CompanyService
    'Dim oTimeSheetService As SAPbobsCOM.ProjectManagementTimeSheetService
    'Dim oTimeSheet As SAPbobsCOM.PM_TimeSheetData
    'Dim oTimeSheetLine As SAPbobsCOM.PM_TimeSheetLineData
    'Dim oTimeSheetParam As SAPbobsCOM.PM_TimeSheetParams
    'Dim StartTime As Date
    'Dim EndTime As Date
    'Dim breakTime As Date
    'Dim NonBillableTime As Date

    'Dim oCompanySer As SAPbobsCOM.CompanyService = oCompany.GetCompanyService
    'Dim oTimeShee As SAPbobsCOM.ProjectManagementTimeSheetService = oCompanyService.GetBusinessService(SAPbobsCOM.ServiceTypes.ProjectManagementTimeSheetService)
    'Dim oTimeSheet As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetData)
    'Dim oTimeSheetLine As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetLineData)
    'Dim oTimeSheetParam As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetParams)

    'oTimeSheet.TimeSheetType = SAPbobsCOM.TimeSheetTypeEnum.tsh_Employee
    'oTimeSheet.UserId = 2


    'StartTime = VBA.DateAdd("h", 7, VBA.Int(Now)) 'start a 7.00
    'EndTime = VBA.DateAdd("n", 90, StartTime) 'add 90 minutes
    'breakTime = VBA.DateAdd("n", 45, VBA.Int(Now)) 'pause  45 minutes


    'NonBillableTime = VBA.DateAdd("n", 15, VBA.Int(Now))
    'oTimeSheetLine.Date = Now
    'oTimeSheetLine.StartTime = StartTime
    'oTimeSheetLine.EndTime = EndTime
    'oTimeSheetLine.Break = breakTime
    'oTimeSheetLine.NonBillableTime = NonBillableTime
    'oTimeSheetLine.ActivityType = 1
    'oTimeSheetLine.CostCenter = ""
    'oTimeSheetLine.FinancialProject = "090"

    'oTimeSheetLine = oTimeSheet.PM_TimeSheetLineDataCollection.Add()

    'oTimeSheetParam = oTimeSheetService.AddTimeSheet(oTimeSheet)

End Class
