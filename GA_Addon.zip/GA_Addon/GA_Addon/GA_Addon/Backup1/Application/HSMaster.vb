Public Class HSMaster
    Dim frmHSMaster As SAPbouiCOM.Form
    Dim oMatrix1, mx_attach, ms_attach As SAPbouiCOM.Matrix
    Dim oDBDSHeader, oDBDSDetail1, oDBDSAttach, oDBDS_Attach As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "OHSM"
    Dim NoofFridays As Double = 0.0
    Dim NoofSaturdays As Double = 0.0
    Dim NoofTodays As Double = 0.0
    Dim DeleteRowITEMUID As String = ""
    Dim RowCtrl1 As SAPbouiCOM.CommonSetting

    Sub LoadHSMaster()
        Try
            oGfun.LoadXML(frmHSMaster, HSMasterFormID, HSMasterXML)
            frmHSMaster = oApplication.Forms.Item(HSMasterFormID)
            frmHSMaster.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE
            oDBDSHeader = frmHSMaster.DataSources.DBDataSources.Item("@INS_OHSM")

            Me.DefineModesForFields()
            Me.InitForm()

        Catch ex As Exception
            oGfun.StatusBarErrorMsg("Load HS Master Application Failed : " & ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try
            ' oGfun.setComboBoxValue(frmHSMaster.Items.Item("c_Dept").Specific, "Select ""Code"",""Name"" from OUDP ")
            frmHSMaster.Freeze(True)
            If frmHSMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                oDBDSHeader.SetValue("Code", 0, oGfun.GetCodeGeneration("@INS_OHSM"))
            End If
            frmHSMaster.ActiveItem = "t_Code1"

            frmHSMaster.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("InitForm Method Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmHSMaster.Freeze(False)
        Finally
        End Try
    End Sub
    Sub DefineModesForFields()
        Try

            frmHSMaster.Items.Item("t_Code1").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            frmHSMaster.Items.Item("t_Code1").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            frmHSMaster.Items.Item("t_Code1").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            frmHSMaster.Items.Item("t_Name").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            frmHSMaster.Items.Item("t_Name").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            frmHSMaster.Items.Item("t_Name").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            'frmHSMaster.Items.Item("t_Type").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            'frmHSMaster.Items.Item("t_Type").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            'frmHSMaster.Items.Item("t_Type").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            'frmHSMaster.Items.Item("t_sort").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            'frmHSMaster.Items.Item("t_sort").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            'frmHSMaster.Items.Item("t_sort").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

        Catch ex As Exception
            oApplication.StatusBar.SetText("DefineModesForFields Method Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Function ValidateAll() As Boolean
        Try
            If frmHSMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then
                If frmHSMaster.Items.Item("t_Code1").Specific.value.Equals("") Then
                    oApplication.StatusBar.SetText("Code Type Should Not be left Empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    frmHSMaster.Items.Item("t_Code1").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                    Return False
                End If
            End If

            ValidateAll = True
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validate Function Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            ValidateAll = False
        Finally
        End Try
    End Function
    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Got Focus event Failed : " & ex.Message)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Item Validate event Failed : " & ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Combo Select Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        frmHSMaster.Freeze(False)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmHSMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmHSMaster.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub
                                    End If
                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID

                            Case "1"
                                If pVal.ActionSuccess And frmHSMaster.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Pressed Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1296", "1288", "1289", "1291"
                    'frmHSMaster.Items.Item("t_Code1").Enabled = True
                    'frmHSMaster.Items.Item("t_Name").Enabled = True
                Case "1281"
                    frmHSMaster.ActiveItem = "t_Code"
                    'Case "1282"
                    '    If pVal.BeforeAction = False Then Me.InitForm()
                Case "1282"
                    Me.InitForm()
                Case "1293"

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If Me.ValidateAll() = False Then
                                System.Media.SystemSounds.Asterisk.Play()
                                BubbleEvent = False
                                Exit Sub
                            End If


                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then
                        'If oDBDSHeader.GetValue("U_DocStatus", 0).Trim = "" Then

                        'End If
                    End If
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        'Try
        '    Select Case EventInfo.EventType
        '        Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
        '            If frmHSMaster.Mode <> SAPbouiCOM.BoFormMode.fm_FIND_MODE And EventInfo.BeforeAction = True Then
        '                DeleteRowITEMUID = EventInfo.ItemUID
        '                Select Case EventInfo.ItemUID
        '                    Case "Matrix1"
        '                        If EventInfo.Row = oMatrix1.VisualRowCount Then
        '                            frmHSMaster.EnableMenu("1293", False)
        '                        Else
        '                            frmHSMaster.EnableMenu("1293", True)
        '                        End If
        '                End Select

        '            End If
        '    End Select
        'Catch ex As Exception
        '    oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        'Finally
        'End Try
    End Sub

End Class








