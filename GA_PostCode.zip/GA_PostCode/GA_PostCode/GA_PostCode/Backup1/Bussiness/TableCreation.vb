﻿Public Class TableCreation

    Public oGFun As New GlobalFunctions
    Dim ValidValueYesORNo = New String(,) {{"N", "No"}, {"Y", "Yes"}}
    Sub New()
        Try

            Me.ItemCreation()
            Me.ColorSizeMaster()
            Me.HSMaster()
            Me.SaleOrder()
            Me.LandedCosts()
            Me.InvoiceApproval()
            Me.ApprovalInterface()
            Me.SalesInvoice()
            Me.UDF()

            oGFun.CreateUserFieldsComboBox("OUSR", "InvApp", "Invoice Approval - Access", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , ValidValueYesORNo, "N")
            oGFun.CreateUserFieldsComboBox("OUSR", "AppReport", "Approval Report - Access", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , ValidValueYesORNo, "N")

        Catch ex As Exception
            oGFun.StatusBarErrorMsg("New Method Failed : " & ex.Message)
        Finally
        End Try
    End Sub
#Region "       ... Item Creation..."

    Sub ItemCreation()
        Try
            Me.ItemCreationHead()
            Me.ItemCreationColorSize()
            Me.ItemCreationProperties()
            Me.ItemCreationAtt()
            If Not oGFun.UDOExists("OITM") Then
                Dim FindField As String(,) = New String(,) {{"DocNum", "DocNum"}}
                oGFun.RegisterUDO("OITM", "Item Creation", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "INS_OITM", "INS_ITM1", "INS_ITM2", "INS_ITM3")
                FindField = Nothing

            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation Item Creation Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub ItemCreationHead()
        Try
            oGFun.CreateTable("INS_OITM", "Item Creation Header", SAPbobsCOM.BoUTBTableType.bott_Document)

            oGFun.CreateUserFields("@INS_OITM", "DocDate", "DocDate", SAPbobsCOM.BoFieldTypes.db_Date)


            oGFun.CreateUserFields("@INS_OITM", "ItmGrpCode", "ItmGrpCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "ItmGrpName", "ItmGrpName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OITM", "ForgName", "ForgName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OITM", "SAPItmGrpCod", "SAPItmGrpCod", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "InvItem", "InvItem", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
            oGFun.CreateUserFields("@INS_OITM", "SaleItem", "SaleItem", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
            oGFun.CreateUserFields("@INS_OITM", "PurItem", "PurItem", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
            oGFun.CreateUserFields("@INS_OITM", "UOMGroup", "UOMGroup", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

            'Tab1----------------
            oGFun.CreateUserFields("@INS_OITM", "Hazardous", "Hazardous", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
            oGFun.CreateUserFields("@INS_OITM", "Manufact", "Manufact", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OITM", "HSCode", "HSCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "HSName", "HSName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OITM", "MinSalPrc", "MinSalPrc", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "MaxSalPrc", "MaxSalPrc", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "OrgCountCod", "OrgCountCod", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "OrgCountNam", "OrgCountNam", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OITM", "Category", "Category", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "Image", "Image", SAPbobsCOM.BoFieldTypes.db_Alpha, 0, SAPbobsCOM.BoFldSubTypes.st_Image)
            oGFun.CreateUserFields("@INS_OITM", "Pict", "Pict", SAPbobsCOM.BoFieldTypes.db_Memo, 0, SAPbobsCOM.BoFldSubTypes.st_Link)
            'Tab1----------------
            'Tab2----------------
            oGFun.CreateUserFields("@INS_OITM", "UnitOfSal", "UnitOfSal", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "UnitOfSalM", "UnitOfSalM", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "SCartQty", "SCartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFields("@INS_OITM", "SalVat", "SalVat", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "SVatRate", "SVatRate", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "SLength", "SLength", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "SWidth", "SWidth", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "SHeight", "SHeight", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "SCalCBM", "SCalCBM", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            'oGFun.CreateUserFields("@INS_OITM", "SLHWInCM", "SLHWInCM", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            'Tab2----------------
            'Tab3----------------
            oGFun.CreateUserFields("@INS_OITM", "UnitOfPur", "UnitOfPur", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "UnitOfPurM", "UnitOfPurM", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "PCartQty", "PCartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFields("@INS_OITM", "PurVat", "PurVat", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "PVatRate", "PVatRate", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OITM", "PLength", "PLength", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "PWidth", "PWidth", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "PHeight", "PHeight", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OITM", "PCalCBM", "PCalCBM", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            'oGFun.CreateUserFields("@INS_OITM", "PLHWInCM", "PLHWInCM", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            'Tab3----------------
 
        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub ItemCreationColorSize()
        Try

            oGFun.CreateTable("INS_ITM1", "Item Creation ColorSize", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)


            oGFun.CreateUserFields("@INS_ITM1", "Code1", "Code1", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ITM1", "Code", "Code", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ITM1", "Name", "Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            Dim Type = New String(,) {{"S", "Size"}, {"C", "Color"}}
            oGFun.CreateUserFieldsComboBox("@INS_ITM1", "Type", "Type", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Type, "")
            oGFun.CreateUserFields("@INS_ITM1", "ItemCode", "ItemCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            'oGFun.CreateUserFields("@INS_ITM1", "Amount", "Amount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ITM1", "Select", "Select", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub ItemCreationProperties()
        Try


            oGFun.CreateTable("INS_ITM2", "Item Creation Property", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_ITM2", "PropCode", "PropCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ITM2", "PropName", "PropName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ITM2", "Select", "Select", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub ItemCreationAtt()
        Try


            oGFun.CreateTable("INS_ITM3", "Item Creation Attchment", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_ITM3", "TrgtPath", "TrgtPath", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ITM3", "ScrPath", "ScrPath", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ITM3", "FileName", "FileName", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ITM3", "FileExt", "FileExt", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ITM3", "Date", "Date", SAPbobsCOM.BoFieldTypes.db_Date)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
#End Region

#Region "... LandedCosts........"

    Sub LandedCosts()
        Try
            Me.LandedCostshead()
            Me.LandedCostsDetail1()
            Me.LandedCostsDetail2()

            If Not oGFun.UDOExists("OIPF") Then
                Dim FindField As String(,) = New String(,) {{"DocNum", "DocNum"}}
                oGFun.RegisterUDO("OIPF", "LandedCosts", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "INS_OIPF", "INS_IPF1", "INS_IPF2")
                FindField = Nothing
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation LandedCosts ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try

    End Sub

    Sub LandedCostshead()
        Try
            oGFun.CreateTable("INS_OIPF", "LandedCostshead", SAPbobsCOM.BoUTBTableType.bott_Document)

            Dim Type = New String(,) {{"1", "AP Invoice"}, {"2", "AP Credit Memo"}}
            oGFun.CreateUserFieldsComboBox("@INS_OIPF", "Type", "Type", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Type, "")

            oGFun.CreateUserFields("@INS_OIPF", "Docdate", "Docdate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OIPF", "DueDate", "DueDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OIPF", "RefNo", "RefNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIPF", "FileNo", "FileNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIPF", "CardCode", "CardCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIPF", "CardName", "CardName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OIPF", "CardCod1", "CardCod1", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIPF", "CardNam1", "CardNam1", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OIPF", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_OIPF", "Curency", "Curency", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_OIPF", "DocTotal", "DocTotal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OIPF", "Vat2", "Vat2", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OIPF", "Vat1", "Vat1", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_OIPF", "BeforeVat", "BeforeVat", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_OIPF", "AmtBal", "AmtBal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_OIPF", "CostSum", "CostSum", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_OIPF", "CustDate", "CustDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OIPF", "ActCustom", "ActCustom", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_OIPF", "ExpCustom", "ExpCustom", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)

            oGFun.CreateUserFields("@INS_OIPF", "APDocEntry", "APDocEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIPF", "APDocNum", "APDocNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

            oGFun.CreateUserFields("@INS_OIPF", "APCrdtDoc", "APCrdtDoc", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIPF", "APCrtDocNo", "APCrtDocNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub LandedCostsDetail1()
        Try
            oGFun.CreateTable("INS_IPF1", "LandedCostsDetail1", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_IPF1", "ItemCode", "ItemCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "Quantity", "Quantity", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFields("@INS_IPF1", "Docprice", "Docprice", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_IPF1", "DocValue", "DocValue", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Rate)
            oGFun.CreateUserFields("@INS_IPF1", "ProjCust", "ProjCust", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_IPF1", "CusValue", "CusValue", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Rate)

            oGFun.CreateUserFields("@INS_IPF1", "Expendi", "Expendi", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Rate)
            oGFun.CreateUserFields("@INS_IPF1", "CosValue", "CosValue", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Rate)
            oGFun.CreateUserFields("@INS_IPF1", "WhsPrice", "WhsPrice", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)

            oGFun.CreateUserFields("@INS_IPF1", "Total", "Total", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_IPF1", "TotaCost", "TotaCost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_IPF1", "Warehous", "Warehous", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_IPF1", "ReleseNo", "ReleseNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "VarCosts", "VarCosts", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_IPF1", "ConstCosts", "ConstCosts", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)

            oGFun.CreateUserFields("@INS_IPF1", "UserCustom", "UserCustom", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "FobnLac", "FobnLac", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Rate)
            oGFun.CreateUserFields("@INS_IPF1", "Project", "Project", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "BaseEntry", "BaseEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "BaseNum", "BaseNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

            oGFun.CreateUserFields("@INS_IPF1", "BaseLine", "BaseLine", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "DistrRule", "DistrRule", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF1", "UoMCode", "UoMCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub LandedCostsDetail2()
        Try
            oGFun.CreateTable("INS_IPF2", "LandedCostsDetail2", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)
            oGFun.CreateUserFields("@INS_IPF2", "AlcCode", "AlcCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_IPF2", "AlcName", "AlcName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_IPF2", "Ohtype", "Ohtype", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_IPF2", "CostSum", "CostSum", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_IPF2", "Factor", "Factor", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "CustCalc", "CustCalc", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_IPF2", "CardCode", "CardCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "Cost", "Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_IPF2", "BaseEntry", "BaseEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "LandAcc", "LandAcc", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "BaseNum", "BaseNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "BaseLine", "BaseLine", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IPF2", "Cost1", "Cost1", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_IPF2", "Weight", "Weight", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)


        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub


#End Region

#Region "       ...ColorSizeMaster ..."

    Sub ColorSizeMaster()
        Try
            Me.ColorSizeMasterHead()

            If Not oGFun.UDOExists("OCSM") Then
                Dim FindField As String(,) = New String(,) {{"Code", "Code"}}
                oGFun.RegisterUDO("OCSM", "ColorSizeMaster", SAPbobsCOM.BoUDOObjType.boud_MasterData, FindField, "INS_OCSM")
                FindField = Nothing
            End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation ColorSizeMaster Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub ColorSizeMasterHead()
        Try
            oGFun.CreateTable("INS_OCSM", "ColorSizeMaster Header", SAPbobsCOM.BoUTBTableType.bott_MasterData)

            oGFun.CreateUserFields("@INS_OCSM", "Code", "Code", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OCSM", "Name", "Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            Dim Type = New String(,) {{"S", "Size"}, {"C", "Color"}}
            oGFun.CreateUserFieldsComboBox("@INS_OCSM", "Type", "Type", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Type, "")
            oGFun.CreateUserFields("@INS_OCSM", "SortID", "SortID", SAPbobsCOM.BoFieldTypes.db_Numeric)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try

    End Sub
#End Region

#Region "       ...HSMaster ..."

    Sub HSMaster()
        Try
            Me.HSMasterHead()

            If Not oGFun.UDOExists("OHSM") Then
                Dim FindField As String(,) = New String(,) {{"Code", "Code"}}
                oGFun.RegisterUDO("OHSM", "HS Master", SAPbobsCOM.BoUDOObjType.boud_MasterData, FindField, "INS_OHSM")
                FindField = Nothing
            End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation HS Master Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub HSMasterHead()
        Try
            oGFun.CreateTable("INS_OHSM", "HS Master Header", SAPbobsCOM.BoUTBTableType.bott_MasterData)

            oGFun.CreateUserFields("@INS_OHSM", "Code", "Code", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OHSM", "Name", "Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
          

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try

    End Sub
#End Region

#Region " Sale Order  "
    Sub SaleOrder()
        Try
            Me.SaleOrderHeader()
            Me.SaleOrderDetail()
            Me.FreightChargesDetail()
            ' Me.SalesQuotationDetail1()
            If Not oGFun.UDOExists("ORDR") Then
                Dim FindField As String(,) = New String(,) {{"DocEntry", "DocEntry"}}
                oGFun.RegisterUDO("ORDR", "SaleOrder", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "INS_ORDR", "INS_RDR1", "INS_FRC2")
                FindField = Nothing
            End If

        Catch ex As Exception
            oGFun.Msg("SaleOrder UDO  Failed: " & ex.Message, "M", "W")
        Finally
        End Try
    End Sub

    Sub SaleOrderHeader()
        Try

            Dim cmb_Status = New String(,) {{"R", "Rejected"}, {"D", "Draft"}, {"O", "Open"}, {"A", "Approved"}, {"L", "Canceled"}, {"C", "Closed"}}
            oGFun.CreateUserFieldsComboBox("@INS_ORDR", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, SAPbobsCOM.BoFldSubTypes.st_None, "", cmb_Status, "D")
            Dim DocType = New String(,) {{"I", "Item"}, {"S", "Service"}}

            oGFun.CreateTable("INS_ORDR", "SaleOrderHeader", SAPbobsCOM.BoUTBTableType.bott_Document)

            oGFun.CreateUserFields("@INS_ORDR", "Location", "Location", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "POStatus", "POStatus", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "POEntry", "POEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "DocDate", "DocDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_ORDR", "BillDate", "BillDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_ORDR", "DocDueDate", "DocDueDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_ORDR", "TaxDate", "TaxDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_ORDR", "CardCode", "CardCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "CardName", "CardName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "CntCtCode", "CntCtCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "NumAtCard", "NumAtCard", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "PickWhs", "PickWhs", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ORDR", "TotalCBM", "TotalCBM", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFields("@INS_ORDR", "TotCartQty", "TotCartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFieldsComboBox("@INS_ORDR", "DocType", "DocType", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , DocType, "I")
            oGFun.CreateUserFields("@INS_ORDR", "SummryType", "SummryType", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "SlpCode", "SlpCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "OwnerCode", "OwnerCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "TotBefDcnt", "TotBefDcnt", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "DiscPrcnt", "DiscPrcnt", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_ORDR", "Discount", "Discount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "Frieght", "Frieght", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "Rounding", "Rounding", SAPbobsCOM.BoFieldTypes.db_Alpha, 2)
            oGFun.CreateUserFields("@INS_ORDR", "RoundOff", "RoundOff", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "TaxAmount", "TaxAmount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "DocTotal", "DocTotal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "Comments", "Comments", SAPbobsCOM.BoFieldTypes.db_Memo, 254)
            oGFun.CreateUserFields("@INS_ORDR", "ShipToCode", "ShipToCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "Address", "Address", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ORDR", "PayToCode", "PayToCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "Address2", "Address2", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ORDR", "TrnspCode", "TrnspCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "PreByCod", "OwnerCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "NewRate", "NewRate", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Rate)
            oGFun.CreateUserFields("@INS_ORDR", "ExpnsCode", "Expense Code", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "ExpnsName", "Expense Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "TaxCode", "TaxCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_ORDR", "Find", "Find", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ORDR", "OwnerName", "Owner Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ORDR", "Attach5", "Attach5", SAPbobsCOM.BoFieldTypes.db_Memo, , SAPbobsCOM.BoFldSubTypes.st_Link)
            oGFun.CreateUserFields("@INS_ORDR", "Attach4", "Attach4", SAPbobsCOM.BoFieldTypes.db_Memo, , SAPbobsCOM.BoFldSubTypes.st_Link)
            oGFun.CreateUserFields("@INS_ORDR", "Attach3", "Attach3", SAPbobsCOM.BoFieldTypes.db_Memo, , SAPbobsCOM.BoFldSubTypes.st_Link)
            oGFun.CreateUserFields("@INS_ORDR", "Attach2", "Attach2", SAPbobsCOM.BoFieldTypes.db_Memo, , SAPbobsCOM.BoFldSubTypes.st_Link)
            oGFun.CreateUserFields("@INS_ORDR", "Attach1", "Attach1", SAPbobsCOM.BoFieldTypes.db_Memo, , SAPbobsCOM.BoFldSubTypes.st_Link)
            oGFun.CreateUserFields("@INS_ORDR", "DocTotal1", "DocTotal1", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "SOEntry", "SOEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ORDR", "SONum", "SONum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ORDR", "SRemarks", "SRemarks", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ORDR", "LRemarks", "LRemarks", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_ORDR", "CreditLimit", "CreditLimit", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "Balance", "Balance", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "Overdue", "Overdue", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_ORDR", "WhsCode", "WhsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_ORDR", "WhsName", "WhsName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_ORDR", "PayTerms", "PayTerms", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

            oGFun.CreateUserFields("@INS_ORDR", "Property", "Property", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

            oGFun.CreateUserFields("@INS_ORDR", "TaxAmount1", "TaxAmount1", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)

            oGFun.CreateUserFields("@INS_ORDR", "SSOEntry", "SBMDUBAILIVE SOEntry", SAPbobsCOM.BoFieldTypes.db_Memo)

        Catch ex As Exception
            oGFun.Msg("Sale Order Header Table creation Failed: " & ex.Message, "M", "W")
        Finally
        End Try
    End Sub

    Sub SaleOrderDetail()
        Try
            Dim Status = New String(,) {{"O", "Open"}, {"C", "Close"}}

            oGFun.CreateTable("INS_RDR1", "SaleOrderDetail", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)
            oGFun.CreateUserFields("@INS_RDR1", "ItemCode", "ItemCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)

            oGFun.CreateUserFields("@INS_RDR1", "Dscription", "Dscription", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_RDR1", "InStock", "InStock", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "Quantity", "Quantity", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "UnitPrice", "UnitPrice", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_RDR1", "Discount", "Discount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "TaxCode", "TaxCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "Total", "Total", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "LineTotal", "LineTotal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "TaxAmount", "TaxAmount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "Location", "Location", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "WhsCode", "WhsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "WhsName", "WhsName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFieldsComboBox("@INS_RDR1", "RowStatus", "RowStatus", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Status, "O")
            oGFun.CreateUserFields("@INS_RDR1", "FreeText", "FreeText", SAPbobsCOM.BoFieldTypes.db_Memo, 254)
            oGFun.CreateUserFields("@INS_RDR1", "PriceList", "PriceList", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_RDR1", "DisAftPri", "DisCount After Price", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_RDR1", "NDPVAL", "NDP Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "NETVAl", "NET Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "MRPVAL", "MRP Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "BefTaxVal", "Before Tax Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "ListVal", "ListPrice Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "AddiPrice", "Additional Price", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)


            oGFun.CreateUserFields("@INS_RDR1", "DisVal", "Discount Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_RDR1", "NDP", "NDP Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "MRP", "MRP Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "NetCost", "Net Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "ListPrice", "ListPrice", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "GRNQty", "GRNQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFields("@INS_RDR1", "DisPercnt", "Discount Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_RDR1", "DisVal", "Discount Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_RDR1", "EDPercnt", "ED Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_RDR1", "EDVal", "ED Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "InsPercnt", "Insurance Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_RDR1", "InsVal", "Insurance Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "NDPValADis", "NDP Value Aft Discount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "AbatmntRat", "Abatement Rate %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_RDR1", "MRPValAABT", "MRP Value Aft Abate", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "NetTotal", "Net Total", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_RDR1", "QOH", "QOH", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "BranchQOH", "BranchQOH", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "OrderQty", "OrderQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_RDR1", "CDPrecnt", "CD Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_RDR1", "CDVal", "CD Value ", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "InStock", "InStock", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "Committed", "Committed", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_RDR1", "OnHand", "OnHand", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            Dim Status1 = New String(,) {{"O", "Open"}, {"L", "Cancel"}, {"C", "Close"}}
            oGFun.CreateUserFieldsComboBox("@INS_RDR1", "LineStatus", "LineStatus", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Status1, "O")
            ' oGFun.CreateUserFieldsComboBox("@INS_RDR1", "RDR1Status", "RDR1Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Status, "O")

            oGFun.CreateUserFields("@INS_RDR1", "BaseEntry", "BaseEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "BaseNum", "BaseNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "BaseLine", "BaseLine", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "BaseType", "BaseType", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_RDR1", "CustCode", "CustCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_RDR1", "CustName", "CustName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        Catch ex As Exception
            oGFun.Msg("Sale Order Detail  Table creation Failed: " & ex.Message, "M", "W")
        Finally
        End Try
    End Sub

    Sub FreightChargesDetail()
        Try
            Dim Status = New String(,) {{"O", "Open"}, {"C", "Close"}}


            oGFun.CreateTable("INS_FRC2", "FreightChargesDetail", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)
            oGFun.CreateUserFields("@INS_FRC2", "Project", "Project", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)

            oGFun.CreateUserFields("@INS_FRC2", "OcrCode2", "OcrCode2", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)

            oGFun.CreateUserFields("@INS_FRC2", "OcrCode1", "OcrCode1", SAPbobsCOM.BoFieldTypes.db_Alpha, 80)
            oGFun.CreateUserFields("@INS_FRC2", "Employee", "Employee", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_FRC2", "Location", "Location", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_FRC2", "GrsAmnt", "GrsAmnt", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            '  oGFun.CreateUserFields("@INS_FRC2", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_FRC2", "NetAmt", "NetAmt", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_FRC2", "DistrbMthd", "DistrbMthd", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_FRC2", "TotVatAmt", "TotVatAmt", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_FRC2", "Vatpercnt", "Vatpercnt", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_FRC2", "VatGroup", "VatGroup", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_FRC2", "UniqID", "UniqID.", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFieldsComboBox("@INS_FRC2", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Status, "O")
            oGFun.CreateUserFields("@INS_FRC2", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo, 254)
            oGFun.CreateUserFields("@INS_FRC2", "ExpnsName", "ExpnsName", SAPbobsCOM.BoFieldTypes.db_Alpha, 80)
            oGFun.CreateUserFields("@INS_FRC2", "ExpnsCode", "ExpnsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_FRC2", "RevAcct", "RevAcct", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_FRC2", "ExpnsAcct", "ExpnsAcct", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_FRC2", "TotBefDis", "TotBefDis", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_FRC2", "FrgPer", "FrgPer", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

        Catch ex As Exception
            oGFun.Msg("Sale Order Detail  Table creation Failed: " & ex.Message, "M", "W")
        Finally
        End Try
    End Sub
#End Region

#Region "... Sales Invoice........"

    Sub SalesInvoice()
        Try
            Me.SalesInvoicehead()
            Me.SalesInvoiceDetail1()
            Me.SalesInvoiceDetail2()

            If Not oGFun.UDOExists("OINV1") Then
                Dim FindField As String(,) = New String(,) {{"DocNum", "DocNum"}}
                oGFun.RegisterUDO("OINV1", "SalesInvoice", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "INS_OINV", "INS_INV1", "INS_INV2")
                FindField = Nothing
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation SalesInvoice ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try

    End Sub

    Sub SalesInvoicehead()
        Try
            oGFun.CreateTable("INS_OINV", "SalesInvoicehead", SAPbobsCOM.BoUTBTableType.bott_Document)

            oGFun.CreateUserFields("@INS_OINV", "Docdate", "Docdate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OINV", "WhsCode", "WhsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OINV", "WhsName", "WhsName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OINV", "CreatedBy", "CreatedBy", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_OINV", "CreatedByNm", "CreatedByNm", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_OINV", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub SalesInvoiceDetail1()
        Try
            oGFun.CreateTable("INS_INV1", "SalesInvoiceDetail1", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_INV1", "SONo", "SONo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_INV1", "SOEntry", "SOEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_INV1", "CardCode", "CardCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_INV1", "CardName", "CardName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_INV1", "InvNo", "InvNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_INV1", "InvEntry", "InvEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_INV1", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)

            Dim Type = New String(,) {{"P", "Pending"}, {"I", "Invoiced"}, {"W", "Waiting For Approval"}, {"A", "Approved"}, {"R", "Rejected"}}
            oGFun.CreateUserFieldsComboBox("@INS_INV1", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Type, "")

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub SalesInvoiceDetail2()
        Try
            Dim Status = New String(,) {{"O", "Open"}, {"C", "Close"}}

            oGFun.CreateTable("INS_INV2", "SalesInvoiceDetail2", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_INV2", "ItemCode", "ItemCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_INV2", "Dscription", "Dscription", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_INV2", "InStock", "InStock", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "Quantity", "Quantity", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "UnitPrice", "UnitPrice", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_INV2", "Discount", "Discount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "TaxCode", "TaxCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_INV2", "Total", "Total", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "LineTotal", "LineTotal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "TaxAmount", "TaxAmount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "Location", "Location", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
            oGFun.CreateUserFields("@INS_INV2", "WhsCode", "WhsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)

            oGFun.CreateUserFieldsComboBox("@INS_INV2", "RowStatus", "RowStatus", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , Status, "O")
            oGFun.CreateUserFields("@INS_INV2", "FreeText", "FreeText", SAPbobsCOM.BoFieldTypes.db_Memo, 254)
            oGFun.CreateUserFields("@INS_INV2", "PriceList", "PriceList", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_INV2", "DisAftPri", "DisCount After Price", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_INV2", "NDPVAL", "NDP Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "NETVAl", "NET Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "MRPVAL", "MRP Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "BefTaxVal", "Before Tax Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "ListVal", "ListPrice Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "AddiPrice", "Additional Price", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_INV2", "DisVal", "Discount Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_INV2", "NDP", "NDP Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "MRP", "MRP Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "NetCost", "Net Cost", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "ListPrice", "ListPrice", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "GRNQty", "GRNQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
            oGFun.CreateUserFields("@INS_INV2", "DisPercnt", "Discount Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_INV2", "DisVal", "Discount Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Price)
            oGFun.CreateUserFields("@INS_INV2", "EDPercnt", "ED Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_INV2", "EDVal", "ED Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "InsPercnt", "Insurance Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_INV2", "InsVal", "Insurance Value", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "NDPValADis", "NDP Value Aft Discount", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "AbatmntRat", "Abatement Rate %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_INV2", "MRPValAABT", "MRP Value Aft Abate", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "NetTotal", "Net Total", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_INV2", "QOH", "QOH", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "BranchQOH", "BranchQOH", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "OrderQty", "OrderQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_INV2", "CDPrecnt", "CD Percentage %", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Percentage)
            oGFun.CreateUserFields("@INS_INV2", "CDVal", "CD Value ", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "InStock", "InStock", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "Committed", "Committed", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
            oGFun.CreateUserFields("@INS_INV2", "OnHand", "OnHand", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)


        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub


#End Region

    Sub UDF()
        oGFun.CreateTable("CATEGORY", "Category", SAPbobsCOM.BoUTBTableType.bott_NoObject)
        oGFun.CreateUserFieldsComboBox("OITM", "Hazardous", "Hazardous", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , ValidValueYesORNo, "N")
        oGFun.CreateUserFields("OITM", "MinSalPrc", "MinSalPrc", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
        oGFun.CreateUserFields("OITM", "MaxSalPrc", "MaxSalPrc", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)
        oGFun.CreateUserFields("OITM", "OrgCountCod", "OrgCountCod", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("OITM", "OrgCountNam", "OrgCountNam", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
        oGFun.CreateUserFields("OITM", "Category", "Category", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("OITM", "SCartQty", "Sales CartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
        oGFun.CreateUserFields("OITM", "PCartQty", "Sale CartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
        oGFun.CreateUserFields("OITM", "CBM", "CBM", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
        oGFun.CreateUserFields("OITM", "CartQty", "CartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)

        oGFun.CreateUserFields("OITM", "Itemgrp", "Itemgrp", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("OITM", "Itemgrpname", "Itemgrpname", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
        oGFun.CreateUserFields("OITM", "HsCode", "HsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("OITM", "HsName", "HsName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        oGFun.CreateUserFields("OITM", "Add1", "Add1", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OITM", "Add2", "Add2", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OITM", "Update1", "Update1", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OITM", "Update2", "Update2", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)

        oGFun.CreateUserFields("OCRD", "Add1", "Add1", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OCRD", "Add2", "Add2", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OCRD", "Update1", "Update1", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OCRD", "Update2", "Update2", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)

        oGFun.CreateUserFields("OACT", "Add1", "Add1", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OACT", "Add2", "Add2", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OACT", "Update1", "Update1", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)
        oGFun.CreateUserFields("OACT", "Update2", "Update2", SAPbobsCOM.BoFieldTypes.db_Alpha, 1)

        oGFun.CreateUserFields("OITM", "DB1ErrorLog", "DB1ErrorLog", SAPbobsCOM.BoFieldTypes.db_Memo)
        oGFun.CreateUserFields("OITM", "DB2ErrorLog", "DB2ErrorLog", SAPbobsCOM.BoFieldTypes.db_Memo)

        oGFun.CreateUserFields("ORDR", "DocEntry", "DocEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "DocNum", "DocNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "GrpName", "GrpName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        oGFun.CreateUserFields("ORDR", "TotalCBM", "TotalCBM", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)
        oGFun.CreateUserFields("ORDR", "TotCartQty", "TotCartQty", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Quantity)

        oGFun.CreateUserFields("ORDR", "PickWhs", "PickWhs", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "SOList", "SOList", SAPbobsCOM.BoFieldTypes.db_Memo)
        oGFun.CreateUserFields("ORDR", "Read", "Read", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "InvRefNo", "InvRefNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "InvType", "InvType", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        oGFun.CreateUserFields("ORDR", "BaseEntry", "BaseEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "BaseNum", "BaseNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "BaseType", "BaseType", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        oGFun.CreateUserFields("RDR1", "BaseEntry", "BaseEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("RDR1", "BaseNum", "BaseNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("RDR1", "BaseType", "BaseType", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("RDR1", "BaseLine", "BaseLine", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        oGFun.CreateUserFields("OADM", "SBMDB", "SBM Data Base", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        'oGFun.CreateUserFields("OITM", "Itemgrp", "Itemgrp", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        'oGFun.CreateUserFields("OITM", "Itemgrpname", "Itemgrpname", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        'oGFun.CreateUserFields("OITM", "HsCode", "HsCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        'oGFun.CreateUserFields("OITM", "HsName", "HsName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        oGFun.CreateUserFields("RDR1", "CardCode", "CardCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("RDR1", "CardName", "CardName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        oGFun.CreateUserFields("OITM", "Size", "Size", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        Dim Approve = New String(,) {{"O", "Open"}, {"P", "Pending"}, {"A", "Approved"}, {"R", "Rejected"}}
        oGFun.CreateUserFieldsComboBox("ODRF", "Approval", "Approval", SAPbobsCOM.BoFieldTypes.db_Alpha, 50, , , Approve, "O")


        oGFun.CreateUserFieldsComboBox("OPCH", "LandedCost", "LandedCost", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , ValidValueYesORNo, "N")
        oGFun.CreateUserFieldsComboBox("ORPC", "LandedCost", "LandedCost", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, , , ValidValueYesORNo, "N")

        oGFun.CreateUserFields("ODRF", "AppRemarks", "AppRemarks", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
    End Sub

#Region "... InvoiceApproval........"

    Sub InvoiceApproval()
        Try
            Me.InvoiceApprovalhead()
            Me.InvoiceApprovalDetail1()
            If Not oGFun.UDOExists("OIAIF") Then
                Dim FindField As String(,) = New String(,) {{"DocNum", "DocNum"}}
                oGFun.RegisterUDO("OIAIF", "InvoiceApproval", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "INS_OIAIF", "INS_IAIF1")
                FindField = Nothing
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation InvoiceApproval ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try

    End Sub

    Sub InvoiceApprovalhead()
        Try
            oGFun.CreateTable("INS_OIAIF", "InvoiceApprovalhead", SAPbobsCOM.BoUTBTableType.bott_Document)

            oGFun.CreateUserFields("@INS_OIAIF", "DueDate", "DueDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OIAIF", "ReqDate", "RequestDate From", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OIAIF", "ReqDateT", "RequestDate To", SAPbobsCOM.BoFieldTypes.db_Date)

            oGFun.CreateUserFields("@INS_OIAIF", "Accept", "Accept All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_OIAIF", "Reject", "Reject All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_OIAIF", "Clear", "Clear All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_OIAIF", "Select", "Select All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)

            oGFun.CreateUserFields("@INS_OIAIF", "OriginCd", "Originator FromCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIAIF", "OriginNm", "Originator FromName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OIAIF", "AuthoCd", "Authorizer FromCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIAIF", "AuthoNm", "Authorizer FromName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OIAIF", "CardCode", "CardCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIAIF", "CardName", "CardName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_OIAIF", "OrignCdT", "Originator ToCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIAIF", "OrignNmT", "Originator ToName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OIAIF", "AuthoCdT", "Authorizer ToCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIAIF", "AuthoNmT", "Authorizer ToName", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OIAIF", "CardCdeT", "CardCode To", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OIAIF", "CardNmeT", "CardName To", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_OIAIF", "Reason", "Reason", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_OIAIF", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub InvoiceApprovalDetail1()
        Try
            oGFun.CreateTable("INS_IAIF1", "InvoiceApprovalDetail1", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_IAIF1", "Select", "Select All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_IAIF1", "DraftKey", "Draft Ke", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IAIF1", "CardCode", "Customer Cod", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IAIF1", "CardName", "Customer Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_IAIF1", "DocTotal", "DocTotal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_IAIF1", "DocDate", "DocDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_IAIF1", "TaxDate", "TaxDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_IAIF1", "DueDate", "DueDate", SAPbobsCOM.BoFieldTypes.db_Date)

            oGFun.CreateUserFields("@INS_IAIF1", "RequBy", "Requested By", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IAIF1", "Remark", "Remark", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_IAIF1", "AppStatus", "Approval Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_IAIF1", "Reason", "Rejection Reason", SAPbobsCOM.BoFieldTypes.db_Memo)


        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
#End Region

#Region "... ApprovalInterface........"

    Sub ApprovalInterface()
        Try
            Me.ApprovalInterfaceHead()
            Me.ApprovalInterfaceDetail1()
            If Not oGFun.UDOExists("OAIF") Then
                Dim FindField As String(,) = New String(,) {{"DocNum", "DocNum"}}
                oGFun.RegisterUDO("OAIF", "ApprovalInterface", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "INS_OAIF", "INS_AIF1")
                FindField = Nothing
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation ApprovalInterface ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try

    End Sub

    Sub ApprovalInterfaceHead()
        Try
            oGFun.CreateTable("INS_OAIF", "ApprovalInterfaceHead", SAPbobsCOM.BoUTBTableType.bott_Document)

            oGFun.CreateUserFields("@INS_OAIF", "DueDate", "DueDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OAIF", "ReqDate", "RequestDate From", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_OAIF", "ReqDateT", "RequestDate To", SAPbobsCOM.BoFieldTypes.db_Date)

            oGFun.CreateUserFields("@INS_OAIF", "Accept", "Accept All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_OAIF", "Reject", "Reject All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_OAIF", "Clear", "Clear All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_OAIF", "Select", "Select All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)

            oGFun.CreateUserFields("@INS_OAIF", "CardCode", "CardCode From", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OAIF", "CardName", "CardName From", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
            oGFun.CreateUserFields("@INS_OAIF", "CardCdeT", "CardCode To", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_OAIF", "CardNmeT", "CardName To", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_OAIF", "Reason", "Reason", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_OAIF", "Remarks", "Remarks", SAPbobsCOM.BoFieldTypes.db_Memo)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub ApprovalInterfaceDetail1()
        Try
            oGFun.CreateTable("INS_AIF1", "ApprovalInterfaceDetail1", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

            oGFun.CreateUserFields("@INS_AIF1", "Select", "Select All", SAPbobsCOM.BoFieldTypes.db_Alpha, 5)
            oGFun.CreateUserFields("@INS_AIF1", "DraftKey", "Draft Ke", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_AIF1", "CardCode", "Customer Cod", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_AIF1", "CardName", "Customer Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

            oGFun.CreateUserFields("@INS_AIF1", "DocTotal", "DocTotal", SAPbobsCOM.BoFieldTypes.db_Float, 0, SAPbobsCOM.BoFldSubTypes.st_Sum)

            oGFun.CreateUserFields("@INS_AIF1", "DocDate", "DocDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_AIF1", "TaxDate", "TaxDate", SAPbobsCOM.BoFieldTypes.db_Date)
            oGFun.CreateUserFields("@INS_AIF1", "DueDate", "DueDate", SAPbobsCOM.BoFieldTypes.db_Date)

            oGFun.CreateUserFields("@INS_AIF1", "RequBy", "Requested By", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_AIF1", "Remark", "Remark", SAPbobsCOM.BoFieldTypes.db_Memo)
            oGFun.CreateUserFields("@INS_AIF1", "AppStatus", "Approval Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_AIF1", "Reason", "Rejection Reason", SAPbobsCOM.BoFieldTypes.db_Memo)

            oGFun.CreateUserFields("@INS_AIF1", "InvNo", "InvNo", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@INS_AIF1", "InvEntry", "InvEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
#End Region

End Class


