﻿using Microsoft.VisualBasic;
using Shared;
using Shared.Models;
using System.Data.Common;

namespace SaPDISrv
{
	public class SAPB1DIS
	{
        public SAPB1DIS()
        {
			Logw.exefolder = AppDomain.CurrentDomain.BaseDirectory;

		}
		public string Login(string DataBaseServer, string DataBaseName, string DataBaseType, string DataBaseUserName, string DataBasePassword, string CompanyUserName, string CompanyPassword, string Language, string LicenseServer)
		{
			SBODI_Server.Node DISnode = null;
			string sSOAPans = null, sCmd = null;

			DISnode = new SBODI_Server.Node();

			sCmd = @"<?xml version=""1.0"" encoding=""UTF-16""?>";
			sCmd += @"<env:Envelope xmlns:env=""http://schemas.xmlsoap.org/soap/envelope/"">";
			sCmd += @"<env:Body><dis:Login xmlns:dis=""http://www.sap.com/SBO/DIS"">";
			sCmd += "<DatabaseServer>" + DataBaseServer + "</DatabaseServer>";
			sCmd += "<DatabaseName>" + DataBaseName + "</DatabaseName>";
			sCmd += "<DatabaseType>" + DataBaseType + "</DatabaseType>";
			sCmd += "<DatabaseUsername>" + DataBaseUserName + "</DatabaseUsername>";
			sCmd += "<DatabasePassword>" + DataBasePassword + "</DatabasePassword>";
			sCmd += "<CompanyUsername>" + CompanyUserName + "</CompanyUsername>";
			sCmd += "<CompanyPassword>" + CompanyPassword + "</CompanyPassword>";
			sCmd += "<Language>" + Language + "</Language>";
			sCmd += "<LicenseServer>" + LicenseServer + "</LicenseServer>"; // ILTLVH25
			sCmd += "</dis:Login></env:Body></env:Envelope>";

			sSOAPans = DISnode.Interact(sCmd);

			//  Parse the SOAP answer
			System.Xml.XmlValidatingReader xmlValid = null;
			string sRet = null;
			xmlValid = new System.Xml.XmlValidatingReader(sSOAPans, System.Xml.XmlNodeType.Document, null);
			while (xmlValid.Read())
			{
				if (xmlValid.NodeType == System.Xml.XmlNodeType.Text)
				{
					if (sRet == null)
					{
						sRet += xmlValid.Value;
					}
					else
					{
						if (sRet.StartsWith("Error"))
						{
							sRet += " " + xmlValid.Value;
						}
						else
						{
							sRet = "Error " + sRet + " " + xmlValid.Value;
						}
					}
				}
			}
			if (Strings.InStr(sSOAPans, "<env:Fault>", Microsoft.VisualBasic.CompareMethod.Text) != 0)
			{
				sRet = "Error: " + sRet;
			}
			return sRet;
		}
		public UserInfo Finduser(UserInfo user)
		{

			UserInfo newuser = new UserInfo();
			string qry = $"Select * From [@G_Mng] Where Code = '1'";
			SqlCommand SqlCmd = null;
			using (SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
			{
				using (SqlDataReader reader = SqlCmd.ExecuteReader())
				{
					if (reader.Read())
					{
						if (reader.HasRows)
						{
							try
							{
								newuser.Password = reader["U_APIpssw"].ToString();

								newuser.Password = Logw.Decrypt(newuser.Password, true);
							}
							catch { }
							newuser.UserId = reader["U_APIUser"].ToString();
							if (newuser.Password != user.Password || newuser.UserId != user.UserId)
								newuser = new UserInfo();
						}
					}
					cn.Close();

				}
			}
			return newuser;
		}


	}
}