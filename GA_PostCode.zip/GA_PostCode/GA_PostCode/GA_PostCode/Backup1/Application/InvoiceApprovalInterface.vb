Public Class InvoiceApprovalInterface

    Dim frmInvoiceApprovalInterface As SAPbouiCOM.Form
    Dim oMatrix1 As SAPbouiCOM.Matrix
    Dim oDBDSHeader, oDBDSDetail1, oDBDSDetail2 As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "OIAIF"
    Dim sDelRowMatrix As String = ""
    Dim row As Integer
    Dim boolFilterItem As Boolean = False
    Dim SubGridCurRow As Integer

    Dim GDays As Integer
    Public dtTemp As SAPbouiCOM.DataTable
    Dim TableCount As Integer = 0

    Sub LoadInvoiceApprovalInterface()
        Try
            oGfun.LoadXML(frmInvoiceApprovalInterface, InvoiceApprovalInterfaceFormID, InvoiceApprovalInterfaceXML)
            frmInvoiceApprovalInterface = oApplication.Forms.Item(InvoiceApprovalInterfaceFormID)
            oDBDSHeader = frmInvoiceApprovalInterface.DataSources.DBDataSources.Item("@INS_OIAIF")
            oDBDSDetail1 = frmInvoiceApprovalInterface.DataSources.DBDataSources.Item("@INS_IAIF1")

            oMatrix1 = frmInvoiceApprovalInterface.Items.Item("Matrix1").Specific

            'oMatrix1.Columns.Item("DocTotal").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto

            Me.DefineModesForFields()
            Me.InitForm()
        Catch ex As Exception
            oGfun.StatusBarWarningMsg("Load InvoiceApprovalInterface Form Failed")
        Finally
        End Try
    End Sub

    Sub DefineModesForFields()
        Try
            frmInvoiceApprovalInterface.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmInvoiceApprovalInterface.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmInvoiceApprovalInterface.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmInvoiceApprovalInterface.Items.Item("t_Duedate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmInvoiceApprovalInterface.Items.Item("t_Duedate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try
            frmInvoiceApprovalInterface.Freeze(True)
            oGfun.LoadComboBoxSeries(frmInvoiceApprovalInterface.Items.Item("c_series").Specific, UDOID, oDBDSHeader.GetValue("U_Duedate", 0), oCompany.UserSignature)
            oGfun.LoadDocumentDate(frmInvoiceApprovalInterface.Items.Item("t_Duedate").Specific)

            oGfun.SetNewLine(oMatrix1, oDBDSDetail1)
            'For i As Integer = 1 To oMatrix1.VisualRowCount
            '    oGfun.setComboBoxValue(oMatrix1.Columns.Item("AppStatus").Cells.Item(i).Specific, "P")
            'Next

            oMatrix1.AutoResizeColumns()

            frmInvoiceApprovalInterface.ActiveItem = "t_OriginNm"
            'oMatrix1.Clear()
            'oDBDSDetail1.Clear()
            'Dim Str As String = "Select * From ODRF"
            'Me.LoadDraft(Str)
            frmInvoiceApprovalInterface.Items.Item("b_Load").Click()
            sQuery = String.Empty
            sQuery = "SELECT  * FROM OUSR WHERE ""USERID""='" & oCompany.UserSignature & "' and IFNULL(""U_InvApp"",'N')='Y'"
            Dim RstChkUser As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            If RstChkUser.RecordCount = 0 Then
                frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
            End If

            frmInvoiceApprovalInterface.Freeze(False)
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            frmInvoiceApprovalInterface.Freeze(False)
        Finally
        End Try
    End Sub
    Function ValidateAll() As Boolean
        Try
            Return True

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            ValidateAll = False
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False Then
                            Select Case pVal.ItemUID
                                Case "t_OriginNm"
                                    'oDBDSHeader.SetValue("U_OriginCd", 0, oDataTable.GetValue("USERID", 0))
                                    oDBDSHeader.SetValue("U_OriginNm", 0, oDataTable.GetValue("USER_CODE", 0))
                                Case "t_AuthoNm"
                                    'oDBDSHeader.SetValue("U_AuthoCd", 0, oDataTable.GetValue("USERID", 0))
                                    oDBDSHeader.SetValue("U_AuthoNm", 0, oDataTable.GetValue("USER_CODE", 0))
                                Case "t_CardCdeT"
                                    oDBDSHeader.SetValue("U_CardCdeT", 0, oDataTable.GetValue("CardCode", 0))
                                    'oDBDSHeader.SetValue("U_CardNmeT", 0, oDataTable.GetValue("CardName", 0))
                                Case "t_OrignNmT"
                                    'oDBDSHeader.SetValue("U_OrignCdT", 0, oDataTable.GetValue("USERID", 0))
                                    oDBDSHeader.SetValue("U_OrignNmT", 0, oDataTable.GetValue("USER_CODE", 0))
                                Case "t_AuthoNmT"
                                    'oDBDSHeader.SetValue("U_AuthoCdT", 0, oDataTable.GetValue("USERID", 0))
                                    oDBDSHeader.SetValue("U_AuthoNmT", 0, oDataTable.GetValue("USER_CODE", 0))
                                Case "t_CardCode"
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    'oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))

                                Case "t_apinv1"
                                    oDBDSHeader.SetValue("U_APDocNum", 0, oDataTable.GetValue("DocNum", 0))
                                    oDBDSHeader.SetValue("U_APDocEntry", 0, oDataTable.GetValue("DocEntry", 0))
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_Curency", 0, oDataTable.GetValue("DocCur", 0))

                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    Dim sQuery As String = "Select a.""ItemCode"",b.""WhsCode"",a.""INMPrice"",a.""StockSum"",a.""StockSumSc"",a.""Quantity"",a.""LineNum"",a.""UomCode"",a.""OcrCode"" from pch1 a inner join oitw b on a.""ItemCode""=b.""ItemCode"" and b.""WhsCode""=a.""WhsCode"""
                                    sQuery += " where ""DocEntry"" ='" & oDataTable.GetValue("DocEntry", 0) & "' "
                                    Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    rset.MoveFirst()
                                    If rset.RecordCount > 0 Then
                                        For j As Integer = 1 To rset.RecordCount
                                            oApplication.StatusBar.SetText("Please Wait System checking & Loading Data " & j & " Out Of " & rset.RecordCount & "......", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                                            oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                                            oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                                            oDBDSDetail1.SetValue("U_ItemCode", oDBDSDetail1.Offset, rset.Fields.Item("ItemCode").Value)
                                            oDBDSDetail1.SetValue("U_Quantity", oDBDSDetail1.Offset, rset.Fields.Item("Quantity").Value)
                                            oDBDSDetail1.SetValue("U_Docprice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_DocValue", oDBDSDetail1.Offset, rset.Fields.Item("StockSum").Value)
                                            oDBDSDetail1.SetValue("U_WhsPrice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_Total", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_BaseEntry", oDBDSDetail1.Offset, oDataTable.GetValue("DocEntry", 0))
                                            oDBDSDetail1.SetValue("U_BaseNum", oDBDSDetail1.Offset, oDataTable.GetValue("DocNum", 0))
                                            oDBDSDetail1.SetValue("U_BaseLine", oDBDSDetail1.Offset, rset.Fields.Item("LineNum").Value)
                                            oDBDSDetail1.SetValue("U_FobnLac", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_Warehous", oDBDSDetail1.Offset, rset.Fields.Item("WhsCode").Value)
                                            oDBDSDetail1.SetValue("U_DistrRule", oDBDSDetail1.Offset, rset.Fields.Item("OcrCode").Value)
                                            oDBDSDetail1.SetValue("U_UoMCode", oDBDSDetail1.Offset, rset.Fields.Item("UomCode").Value)
                                            rset.MoveNext()
                                        Next
                                    End If
                                    oMatrix1.LoadFromDataSource()
                                    oApplication.StatusBar.SetText("Operation completed....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                Case "Matrix1"
                                    Select Case pVal.ColUID
                                        Case "Project"
                                            oMatrix1.FlushToDataSource()
                                            oDBDSDetail1.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue("PrjCode", 0))
                                            'oDBDSDetail1.SetValue("U_Sizename", pVal.Row - 1, oDataTable.GetValue("U_Clrname", 0))
                                            oMatrix1.LoadFromDataSource()
                                            oMatrix1.AutoResizeColumns()
                                            oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End Select
                            End Select
                        End If
                    Catch ex As Exception
                        frmInvoiceApprovalInterface.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            Case "Matrix1"
                                Select Case pVal.ColUID
                                    Case "DraftKey"
                                        If pVal.BeforeAction = False Then
                                            oGfun.SetNewLine(oMatrix1, oDBDSDetail1, pVal.Row, pVal.ColUID)
                                        End If
                                End Select

                        End Select
                    Catch ex As Exception
                        frmInvoiceApprovalInterface.Freeze(False)
                        oApplication.StatusBar.SetText("Lost focus event fail", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "t_Vat1", "t_Vat2"
                                If pVal.BeforeAction = False Then
                                    Dim Vat2 As Double = 0.0
                                    Dim Vat1 As Double = 0.0
                                    Vat2 = CDbl(frmInvoiceApprovalInterface.Items.Item("t_Vat2").Specific.value)
                                    Vat1 = CDbl(frmInvoiceApprovalInterface.Items.Item("t_Vat1").Specific.value)
                                    Dim Sum1 As Double = 0.0
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        Dim a As Double = CDbl(oMatrix1.Columns.Item("Total").Cells.Item(i).Specific.value)
                                        Sum1 += a
                                    Next

                                    oDBDSHeader.SetValue("U_BeforeVat", 0, (Sum1))
                                    oDBDSHeader.SetValue("U_DocTotal", 0, (Sum1 + Vat1 + Vat2))
                                End If
                            Case "Matrix1"
                                Select Case pVal.ColUID

                                    Case "ProjCust", "Expendi"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmInvoiceApprovalInterface.Freeze(True)
                                            oMatrix1.FlushToDataSource()
                                            Dim ProjCust As Double = 0.0
                                            'Dim CusValue As Double = 0.0
                                            Dim Expendi As Double = 0.0
                                            ' Dim CosValue As Double = 0.0
                                            Dim WhsPrice As Double = 0.0
                                            Dim TotaCost As Double = 0.0
                                            Dim Quantity As Double = 0.0
                                            Dim DocValue As Double = 0.0

                                            DocValue = CDbl(oMatrix1.Columns.Item("DocValue").Cells.Item(pVal.Row).Specific.value)
                                            ProjCust = CDbl(oMatrix1.Columns.Item("ProjCust").Cells.Item(pVal.Row).Specific.value)
                                            Quantity = CDbl(oMatrix1.Columns.Item("Quantity").Cells.Item(pVal.Row).Specific.value)
                                            ' CusValue = CDbl(oMatrix1.Columns.Item("CusValue").Cells.Item(pVal.Row).Specific.value)
                                            Expendi = CDbl(oMatrix1.Columns.Item("Expendi").Cells.Item(pVal.Row).Specific.value)
                                            'CosValue = CDbl(oMatrix1.Columns.Item("CosValue").Cells.Item(pVal.Row).Specific.value)


                                            oDBDSDetail1.SetValue("U_CusValue", pVal.Row - 1, (Quantity * ProjCust))
                                            'oDBDSDetail1.SetValue("U_ProjCust", pVal.Row - 1, (CusValue / Quantity))
                                            oDBDSDetail1.SetValue("U_CosValue", pVal.Row - 1, (Quantity * Expendi))
                                            'oDBDSDetail1.SetValue("U_Expendi", pVal.Row - 1, (CosValue / Quantity))


                                            oDBDSDetail1.SetValue("U_WhsPrice", pVal.Row - 1, (DocValue + ((Quantity * ProjCust) + (Quantity * Expendi))))
                                            oDBDSDetail1.SetValue("U_Total", pVal.Row - 1, (DocValue + ((Quantity * ProjCust) + (Quantity * Expendi))))
                                            oDBDSDetail1.SetValue("U_TotaCost", pVal.Row - 1, ((Quantity * ProjCust) + (Quantity * Expendi)))
                                            oMatrix1.LoadFromDataSource()
                                            oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            frmInvoiceApprovalInterface.Freeze(False)
                                            Dim total As Double = 0.0
                                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                                Dim a As Double = CDbl(oMatrix1.Columns.Item("CosValue").Cells.Item(i).Specific.value)
                                                total += a
                                            Next

                                            oDBDSHeader.SetValue("U_CostSum", 0, (total))
                                            oDBDSHeader.SetValue("U_AmtBal", 0, (-total))
                                            Dim sum As Double = 0.0
                                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                                Dim a As Double = CDbl(oMatrix1.Columns.Item("CusValue").Cells.Item(i).Specific.value)
                                                sum += a
                                            Next

                                            oDBDSHeader.SetValue("U_ExpCustom", 0, (sum))
                                            oDBDSHeader.SetValue("U_ActCustom", 0, (sum))
                                            Dim Vat2 As Double = 0.0
                                            Dim Vat1 As Double = 0.0
                                            Vat2 = CDbl(frmInvoiceApprovalInterface.Items.Item("t_Vat2").Specific.value)
                                            Vat1 = CDbl(frmInvoiceApprovalInterface.Items.Item("t_Vat1").Specific.value)
                                            Dim Sum1 As Double = 0.0
                                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                                Dim a As Double = CDbl(oMatrix1.Columns.Item("Total").Cells.Item(i).Specific.value)
                                                Sum1 += a
                                            Next

                                            oDBDSHeader.SetValue("U_BeforeVat", 0, (Sum1))
                                            oDBDSHeader.SetValue("U_DocTotal", 0, (Sum1 + Vat1 + Vat2))
                                            'oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        End If

                                End Select
                        End Select
                    Catch ex As Exception
                        frmInvoiceApprovalInterface.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub
                                    End If
                                End If
                            Case "b_Load"
                                If pVal.BeforeAction Then
                                    frmInvoiceApprovalInterface.Freeze(True)
                                    'Dim FromDate As String = oDBDSHeader.GetValue("U_FromDate", 0).Trim
                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    Dim Str As String = "CALL ""@INSPL_APPROVAL_GET_DRAFTDETAILS"" ('" & oDBDSHeader.GetValue("U_OriginNm", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_OrignNmT", 0).Trim & "','" & oDBDSHeader.GetValue("U_AuthoNm", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_AuthoNmT", 0).Trim & "','" & oDBDSHeader.GetValue("U_ReqDate", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_ReqDateT", 0).Trim & "','" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_CardCdeT", 0).Trim & "','" & oCompany.UserSignature & "')"
                                    'Dim Str As String = "SELECT Top 10 * FROM ODRF"

                                    Me.LoadDraft(Str)
                                    oMatrix1.LoadFromDataSource()
                                    frmInvoiceApprovalInterface.Freeze(False)
                                End If

                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Click Event Failed:" & ex.Message)
                        frmInvoiceApprovalInterface.Freeze(False)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK
                    Try
                        Select Case pVal.ItemUID

                        End Select
                        Select Case pVal.ItemUID
                            Case "Matrix1"
                                If pVal.BeforeAction = False Then oGfun.OpenAttachment(oMatrix1, oDBDSDetail1, pVal.Row)
                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Item Double Click Event Failed : " & ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "c_series"
                                If frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    'Get the Serial Number Based On Series...
                                    Dim oCmbSerial As SAPbouiCOM.ComboBox = frmInvoiceApprovalInterface.Items.Item("c_series").Specific
                                    Dim strSerialCode As String = oCmbSerial.Selected.Value
                                    Dim strDocNum As Long = frmInvoiceApprovalInterface.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                                    oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                                End If
                        End Select
                    Catch ex As Exception
                        frmInvoiceApprovalInterface.Freeze(False)
                        oGfun.StatusBarErrorMsg("Combobox Event Failed")
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.ActionSuccess And frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If

                            Case "b_Copy"
                                If pVal.Before_Action = False Then
                                    'Me.CreateMySimpleForm()
                                End If
                            Case "t_Select"
                                If pVal.BeforeAction = False Then
                                    frmInvoiceApprovalInterface.Freeze(True)
                                    Dim isAvail As Boolean = False
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        oGfun.StatusBarWarningMsg("Please Wait !!!!!!! System is Reflect (Select All OR UnSelect All) Hide Header to line--'" & i & "'Out of'" & oMatrix1.VisualRowCount - 1 & "'")

                                        Dim chk As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Select").Specific
                                        Dim Checkhide As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific

                                        If chk.Checked = True Then
                                            If oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                                Checkhide.Checked = True
                                            End If
                                        Else
                                            Checkhide.Checked = False
                                        End If
                                    Next
                                    oGfun.StatusBarWarningMsg("Operation Completed.....")
                                    frmInvoiceApprovalInterface.Freeze(False)
                                End If
                            Case "t_Accept"
                                If pVal.BeforeAction = False Then
                                    'oDBDSHeader.SetValue("U_Accept", 0, "")
                                    oDBDSHeader.SetValue("U_Reject", 0, "")
                                    oDBDSHeader.SetValue("U_Clear", 0, "")
                                    frmInvoiceApprovalInterface.Freeze(True)
                                    oMatrix1.FlushToDataSource()
                                    Dim chk As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Accept").Specific
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        oGfun.StatusBarWarningMsg("Please Wait !!!!!!! System updating Line : " & i & " OutOf " & oMatrix1.VisualRowCount)
                                        Dim Chec As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific
                                        If Chec.Checked = True And chk.Checked = True And oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                            oDBDSDetail1.SetValue("U_AppStatus", i - 1, "A")
                                        ElseIf Chec.Checked = True And chk.Checked = False And oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                            oDBDSDetail1.SetValue("U_AppStatus", i - 1, "P")
                                        End If
                                    Next
                                    oGfun.StatusBarWarningMsg("Operation Completed.....")
                                    oMatrix1.LoadFromDataSource()
                                    frmInvoiceApprovalInterface.Freeze(False)
                                End If
                            Case "t_Reject"
                                If pVal.BeforeAction = False Then
                                    oDBDSHeader.SetValue("U_Accept", 0, "")
                                    '' oDBDSHeader.SetValue("U_Reject", 0, "")
                                    oDBDSHeader.SetValue("U_Clear", 0, "")
                                    frmInvoiceApprovalInterface.Freeze(True)
                                    oMatrix1.FlushToDataSource()
                                    Dim chk As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Reject").Specific
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        oGfun.StatusBarWarningMsg("Please Wait !!!!!!! System updating Line : " & i & " OutOf " & oMatrix1.VisualRowCount)
                                        Dim Chec As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific
                                        If Chec.Checked = True And chk.Checked = True And oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                            oDBDSDetail1.SetValue("U_AppStatus", i - 1, "R")
                                        ElseIf Chec.Checked = True And chk.Checked = False And oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                            oDBDSDetail1.SetValue("U_AppStatus", i - 1, "P")
                                        End If
                                    Next
                                    oGfun.StatusBarWarningMsg("Operation Completed.....")
                                    oMatrix1.LoadFromDataSource()
                                    frmInvoiceApprovalInterface.Freeze(False)
                                End If
                            Case "t_Clear"
                                If pVal.BeforeAction = False Then
                                    oDBDSHeader.SetValue("U_Accept", 0, "")
                                    oDBDSHeader.SetValue("U_Reject", 0, "")
                                    ''oDBDSHeader.SetValue("U_Clear", 0, "")
                                    frmInvoiceApprovalInterface.Freeze(True)
                                    oMatrix1.FlushToDataSource()
                                    Dim chk As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Clear").Specific
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        oGfun.StatusBarWarningMsg("Please Wait !!!!!!! System updating Line : " & i & " OutOf " & oMatrix1.VisualRowCount)
                                        Dim Chec As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific
                                        If Chec.Checked = True And chk.Checked = True And oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                            oDBDSDetail1.SetValue("U_AppStatus", i - 1, "P")
                                        ElseIf Chec.Checked = True And chk.Checked = False And oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                            oDBDSDetail1.SetValue("U_AppStatus", i - 1, "P")
                                        End If
                                    Next
                                    oGfun.StatusBarWarningMsg("Operation Completed.....")
                                    oMatrix1.LoadFromDataSource()
                                    frmInvoiceApprovalInterface.Freeze(False)
                                End If
                        End Select
                    Catch ex As Exception
                        frmInvoiceApprovalInterface.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
            End Select

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub LoadDraft(ByVal Str As String)
        'Dim BillAmt As Double = 0.0, BeforeDisc As Double = 0.0, AfterDisc As Double = 0.0, Doctotal As Double = 0.0, VatSum As Double = 0.0, RoundDif As Double = 0.0, DiscSum As Double = 0.0

        Try

            Dim Rset1 As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

            For i As Integer = 1 To Rset1.RecordCount
                oGfun.StatusBarWarningMsg("Please Wait !!!!!!! Draft Details List Loading Please Wait--'" & i & "'Out of'" & Rset1.RecordCount & "'")

                oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                oDBDSDetail1.SetValue("U_DraftKey", oDBDSDetail1.Offset, Rset1.Fields.Item("DocEntry").Value)
                oDBDSDetail1.SetValue("U_CardCode", oDBDSDetail1.Offset, Rset1.Fields.Item("CardCode").Value)
                oDBDSDetail1.SetValue("U_CardName", oDBDSDetail1.Offset, Rset1.Fields.Item("CardName").Value)
                oDBDSDetail1.SetValue("U_DocDate", oDBDSDetail1.Offset, CDate(Rset1.Fields.Item("DocDate").Value).ToString("yyyyMMdd"))
                oDBDSDetail1.SetValue("U_TaxDate", oDBDSDetail1.Offset, CDate(Rset1.Fields.Item("TaxDate").Value).ToString("yyyyMMdd"))
                oDBDSDetail1.SetValue("U_DueDate", oDBDSDetail1.Offset, CDate(Rset1.Fields.Item("DocDueDate").Value).ToString("yyyyMMdd"))
                oDBDSDetail1.SetValue("U_DocTotal", oDBDSDetail1.Offset, Rset1.Fields.Item("DocTotal").Value)

                oDBDSDetail1.SetValue("U_RequBy", oDBDSDetail1.Offset, Rset1.Fields.Item("USER_CODE").Value)
                oDBDSDetail1.SetValue("U_Remark", oDBDSDetail1.Offset, Rset1.Fields.Item("U_AppRemarks").Value)

                Dim chkA As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Accept").Specific
                Dim chkR As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Reject").Specific
                Dim chkP As SAPbouiCOM.CheckBox = frmInvoiceApprovalInterface.Items.Item("t_Clear").Specific
                'Dim Checkhide As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific
                'If oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then

                If chkA.Checked = True And chkR.Checked = False And chkP.Checked = False Then
                    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "A")
                ElseIf chkA.Checked = False And chkR.Checked = True And chkP.Checked = False Then
                    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "R")
                ElseIf chkA.Checked = False And chkR.Checked = False And chkP.Checked = True Then
                    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "P")
                Else
                    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "P")
                End If

                Rset1.MoveNext()
            Next
            oMatrix1.LoadFromDataSource()
            oGfun.StatusBarWarningMsg("Operation Completed.....")

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        End Try
    End Sub
    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1281"
                    frmInvoiceApprovalInterface.ActiveItem = ("t_docnum")
                Case "1293"
                    Select Case sDelRowMatrix
                        Case "Matrix1"
                            oGfun.DeleteRow(oMatrix1, oDBDSDetail1)

                    End Select

                Case "1282"
                    Me.InitForm()
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If ValidateAll() = False Then
                                BubbleEvent = False
                                Exit Sub
                            End If
                        End If
                        If BusinessObjectInfo.ActionSuccess Then
                            Me.Post_Transaction_Notification()
                        End If
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    Try
                        If BusinessObjectInfo.ActionSuccess Then
                            If frmInvoiceApprovalInterface.Mode <> SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
                            Else
                                frmInvoiceApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form data load event fail...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub Post_Transaction_Notification()

        Dim RsetUpdate As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim sQuery As String = String.Empty
        sQuery = "UPDATE A SET A.""U_Approval""= B.""U_AppStatus"" FROM  ODRF A, ""@INS_IAIF1"" B WHERE A.""DocEntry""=IFNULL(B.""U_DraftKey"",0)"
        sQuery += " AND B.""U_Select""='Y' and IFNULL(A.""U_Approval"",'O')<>'C' AND B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
        RsetUpdate.DoQuery(sQuery)

        sQuery = String.Empty
        sQuery = " UPDATE B SET B.""U_Status""=C.""U_AppStatus"" FROM ODRF A,""@INS_INV1"" B,""@INS_IAIF1"" C "
        sQuery += " WHERE A.""U_BaseEntry""=CAST(B.""DocEntry"" AS NVARCHAR(50))"
        sQuery += " AND A.""DocEntry""=CAST(C.""U_DraftKey"" AS NVARCHAR(50)) AND IFNULL(C.""U_Select"",'N')='Y'"
        sQuery += " AND CAST(A.""U_BaseLine"" AS NVARCHAR(50))=B.""LineId""  AND A.""U_BaseType""='OINV' "
        sQuery += " and C.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' "
        RsetUpdate.DoQuery(sQuery)
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    sDelRowMatrix = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                        Case "Matrix1"
                            If EventInfo.Row = oMatrix1.VisualRowCount Then
                                frmInvoiceApprovalInterface.EnableMenu("1293", False)
                            Else
                                frmInvoiceApprovalInterface.EnableMenu("1293", True)
                            End If
                    End Select
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

End Class