﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
    public class ProgData
    {
        public static SAPbobsCOM.Company B1Company = null;
        public static SAPbouiCOM.Application B1Application = null;
        public static string sqlConnectionString;
      

        public static Dictionary<String, IBForm> Forms;
        public static string getConnectionString()
        {
			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			string qry = $"Select U_TrcDBSrv,U_TrcDBName,U_TrcDBUser,U_TrcDBpssw FROM \"@G_Mng\"";
			rs.DoQuery(qry);
			string f4 = rs.Fields.Item("U_TrcDBSrv").Value.ToString();
			string f5 = rs.Fields.Item("U_TrcDBName").Value.ToString();
			string f6 = rs.Fields.Item("U_TrcDBUser").Value.ToString();
			string f7 = rs.Fields.Item("U_TrcDBpssw").Value.ToString();
			string f77 = Logger.Decrypt(f7, true);
			ProgData.sqlConnectionString = $"Server = {f4}; Database = {f5}; User Id = {f6}; Password = {f77};";
			return ProgData.sqlConnectionString;
		}


    }

}
