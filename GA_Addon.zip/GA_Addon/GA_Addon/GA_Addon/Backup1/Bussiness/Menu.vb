﻿
''' <summary>
''' This Application Sarted from here
''' This is Used for to connect the SAP and dot net console
''' And create menu
''' 1)SetApplication
'''  It is used to get connection to SAP.
'''  Here we are using SAPbouiCOM.SboGuiApi, it is part of the SAP Business One Software Development Kit (SDK), and exposes user 
'''  Collection elements of the SAP Business One front end
''' 2)SetFilter
'''   Sets an EventFilter object that filters in events on specific forms
''' 3)CookieConnect
'''  It is represent the one of the Company Data base
'''  It is enable to connect the company and Create the Business Object to use the company data base
''' 4)ConnectionContext
'''   It is used for to connect the company
''' 5)TableCreation
'''   It is used for to craete user tables and user define objects
''' 6)SetEventFilter
'''   User to filder the events for particilar forms
'''   it is used to high performance 
''' 7)AddXML
'''   It is used to add memu XML 
''' </summary>
''' <remarks></remarks>
''' 

Module Menu


#Region "... Main ..."

    Sub Main()
        Try

            'Welcom.Show()
            oGfun.SetApplication() '1)
            ' oApplication.SetFilter(New SAPbouiCOM.EventFilter) '2)
            If Not oGfun.CookieConnect() = 0 Then '3)
                oApplication.MessageBox("DI Api Conection Failed")
                End
            End If
            If Not oGfun.ConnectionContext() = 0 Then '4)
                oApplication.MessageBox("Failed to Connect Company")
                End
            End If
            'Welcom.Close()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("Application Not Found", AddOnName)
            System.Windows.Forms.Application.ExitThread()
        Finally
        End Try
        Try
            Try


                '**********************************************************************

                Dim Day As Integer = 31
                Dim Month As Integer = 5
                Dim Year As Integer = 2021

                Dim EndDate As New Date(Year, Month, Day)
                Dim CurrDate As Date = Now()
                Dim DayDiff As Integer = DateDiff(DateInterval.Day, CurrDate, EndDate)
                If DayDiff <= 15 And DayDiff > 0 Then
                    oApplication.MessageBox("Addon will be expired on : " & EndDate)
                    oApplication.StatusBar.SetText("Addon will be expired on : " & EndDate, SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                ElseIf DayDiff < 0 Then
                    oApplication.StatusBar.SetText("Addon expired, Please Contact Indus Team.....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    oApplication.MessageBox("Addon not connected : Addon expired, Please Contact Indus Team.....")
                    Exit Sub
                End If

                '**********************************************************************


                '---------------------- Hardware key Checking with SAP Help Menu-----------------------

                'Dim oForm As SAPbouiCOM.Form
                'oApplication.ActivateMenuItem("257")
                'oForm = oApplication.Forms.Item(oApplication.Forms.ActiveForm.UniqueID)
                'Dim HKEY As String = oForm.Items.Item("79").Specific.value
                'oForm.Close()

                'oApplication.StatusBar.SetText("Checking Indus Add-On License.......", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                ''Dim HKEY As String = oCompany.GetHardwareKey()
                'Dim HWKeyCheck As Boolean = False
                'If HKEY.Trim.Equals("T1894274141") = True Or HKEY.Trim.Equals("S1130340398") = True Then
                '    HWKeyCheck = True
                'Else
                '    HWKeyCheck = False
                'End If

                'If HWKeyCheck = False Then
                '    If oCompany.Connected Then oCompany.Disconnect()
                '    System.Windows.Forms.Application.Exit()
                '    oApplication.StatusBar.SetText("Failed to Connect Add-On Due to License Mismatch", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                'End If

                '**********************************************************************


                Dim oTableCreation As New TableCreation     '5)              
                EventHandler.SetEventFilter()               '6)
                oGfun.AddXML("Menu.xml")                    '7)
                Dim oMeniItem As SAPbouiCOM.MenuItem = EventHandler.oApplication.Menus.Item("OITMC")
                oMeniItem.Image = System.Windows.Forms.Application.StartupPath & "\icons8-process-15.png"

            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show(ex.Message)
                System.Windows.Forms.Application.ExitThread()
            Finally
            End Try
            oApplication.StatusBar.SetText("Connected.......", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            System.Windows.Forms.Application.Run()
        Catch ex As Exception
            oApplication.StatusBar.SetText(AddOnName & "Main Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub
#End Region

End Module
