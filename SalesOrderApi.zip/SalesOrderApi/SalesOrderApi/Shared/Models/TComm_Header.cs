﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class TComm_Header
	{
		public string CustomerPoNumber { get; set; }
		public string Customer { get; set; }
		public string CustomerName { get; set; }
		public string OrderDate { get; set; }
		public string ShipAddress1 { get; set; }
		public string ShipAddress2 { get; set; }
		public string ShipAddress3 { get; set; }
		public string ShipAddress4 { get; set; }
		public string ShipPostalCode { get; set; }
		public string RequestedShipDate { get; set; }
		public string Branch { get; set; }	
		public string DocRef { get; set; }
		public string Status { get; set; }
		public string Message { get; set; }
		public DateOnly ImportDate { get; set; }
		public TimeOnly ImportTime { get; set; }
		public string AR { get; set; }
		public string AppUser { get; set; }
		public DateOnly App_Date { get; set; }
		public TimeOnly App_Time { get; set; }
		public string CardCode { get; set; }

	}
	public class TComm_Lines
	{
		public string CustomerPoNumber { get; set; }
		public string CustomerPoLine { get; set; }
	
		public string StockCode { get; set; }
		public string StockDescription { get; set; }
		public string OrderQty { get; set; }
		public string Price { get; set; }
		public string Comment { get; set; }
		public string Status { get; set; }
		public string Message { get; set; }

	}
}
