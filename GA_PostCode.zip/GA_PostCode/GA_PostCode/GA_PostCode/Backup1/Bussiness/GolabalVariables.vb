﻿''' <summary>
''' GGlobally whatever variable do you want declare here 
''' We can use any class and module from here  
''' </summary>
''' <remarks></remarks>
Module GolabalVariables



#Region " ... Common For SAP ..."
    Public oCompany As SAPbobsCOM.Company
    Public oGfun As New GlobalFunctions
    'Public oDBFun As New DataBase_Proc_Functions
    Public oForm As SAPbouiCOM.Form
    Public AddOnName As String = "Item Creation"
    Public ErrCode As Long
    Public ErrMsg As String = ""
    Public oCompanySrv As SAPbobsCOM.CompanyService


#End Region

#Region " ... Common For Forms ..."
    'Import
    Public ImportFormID As String = "OIMP"
    Public ImportXML As String = "ImportExl.XML"
    Public ImportCreation As New clsImport
    
    'ItemCreation
    Public ItemCreationFormID As String = "OITM"
    Public ItemCreationXML As String = "ItemCreation.xml"
    Public oItemCreation As New ItemCreation

    'ColorSizeMaster
    Public ColorSizeMasterFormID As String = "OCSM"
    Public ColorSizeMasterXML As String = "ColorSizeMaster.xml"
    Public oColorSizeMaster As New ColorSizeMaster

    'HS Master
    Public HSMasterFormID As String = "OHSM"
    Public HSMasterXML As String = "HSMaster.xml"
    Public oHSMaster As New HSMaster

    'Sales Order
    Public oSalesOrder As New SalesOrder
    Public SalesOrderTypeEx As String = "139"

    'SaleOrderNew
    Public SaleOrderNewFormID As String = "ORDR"
    Public SaleOrderNewXML As String = "SaleOrderNew.xml"
    Public oSaleOrderNew As New SaleOrderNew

    'LandedCosts
    Public LandedCostsFormID As String = "OIPF"
    Public LandedCostsXML As String = "LandedCosts.xml"
    Public oLandedCosts As New LandedCosts

    Public FrieghtChargesSubFormID As String = "OFRC"
    Public FrieghtChargesSubXML As String = "FrieghtCharges.xml"

    'Sale Invoice 
    Public SalesInvoiceFormID As String = "OINV1"
    Public SalesInvoiceXML As String = "SalesInvoice.xml"
    Public oSalesInvoice As New SalesInvoice


    'BP Master
    Public oBPMaster As New BPMaster
    Public BPMasterTypeEx As String = "134"

    'Item Master
    Public oItemMaster As New ItemMaster
    Public ItemMasterTypeEx As String = "150"

    'Account Master
    Public oAccountMaster As New AccountMaster
    Public AccountMasterTypeEx As String = "804"

    'InvoiceApprovalInterface
    Public InvoiceApprovalInterfaceFormID As String = "OIAIF"
    Public InvoiceApprovalInterfaceXML As String = "InvoiceApprovalInterface.xml"
    Public oInvoiceApprovalInterface As New InvoiceApprovalInterface

    'ApprovalInterface
    Public ApprovalInterfaceFormID As String = "OAIF"
    Public ApprovalInterfaceXML As String = "ApprovalInterface.xml"
    Public oApprovalInterface As New ApprovalInterface

#End Region

#Region " ... Gentral Purpose ..."

    Public v_RetVal, v_ErrCode As Long
    Public v_ErrMsg As String = ""
    'Attachment Option
    Public ShowFolderBrowserThread As Threading.Thread
    Public BankFileName As String
    Public boolModelForm As Boolean = False
    Public boolModelFormID As String = ""
    Public ShouldNotErrorMsg As String = " Should Not be Left Empty"
    Public sQuery As String = ""
    Public boolTripStatusCanceled As Boolean = False

#End Region

End Module
