﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using SAPProc;
using Shared;
using Shared.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace SalesOrderApi.Controllers
{
	[ApiController]
	public class UserController : ControllerBase
	{
		private readonly ISapB1 _SapB1;
		public UserController(ISapB1 sapB1)
		{
			_SapB1 = sapB1;
		}


		[HttpPost("login")]
		public UserInfo Login(UserInfo _userData)
		{
			var user = _SapB1.Finduser(_userData);
			if (user != null && !String.IsNullOrEmpty(user.UserId) && !String.IsNullOrEmpty(user.Password))
			{

				var claim = new List<Claim>
			{
				new Claim(JwtRegisteredClaimNames.NameId,_userData.UserId)
			};

				var cred = new SigningCredentials(Logw.getTKey(), SecurityAlgorithms.HmacSha512Signature);

				var tokenDesciptor = new SecurityTokenDescriptor
				{
					Subject = new ClaimsIdentity(claim),
					Expires = DateTime.Now.AddMinutes(10),
					Issuer = Logw.Issuer,
					Audience = Logw.Audience,
					SigningCredentials = cred

				};

				var tokenHandler = new JwtSecurityTokenHandler();

				var token = tokenHandler.CreateToken(tokenDesciptor);

				user.Token = tokenHandler.WriteToken(token);


			}
			return user;

			
		}


	}
}
