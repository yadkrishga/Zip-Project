Public Class SalesQuotation
    Dim frmSaleQuot, frmGloSaleOrder As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer
    Dim GblDocEntry As String = ""
    Dim GblSelRow As Integer = 0
    Dim GblSelRow1 As Integer = 0
    Dim GblItemCode As String = ""
    Dim GblPlanQty As Double = 0
    Dim GblLineNum As Integer = 0
    Dim GblWhse As String = ""
    Dim GblModel As String = ""
    Dim GblSQuery2 As String = ""



    Sub LoadSaleOrder(ByVal FormUID As String)
        Try
            boolFormLoaded = False
            Dim oItem As SAPbouiCOM.Item
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oComboBox As SAPbouiCOM.ComboBox
            Dim oEditText As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource

            frmSaleQuot = oApplication.Forms.Item(FormUID)
            frmGloSaleOrder = oApplication.Forms.Item(FormUID)

            oMatrix = frmSaleQuot.Items.Item("38").Specific
            oDBDSHeader = frmSaleQuot.DataSources.DBDataSources.Item("OQUT")
            oDBDSDetail = frmSaleQuot.DataSources.DBDataSources.Item("QUT1")


            frmSaleQuot.Freeze(True)

            ' Purchase Indent Copy From Button ...
            '------------------------------------

            oItem = frmSaleQuot.Items.Add("s_GA_Post", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmSaleQuot.Items.Item("70").Left
            oItem.Width = frmSaleQuot.Items.Item("70").Width
            oItem.Height = frmSaleQuot.Items.Item("70").Height
            oItem.Top = frmSaleQuot.Items.Item("70").Top + frmSaleQuot.Items.Item("70").Height + 20
            oItem.Visible = True
            oItem.Enabled = True
            oItem.LinkTo = "70"
            oLabel = oItem.Specific
            oLabel.Caption = "Postcode"

            oItem = frmSaleQuot.Items.Add("e_GA_Post", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = frmSaleQuot.Items.Item("s_GA_Post").Left + frmSaleQuot.Items.Item("s_GA_Post").Width - 15
            oItem.Width = frmSaleQuot.Items.Item("s_GA_Post").Width - 40
            oItem.Height = frmSaleQuot.Items.Item("s_GA_Post").Height
            oItem.Top = frmSaleQuot.Items.Item("s_GA_Post").Top
            oItem.Visible = True
            oItem.Enabled = True
            oItem.LinkTo = "s_GA_Post"
            oEditText = oItem.Specific

            ' oUserdatasource = frmSaleQuot.DataSources.UserDataSources.Add("U_Post", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditText.DataBind.SetBound(True, "OQUT", "U_GA_Post")

            oItem = frmSaleQuot.Items.Add("b_GA_Post", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmSaleQuot.Items.Item("e_GA_Post").Left + frmSaleQuot.Items.Item("e_GA_Post").Width + 5
            oItem.Width = frmSaleQuot.Items.Item("e_GA_Post").Width + 10
            oItem.Height = frmSaleQuot.Items.Item("e_GA_Post").Height
            oItem.Top = frmSaleQuot.Items.Item("e_GA_Post").Top
            oItem.Visible = True
            oItem.Enabled = True
            oItem.LinkTo = "e_GA_Post"
            oButton = oItem.Specific
            oButton.Caption = "Find Customer"





            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmSaleQuot.Freeze(False)
        Catch ex As Exception
            frmSaleQuot.Freeze(False)
            'oApplication.StatusBar.SetText("Load SalesOrder Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmSaleQuot.Freeze(True)
            frmSaleQuot.Items.Item("b_GA_Post").Enabled = True
            frmSaleQuot.Freeze(False)
        Catch ex As Exception
            frmSaleQuot.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmSaleQuot.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub



    Function Validation() As Boolean
        Try
            Dim flag As Boolean = True
            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
            Dim Status As String = oDBDSHeader.GetValue("Status", 0)
            Dim SqlWipExist As String = "Select *  from [@GA_WIPN] WHERE U_GA_PoEnt='" & DocEntry & "'"
            Dim RsWIP As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RsWIP.DoQuery(SqlWipExist)
            If (RsWIP.RecordCount > 0 And Status = "P") Then
                flag = False
                oApplication.MessageBox("Saleuction order status change is not permitted after WIP number is generated", 1, "Ok")
            Else
                flag = True

            End If

            Return flag
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validation Function Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function
    Sub ItemEvent_CardDetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "Add"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim PostCode As String = oDBDSHeader.GetValue("U_GA_Post", 0)
                                    'GoTo M 
                                    Dim RowID As Integer = 1


                                    For j As Integer = 1 To oGrid.Rows.Count

                                        Dim Status As String = oGrid.DataTable.Columns.Item("Select").Cells.Item(j - 1).Value
                                        If (Status = "Y") Then


                                            Dim oEdit As SAPbouiCOM.EditText = frmSaleQuot.Items.Item("4").Specific
                                            oEdit.Value = oGrid.DataTable.Columns.Item("CardCode").Cells.Item(j - 1).Value
                                            Dim sQuery3 As String = String.Empty
                                            sQuery3 = "SELECT T0.Address FROM CRD1 T0 WHERE   T0.[ZipCode]='" + PostCode + "' and  T0.[AdresType]='S' and T0.CardCode='" + oEdit.Value + "' "
                                            Dim Rsta As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery3)
                                            If (Rsta.RecordCount > 0) Then
                                                frmSaleQuot.PaneLevel = "6"
                                                frmSaleQuot.Items.Item("114").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                                Dim oCOmboA As SAPbouiCOM.ComboBox = frmSaleQuot.Items.Item("40").Specific
                                                oCOmboA.Select(Rsta.Fields.Item(0).Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                frmSaleQuot.PaneLevel = "1"
                                                frmSaleQuot.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            End If



                                            GoTo ForEnd
                                        End If

                                    Next
ForEnd:
                                    oApplication.StatusBar.SetText("Customer Selected", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oForm.Close()

                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("ComboBox Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "MyGrid"

                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                Select Case pVal.ColUID
                                    Case "Select"
                                        Try
                                            oForm.Freeze(True)

                                            If (pVal.BeforeAction = False) Then
                                                Dim RowLine As Integer = oGrid.GetDataTableRowIndex(pVal.Row)
                                                Dim Chk As String = oGrid.DataTable.Columns.Item("Select").Cells.Item(RowLine).Value
                                                If Chk = "Y" Then


                                                    For i As Integer = 1 To oGrid.Rows.Count
                                                        If i <> RowLine + 1 Then


                                                            oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value = "N"
                                                        End If

                                                    Next
                                                End If
                                            End If
                                        Catch ex As Exception
                                            oForm.Freeze(False)
                                        Finally
                                            oForm.Freeze(False)
                                        End Try
                                End Select
                            Case "c_select"
                                oForm.Freeze(True)
                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                If pVal.BeforeAction = False Then
                                    Dim RowID As Integer = 1
                                    Dim s1 As SAPbouiCOM.CheckBox = oForm.Items.Item("c_select").Specific
                                    s1.ValOn = "Y"
                                    s1.ValOff = "N"
                                    If s1.Checked = True Then
                                        For i As Integer = 1 To oGrid.Rows.Count
                                            oGrid.DataTable.Columns.Item("Print").Cells.Item(i - 1).Value = "Y"
                                            RowID += 1
                                        Next
                                    ElseIf s1.Checked = False Then
                                        For i As Integer = 1 To oGrid.Rows.Count
                                            oGrid.DataTable.Columns.Item("Print").Cells.Item(i - 1).Value = "N"
                                            RowID += 1
                                        Next
                                    End If
                                End If
                                oForm.Freeze(False)
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                'Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific 
                                Select Case pVal.ColUID

                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Validate Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmSaleQuot = oApplication.Forms.Item(FormUID)
                If (frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                    frmSaleQuot.Items.Item("b_GA_Post").Enabled = True
                Else
                    frmSaleQuot.Items.Item("b_GA_Post").Enabled = False
                End If
                '   oForm = frmSaleQuot
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = SaleQuotTypeEx Then
                Select Case pVal.EventType

                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadSaleOrder(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                        Try
                            Select Case pVal.ItemUID
                                Case "38"
                                    Select Case pVal.ColUID
                                        Case "1"
                                            If (pVal.BeforeAction = False And pVal.ActionSuccess = True And frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                                Dim Whse As String = WhseSearch()
                                                Dim Row As Integer = pVal.Row
                                                Dim EditItem As SAPbouiCOM.EditText = oMatrix.Columns.Item("1").Cells.Item(Row).Specific
                                                If (EditItem.Value <> "") Then
                                                    Dim Edit As SAPbouiCOM.EditText = oMatrix.Columns.Item("24").Cells.Item(Row).Specific
                                                    Edit.Value = Whse
                                                    Dim SlDflt As String = "Select *  from NNM2 WHERE UserSign='" & oCompany.UserSignature & "' and ObjectCode='23'"
                                                    Dim RsDflt As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                    RsDflt.DoQuery(SlDflt)
                                                    If (RsDflt.RecordCount = 0) Then


                                                        Dim SqlSeries As String = "Select U_GA_SQSER  from [@GA_HUBSER] WHERE   Name='" & Whse & "'"
                                                        Dim Series As String = ""
                                                        Dim RsSeries As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                        RsSeries.DoQuery(SqlSeries)
                                                        If (RsSeries.RecordCount > 0) Then
                                                            Try


                                                                Series = RsSeries.Fields.Item(0).Value.ToString()
                                                                Dim oCombo As SAPbouiCOM.ComboBox = frmSaleQuot.Items.Item("88").Specific
                                                                oCombo.Select(Series, SAPbouiCOM.BoSearchKey.psk_ByDescription)
                                                            Catch ex As Exception

                                                            End Try
                                                        End If
                                                    End If
                                                End If
                                            End If
                                    End Select
                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_CLOSE
                        Try
                            If pVal.BeforeAction Then
                                CardPost = ""
                            End If
                        Catch ex As Exception

                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "10002101"
                                    If pVal.BeforeAction Then
                                        CardPost = oDBDSHeader.GetValue("CardCode", 0)
                                    End If
                                Case "1"
                                    If pVal.ActionSuccess And frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Me.InitForm()
                                    End If
                                Case "b_GA_Post"
                                    If pVal.ActionSuccess And frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Dim PostCode As String = oDBDSHeader.GetValue("U_GA_Post", 0)
                                        If (PostCode <> "") Then
                                            Dim sQuery2 As String = String.Empty
                                            sQuery2 = "SELECT DISTINCT 'N' [Select],T0.CardCode,T1.CardName FROM CRD1 T0 INNER JOIN OCRD T1 ON T0.CardCode=T1.CardCode WHERE  T0.[ZipCode]='" + PostCode + "' and  T0.[AdresType]='S' and T1.CardType='C' "
                                            Dim RstP As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery2)
                                            If (RstP.RecordCount > 0) Then
                                                If (RstP.RecordCount = 1) Then
                                                    Dim EditCard As SAPbouiCOM.EditText
                                                    EditCard = frmSaleQuot.Items.Item("4").Specific
                                                    EditCard.Value = RstP.Fields.Item("CardCode").Value.ToString()

                                                    Dim sQuery3 As String = String.Empty
                                                    sQuery3 = "SELECT T0.Address FROM CRD1 T0  WHERE  T0.[ZipCode]='" + PostCode + "' and  T0.[AdresType]='S' and T0.CardCode='" + RstP.Fields.Item("CardCode").Value.ToString() + "' "
                                                    Dim Rsta As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery3)
                                                    If (Rsta.RecordCount > 0) Then

                                                        frmSaleQuot.PaneLevel = "6"
                                                        frmSaleQuot.Items.Item("114").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                                        Dim oCOmboA As SAPbouiCOM.ComboBox = frmSaleQuot.Items.Item("40").Specific
                                                        oCOmboA.Select(Rsta.Fields.Item(0).Value.ToString(), SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                        frmSaleQuot.PaneLevel = "1"
                                                        frmSaleQuot.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                                    End If
                                                Else
                                                    GblSQuery2 = sQuery2
                                                    CreateMySimpleForm_CustomerList()
                                                End If
                                            End If
                                        End If

                                    End If
                                    'Case "lk_grp"
                                    '    If pVal.BeforeAction = False Then
                                    '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", frmSaleQuot.Items.Item("t_docentry").Specific.value)
                                    '    End If



                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    'If pVal.BeforeAction = True And (frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then

                                    '    Try
                                    '        frmSaleQuot.PaneLevel = "1"

                                    '        frmSaleQuot.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    '        For i As Integer = 1 To 1
                                    '            Dim EditItem As SAPbouiCOM.EditText = oMatrix.Columns.Item("1").Cells.Item(i).Specific
                                    '            Dim Edit As SAPbouiCOM.EditText = oMatrix.Columns.Item("24").Cells.Item(i).Specific
                                    '            Dim WhseCode = Edit.Value
                                    '            If (EditItem.Value <> "" And WhseCode <> "") Then

                                    '                Dim Cmb As SAPbouiCOM.ComboBox = frmSaleQuot.Items.Item("88").Specific
                                    '                Dim Series2 = Cmb.Selected.Description
                                    '                Dim SqlSeries As String = "Select U_GA_SQSER  from [@GA_HUBSER] WHERE   Name='" & WhseCode & "' and U_GA_SQSER='" & Series2 & "'"

                                    '                Dim RsSeries As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                    '                RsSeries.DoQuery(SqlSeries)
                                    '                If (RsSeries.RecordCount = 0) Then
                                    '                    Dim ithReturnValue As Integer
                                    '                    ithReturnValue = oApplication.MessageBox("Selected Series is Not mapped against selected HubCode,Do you want to Continue?", 1, "Continue", "Cancel", "")
                                    '                    If (ithReturnValue = 1) Then
                                    '                        BubbleEvent = True
                                    '                    Else
                                    '                        BubbleEvent = False
                                    '                    End If

                                    '                End If
                                    '                End If

                                    '        Next
                                    '    Catch ex As Exception

                                    '    End Try

                                    'End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID
                                Case "40"
                                    If pVal.BeforeAction = False And pVal.ActionSuccess = True And (frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                        Dim Whse As String = WhseSearch()
                                        If (Whse <> "") Then
                                            frmSaleQuot.PaneLevel = "1"
                                            frmSaleQuot.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            For i As Integer = 1 To oMatrix.RowCount
                                                Dim EditItem As SAPbouiCOM.EditText = oMatrix.Columns.Item("1").Cells.Item(i).Specific
                                                If (EditItem.Value <> "") Then
                                                    Dim Edit As SAPbouiCOM.EditText = oMatrix.Columns.Item("24").Cells.Item(i).Specific
                                                    Edit.Value = Whse

                                                    Dim SqlSeries As String = "Select U_GA_SQSER  from [@GA_HUBSER] WHERE   Name='" & Whse & "'"
                                                    Dim Series As String = ""
                                                    Dim RsSeries As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                                    RsSeries.DoQuery(SqlSeries)
                                                    If (RsSeries.RecordCount > 0) Then
                                                        Try


                                                            Series = RsSeries.Fields.Item(0).Value.ToString()
                                                            Dim oCombo As SAPbouiCOM.ComboBox = frmSaleQuot.Items.Item("88").Specific
                                                            oCombo.Select(Series, SAPbouiCOM.BoSearchKey.psk_ByDescription)
                                                        Catch ex As Exception

                                                        End Try
                                                    End If

                                                End If
                                            Next
                                        End If
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmSaleQuot = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            'If pVal.FormTypeEx = SalesOrderTypeEx Then
            Select Case pVal.MenuUID
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
            End Select
            'End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmSaleQuot = frmGloSaleOrder
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            frmSaleQuot = oApplication.Forms.ActiveForm
                            If (frmSaleQuot.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then

                                Try
                                    frmSaleQuot.PaneLevel = "1"
                                    frmSaleQuot.Items.Item("112").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    For i As Integer = 1 To 1
                                        Dim EditItem As SAPbouiCOM.EditText = oMatrix.Columns.Item("1").Cells.Item(i).Specific
                                        Dim Edit As SAPbouiCOM.EditText = oMatrix.Columns.Item("24").Cells.Item(i).Specific
                                        Dim WhseCode = Edit.Value
                                        If (EditItem.Value <> "" And WhseCode <> "") Then
                                            Dim Cmb As SAPbouiCOM.ComboBox = frmSaleQuot.Items.Item("88").Specific
                                            Dim Series2 = Cmb.Selected.Description
                                            Dim SqlSeries As String = "Select U_GA_SOSER  from [@GA_HUBSER] WHERE   Name='" & WhseCode & "' and U_GA_SOSER='" & Series2 & "'"

                                            Dim RsSeries As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                            RsSeries.DoQuery(SqlSeries)
                                            If (RsSeries.RecordCount = 0) Then
                                                Dim ithReturnValue As Integer
                                                ithReturnValue = oApplication.MessageBox("Selected Series is Not mapped against selected HubCode,Do you want to Continue?", 1, "Continue", "Cancel", "")
                                                If (ithReturnValue = 1) Then
                                                    BubbleEvent = True
                                                Else
                                                    _newMsg = "Select the Series Linked with HubCode"
                                                    _changeMsg = True
                                                    BubbleEvent = False
                                                End If

                                            End If
                                        End If

                                    Next
                                Catch ex As Exception

                                End Try

                            End If
                        End If
                        If BusinessObjectInfo.ActionSuccess Then

                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then
                        frmSaleQuot.Items.Item("b_GA_Post").Enabled = False
                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                    End Select
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub CreateMySimpleForm_CustomerList()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim ocheckbox As SAPbouiCOM.CheckBox
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_CARD1"
            CP.FormType = "705"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height  
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Customer Details"
            '' Add a Grid item to the form  
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position  
            oItem.Left = 5
            oItem.Top = 25
            oItem.Width = 675
            oItem.Height = 240
            ' Set the grid data  
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button  
            oItem = oForm.Items.Add("Add", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button  
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific


            sQuery = GblSQuery2


            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()

            For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                    oGrid.Columns.Item(i).Editable = True
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Purchase Order Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Function WhseSearch() As String
        Dim CardCode As String = oDBDSHeader.GetValue("CardCode", 0)
        Dim ShipCode As String = oDBDSHeader.GetValue("ShipToCode", 0)
        Dim ZipCode As String = ""
        Dim SqlPost As String = "Select ZipCode  from CRD1 WHERE CardCode='" & CardCode & "' and Address='" & ShipCode & "' and AdresType='S'"
        Dim WhsCode As String = ""
        Dim RsPost As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        RsPost.DoQuery(SqlPost)
        If (RsPost.RecordCount > 0) Then
            ZipCode = RsPost.Fields.Item(0).Value.ToString().Trim()
            Dim SqlPostWhs As String = "SELECT U_HubCode FROM [@GA_DP] WHERE U_PostCode =(Select  Left('" & ZipCode & "',patindex('%[0-9]%','" & ZipCode & "')-1))"
            Dim RsPostWhs As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RsPostWhs.DoQuery(SqlPostWhs)
            If (RsPostWhs.RecordCount > 0) Then
                WhsCode = RsPostWhs.Fields.Item(0).Value.ToString()
            End If
        End If
        Return WhsCode
    End Function

    Sub ProductionOrder(ByVal DocEntry As String, ByVal ItemCode As String, ByVal Qty As Integer, ByVal Whse As String, ByVal Model As String)
        Try
            Dim Error1 As Integer = 0
            Dim Prod As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
            Prod.PostingDate = Now()
            Prod.ItemNo = ItemCode
            Prod.PlannedQuantity = Qty
            Prod.Warehouse = Whse
            Prod.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned
            Prod.ProductionOrderOrigin = SAPbobsCOM.BoProductionOrderOriginEnum.bopooSalesOrder
            Prod.ProductionOrderOriginEntry = DocEntry
            Prod.UserFields.Fields.Item("U_GA_MODEL").Value = Model
            Error1 = Prod.Add()
            If (Error1 <> 0) Then
                oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Else
                oApplication.MessageBox("Production Order Created successfully", 1, "Ok")
            End If
            'Dim ithReturnValue As Integer
            'ithReturnValue = oApplication.MessageBox("Do you want to Scrap the Item ?", 1, "Continue", "Cancel", "")
            'If (ithReturnValue = 1) Then
            '    CreateMySimpleForm_QtyScrap()
            'End If

        Catch ex As Exception

        End Try
    End Sub



End Class
