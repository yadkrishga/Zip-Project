Public Class SalesOrder
    Dim frmSalesOrder, frmGloSaleOrder As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer

    Sub LoadSalesOrder(ByVal FormUID As String)
        Try
            boolFormLoaded = False
            Dim oItem As SAPbouiCOM.Item
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oComboBox As SAPbouiCOM.ComboBox
            Dim oEditText As SAPbouiCOM.EditText


            frmSalesOrder = oApplication.Forms.Item(FormUID)
            frmGloSaleOrder = oApplication.Forms.Item(FormUID)

            oMatrix = frmSalesOrder.Items.Item("38").Specific
            oDBDSHeader = frmSalesOrder.DataSources.DBDataSources.Item("ORDR")
            oDBDSDetail = frmSalesOrder.DataSources.DBDataSources.Item("RDR1")


            frmSalesOrder.Freeze(True)

            ' Purchase Indent Copy From Button ...
            '------------------------------------

            oItem = frmSalesOrder.Items.Add("b_loaddata", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmSalesOrder.Items.Item("2").Left + frmSalesOrder.Items.Item("2").Width + 5
            oItem.Width = frmSalesOrder.Items.Item("2").Width
            oItem.Height = frmSalesOrder.Items.Item("2").Height
            oItem.Top = frmSalesOrder.Items.Item("2").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "Select Item"


            oItem = frmSalesOrder.Items.Add("b_cal", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmSalesOrder.Items.Item("2").Left + frmSalesOrder.Items.Item("2").Width + 5 + frmSalesOrder.Items.Item("2").Width + 5
            oItem.Width = frmSalesOrder.Items.Item("2").Width + 20
            oItem.Height = frmSalesOrder.Items.Item("2").Height
            oItem.Top = frmSalesOrder.Items.Item("2").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "Cal. CBM & Carton"

            oItem = frmSalesOrder.Items.Add("b_copy", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmSalesOrder.Items.Item("2").Left + frmSalesOrder.Items.Item("2").Width + 5 + frmSalesOrder.Items.Item("2").Width + 5 + frmSalesOrder.Items.Item("2").Width + 5 + 20
            oItem.Width = frmSalesOrder.Items.Item("2").Width + 20
            oItem.Height = frmSalesOrder.Items.Item("2").Height
            oItem.Top = frmSalesOrder.Items.Item("2").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "Copy SO"
            frmSalesOrder.Items.Item("b_copy").LinkTo = "b_cal"

            oItem = frmSalesOrder.Items.Add("l_pickwhs", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmSalesOrder.Items.Item("86").Left
            oItem.Width = frmSalesOrder.Items.Item("86").Width
            oItem.Height = frmSalesOrder.Items.Item("86").Height
            oItem.Top = frmSalesOrder.Items.Item("86").Top + 16
            oLabel = oItem.Specific
            oLabel.Caption = "Pick Whs"

        

            oItem = frmSalesOrder.Items.Add("t_pickwhs", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = frmSalesOrder.Items.Item("46").Left
            oItem.Width = frmSalesOrder.Items.Item("46").Width
            oItem.Height = frmSalesOrder.Items.Item("46").Height
            oItem.Top = frmSalesOrder.Items.Item("46").Top + 16
            oEditText = oItem.Specific
            oEditText.DataBind.SetBound(True, "ORDR", "U_PickWhs")
            frmSalesOrder.Items.Item("l_pickwhs").LinkTo = "t_pickwhs"

            Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            ocfls = frmSalesOrder.ChooseFromLists
            Dim Whs_CFL As SAPbouiCOM.ChooseFromList
            Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            cflcrepa.MultiSelection = False
            cflcrepa.ObjectType = "64"
            cflcrepa.UniqueID = "Whs_CFL"
            Whs_CFL = ocfls.Add(cflcrepa)
            oEditText.ChooseFromListUID = "Whs_CFL"
            oEditText.ChooseFromListAlias = "WhsCode"

            oItem = frmSalesOrder.Items.Add("l_sso", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmSalesOrder.Items.Item("86").Left
            oItem.Width = frmSalesOrder.Items.Item("86").Width
            oItem.Height = frmSalesOrder.Items.Item("86").Height
            oItem.Top = frmSalesOrder.Items.Item("86").Top + 16 + 16
            oLabel = oItem.Specific
            oLabel.Caption = "Selected SO"

            oItem = frmSalesOrder.Items.Add("t_sso", SAPbouiCOM.BoFormItemTypes.it_EXTEDIT)
            oItem.Left = frmSalesOrder.Items.Item("46").Left
            oItem.Width = frmSalesOrder.Items.Item("46").Width
            oItem.Height = frmSalesOrder.Items.Item("46").Height + 10
            oItem.Top = frmSalesOrder.Items.Item("46").Top + 16 + 16
            oEditText = oItem.Specific
            oEditText.DataBind.SetBound(True, "ORDR", "U_SOList")
            oItem.Enabled = False
            frmSalesOrder.Items.Item("l_sso").LinkTo = "t_sso"



         
        

            oItem = frmSalesOrder.Items.Add("l_cbm", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmSalesOrder.Items.Item("230").Left
            oItem.Width = frmSalesOrder.Items.Item("230").Width
            oItem.Height = frmSalesOrder.Items.Item("230").Height
            oItem.Top = frmSalesOrder.Items.Item("230").Top + 16
            oLabel = oItem.Specific
            oLabel.Caption = "Total CBM"

            oItem = frmSalesOrder.Items.Add("t_cbm", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = frmSalesOrder.Items.Item("222").Left
            oItem.Width = frmSalesOrder.Items.Item("222").Width
            oItem.Height = frmSalesOrder.Items.Item("222").Height
            oItem.Top = frmSalesOrder.Items.Item("222").Top + 16
            oEditText = oItem.Specific
            oEditText.DataBind.SetBound(True, "ORDR", "U_TotalCBM")
            frmSalesOrder.Items.Item("l_cbm").LinkTo = "t_cbm"
            oItem.Enabled = False

            oItem = frmSalesOrder.Items.Add("l_carton", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmSalesOrder.Items.Item("230").Left
            oItem.Width = frmSalesOrder.Items.Item("230").Width
            oItem.Height = frmSalesOrder.Items.Item("230").Height
            oItem.Top = frmSalesOrder.Items.Item("230").Top + 16 + 16
            oLabel = oItem.Specific
            oLabel.Caption = "Total Carton"

            oItem = frmSalesOrder.Items.Add("t_carton", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = frmSalesOrder.Items.Item("222").Left
            oItem.Width = frmSalesOrder.Items.Item("222").Width
            oItem.Height = frmSalesOrder.Items.Item("222").Height
            oItem.Top = frmSalesOrder.Items.Item("222").Top + 16 + 16
            oEditText = oItem.Specific
            oEditText.DataBind.SetBound(True, "ORDR", "U_TotCartQty")
            frmSalesOrder.Items.Item("l_carton").LinkTo = "t_carton"
            oItem.Enabled = False

            'oItem = frmSalesOrder.Items.Add("t_docno", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = frmSalesOrder.Items.Item("46").Left
            'oItem.Width = frmSalesOrder.Items.Item("46").Width
            'oItem.Height = frmSalesOrder.Items.Item("46").Height
            'oItem.Top = frmSalesOrder.Items.Item("46").Top + 32
            'oEditText = oItem.Specific
            'oEditText.DataBind.SetBound(True, "ORDR", "U_DocNum")
            'oItem.Enabled = False

            'oItem = frmSalesOrder.Items.Add("t_grpname", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = frmSalesOrder.Items.Item("46").Left
            'oItem.Width = frmSalesOrder.Items.Item("46").Width
            'oItem.Height = frmSalesOrder.Items.Item("46").Height
            'oItem.Top = frmSalesOrder.Items.Item("46").Top + 32
            'oEditText = oItem.Specific
            'oEditText.DataBind.SetBound(True, "ORDR", "U_GrpName")
            ''oItem.Enabled = False

            'frmSalesOrder.Items.Item("l_docnum").LinkTo = "t_grpname"


            'Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            'ocfls = frmSalesOrder.ChooseFromLists
            'Dim ITMGRP_CFL As SAPbouiCOM.ChooseFromList
            'Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            'cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            'cflcrepa.MultiSelection = False
            'cflcrepa.ObjectType = "OITM"
            'cflcrepa.UniqueID = "ITMGRP_CFL"
            'ITMGRP_CFL = ocfls.Add(cflcrepa)
            'oEditText.ChooseFromListUID = "ITMGRP_CFL"
            'oEditText.ChooseFromListAlias = "U_ItmGrpName"
            ''frmSalesOrder.Items.Item("4").Specific.value = ""


            'oItem = frmSalesOrder.Items.Add("lk_grp", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
            'oItem.Left = frmSalesOrder.Items.Item("t_grpname").Left - 13
            'oItem.Width = 10
            'oItem.Height = frmSalesOrder.Items.Item("t_grpname").Height
            'oItem.Top = frmSalesOrder.Items.Item("t_grpname").Top
            'frmSalesOrder.Items.Item("lk_grp").LinkTo = "t_docentry"


            'oItem = frmSalesOrder.Items.Add("l_BLNo", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            'oItem.Left = frmSalesOrder.Items.Item("86").Left
            'oItem.Width = frmSalesOrder.Items.Item("86").Width
            'oItem.Height = frmSalesOrder.Items.Item("86").Height
            'oItem.Top = frmSalesOrder.Items.Item("86").Top + 32 + 16
            'oLabel = oItem.Specific
            'oLabel.Caption = "BL No."

            'oItem = frmSalesOrder.Items.Add("t_BLNo", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX)
            'oItem.Left = frmSalesOrder.Items.Item("46").Left
            'oItem.Width = frmSalesOrder.Items.Item("46").Width
            'oItem.Height = frmSalesOrder.Items.Item("46").Height
            'oItem.Top = frmSalesOrder.Items.Item("46").Top + 32 + 16
            'oComboBox = oItem.Specific
            'oComboBox.DataBind.SetBound(True, "ORDR", "U_BLNo")
            'frmSalesOrder.Items.Item("l_BLNo").LinkTo = "t_BLNo"



            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmSalesOrder.Freeze(False)
        Catch ex As Exception
            frmSalesOrder.Freeze(False)
            'oApplication.StatusBar.SetText("Load SalesOrder Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmSalesOrder.Freeze(True)

            frmSalesOrder.Freeze(False)
        Catch ex As Exception
            frmSalesOrder.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmSalesOrder.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub Calculation()
        Try
            Dim TotCBMQty As Double = 0.0
            Dim TotCartonQty As Double = 0.0
            'Dim CartonQty As Double = 0.0
            For i As Integer = 1 To oMatrix.VisualRowCount
                If oMatrix.Columns.Item("1").Cells.Item(i).Specific.value <> "" Then
                    sQuery = String.Empty
                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value & "'"
                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    Dim CBMQty As Double = Rst.Fields.Item("U_CBM").Value
                    Dim CartonQty As Double = Rst.Fields.Item("U_CartQty").Value
                    TotCBMQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value
                    TotCartonQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value / CartonQty
                End If
            Next

            frmSalesOrder.Items.Item("t_cbm").Enabled = True
            frmSalesOrder.Items.Item("t_carton").Enabled = True
            frmSalesOrder.Items.Item("t_cbm").Specific.value = TotCBMQty
            frmSalesOrder.Items.Item("t_carton").Specific.value = TotCartonQty
            frmSalesOrder.Items.Item("16").Specific.value = frmSalesOrder.Items.Item("16").Specific.value
            frmSalesOrder.Items.Item("t_cbm").Enabled = False
            frmSalesOrder.Items.Item("t_carton").Enabled = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("Calculation Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Function Validation() As Boolean
        Try

            ''Dim aaaaa As String = frmSalesOrder.Items.Item("t_sso").Specific.value
            'frmSalesOrder = frmGloSaleOrder
            'If frmSalesOrder.Items.Item("t_sso").Specific.value.Equals("") = True Then
            '    Me.Calculation()

            '    For i As Integer = 1 To oMatrix.VisualRowCount
            '        If oMatrix.Columns.Item("1").Cells.Item(i).Specific.value <> "" Then
            '            sQuery = String.Empty
            '            sQuery = "SELECT  IFNULL(C.""Price"",0) ""MinPrice"",IFNULL(D.""Price"",0) ""MaxPrice"" FROM OITM B  "
            '            sQuery += " LEFT JOIN (SELECT * FROM ITM1 WHERE ""PriceList""='1') C ON B.""ItemCode""=C.""ItemCode"""
            '            sQuery += " LEFT JOIN (SELECT * FROM ITM1 WHERE ""PriceList""='11') D ON B.""ItemCode""=D.""ItemCode"""
            '            sQuery += " WHERE B.""ItemCode""='" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value & "'"
            '            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            '            If Rst.RecordCount > 0 Then
            '                Dim MinPrice As Double = Rst.Fields.Item(0).Value
            '                Dim MaxPrice As Double = Rst.Fields.Item(1).Value

            '                Dim StrAmount As String = UCase(oMatrix.Columns.Item("14").Cells.Item(i).Specific.value)
            '                For Y As Int16 = Convert.ToInt16("A"c) To Convert.ToInt16("Z"c)
            '                    Dim letter As Char = Convert.ToChar(Y)
            '                    'Do my loop work...
            '                    If StrAmount.Contains(letter) Then
            '                        StrAmount = StrAmount.Replace(letter, "")
            '                    Else
            '                        StrAmount = StrAmount
            '                    End If
            '                Next
            '                Dim Amt As Double = StrAmount
            '                If Amt < MinPrice Then
            '                    oApplication.StatusBar.SetText("Unit price should not less than Maximum price............" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            '                    Return False
            '                ElseIf Amt > MaxPrice Then
            '                    oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            '                    Return False
            '                End If
            '            Else
            '                oApplication.StatusBar.SetText("Define price list for itemcode " & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            '                Return False
            '            End If
            '        End If
            '    Next
            'End If
            Return True
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validation Function Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmSalesOrder = oApplication.Forms.Item(FormUID)
                '   oForm = frmSalesOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = SalesOrderTypeEx Then
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                        Try
                            Dim oDataTable As SAPbouiCOM.DataTable
                            Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                            Dim Txt, txt1 As SAPbouiCOM.EditText
                            oDataTable = oCFLE.SelectedObjects
                            If Not oDataTable Is Nothing And pVal.Before_Action = False Then
                                Select Case pVal.ItemUID
                                    'Case "4"
                                    '    BubbleEvent = False
                                    '    oMatrix.Clear()
                                    '    oMatrix.AddRow()
                                    '    frmSalesOrder.Items.Item("t_operoad").Specific.value = ""
                                    '    frmSalesOrder.Items.Item("14").Specific.value = ""
                                    Case "t_pickwhs"
                                        oMatrix.Clear()
                                        oMatrix.AddRow()
                                        Try
                                            frmSalesOrder.Items.Item("t_pickwhs").Enabled = True
                                            Txt = frmSalesOrder.Items.Item("t_pickwhs").Specific
                                            Txt.Value = Trim(oDataTable.GetValue("WhsCode", 0))
                                        Catch ex As Exception

                                        End Try
 

                                    Case "t_grpname"
                                        oMatrix.Clear()
                                        oMatrix.AddRow()
                                        Try
                                            frmSalesOrder.Items.Item("t_docentry").Enabled = True
                                            Txt = frmSalesOrder.Items.Item("t_docentry").Specific
                                            Txt.Value = Trim(oDataTable.GetValue("DocEntry", 0))
                                        Catch ex As Exception

                                        End Try

                                        Try
                                            frmSalesOrder.Items.Item("t_docno").Enabled = True
                                            txt1 = frmSalesOrder.Items.Item("t_docno").Specific
                                            txt1.Value = Trim(oDataTable.GetValue("DocNum", 0))
                                        Catch ex As Exception
                                        End Try

                                        Try

                                            Txt = frmSalesOrder.Items.Item("t_grpname").Specific
                                            Txt.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                            frmSalesOrder.Items.Item("t_docentry").Enabled = False
                                            frmSalesOrder.Items.Item("t_docno").Enabled = False
                                        Catch ex As Exception
                                        End Try

                                End Select
                            End If
                        Catch ex As Exception
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadSalesOrder(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID
                                'Case "t_JobNo"
                                '    If pVal.BeforeAction = False Then
                                '        sQuery = String.Empty
                                '        sQuery = "SELECT DISTINCT U_BLNo,U_BLNo FROM [@INL_CSJOR2] "
                                '        sQuery += " WHERE ISNULL(U_BLNo,'')!='' "
                                '        sQuery += " AND DocEntry IN (SELECT DocEntry FROM [@INL_OCSJOR] WHERE DocNum='" & frmSalesOrder.Items.Item("t_JobNo").Specific.value & "')"
                                '        'Dim Rst As SAPbobsCOM.Recordset = oGFun.DoQuery(sQuery)

                                '        oGfun.SetComboBoxValueRefresh(frmSalesOrder.Items.Item("t_BLNo").Specific, sQuery)
                                '    End If
                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID
                                'Case "t_BLNo"
                                '    If pVal.BeforeAction = False Then
                                '        sQuery = String.Empty
                                '        sQuery = "SELECT DISTINCT U_BLNo,U_BLNo FROM [@INL_CSJOR2] "
                                '        sQuery += " WHERE ISNULL(U_BLNo,'')!='' "
                                '        sQuery += " AND DocEntry IN (SELECT DocEntry FROM [@INL_OCSJOR] WHERE DocNum='" & frmSalesOrder.Items.Item("t_JobNo").Specific.value & "')"
                                '        'Dim Rst As SAPbobsCOM.Recordset = oGFun.DoQuery(sQuery)

                                '        oGFun.SetComboBoxValueRefresh(frmSalesOrder.Items.Item("t_BLNo").Specific, sQuery)
                                '    End If
                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.ActionSuccess And frmSalesOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Me.InitForm()
                                    End If
                                    'Case "lk_grp"
                                    '    If pVal.BeforeAction = False Then
                                    '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", frmSalesOrder.Items.Item("t_docentry").Specific.value)
                                    '    End If
                                Case "b_loaddata"
                                    If pVal.BeforeAction = False Then
                                        Me.CreateMySimpleForm_ItemList()
                                    End If
                                Case "b_cal"
                                    If pVal.BeforeAction = False Then
                                        Me.Calculation()
                                    End If
                                Case "b_copy"
                                    If pVal.BeforeAction = False Then
                                        Me.CreateMySimpleForm_SODetails()
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.BeforeAction = True And (frmSalesOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmSalesOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                        If Me.Validation() = False Then
                                            System.Media.SystemSounds.Asterisk.Play()
                                            BubbleEvent = False
                                            Exit Sub
                                        End If
                                    Else

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID
                                Case "15"
                                    If pVal.BeforeAction = False Then

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmSalesOrder = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            'If pVal.FormTypeEx = SalesOrderTypeEx Then
            Select Case pVal.MenuUID
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
            End Select
            'End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmSalesOrder = frmGloSaleOrder
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If Validation() = False Then
                                BubbleEvent = False
                                Exit Sub
                            End If
                        End If
                        If BusinessObjectInfo.ActionSuccess Then
                            If frmSalesOrder.Items.Item("t_sso").Specific.value.Equals("") = False Then
                                sQuery = String.Empty
                                sQuery = "UPDATE  SBMDUBAILIVE.""ORDR"" SET ""U_Read""='Y' WHERE ""DocEntry"" IN (" & frmSalesOrder.Items.Item("t_sso").Specific.value & ")"
                                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then

                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                    End Select
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub CreateMySimpleForm_ItemList()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SOItemList"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Item Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 70
            oItem.Width = 675
            oItem.Height = 200
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            ' Add OK Button 
            oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 160
            oItem.Top = 280
            oItem.Width = 70
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Clear & Add"

            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_itmgrp", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_itmgrp"
            oLabel = oItem.Specific
            oLabel.Caption = "Item Group"


            '----------------------------------------

            ''Item Group
            'oItem = oForm.Items.Add("U_DocNum", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155
            'oItem.Top = 10
            'oItem.Width = 74
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_DocNum", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_DocNum")
            'oItem.Enabled = True



            'Item Group
            oItem = oForm.Items.Add("ItmGrpCd", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10
            oItem.Width = 150
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpCd", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditBox.DataBind.SetBound(True, "", "U_ItmGrpCd")
            ' oItem.Enabled = False

            Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            ocfls = oForm.ChooseFromLists
            Dim ITMGRP_CFL As SAPbouiCOM.ChooseFromList
            Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            cflcrepa.MultiSelection = False
            cflcrepa.ObjectType = "OITM"
            cflcrepa.UniqueID = "ITMGRP_CFL"
            ITMGRP_CFL = ocfls.Add(cflcrepa)
            oEditBox.ChooseFromListUID = "ITMGRP_CFL"
            oEditBox.ChooseFromListAlias = "U_ItmGrpCode"


            ''Item Group
            'oItem = oForm.Items.Add("ItmGrpCd", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155 + 76
            'oItem.Top = 10
            'oItem.Width = 74
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpCd", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_ItmGrpCd")
            'oItem.Enabled = False
            '----------------------------------------


            'Item Group
            oItem = oForm.Items.Add("ItmGrpNm", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 310
            oItem.Top = 10
            oItem.Width = 200
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpNm", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditBox.DataBind.SetBound(True, "", "U_ItmGrpNm")
            oItem.Enabled = False

           

            'oItem = oForm.Items.Add("lk_grp", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
            'oItem.Left = oForm.Items.Item("t_itmgrp").Left - 13
            'oItem.Width = 10
            'oItem.Height = oForm.Items.Item("t_itmgrp").Height
            'oItem.Top = oForm.Items.Item("t_itmgrp").Top
            'oForm.Items.Item("lk_grp").LinkTo = "t_itmcode"

            'Item Group
            oItem = oForm.Items.Add("t_minprc", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10 + 16
            oItem.Width = 74
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_MinPrice", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_MinPrice")
            oItem.Enabled = False

            'Item Group
            oItem = oForm.Items.Add("t_maxprc", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155 + 76
            oItem.Top = 10 + 16
            oItem.Width = 74
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_MaxPrice", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_MaxPrice")
            oItem.Enabled = False

            'Vat Group
            oItem = oForm.Items.Add("l_MMPrice", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10 + 16
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_tax"
            oLabel = oItem.Specific
            oLabel.Caption = "Min Price / Max Price"


            'Item Group
            oItem = oForm.Items.Add("l_unitprc", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10 + 16 + 16
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_minprc"
            oLabel = oItem.Specific
            oLabel.Caption = "Unit Price"
            'Item Group
            oItem = oForm.Items.Add("UnitPrice", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10 + 16 + 16
            oItem.Width = 150
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_UnitPr", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_UnitPr")
            oItem.Enabled = True

            'oGfun.SetComboBoxValueRefresh(oForm.Items.Item("t_tax").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='O' AND ""Inactive""='N'")

            ''Item Group
            'oItem = oForm.Items.Add("t_remark", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155
            'oItem.Top = 10
            'oItem.Width = 125
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_remark", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_remark")
            'oItem.Visible = False

            'sQuery = String.Empty

            ''sQuery = "[@INSPL_AR_ItemList] '" & oDBDSHeader.GetValue("U_JobEntry", 0).Trim & "' ,'" & oDBDSHeader.GetValue("CardCode", 0).Trim & "','" & oDBDSHeader.GetValue("U_BLNo", 0).Trim & "'"
            'sQuery = "CALL ""@INSPL_SO_ItemList"" ('" & oDBDSHeader.GetValue("U_DocEntry", 0).Trim & "')"
            'oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            'oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            'oGrid.AutoResizeColumns()
            'oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
            'For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
            '    If i = 0 Then
            '        oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
            '    ElseIf i = 4 Then
            '        oGrid.Columns.Item(i).Editable = True
            '    Else
            '        oGrid.Columns.Item(i).Editable = False
            '    End If
            'Next

            'oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_ItemList(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then
                            Select Case pVal.ItemUID
                                Case "ItmGrpCd"

                                    'Dim Str As String = oForm.ActiveItem
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific

                                    oForm.Items.Item("ItmGrpNm").Enabled = True
                                    oForm.Items.Item("t_maxprc").Enabled = True
                                    oForm.Items.Item("t_minprc").Enabled = True

                                    ' oForm.Items.Item("ItmGrpCd").Enabled = True

                                    Try
                                        Txt2 = oForm.Items.Item("ItmGrpNm").Specific
                                        Txt2.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                    Catch ex As Exception

                                    End Try

                                    Try
                                        Txt2 = oForm.Items.Item("ItmGrpNm").Specific
                                        Txt2.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                    Catch ex As Exception

                                    End Try



                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_SO_GET_PRICE"" ('" & oDataTable.GetValue("DocEntry", 0) & "','" & oDBDSHeader.GetValue("CardCode", 0).Trim & "')"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If Rst.RecordCount > 0 Then
                                        Try
                                            Txt2 = oForm.Items.Item("t_minprc").Specific
                                            Txt2.Value = Rst.Fields.Item(0).Value
                                        Catch ex As Exception

                                        End Try
                                        Try
                                            Txt2 = oForm.Items.Item("t_maxprc").Specific
                                            Txt2.Value = Rst.Fields.Item(1).Value
                                        Catch ex As Exception

                                        End Try

                                        Try
                                            Txt2 = oForm.Items.Item("UnitPrice").Specific
                                            Txt2.Value = Rst.Fields.Item(2).Value
                                        Catch ex As Exception

                                        End Try
                                    End If

                                    Try
                                        Txt3 = oForm.Items.Item("ItmGrpCd").Specific
                                        Txt3.Value = Trim(oDataTable.GetValue("U_ItmGrpCode", 0))
                                    Catch ex As Exception

                                    End Try
                                    oForm.Items.Item("ItmGrpNm").Enabled = False
                                    oForm.Items.Item("t_maxprc").Enabled = False
                                    oForm.Items.Item("t_minprc").Enabled = False

                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_SO_ItemList"" ('" & oDataTable.GetValue("DocEntry", 0) & "')"
                                    oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
                                    oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
                                    oGrid.AutoResizeColumns()
                                    oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
                                    For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                                        If i = 0 Then
                                            oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                                        ElseIf i = oGrid.DataTable.Columns.Count - 1 Then
                                            oGrid.Columns.Item(i).Editable = True
                                            Dim ColQty As SAPbouiCOM.EditTextColumn
                                            ColQty = oGrid.Columns.Item(oGrid.Columns.Item(i).TitleObject.Caption)
                                            ColQty.ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
                                        Else
                                            oGrid.Columns.Item(i).Editable = False
                                        End If
                                    Next
                                    oGrid.AutoResizeColumns()
                            End Select
                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) > CDbl(oForm.Items.Item("t_maxprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        oForm.Items.Item("UnitPrice").Specific.value = CDbl(oForm.Items.Item("UnitPrice").Specific.value)
                                        Exit Sub
                                    End If
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) < CDbl(oForm.Items.Item("t_minprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not less than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        oForm.Items.Item("UnitPrice").Specific.value = CDbl(oForm.Items.Item("UnitPrice").Specific.value)
                                        Exit Sub
                                    End If

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0
                                    'frmSalesOrder.Freeze(True)
                                    'oMatrix.Clear()
                                    'oMatrix.AddRow()
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    'Dim DocTyp As SAPbouiCOM.ComboBox = frmSalesOrder.Items.Item("3").Specific
                                    'DocTyp.Select("I", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value
                                            oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                            oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = oForm.Items.Item("UnitPrice").Specific.value 'oGrid.DataTable.Columns.Item("UnitPrice").Cells.Item(i - 1).Value
                                            'If oForm.Items.Item("t_tax").Specific.value <> "" Then
                                            '    Dim MainTaxCode As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
                                            '    Dim SubTaxCode As SAPbouiCOM.ComboBox = oForm.Items.Item("t_tax").Specific
                                            '    MainTaxCode.Select(SubTaxCode.Selected.Value, SAPbouiCOM.BoSearchKey.psk_ByValue)
                                            'End If
                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()

                                    Me.Calculation()

                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                    frmSalesOrder = oForm
                                    'frmSalesOrder.Freeze(False)
                                End If

                            Case "Clear"
                                If pVal.BeforeAction = False Then

                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) > CDbl(oForm.Items.Item("t_maxprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        Exit Sub
                                    End If
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) < CDbl(oForm.Items.Item("t_minprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not less than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        Exit Sub
                                    End If

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0
                                    'frmSalesOrder.Freeze(True)
                                    oMatrix.Clear()
                                    oMatrix.AddRow()
                                    Dim RowID As Integer = 1
                                    'Dim DocTyp As SAPbouiCOM.ComboBox = frmSalesOrder.Items.Item("3").Specific
                                    'DocTyp.Select("I", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value
                                            oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                            oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = oForm.Items.Item("UnitPrice").Specific.value 'oGrid.DataTable.Columns.Item("UnitPrice").Cells.Item(i - 1).Value
                                            'If oForm.Items.Item("t_tax").Specific.value <> "" Then
                                            '    Dim MainTaxCode As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
                                            '    Dim SubTaxCode As SAPbouiCOM.ComboBox = oForm.Items.Item("t_tax").Specific
                                            '    MainTaxCode.Select(SubTaxCode.Selected.Value, SAPbouiCOM.BoSearchKey.psk_ByValue)
                                            'End If
                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                    frmSalesOrder = oForm
                                    'frmSalesOrder.Freeze(False)
                                End If
                        End Select
                    Catch ex As Exception
                        frmSalesOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID
                                    Case "Quantity"
                                        If pVal.BeforeAction = False Then

                                            If oGrid.DataTable.Columns.Item("Quantity").Cells.Item(pVal.Row).Value > 0 Then
                                                oGrid.DataTable.Columns.Item("Select").Cells.Item(pVal.Row).Value = "Y"
                                            Else
                                                oGrid.DataTable.Columns.Item("Select").Cells.Item(pVal.Row).Value = "N"
                                            End If
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                          
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub

    Sub CreateMySimpleForm_SODetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SODetails"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Sale Order Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 675
            oItem.Height = 260
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"

            sQuery = String.Empty
            sQuery = "CALL ""@INSPL_GET_SO_DETAILS""  ('" & oDBDSHeader.GetValue("U_PickWhs", 0).Trim & "')"
            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_SODetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then
                             
                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    Dim DocEntryList As String = String.Empty
                                    Dim DocCount As Integer = 0
                                    oMatrix.Clear()
                                    oMatrix.AddRow()

                                    'For i As Integer = 1 To oGrid.Rows.Count
                                    '    If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                    '        If DocCount = 0 Then
                                    '            DocEntryList = "|" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "|"
                                    '        Else
                                    '            DocEntryList = DocEntryList & "," & "|" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "|"
                                    '        End If
                                    '        DocCount += 1
                                    '    End If
                                    'Next

                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            If DocCount = 0 Then
                                                DocEntryList = "'" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "'"
                                            Else
                                                DocEntryList = DocEntryList & "," & "'" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "'"
                                            End If
                                            DocCount += 1
                                        End If
                                    Next


                                    sQuery = String.Empty
                                    sQuery = " SELECT B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"",A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"",SUM(""Quantity"") ""Quantity"" FROM   RDR1 A, "
                                    sQuery += " ORDR B WHERE A.""DocEntry""=B.""DocEntry""   AND CAST(B.""DocEntry"" AS NVARCHAR(100)) IN (" & DocEntryList & ")"
                                    sQuery += " GROUP BY A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"",B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"";"

                                    'sQuery = " SELECT TOP 10 B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"",A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"","
                                    'sQuery += " SUM(A.""Quantity"") ""Quantity"" FROM  RDR1 A, ORDR B WHERE A.""DocEntry""=B.""DocEntry"" AND CAST(A.""DocEntry"" AS NVARCHAR(100)) IN (" & DocEntryList & ")"
                                    'sQuery += " GROUP BY  A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"",B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"";"

                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                                    RowID = 1
                                    If Rst.RecordCount > 0 Then
                                        Rst.MoveFirst()
                                        For j As Integer = 1 To Rst.RecordCount
                                            oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = Rst.Fields.Item("ItemCode").Value
                                            oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = Rst.Fields.Item("Quantity").Value
                                            oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = Rst.Fields.Item("Price").Value
                                            'oMatrix.Columns.Item("24").Cells.Item(RowID).Specific.value = Rst.Fields.Item("WhsCode").Value

                                            Dim TaxCode As String = Rst.Fields.Item("VatGroup").Value
                                            Dim Combo As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
                                            'Combo.Select(Rst.Fields.Item("VatGroup").Value, SAPbouiCOM.BoSearchKey.psk_ByValue)

                                            oMatrix.Columns.Item("U_BaseNum").Cells.Item(RowID).Specific.value = Rst.Fields.Item("DocNum").Value
                                            oMatrix.Columns.Item("U_BaseEntry").Cells.Item(RowID).Specific.value = Rst.Fields.Item("DocEntry").Value
                                            oMatrix.Columns.Item("U_BaseLine").Cells.Item(RowID).Specific.value = Rst.Fields.Item("LineNum").Value
                                            oMatrix.Columns.Item("U_BaseType").Cells.Item(RowID).Specific.value = "SBMDUBAILIVE"
                                            oMatrix.Columns.Item("U_CardCode").Cells.Item(RowID).Specific.value = Rst.Fields.Item("CardCode").Value
                                            oMatrix.Columns.Item("U_CardName").Cells.Item(RowID).Specific.value = Rst.Fields.Item("CardName").Value
                                            Rst.MoveNext()
                                            RowID += 1
                                        Next
                                    End If

                                    frmSalesOrder.Items.Item("t_sso").Enabled = True
                                    frmSalesOrder.Items.Item("t_sso").Specific.value = DocEntryList
                                    frmSalesOrder.Items.Item("16").Specific.value = frmSalesOrder.Items.Item("16").Specific.value
                                    frmSalesOrder.Items.Item("t_sso").Enabled = False
                                    oForm.Close()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    'frmSalesOrder = oForm
                                End If

                            Case "Clear"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0
                                    oMatrix.Clear()
                                    oMatrix.AddRow()
                                    Dim RowID As Integer = 1
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value
                                            oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                            oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = oForm.Items.Item("UnitPrice").Specific.value 'oGrid.DataTable.Columns.Item("UnitPrice").Cells.Item(i - 1).Value
                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    frmSalesOrder = oForm
                                End If
                        End Select
                    Catch ex As Exception
                        frmSalesOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID
                                   
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub



    'Dim oCompanyService As SAPbobsCOM.CompanyService
    'Dim oTimeSheetService As SAPbobsCOM.ProjectManagementTimeSheetService
    'Dim oTimeSheet As SAPbobsCOM.PM_TimeSheetData
    'Dim oTimeSheetLine As SAPbobsCOM.PM_TimeSheetLineData
    'Dim oTimeSheetParam As SAPbobsCOM.PM_TimeSheetParams
    'Dim StartTime As Date
    'Dim EndTime As Date
    'Dim breakTime As Date
    'Dim NonBillableTime As Date

    'Dim oCompanySer As SAPbobsCOM.CompanyService = oCompany.GetCompanyService
    'Dim oTimeShee As SAPbobsCOM.ProjectManagementTimeSheetService = oCompanyService.GetBusinessService(SAPbobsCOM.ServiceTypes.ProjectManagementTimeSheetService)
    'Dim oTimeSheet As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetData)
    'Dim oTimeSheetLine As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetLineData)
    'Dim oTimeSheetParam As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetParams)

    'oTimeSheet.TimeSheetType = SAPbobsCOM.TimeSheetTypeEnum.tsh_Employee
    'oTimeSheet.UserId = 2


    'StartTime = VBA.DateAdd("h", 7, VBA.Int(Now)) 'start a 7.00
    'EndTime = VBA.DateAdd("n", 90, StartTime) 'add 90 minutes
    'breakTime = VBA.DateAdd("n", 45, VBA.Int(Now)) 'pause  45 minutes


    'NonBillableTime = VBA.DateAdd("n", 15, VBA.Int(Now))
    'oTimeSheetLine.Date = Now
    'oTimeSheetLine.StartTime = StartTime
    'oTimeSheetLine.EndTime = EndTime
    'oTimeSheetLine.Break = breakTime
    'oTimeSheetLine.NonBillableTime = NonBillableTime
    'oTimeSheetLine.ActivityType = 1
    'oTimeSheetLine.CostCenter = ""
    'oTimeSheetLine.FinancialProject = "090"

    'oTimeSheetLine = oTimeSheet.PM_TimeSheetLineDataCollection.Add()

    'oTimeSheetParam = oTimeSheetService.AddTimeSheet(oTimeSheet)
 
End Class
