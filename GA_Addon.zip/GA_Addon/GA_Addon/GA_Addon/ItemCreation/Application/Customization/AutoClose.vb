﻿Public Class AutoClose
    Dim frmAutoClose As SAPbouiCOM.Form
    Dim oMatrix As SAPbouiCOM.Matrix

    Sub LoadAutoClose()
        oGfun.LoadXML(frmAutoClose, AutoCloseFormID, AutoCloseXML)
        frmAutoClose = oApplication.Forms.Item(AutoCloseFormID)


        InitForm()

    End Sub
#Region "InitForm"
    Sub InitForm()
        Try
            frmAutoClose.Freeze(True)



            oMatrix = frmAutoClose.Items.Item("mtx_Auto").Specific

            Dim StrQry As String = "Select Code,Name,U_GA_Auto from [@GA_PROCL_H] where ISNULL(Code,'') <>''"
            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(StrQry)
            oMatrix.Clear()
            For i As Integer = 1 To Rst.RecordCount
                oMatrix.AddRow()
                oMatrix.GetLineData(i)
                frmAutoClose.DataSources.UserDataSources.Item("UD_Code").ValueEx = Rst.Fields.Item(0).Value.ToString()
                frmAutoClose.DataSources.UserDataSources.Item("UD_Nm").ValueEx = Rst.Fields.Item(1).Value.ToString()
                frmAutoClose.DataSources.UserDataSources.Item("UD_Auto").ValueEx = Rst.Fields.Item(2).Value.ToString()
                oMatrix.SetLineData(i)
                Rst.MoveNext()
            Next
            oMatrix.AutoResizeColumns()


            frmAutoClose.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("InitForm Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmAutoClose.Freeze(False)
        Finally
        End Try
    End Sub
#End Region

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmAutoClose = oApplication.Forms.Item(FormUID)

                '   oForm = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = AutoCloseFormID Then
                Select Case pVal.EventType





                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "Update"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Updating Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        For i As Integer = 1 To oMatrix.RowCount

                                            oMatrix.GetLineData(i)
                                            Dim oGeneralservice As SAPbobsCOM.GeneralService
                                            Dim oGeneralData As SAPbobsCOM.GeneralData
                                            Dim oGeneralDataParam As SAPbobsCOM.GeneralDataParams
                                            Dim oCompanyService As SAPbobsCOM.CompanyService
                                            oCompanyService = oCompany.GetCompanyService()
                                            oGeneralservice = oCompanyService.GetGeneralService("GA_PROCL")
                                            'oGeneralData = oGeneralservice.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData)
                                            oGeneralDataParam = oGeneralservice.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams)
                                            oGeneralDataParam.SetProperty("Code", frmAutoClose.DataSources.UserDataSources.Item("UD_Code").ValueEx)

                                            'oGeneralDataParam.SetProperty("U_GA_Auto", frmAutoClose.DataSources.UserDataSources.Item("UD_Auto").ValueEx)
                                            oGeneralData = oGeneralservice.GetByParams(oGeneralDataParam)

                                            oGeneralData.SetProperty("U_GA_Auto", frmAutoClose.DataSources.UserDataSources.Item("UD_Auto").ValueEx)
                                            oGeneralservice.Update(oGeneralData)
                                        Next
                                        oApplication.StatusBar.SetText("Operation Completed", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                        frmAutoClose.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End If

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try


                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try

                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
