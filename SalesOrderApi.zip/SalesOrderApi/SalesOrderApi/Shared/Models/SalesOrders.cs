﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class SalesOrders
	{
		public TransmissionHeader TransmissionHeader { get; set; }
		public OrderHeader OrderHeader { get; set; }
		public OrderDetails OrderDetails { get; set; }

	}
	public class TransmissionHeader
	{
		public string ReceiverCode { get; set; }      //	
		public string DatePrepared { get; set; }      //		
		public string TimePrepared { get; set; }
	}
	public class OrderHeader
	{
		public string CustomerPoNumber { get; set; }
		
		public string OrderActionType { get; set; }
	
		public string Customer { get; set; }	
		public string OrderDate { get; set; }

		public string CustomerName { get; set; }
		public string ShipAddress1 { get; set; }
		public string ShipAddress2 { get; set; }
		public string ShipAddress3 { get; set; }
		public string ShipAddress4 { get; set; }
		public string ShipPostalCode { get; set; }
		public string AlternateReference { get; set; }
		public string Branch { get; set; }
		public string RequestedShipDate { get; set; }
		public string OrderComments { get; set; }
	}
	public class OrderDetails
	{
		public List<StockLine> StockLines { get; set; }
		public CommentLine CommentLine { get; set; }
	}
	public class StockLine
	{
		public string CustomerPoLine { get; set; }      //

		public string LineActionType { get; set; }      //

		public string StockCode { get; set; }      //

		public string StockDescription { get; set; }      //

		public string CustomersPartNumber { get; set; }      //

		public string OrderQty { get; set; }      //

		public string OrderUom { get; set; }      //

		public string Price { get; set; }      //

		public string PriceUom { get; set; }

	}
	public class CommentLine
	{
		public string CustomerPoLine { get; set; }      //

		public string LineActionType { get; set; }      //

		public string Comment { get; set; }      //

		public string AttachedLineNumber { get; set; }
	}
}
