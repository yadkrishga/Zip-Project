﻿
using System.Net.Security;
using System.Net;

using System.Security.Cryptography.X509Certificates;
using System.Text;

using Newtonsoft.Json.Linq;
using Newtonsoft.Json;


using System.Xml;

using System.Globalization;


using System.Data;
using Shared.Models;
using Shared;

using System.Data.SqlClient;
using System.Reflection.PortableExecutable;
using System.Xml.Linq;
using System.ComponentModel;
using System.Reflection.Emit;
using System.Threading.Tasks.Dataflow;

namespace SAPProc
{
	

	public class SAPB1Context :ISapB1
	{
		private HttpClientHandler handler;
		private HttpClient client;
		
		private string SessionID = string.Empty;
		private string RouteID = string.Empty;
		private string Folder;
		private int BPPriceListNum;
		private TComm_Header Header;
		private List<TComm_Lines> Lines;
		private int  err,lastix,lnix,ordrlnnum,explnnum;
		private string shiptoCode, billtoCode, docEntry;
		public SqlConnection cn;
		private string CallSource;
		SqlTransaction transaction;
		SqlConnection DBConnection
		{
			get
			{

				if (cn != null && cn.State == ConnectionState.Open)
					return cn;
				else
				{
					try
					{
						cn = new SqlConnection(Logw.sqlConnectionString);
						cn.Open();
		//	transaction = cn.BeginTransaction();

					}
					catch (Exception e)
					{
						Logw.Log(new Exception(e.Message+ Logw.sqlConnectionString));
					}
				}

				return cn;

			}

		}
	
		public  UserInfo Finduser(UserInfo user)
		{
			
			UserInfo newuser = new UserInfo();
			string qry = $"Select * From [@G_Mng] Where Code = '1'";
			SqlCommand SqlCmd = null;
			using (SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
			{
				using (SqlDataReader reader =  SqlCmd.ExecuteReader())
				{
					if (reader.Read())
					{
						if (reader.HasRows)
						{
							try
							{
								newuser.Password = reader["U_APIpssw"].ToString();
							
								newuser.Password = Logw.Decrypt(newuser.Password,true);
							} 
							catch { }
							newuser.UserId = reader["U_APIUser"].ToString();
							if (newuser.Password != user.Password || newuser.UserId != user.UserId)
								newuser = new UserInfo();
						}
					}
					cn.Close();
				
				}
			}
			return newuser;
		}
		public SAPB1Context()
        {
			ServicePointManager.ServerCertificateValidationCallback += RemoteSSLTLSCertificateValidate;
			Logw.exefolder = AppDomain.CurrentDomain.BaseDirectory;
			//ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, errors) =>
			//{
			//	// local dev, just approve all certs
			
			//	return errors == SslPolicyErrors.None;
			//};

		}
		private string PriceCheck(string itemCode,string cardCode,double price)
		{
			string ret = "";
			string EntityName = "SpecialPrices";
			/*string ext = $"?$select = ItemCode,ItemName,ItemsGroupCode,Frozen,ItemPrices&$filter = ItemCode eq '{itemCode}' ";
			string value = this.Get(EntityName, ext);
			var ItemObj = JsonConvert.DeserializeObject<dynamic>(value);
			if (ItemObj != null)
			{
				if (ItemObj.Frozen == "Y")
				{
					ret = $"Item  {itemCode} is Frozen";

				}
				else if (String.IsNullOrEmpty(ItemObj.ItemName))
				{
					ret = $"{itemCode} Item cannot found";
				}
				else

					ret = "";
			}
			else
			{
				ret = $"{itemCode} Item cannot found";
			}*/
			return ret;
		}
		private string GetSpp(string cardcode,string Itemcode)
		{
			string ret = "0";

			string EntityName = $"SpecialPrices(CardCode='{cardcode}',ItemCode='{Itemcode}')";
			
			string ext = $"";
			try
			{
				JObject value = this.Get(EntityName, ext);
				
				if (value != null)
				{
					if (value.ToString().ToLower().IndexOf("error") > -1)
					{
						ret = "0";
					}
					var SppObj = value.ToObject<SpecialPrices>();
					if (SppObj != null)
					{
						return SppObj.Price;
					}
				}
			} catch (Exception ex) { }
			return ret;
		}
		private AdditionalExpenses GetExpenceCode(string expName)
		{

			AdditionalExpenses ExpObj = null;
			string EntityName = "AdditionalExpenses";
			string ext = $"?$select = ExpensCode,OutputVATGroup&$filter = Name eq '{expName}' ";
			JObject joResponse = this.Get(EntityName, ext);
			if (joResponse != null)
			{
				JArray array = (JArray)joResponse["value"];
				string st = "";
				if (array != null && array.Count > 0)
					st = array[0].ToString();
				
			     ExpObj = JsonConvert.DeserializeObject<AdditionalExpenses>(st);
				if (ExpObj != null)
				{
					return ExpObj;
				}
			}
			return ExpObj;
		}
		private string ItemCheck(string itemCode,double price)
		{
			string ret = "";
			 double PriceofList= 0;
			double spprice = 0;
		    string EntityName = "Items";
			string ext = $"?$select = ItemCode,ItemName,ItemsGroupCode,Frozen,ItemPrices&$filter = ItemCode eq '{itemCode}' ";
			
			JObject joResponse = this.Get(EntityName, ext);
			if (joResponse != null)
			{
				JArray array = (JArray)joResponse["value"];
				string st = "";
				if (array != null && array.Count > 0)
					st = array[0].ToString();

				var ItemObj = JsonConvert.DeserializeObject<Invent>(st);

				if (ItemObj != null)
				{
					if (ItemObj.Frozen == "Y")
					{
						err++;
						ret = $" # Item  {itemCode} is Frozen";

					}
					else if (String.IsNullOrEmpty(ItemObj.ItemName))
					{
						err++;
						ret += $" # {itemCode} Item Code is missing";
					}
					else
					{
						ret = "";
						if (String.IsNullOrEmpty(CallSource))
						{
							Logw.Log("CallSource empty");
							spprice = Convert.ToDouble(this.GetSpp(Header.CardCode, itemCode));

							if (spprice == 0 && BPPriceListNum > 0)
							{
								PriceofList = Convert.ToDouble(ItemObj.ItemPrices[BPPriceListNum - 1].Price);
							}
							if (price == spprice)
							{
								Logw.Log("spp price "+price.ToString()+"--"+spprice);
								ret = "";
							} else 
							if (price == PriceofList &&  spprice == 0)
							{
								Logw.Log("list price");
								ret = "";
							} else								
							{

								    if (spprice >0)
									ret += $" # Price of Item({itemCode}) is different Price = " + spprice.ToString();
									else
									ret += $" # Price of Item({itemCode}) is different Price = " + PriceofList.ToString();
								err++;
							}
								
					    }
							
					} 
				} else
					
				{
					err++;
					ret += $"  {itemCode} Item Code is missing";
				}
			}
			else
			{
				err++;
					ret += $"  {itemCode} Item Code is missing";
			}
			
			return ret;
		}

        private string ItemGroupCheck(string itemCode)
        {
            string ret = "";

            string EntityName = "Items";
            string ext = "?$select = ItemsGroupCode&$filter = ItemCode eq '" + itemCode + "' ";
            JObject joResponse = Get(EntityName, ext);
            if (joResponse != null)
            {
                JArray array = (JArray)joResponse["value"];
                string st = "";
                if (array != null && array.Count > 0)
                {
                    st = array[0].ToString();
                }
                ItemGrp ItemObj = JsonConvert.DeserializeObject<ItemGrp>(st);
                if (ItemObj != null)
                {
					Int32 ItemGroupCode = Convert.ToInt32(ItemObj.ItemsGroupCode);
                    string EntityName2 = "ItemGroups";
                    string ext2 = "?$select = GroupName&$filter = Number eq " + ItemGroupCode + "";
                    JObject joResponse2 = Get(EntityName2, ext2);
                    if (joResponse2 != null)
                    {
                        JArray array2 = (JArray)joResponse2["value"];
                        string st2 = "";
                        if (array2 != null && array2.Count > 0)
                        {
                            st2 = array2[0].ToString();
                        }
                        ItemGrpName ItemObj2 = JsonConvert.DeserializeObject<ItemGrpName>(st2);
                        if (ItemObj2 != null)
                        {
                            string ItemGroupName = ItemObj2.GroupName;
                            ret = ItemGroupName;
                        }

                    }
                }
            }

            return ret;
        }
        private string CustomerCheck(string AliasName,string postcode)
		{
			string ret = "";
			string cardCode = findCardCode(AliasName);
			Logw.Log("cardCode=" + cardCode);
			string EntityName = "BusinessPartners";
			Header.CardCode = cardCode;
			string ext = $"?$select = CardCode,CardName,CardType,Frozen,PriceListNum,BPAddresses  &$filter = CardCode eq '{cardCode}' ";
			Logw.Log(ext);
			
			JObject joResponse = this.Get(EntityName, ext);
			if (joResponse != null)
			{

				JArray array = (JArray)joResponse["value"];
				string st = "";
				if (array != null && array.Count > 0)
					st = array[0].ToString();


				var BussPObj = JsonConvert.DeserializeObject<BussinesPartner>(st);
				if (BussPObj != null)
				{
					if (BussPObj.Frozen == "Y")
					{
						ret = $"#Customer Card {cardCode} is Frozen";

					}
					else if (String.IsNullOrEmpty(BussPObj.CardName))
					{
						ret = $"#{AliasName} Customer name empty";
					}
					if (String.IsNullOrEmpty(ret))
					{
						try
						{
							BPPriceListNum = Convert.ToInt32(BussPObj.PriceListNum);
						}
						catch (Exception e)
						{
							ret = $"{BussPObj.PriceListNum} BP price list num invalid";
						}
						List<BPAddress> BPAddresses = BussPObj.BPAddresses;
						BPAddress addr = BPAddresses.Find(x => x.AddressType == "bo_ShipTo" && x.ZipCode == postcode);

						if (addr == null)
						{
							//addr = BPAddresses.Find(x => x.AddressType == "bo_ShipTo");
							//if (addr == null)
							//{
							//	ret = "Ship Address is missing";
							//	err++;
							//}
							//else
							//	ret = $"#ShipPostalCode={postcode}  cannot found in Addresses" + addr.AddressName;
						}
						else
						{
							shiptoCode = addr.AddressName;

							Header.CardCode = cardCode;

							ret = "";
						}
						addr = BPAddresses.Find(x => x.AddressType == "bo_BillTo" && x.ZipCode == postcode);
						if (addr == null)
						{

						}
						else
						{
							billtoCode = addr.AddressName;

						}
					}



				}
				else
				{
					err++;
					Logw.Log("joResponse  null");
					ret = $"#{AliasName} BP cannot found";
				}
			}
			else
			{
				err++;
				ret = $"{AliasName} Customer Code is missing";
			}
			return ret;
		}


		private  void getSettings()
		{

			try
			{
				//Logw.
				//Folder = AppDomain.CurrentDomain.BaseDirectory;
				
				//StreamReader r = new StreamReader(Folder + @"\config.json");

				//string json = r.ReadToEnd();

				//JObject joResponse = JObject.Parse(json);
				//JArray array = (JArray)joResponse["SLConnection"];
				//json = array.ToString();
				//json = json.Remove(0, 1);
				//json = json.Remove(json.Length - 1, 1);
				//cnf = JsonConvert.DeserializeObject<config>(json);
				
				//cnf.Password = Logw.Decrypt(cnf.Password, true);				
				//cnf.DbPassword = Decrypt(cnf.DbPassword, true);
				//sqlConnectionString = $"Server={cnf.DbServer};Database={cnf.DbName};Uid={cnf.DbUserName};Pwd={cnf.DbPassword};";


			}
			catch (Exception er)
			{
				Logw.Log(er);
			}



		}
		private string DuplicateOrder()
		{
			string ret = "";
			string EntityName = "Orders";

			string ext = $"?$select = CardCode,DocNum,NumAtCard&$filter = CardCode eq '{Header.CardCode}' and NumAtCard eq '{Header.CustomerPoNumber}'";
			
			JObject joResponse = this.Get(EntityName, ext);
			if (joResponse != null)
			{
				JArray array = (JArray)joResponse["value"];
				string st = "";
				if (array != null && array.Count > 0)
				{
					st = array[0].ToString();
					try
					{
						var definition = new
						{
							CardCode = "",
							DocNum = "",
							NumatCard = ""

						};
						var def = JsonConvert.DeserializeAnonymousType(st, definition);
						if (def != null)
						{
							ret = "DocNum:" + def.DocNum;

						}

					}
					catch (Exception errt)
					{
						Logw.Log(errt);
					}
				}

				
			}
			
			return ret;
		}
		public string CreateOrder(Param1 param)
		{
			CallSource = param.source;
			err = 0;
			int err1 = 0;
			string ret = "Created Order DocNum = {0}";
			XmlDocument doc = new XmlDocument();
			docEntry = "0";
			try
			{
				err1 = 1;
				doc.LoadXml(param.xmlDoc);
				if (doc == null)
					return "XML Document null";
				err1 = 2;
				ret = Connect();
				err1 = 3;
				if (SessionID == string.Empty)
				{
					throw new Exception("Session Id empty " + ret);
					Logw.Log("Session Id empty");
				}

				err1 = 4;
				Orders order = new Orders();
				order.DocObjectCode = "oOrders";
				Lines = new List<TComm_Lines>();
				err1 = 5;
				Header = new TComm_Header();
				Header.DocRef = "";
				Header.Status = "";
				Header.Message = "";

				XmlNode headernode = doc.SelectSingleNode("SalesOrders/Orders/OrderHeader");
				if (headernode == null)
				{
					Logw.Log(new Exception("XML Data invalid"));
					return "XML Data invalid";

				}
				try
				{
					order.CardCode = headernode.SelectSingleNode("Customer").InnerText.Trim();

					Header.Customer = order.CardCode;
					order.NumAtCard = headernode.SelectSingleNode("CustomerPoNumber").InnerText;
					Header.CustomerPoNumber = order.NumAtCard;
				}
				catch
				{

				}
			
				
				
				try
				{
					Header.CustomerName = headernode.SelectSingleNode("CustomerName").InnerText.Trim();
					
				}

				catch (Exception e)
				{

				}
				try
				{

					Header.ShipAddress1 = headernode.SelectSingleNode("ShipAddress1").InnerText;
					//order.ShipToCode = Header.ShipAddress1;
				}
				catch (Exception e)
				{

				}

				try
				{
					Header.ShipAddress2 = headernode.SelectSingleNode("ShipAddress2").InnerText;
				}
				catch (Exception e)
				{

				}
				try
				{
					Header.ShipAddress3 = headernode.SelectSingleNode("ShipAddress3").InnerText;
				}
				catch (Exception e)
				{

				}

				try
				{
					Header.ShipAddress4 = headernode.SelectSingleNode("ShipAddress4").InnerText;
				}
				catch (Exception e)
				{

				}

				string postcode = "";
				try
				{
					
					postcode = headernode.SelectSingleNode("ShipPostalCode").InnerText;
					Header.ShipPostalCode = postcode;
					order.AddressExtension.ShipToBuilding  = Header.ShipAddress1 +" "+Header.ShipAddress2 + " " + Header.ShipAddress3 + " " + Header.ShipAddress4;
					//order.AddressExtension.ShipToAddress3 = Header.ShipAddress3;

				//	order.AddressExtension.ShipToCity  = Header.ShipAddress4;
					order.AddressExtension.ShipToZipCode = postcode;
					
					//order.Address2 = Header.ShipAddress2 + "\n" + Header.ShipAddress3 + "\n" + Header.ShipAddress4 + "\n" + postcode;
					
				}
				catch (Exception e)
				{
					Logw.Log(e);
				}

				ret = CustomerCheck(Header.Customer, postcode);
				order.CardCode = Header.CardCode;

				if (shiptoCode != null)
				{
					order.ShipToCode = shiptoCode;
				}
				order.PayToCode = billtoCode;
				if (ret.Length > 0)
				{
					Header.Message = ret + " **";
					
					err++;
				}
				order.DocDate = "";
				try
				{
					order.DocDate = headernode.SelectSingleNode("OrderDate").InnerText;
					order.TaxDate = order.DocDate;
					Header.OrderDate = order.DocDate;
					order.DocDueDate = headernode.SelectSingleNode("RequestedShipDate").InnerText;
					Header.RequestedShipDate = order.DocDueDate;
				}
				catch (Exception e)
				{
					Logw.Log(new Exception(e.Message + " date " + order.DocDate));
				}
				
				string dpret = DuplicateOrder();
				if (dpret.Length > 0)
				{
					Header.Status = "F";
					Header.Message = $"Fail..Duplicate XML {dpret}";
					Logoff();
					writeresult(doc, param.xmlName);
					return $"Duplicate XML {dpret}";
				}
				
				string branch = "";

				try
				{
					branch = headernode.SelectSingleNode("Branch").InnerText;
					Header.Branch = branch;
					order.Series = this.GetSeries("17", branch);
					
					if (String.IsNullOrEmpty(order.Series) || order.Series == "0")
					{
						order.Series = GetSeriesbyname("17", branch);
					}
				}
				catch (Exception e)
				{
					Logw.Log(e);
				}
				try
				{
					order.Comments = headernode.SelectSingleNode("OrderComments").InnerText;

				}
				catch (Exception e)
				{

				}
				XmlNode detailsnode = doc.SelectSingleNode("SalesOrders/Orders/OrderDetails");
				int lx = -1;
				string wh = branch;
				if (branch.Length<3)
					wh = branch.Substring(0, 1)+"0"+branch.Substring(1,1);
				foreach (XmlNode line in detailsnode)
				{
					lx++;
					
					order = addLines(order, line, lx, wh);
					
				}
				// Freight;
				string postmess = "";
				Header.DocRef = "";
				
				Header.Status = "S";
				order.U_GA_OrderOrigin = "EDI";
				order.U_ImportXML = param.xmlName;

				if (err == 0)
				{
					try
					{
						//string owner = getowner();
						
						//if (Convert.ToInt32(owner) > 0)
						//	order.DocumentsOwner = owner;
					} catch (Exception e)
					{
						Logw.Log(e);
					}
					postmess = Post("Orders", order);
				}
				
				if (postmess.ToLower().IndexOf("error") > -1)
				{
					err1 = 88;
					
					Header.Status = "F";
					err1 = 881;
					postmess = GetPostMess(postmess);
					Header.Message = postmess;
					ret = postmess;
				}
				else
				{
					string[] splt = postmess.Split(':');
					if (splt.Length > 1)
						Header.DocRef = splt[1];

				}
				if (err > 0 && Header.Message.Length == 0)
				{
					Header.Message = postmess + " there is error in lines";
					ret = postmess + " there is error in lines";
				}
				if (Header.Message.Length == 0)
				{
					Header.Message = postmess;
					ret = postmess;
				}
				if (err > 0)
					Header.Status = "F";
				Header.Message = Header.Message.Replace("'", "");

			}
			catch (Exception er)
			{
				ret = er.Message + "--" + err1.ToString();
				Logw.Log(new Exception(ret));
				return ret;
			}
			Logoff();
		

			writeresult(doc,param.xmlName);
			string ret1 = "Fail ";
			if (Header.Status == "S")
				ret1 = "Success ";
			return ret1+ret;
		}
		private string getowner()
		{
			string ret = "";
			string qry = $"Select empID FROM OUSR A INNER JOIN OHEM B ON A.UserId = B.UserId Where A.USER_Code = '{Logw.cnf.UserName}'";
			using (SqlCommand SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
			{
				
				using (SqlDataReader reader = SqlCmd.ExecuteReader())
				{
					
					if (reader.Read())
					{
						
						if (reader.HasRows)
						{
							
							ret = reader[0].ToString();

						}
					}
				}
			}
			return ret;
		}
		private string GetPostMess(string st)
		{
			string ret = st;
			st.Replace("'", "");
			
			try
			{
				var definition = new
				{
					error = new
					{
						code = "",
						message = ""
					}

				};
				var def = JsonConvert.DeserializeAnonymousType(st, definition);
				if (def != null)
				{
					ret = def.error.message;

				}

			}
			catch (Exception errt)
			{
				Logw.Log(new Exception(errt.Message+st));
				ret = st;

			}
			return ret;
		}
		private bool existlogdata()
		{
			bool ret = false;
			string qry = "";
			int cnt = 0;
			try
			{

				qry = $"Select Count(*) From  TComm_Header Where CustomerPoNumber = '{Header.CustomerPoNumber}'";

				using (SqlCommand SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
				{
					
					using (SqlDataReader reader = SqlCmd.ExecuteReader())
					{
						if (reader.Read())
						{							
							if (reader.HasRows)
							{								
								cnt = Convert.ToInt32(reader[0].ToString());
								if (cnt>0)
								   ret = true;
							}
						}
					}
				}

			}
			catch (Exception errt) {
			   Logw.Log(new Exception(errt.Message+qry));
			}
			return ret;
		}
		private void writeresult(XmlDocument XmlData,string xmlname)
		{
			string qry = "";
			int cnt = 0;
			string hata = "";
			if (String.IsNullOrEmpty(docEntry))
				docEntry = "0";
			try
			{
				
				qry = $"Select Count(*) From  TComm_Header Where CustomerPoNumber = '{Header.CustomerPoNumber}'";

				using (SqlCommand SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
				{
					hata = "1";
					using (SqlDataReader reader = SqlCmd.ExecuteReader())
					{
						hata = "2";
						if (reader.Read())
						{
							hata = "3";
							if (reader.HasRows)
							{
								hata = "4";
								cnt = Convert.ToInt32(reader[0].ToString());

							}
						}
					}
				}
				hata = "5";
				string fname = "", filename = "";
				string date = DateTime.Now.ToString("yyyy-MM-dd");
				string time = DateTime.Now.ToString("HH:mm:ss");
				hata = "6";
				if (Header.Message.Length > 150)
					Header.Message = Header.Message.Substring(0, 150);
				hata = "7";
				fname = Logw.saveXml(XmlData, Header.Status, xmlname);
				filename = Path.GetFileName(fname);
				if (cnt == 0)
				{
					qry = "INSERT INTO TComm_Header (";
					qry += "CustomerPoNumber,Customer ,CustomerName ,OrderDate ,ShipAddress1 ,ShipAddress2 ,ShipAddress3 ,ShipPostalCode ,RequestedShipDate ,Branch ,DocRef ,Status ,Message ,ImportDate , ImportTime,XmlFile,XmlFolder,AppUser,CardCode )";
					qry += " VALUES (";
					qry += $" '{Header.CustomerPoNumber}','{Header.Customer}','{Header.CustomerName}','{Header.OrderDate}','{Header.ShipAddress1}','{Header.ShipAddress2}','{Header.ShipAddress3}','{Header.ShipPostalCode}','{Header.RequestedShipDate}','{Header.Branch}',";

					qry += $" '{docEntry}','{Header.Status}','{Header.Message}','{date}','{time}','{filename}','{fname}','{Logw.cnf.UserName}','{Header.CardCode}')";
					using (SqlCommand SqlCmd = new SqlCommand(qry, DBConnection))
					{
						
						Convert.ToInt32(SqlCmd.ExecuteScalar());
					}
				} else
				{
					qry = $"UPDATE TComm_Header SET DocRef = '{docEntry}',Status ='{Header.Status}' ,Message= '{Header.Message}',XmlFile='{filename}',XmlFolder='{fname}',AppUser='{Logw.cnf.UserName}',CardCode='{Header.CardCode}',Customer='{Header.Customer}' WHERE CustomerPoNumber = '{Header.CustomerPoNumber}'";
					Logw.Log(qry);	
					using (SqlCommand SqlCmd = new SqlCommand(qry, DBConnection))
					{
						
						Convert.ToInt32(SqlCmd.ExecuteScalar());
					}
					
				}
			}
			catch (Exception ex)
			{
				Logw.Log(new Exception(ex.Message+ " hata="+hata + qry.ToString()));
				if (transaction != null)
					transaction.Rollback();
				cn.Close();
				
				
			}
			try
			{
				int cntl = 0;
				
					foreach (var item in Lines)
					{
						cntl = 0;
						qry = $"Select count(*) FROM TComm_Lines WHERE CustomerPoNumber = '{Header.CustomerPoNumber}' AND CustomerPoLine = '{item.CustomerPoLine}'";
						using (SqlCommand SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
						{
						Logw.Log(qry);
							using (SqlDataReader reader = SqlCmd.ExecuteReader())
							{
								if (reader.Read())
								{
									if (reader.HasRows)
									{
										cntl = Convert.ToInt32(reader[0].ToString());

									}
								}
							}
						}
					item.Message = item.Message.Replace("'", "");
					if (item.Message.Length > 150)
						item.Message = item.Message.Substring(0, 150);
					
						if (cntl == 0)
						{
							qry = "INSERT INTO TComm_Lines (";
							qry += "CustomerPoNumber,CustomerPoLine,StockCode,StockDescription,OrderQty,Price,Comment,Status,Message) VALUES ( ";
							qry += $" '{Header.CustomerPoNumber}','{item.CustomerPoLine}','{item.StockCode}','{item.StockDescription}',{item.OrderQty},{item.Price},'{item.Comment}','{item.Status}','{item.Message}')";
						} else
						{
							qry = $"UPDATE TComm_Lines SET StockCode='{item.StockCode}',StockDescription='{item.StockDescription}',OrderQty={item.OrderQty},Price={item.Price},Comment='{item.Comment}',Status='{item.Status}',Message='{item.Message}'";
							qry += $" WHERE CustomerPoNumber = '{Header.CustomerPoNumber}' AND CustomerPoLine = '{item.CustomerPoLine}'";
						
						}
						using (SqlCommand SqlCmd = new SqlCommand(qry, DBConnection))
						{
							Convert.ToInt32(SqlCmd.ExecuteScalar());
						}
					}
					if (Header.Status == "S")
				    {
				     	Logw.RemoveXml("F", xmlname);
				    }
				
			}
			catch (Exception ex)
			{
				Logw.Log(new Exception(ex.Message + qry.ToString()));
				if (transaction != null)
					transaction.Rollback();
				cn.Close();
				
				
			}
			
		
			
		}
		private string findCardCode(string AliasName)
		{
			string ret = "";
			try
			{
				string qry = $"Select CardCode From OCRD Where AliasName LIKE '{AliasName}' OR CardCode ='{AliasName}'";
				SqlCommand SqlCmd = null;
				Logw.Log(qry);
				using (SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
				{
					using (SqlDataReader reader = SqlCmd.ExecuteReader())
					{
						if (reader.Read())
						{
							if (reader.HasRows)
							{
								ret = reader[0].ToString();

							}
						}
					}
				}
			}
			catch (Exception er)
			{
				Logw.Log(er);
			}

			return ret;

		}
		private string GetSeriesbyname(string objcode, string seriesname)
		{
			string ret = "";
			try
			{
				string qry = $"Select Series From NNM1 Where ObjectCode = {objcode} AND SeriesName = '{seriesname}'";
				SqlCommand SqlCmd = null;
				
				using (SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
				{
					using (SqlDataReader reader = SqlCmd.ExecuteReader())
					{
						if (reader.Read())
						{
							if (reader.HasRows)
							{
								ret = reader[0].ToString();

							}
						}
					}
				}
			}
			catch (Exception er)
			{
				Logw.Log(er);
			}

			return ret;
		}
		public string GetSeries(string objcode, string sube)
		{
			string ret = "";
			try
			{
				string bplId = null;
				string qry = $"Select BPLId From OBPL Where BPLName = '{sube}'";
				SqlCommand SqlCmd = null;
				using (SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
				{
					using (SqlDataReader reader = SqlCmd.ExecuteReader())
					{
						if (reader.Read())
						{
							if (reader.HasRows)
							{
								bplId = reader[0].ToString();

							}
						}
					}
				}
				if (String.IsNullOrEmpty(bplId))
					return "";
				qry = $"SELECT \"Series\" FROM \"NNM1\" " +
					$"WHERE \"ObjectCode\"='{objcode}' AND \"Locked\"='N' AND \"GroupCode\" = 1 AND (\"BPLId\" = {bplId}) ORDER BY \"BPLId\" desc ";


			   SqlCmd = null;
				
				using (SqlCmd = new SqlCommand(qry.ToString(), DBConnection))
				{
					using (SqlDataReader reader = SqlCmd.ExecuteReader())
					{
						if (reader.Read())
						{
							if (reader.HasRows)
							{
								ret = reader[0].ToString();

							}
						}
					}
				}
			}

			catch (Exception er)
			{
				Logw.Log(er);
			}

			return ret;
		}
		public Orders addLines(Orders doc, XmlNode line,int lx,string wh)
		{
			TComm_Lines tcomline = new TComm_Lines();
			tcomline.Status = "";
			tcomline.Message = "";
			tcomline.Comment = "";
			tcomline.Price = "0";
			tcomline.OrderQty = "0";
			
			try
			{
				if (line.Name == "StockLine")
				{
					string ltyp = "";
					
					try
					{
						ltyp = line.SelectSingleNode("NonStockedLine").InnerText;
					}
					catch {
						ltyp = "N";
					}
					tcomline.CustomerPoLine = line.SelectSingleNode("CustomerPoLine").InnerText;
					tcomline.Status = ltyp;
					if (ltyp != "Y")
					{
						ordrlnnum++;
						DocumentLine docline = new DocumentLine();
						docline.Price = 0;
						docline.Quantity = 0;
                        string ItemGroup = ItemGroupCheck(line.SelectSingleNode("StockCode").InnerText);
						if (ItemGroup != "Spare Parts")
						{ docline.WarehouseCode = wh; }
						else {
                            docline.WarehouseCode = "SP01";
                        }
                        
						docline.PriceSource = "dpsManual";
						try
						{
							docline.ItemCode = line.SelectSingleNode("StockCode").InnerText;
						}
						


                        catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " StockCode"));

						}
						
						tcomline.StockCode = docline.ItemCode;
						try
						{
							tcomline.StockDescription = line.SelectSingleNode("StockDescription").InnerText;
						}
						catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " StockDescription"));

						}
						
						try
						{
							docline.Quantity = Convert.ToDouble(line.SelectSingleNode("OrderQty").InnerText, CultureInfo.InvariantCulture);
							tcomline.OrderQty = line.SelectSingleNode("OrderQty").InnerText;
						}
						catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " OrderQty"));

						}
						try
						{

							docline.UnitPrice = Convert.ToDouble(line.SelectSingleNode("Price").InnerText, CultureInfo.InvariantCulture);
							tcomline.Price = line.SelectSingleNode("Price").InnerText;
						}
						catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " Price"));

						}
						
						var itmmess = this.ItemCheck(docline.ItemCode, docline.UnitPrice);
						if (itmmess.Length > 0)
						{
							Logw.Log("item 0005");
							err++;
						}
						tcomline.Message = itmmess;
						docline.LineNum = ordrlnnum;
						doc.DocumentLines.Add(docline);
						lastix = doc.DocumentLines.Count - 1;
						lnix = Lines.Count;

					}
					else if (ltyp == "Y")
					{
						explnnum++;
						
						Expense expense = new Expense();
						try
						{
							
							tcomline.StockCode = line.SelectSingleNode("StockCode").InnerText;
							tcomline.Price = line.SelectSingleNode("Price").InnerText;
							tcomline.StockDescription = line.SelectSingleNode("StockDescription").InnerText;
							AdditionalExpenses addexpence = GetExpenceCode(tcomline.StockCode);  // "1";

							if (addexpence == null)
							{

								err++;
								tcomline.Message = $"Expenses name not exist {tcomline.StockCode}";

								Lines.Add(tcomline);

								lnix = Lines.Count;
								return doc;
							}
							else
							{

								expense.ExpenseCode = addexpence.ExpensCode;
								expense.TaxCode = addexpence.OutputVATGroup;
							}

						}
						catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " StockCode 2"));

						}


						//	docline.ItemCode = line.SelectSingleNode("StockCode").InnerText;
						try
						{
							
							tcomline.StockDescription = line.SelectSingleNode("StockDescription").InnerText;
							expense.Remarks = line.SelectSingleNode("StockDescription").InnerText;
						}
						catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " StockDescription 2"));

						}
						try
						{
							
							expense.LineTotal = Convert.ToDouble(line.SelectSingleNode("Price").InnerText, CultureInfo.InvariantCulture);
							

						}
						catch (Exception ex)
						{
							Logw.Log(new Exception(ex.Message + " Price 2"));

						}
						
						tcomline.OrderQty = "0";

						expense.LineNum = explnnum;
					
						doc.DocumentAdditionalExpenses.Add(expense);
					}
				
					Lines.Add(tcomline);
				
					lnix = Lines.Count;
				}
				else
				if (line.Name == "CommentLine")
				{
					try
					{
						
						int ixm = Convert.ToInt32(line.SelectSingleNode("CustomerPoLine").InnerText);
						if (lnix >= Lines.Count) {
						     lnix = Lines.Count-1;
						}
						
						if (lnix <Lines.Count)
						{
							
							Lines[lnix].Comment = line.SelectSingleNode("Comment").InnerText;
							//if (ixm>0)
							//doc.DocumentLines[ixm - 1].FreeText = line.SelectSingleNode("Comment").InnerText;
						}
					}
					catch (Exception ex)
					{
						Logw.Log(new Exception(ex.Message + " Comment"));

					}
				}
			} catch (Exception e)
			{
				Logw.Log(e);
			}
			return doc;
		}
		private JObject Get(string EntityName, string ext=null)
		{
			JObject joResponse = null;
			client.DefaultRequestHeaders.Clear();
			client.DefaultRequestHeaders.Add("Cookie", "B1SESSION=" + SessionID + "; ROUTEID=" + RouteID);
			client.DefaultRequestHeaders.Add("Prefer", "odata.maxpagesize=500");
			try
			{
				var request = client.GetAsync(Logw.cnf.Uri + EntityName + ext);
				string st = request.Result.Content.ReadAsStringAsync().Result;

				if (st == null || st == "" || request.Result.StatusCode != HttpStatusCode.OK)
					return null;


				 joResponse = JObject.Parse(st);
			} catch (Exception e)
			{
				Logw.Log(new Exception(ext + e.Message));
			}
			return joResponse;
			

		}

		public string Post( string EntityName,Orders Order)
		{
			string ret = "";
		
			client.DefaultRequestHeaders.Add("Cookie", "B1SESSION=" + SessionID);
			client.DefaultRequestHeaders.Add("Cookie", "ROUTEID=" + RouteID);

			string Jsbody = "";
			StringContent data=null;


			if (Order != null) {
				Jsbody = JsonConvert.SerializeObject(Order);
				Logw.Log(Jsbody);
				data = new StringContent(Jsbody, Encoding.UTF8, "application/json");
			}
			
			var response = client.PostAsync(EntityName, data);


			var responseString = response.Result.Content.ReadAsStringAsync().Result;
			if (responseString.IndexOf("error") > -1)
			{
				ret = responseString;
				
				try
				{
					var definition = new
					{
						error = new
						{
							code = "",
							message = new
							{
								lang = "",
								value = ""
							}
						}


					};
					
					try
					{
						var error = JsonConvert.DeserializeAnonymousType(responseString, definition);

						ret = "Error:"+error.error.message.value;
					}
					catch (Exception e)
					{ }
					
				}
				catch (Exception er)
				{

				}
				
			} else
			{
				try
				{


					var definition = new
					{

						DocEntry = "",
						DocNum = "",
						Number = ""
						
					};
					
					var def = JsonConvert.DeserializeAnonymousType(responseString, definition);

					

					if (def != null)
					{

						ret = "DocNum:" + def.DocNum;
						docEntry = def.DocEntry;
					}



				}
				catch (Exception errt)
				{
					Logw.Log(errt);
				}

			}

			return ret;

		}
		public void Logoff()
		{
			try
			{
				//Logout
				this.Post("Logout",null);
				SessionID = string.Empty;
			}
			catch (Exception ex)
			{
			}

		}

		private string Connect()
		{
			string ret = "";
			client = new HttpClient();

			CookieContainer cookies = new CookieContainer();
			handler = new HttpClientHandler();
			handler.ServerCertificateCustomValidationCallback += (sender, cert, chain, sslPolicyErrors) => { return true; };

			handler.CookieContainer = cookies;

			client = new HttpClient(handler);
			
			client.BaseAddress = new Uri(Logw.cnf.Uri);
			client.DefaultRequestHeaders.Add("Accept", "application/json");
			string jsonstr = "";
			try
			{
				jsonstr = "{     \"UserName\": \"" + Logw.cnf.UserName + "\", \"Password\": \"" + Logw.cnf.Password + "\", \"CompanyDB\": \"" + Logw.cnf.SapDbName + "\" }";
				
				var content = new StringContent(jsonstr, Encoding.UTF8, "application/json");
				var result = client.PostAsync(Logw.cnf.Uri + "Login", content).Result;

				if (result.StatusCode != HttpStatusCode.OK)
					throw new Exception(result.ReasonPhrase);
				Uri uri = new Uri(Logw.cnf.Uri + "Login");
				
				List<Cookie> cookiesx = cookies.GetCookies(uri).Cast<Cookie>().ToList();
				SessionID = cookiesx.FirstOrDefault(x => x.Name == "B1SESSION").ToString();
				
				string[] s = SessionID.Split('=');
				if (s != null && s.Length > 1)
				{
					SessionID = s[1];
				}
				try
				{
					RouteID = cookiesx.FirstOrDefault(x => x.Name == "ROUTEID").ToString();
					s = RouteID.Split('=');
					if (s != null && s.Length > 1)
					{
						RouteID = s[1];
					}
				} catch (Exception e)
				{
					
				}
				if (result != null)
				{
					var responseString = result.Content;
					ret = responseString.ToString();
					
				}

			}
			catch (ArgumentException e)
			{
				ret = e.Message + "-" + "Service Layer can't connected..";
				Logw.Log(new Exception(ret));
			}
			catch (Exception e)
			{
				ret = e.Message + "-" + "Service Layer can't connected..";
				Logw.Log(new Exception(ret));
			}
			return ret;
		}
		private static bool RemoteSSLTLSCertificateValidate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors ssl)
		{
			//accept
			return true;
		}

		
	}
}
