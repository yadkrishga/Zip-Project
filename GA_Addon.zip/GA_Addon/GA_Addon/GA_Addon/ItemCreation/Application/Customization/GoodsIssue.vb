﻿Public Class GoodsIssue
    Dim frmGoodsIssue, frmGloGoodsIssue As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer
    Dim GblDocEntry As String = ""

    Sub LoadGoodsIssue(ByVal FormUID As String)
        Try
            boolFormLoaded = False



            frmGoodsIssue = oApplication.Forms.Item(FormUID)
            frmGloGoodsIssue = oApplication.Forms.Item(FormUID)


            oDBDSHeader = frmGoodsIssue.DataSources.DBDataSources.Item("OIGE")



            frmGoodsIssue.Freeze(True)





            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmGoodsIssue.Freeze(False)
        Catch ex As Exception
            frmGoodsIssue.Freeze(False)
            'oApplication.StatusBar.SetText("Load SalesOrder Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmGoodsIssue.Freeze(True)

            frmGoodsIssue.Freeze(False)
        Catch ex As Exception
            frmGoodsIssue.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmProdOrder.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try

                frmGoodsIssue = oApplication.Forms.Item(FormUID)
                '   oForm = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = GIssueTypeEx Then
                Select Case pVal.EventType

                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadGoodsIssue(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED

                    Case SAPbouiCOM.BoEventTypes.et_CLICK

                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT

                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE

                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmGloGoodsIssue = frmGloGoodsIssue
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                    Try


                        If BusinessObjectInfo.ActionSuccess And frmGoodsIssue.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                            Dim DocEntry2 As String = oDBDSHeader.GetValue("DocEntry", 0)
                            Dim Error1 As String = ""
                            Dim sQuery2 As String = String.Empty
                            sQuery2 = " SELECT CONVERT(VARCHAR(20),GETDATE(),112) [DocDate],T0.[U_GA_BWIP] ,T2.[ItemCode],T3.[AvgPrice],T1.[WhsCode],'C'[BatchID],T0.[ItemCode][ParentCode] FROM OSRI T0 INNER JOIN SRI1 T1 ON T0.[SysSerial] = T1.[SysSerial]  and T0.[ItemCode]=T1.[ItemCode] "
                            sQuery2 += "INNER Join OSRI T2 ON T0.[U_GA_BWIP]=T2.[IntrSerial] "
                            sQuery2 += "INNER Join OITM T3 ON t2.[ItemCode]=T3.[ItemCode] "
                            sQuery2 += "WHERE T1.[BaseType] ='60' and T0.[BatchID]='R' and CONVERT(VARCHAR(20),T1.[BaseEntry]) ='" + DocEntry2 + "'"

                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery2)
                            If (Rst.RecordCount > 0) Then

                                Dim StrQry3 = "SELECT MAX([U_GA_PWhs]) as [PWHS],(SELECT [U_GA_BINL] FROM OWHS WHERE WhsCode =MAX([U_GA_PWhs])) as [BINL] FROM [@GA_LOCM] X WHERE X.[U_GA_LName] IN(Select Location FROM OLCT WHERE Code=(SELECT Location FROM OWHS WHERE [WhsCode]='" + Convert.ToString(Rst.Fields.Item("WhsCode").Value.ToString()) + "')) and [U_GA_RWhs]='" + Convert.ToString(Rst.Fields.Item("WhsCode").Value.ToString()) + "'"
                                Dim Rst3 As SAPbobsCOM.Recordset = oGfun.DoQuery(StrQry3)
                                Dim WhsCodeR As String = ""
                                Dim BinR As String = ""
                                If (Rst3.RecordCount > 0) Then
                                    WhsCodeR = Convert.ToString(Rst3.Fields.Item("PWHS").Value.ToString())
                                    BinR = Convert.ToString(Rst3.Fields.Item("BINL").Value.ToString())
                                End If

                                Dim GReceipt As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry)
                                GReceipt.DocDate = Now()
                                GReceipt.DocumentReferences.ReferencedObjectType = SAPbobsCOM.ReferencedObjectTypeEnum.rot_GoodsIssue
                                GReceipt.DocumentReferences.ReferencedDocEntry = DocEntry2
                                GReceipt.DocumentReferences.Remark = "Rework Document"
                                GReceipt.DocumentReferences.Add()
                                For i As Integer = 1 To Rst.RecordCount
                                    Dim ParentCode As String = Convert.ToString(Rst.Fields.Item("ParentCode").Value.ToString())
                                    Dim QueryP As String = "Select A.Code,B.ItemName,B.AvgPrice FROM ITT1 A INNER JOIN OITM B ON A.Code=B.ItemCode where A.Father='" & ParentCode & "' and ISNULL(A.U_GA_Packaging,'N')='Y'"
                                    Dim RstP As SAPbobsCOM.Recordset = oGfun.DoQuery(QueryP)
                                    If (i > 1) Then
                                        GReceipt.Lines.Add()
                                    End If
                                    GReceipt.Lines.UserFields.Fields.Item("U_PMX_LOCO").Value = BinR
                                    GReceipt.Lines.UserFields.Fields.Item("U_PMX_LUID").Value = "-1"
                                    GReceipt.Lines.ItemCode = Convert.ToString(Rst.Fields.Item("ItemCode").Value.ToString())
                                    GReceipt.Lines.WarehouseCode = WhsCodeR
                                    GReceipt.Lines.UnitPrice = Convert.ToDouble(Rst.Fields.Item("AvgPrice").Value.ToString())
                                    GReceipt.Lines.Quantity = 1
                                    GReceipt.Lines.SerialNumbers.BaseLineNumber = i - 1
                                    GReceipt.Lines.SerialNumbers.InternalSerialNumber = Convert.ToString(Rst.Fields.Item("U_GA_BWIP").Value.ToString())
                                    GReceipt.Lines.SerialNumbers.BatchID = Convert.ToString(Rst.Fields.Item("BatchID").Value.ToString())
                                    GReceipt.Lines.SerialNumbers.UserFields.Fields.Item("U_GA_BWIP").Value = Convert.ToString(Rst.Fields.Item("U_GA_BWIP").Value.ToString())


                                    For j As Integer = 1 To RstP.RecordCount
                                        GReceipt.Lines.Add()
                                        GReceipt.Lines.UserFields.Fields.Item("U_PMX_LOCO").Value = BinR
                                        GReceipt.Lines.UserFields.Fields.Item("U_PMX_LUID").Value = "-1"
                                        GReceipt.Lines.ItemCode = Convert.ToString(RstP.Fields.Item("Code").Value.ToString())
                                        GReceipt.Lines.WarehouseCode = WhsCodeR
                                        GReceipt.Lines.UnitPrice = Convert.ToDouble(RstP.Fields.Item("AvgPrice").Value.ToString())
                                        GReceipt.Lines.Quantity = 1
                                        RstP.MoveNext()
                                    Next
                                    Rst.MoveNext()
                                Next
                                Error1 = GReceipt.Add()
                                If (Error1 <> 0) Then
                                    oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                Else

                                    Dim DocEntry3 As String = oCompany.GetNewObjectKey()
                                    Dim RstDoc As SAPbobsCOM.Recordset = oGfun.DoQuery("select DocNum FROM OIGN WHERE DocEntry='" + DocEntry3 + "'")

                                    oApplication.MessageBox("Goods receipt Posted successfully ,DocNum: " + RstDoc.Fields.Item(0).Value.ToString(), 1, "Ok")

                                End If
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then

                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
