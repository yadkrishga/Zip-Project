﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Shared;
using SAPbouiCOM;
using Newtonsoft.Json;

namespace Invoices
{
	public class InvoiceList : IBForm
	{
		Form oForm;
		public Grid Grid0, Grid1;
		int SelRow;
        SAPbouiCOM.DataTable dt0, dt1;
		List<string> secilen;
		List<int> secrow;
		int  ix1;
		bool renk;
		HttpClient client;
		int install;
		public InvoiceList()
		{

		}
		public int findFormSeq(string ftype)
		{
			int fnum = 0;
			IEnumerator forms = ProgData.B1Application.Forms.GetEnumerator();
			Form bForm = null;

			try
			{
				forms.Reset();
				while (forms.MoveNext())
				{
					try
					{
						bForm = (SAPbouiCOM.Form)forms.Current;
					}
					catch (Exception err)
					{
						continue;
					}
					if (bForm.UniqueID.Length >= ftype.Length && bForm.UniqueID.Substring(0, ftype.Length) == ftype)
					{
						string scnt = bForm.UniqueID.Substring(ftype.Length, bForm.UniqueID.Length - ftype.Length);
						int icnt = Convert.ToInt32(scnt);
						if (fnum < icnt)
							fnum = icnt;


					}
				}



			}
			catch (Exception et)
			{


			}
			fnum++;
			return fnum;



		}

		public void CreateForm()
		{
			try
			{
				string srf = string.Empty;
				System.Xml.XmlDocument oXMLDoc;
				install = 0;
				
				oXMLDoc = new System.Xml.XmlDocument();

				oXMLDoc.Load(Logger.exeFolder + @"\Invoice.xml");

				string uid = oXMLDoc.SelectSingleNode("/application/forms/action/form | /Application/forms/action/form").Attributes["uid"].Value;
				uid = uid + Guid.NewGuid().ToString().Substring(0, 6);
				oXMLDoc.SelectSingleNode("/application/forms/action/form | /Application/forms/action/form").Attributes["uid"].Value = uid;

				srf = oXMLDoc.InnerXml;
				// ProgData.B1Application.LoadBatchActions(ref srf);

				// oForm = ProgData.B1Application.Forms.Item(uid);
				SAPbouiCOM.FormCreationParams oCP = null;
				oCP = ((SAPbouiCOM.FormCreationParams)(ProgData.B1Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)));
				oCP.XmlData = oXMLDoc.InnerXml;//load the form with XML 


				oForm = ProgData.B1Application.Forms.AddEx(oCP);

				ProgData.Forms.Add(oForm.UniqueID, this);
				//oForm.AutoManaged = true;
				oForm.Visible = true;
				oForm.EnableMenu("1282", true);
				oForm.EnableMenu("1288", true);
				oForm.EnableMenu("1289", true);
				oForm.EnableMenu("1290", true);
				oForm.EnableMenu("1291", true);

				
				Grid0 = (Grid)oForm.Items.Item("Grid0").Specific;
				//Grid1 = (Grid)oForm.Items.Item("Grid1").Specific;

				dt0 = oForm.DataSources.DataTables.Item("DT0");
				//dt1 = oForm.DataSources.DataTables.Item("DT1");
			
				string Value1 = DateTime.Today.ToString("yyyyMMdd");

				string Value2 = DateTime.Today.ToString("yyyyMMdd");
				UserDataSource ds1 = oForm.DataSources.UserDataSources.Item("UD_3");
				UserDataSource ds2 = oForm.DataSources.UserDataSources.Item("UD_4");
				ds1.ValueEx = Value1;
				ds2.ValueEx = Value2;
				SAPbouiCOM.ComboBox cmb = (SAPbouiCOM.ComboBox )oForm.Items.Item("cmbpr").Specific;
				cmb.Select("N", BoSearchKey.psk_ByValue);

				this.conjfilter();
				install = 1;
			}
			catch (Exception err)
			{
				Logger.Log(err);
			}
		}
		private string getDatefilter(string val)
		{
			DateTime dt = DateTime.MinValue;
			string y = "";
			string ret = "";
			try
			{
				dt = DateTime.ParseExact(val, "yyyyMMdd", CultureInfo.InvariantCulture);

			}
			catch (Exception ex)
			{
				dt = DateTime.MinValue;
			}
			if (dt.Year == 1)
				y = "1900";
			else
				y = dt.Year.ToString();
			ret = y + "-" + dt.Month.ToString() + "-" + dt.Day.ToString();
			return ret;

		}
		private void conjfilter()
		{
			try
			{
				string filter = "";
				string Value1 = "", Value2 = "";
				
				//DocDate
				EditText edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt1").Specific;
				EditText edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt2").Specific;

				UserDataSource ds1 = oForm.DataSources.UserDataSources.Item("UD_3");
				UserDataSource ds2 = oForm.DataSources.UserDataSources.Item("UD_4");
				UserDataSource ds7 = oForm.DataSources.UserDataSources.Item("UD_7");
				Value1 = edt1.Value;
				Value2 = edt2.Value;
				if (Value1.Length > 6 || Value2.Length > 6)
				{
					Value1 = getDatefilter(Value1);
					Value2 = getDatefilter(Value2);
					string dtfilter = $" (\"DocDate\" BETWEEN '{Value1}' AND '{Value2}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}
				// CustCode
				edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt3").Specific;
				edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt4").Specific;

				ds1 = oForm.DataSources.UserDataSources.Item("UD_0");
				ds2 = oForm.DataSources.UserDataSources.Item("UD_1");
				Value1 = ds1.Value;
				Value2 = ds2.Value;
				if (Value1.Length > 0 || Value2.Length > 0)
				{


					string dtfilter = $" (\"CardCode\" BETWEEN '{Value1}' AND '{Value2}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}

			
				Value1 = ds7.Value;
				
				if (Value1 !="A")
				{
					string dtfilter = "";
					if (Value1 == "N")
					{ dtfilter = $" ISNULL(A.U_ExportXML,'')=''"; }
					else if (Value1 == "Y")
					{ dtfilter = $" ISNULL(A.U_ExportXML,'')<>''"; }

					
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}

				Bind(filter);
			}
			catch (Exception ex)
			{
				Logger.Log(ex);
			}

		}
		private async Task renklendir(int startrow = 1, int say = 99999)
		{
			int errcolor = 252 | (221 << 8) | (130 << 16);

			int color = 255 | (255 << 8) | (255 << 16);
			string pId = "";
			int ix = 0;
			DataTable dt = Grid0.DataTable;
			if (startrow > dt.Rows.Count)
				startrow = 1;
			if (startrow < 1)
				startrow = 1;
			try
			{
				for (int rownum = startrow; rownum <= dt.Rows.Count; rownum++)
				{
					if (!renk)
						break;
					int row = Convert.ToInt32(dt.GetValue("ROW", rownum-1).ToString());

					row -= 1;
					if (row < 0)
						row = 1;
					if (row > dt.Rows.Count - 1)
						row = rownum - 1;

					// Grid0.CommonSetting.SetCellEditable(row, hataliCol, false);
					if (dt.GetValue("U_ExportXML", row).ToString() == "")
					{

						//Grid0.CommonSetting.SetRowBackColor(rownum, errcolor);

						Grid0.CommonSetting.SetCellEditable(rownum, ix1+1, true);
					}
					else
					{
						//Grid0.CommonSetting.SetRowBackColor(rownum, color);
						Grid0.CommonSetting.SetCellEditable(rownum, ix1+1, false );
						//	Grid0.CommonSetting.SetCellEditable(rownum, ornekColumn, true);


					}
					ix++;
					if (ix > say)
						break;

				}
			}
			catch (Exception e)
			{
				Logger.Log(e);
			}
			Task t = Task.Delay(500);
			await t;
		}

		private void renklendir2(int startrow = 0, int say = 99999)
		{
			int errcolor = 252 | (221 << 8) | (130 << 16);

			int color = 255 | (255 << 8) | (255 << 16);
			string pId = "";
			int ix = 0;
			DataTable dt = Grid0.DataTable;
			if (startrow > dt.Rows.Count)
				startrow = 1;
			if (startrow < 1)
				startrow = 1;
			try
			{
				for (int rownum = startrow; rownum <= dt.Rows.Count; rownum++)
				{
					if (!renk)
						break;
					int row = Convert.ToInt32(dt.GetValue("ROW", rownum-1).ToString());

					row -= 1;
					if (row < 0)
						row = 1;
					if (row > dt.Rows.Count - 1)
						row = rownum - 1;

					// Grid0.CommonSetting.SetCellEditable(row, hataliCol, false);
					if (dt.GetValue("Confirmed", row).ToString() == "N")
					{

						//Grid0.CommonSetting.SetRowBackColor(rownum, errcolor);

						Grid0.CommonSetting.SetRowEditable(rownum, true);
					}
					else
					{
						//Grid0.CommonSetting.SetRowBackColor(rownum, color);
						Grid0.CommonSetting.SetRowEditable(rownum, false);
						//	Grid0.CommonSetting.SetCellEditable(rownum, ornekColumn, true);


					}
					ix++;
					if (ix > say)
						break;

				}
			}
			catch (Exception e)
			{
				Logger.Log(e);
			}
			
		}

		private void Bind(string filter = "", string fld = "")
		{
			string sql = "";
			string Sel = oForm.DataSources.UserDataSources.Item("UD_8").Value;
			if (Sel == "")
				Sel = "N";
			{
				//ROW_NUMBER() OVER(ORDER BY DocRef) AS ROW,
				sql = $"select  ROW_NUMBER() OVER(ORDER BY A.DocNum) AS ROW,'{Sel}' as Sel,A.DocType ,A.DocEntry,A.DocNum,A.DocDate,Case A.DocStatus WHEN 'O' Then 'Open' WHEN 'C' THEN 'Closed' END As [Document Status],A.CardCode,A.CardName,A.NumAtCard,A.DocTotal,A.DocCur,A.Comments,A.Confirmed";
				sql += ",A.U_ExportXML,A.DocEntry FROM OINV A INNER JOIN OCRD B ON A.CardCode=B.CardCode  ";

				if (filter.Length > 0)
				{
					sql += " WHERE B.U_GA_EDI_INV='Y' and A.CANCELED != 'Y' and A.DocStatus='O' AND " + filter;
					string bag = "";
				}
			}
			try
			{
				oForm.Freeze(true);

				dt0.ExecuteQuery(sql);
				Grid0.DataTable = dt0;


				int ix = 0;


				SAPbouiCOM.GridColumn oColumn = Grid0.Columns.Item(ix);
				oColumn.TitleObject.Caption = "#";
				oColumn.TitleObject.Sortable = true;
				oColumn.Editable = false;

				for (int i = 0; i < Grid0.Columns.Count; i++)
				{
					oColumn = Grid0.Columns.Item(i);
					if (oColumn.UniqueID == "DocEntry")
					{
						
						oColumn = Grid0.Columns.Item(i);
						(oColumn as EditTextColumn).LinkedObjectType = "13";
						(oColumn as EditTextColumn).PressedBefore += ItemCostList_LinkPressedBefore;
					}
					if (oColumn.UniqueID == "CardCode")
					{

						oColumn = Grid0.Columns.Item(i);
						(oColumn as EditTextColumn).LinkedObjectType = "2";
						(oColumn as EditTextColumn).PressedBefore += ItemCostList_LinkPressedBefore;
					}
					if (oColumn.UniqueID == "Sel")
					{
						ix1 = i;
						ix = i;
						oColumn.Editable = true;
					}
					else
						oColumn.Editable = false;
				}
				oColumn = Grid0.Columns.Item(Grid0.Columns.Count - 1);
				oColumn.Visible = false;
				oColumn = Grid0.Columns.Item(ix);
				oColumn.TitleObject.Sortable = true;
				oColumn.Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
				oColumn.Editable = true;
				Grid0.SelectionMode = BoMatrixSelect.ms_Single;
				SelRow = 0;
				//SubBind(dt0.GetValue("CustomerPoNumber", SelRow).ToString());
				var task = Task.Run(async () => await renklendir(1));
				//renklendir2(1);
			}
			catch (Exception e)
			{
				Logger.Log(new Exception(e.Message + sql));
			}
			oForm.Freeze(false);
		}
		
		private void ItemCostList_LinkPressedBefore(object sboObject, SBOItemEventArg pVal, out bool BubbleEvent)
		{
			BubbleEvent = false;
			try
			{
				GridColumn oColumn = Grid0.Columns.Item(pVal.ColUID);
				string docEntry = dt0.GetValue("DocEntry", pVal.Row).ToString();
				ProgData.B1Application.OpenForm(BoFormObjectEnum.fo_Invoice, "",docEntry);
				
			}
			catch (Exception e)
			{

			}
		}
		private void Chk_PressedAfter(object sboObject, SBOItemEventArg pVal)
		{
			Bind();
		}
		private void process()
		{
			string ret = "";
			string docentries = "";
			try
			{
				SAPbobsCOM.Recordset orec = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

				string qry = "select * from  \"@G_Mng\"";
				orec.DoQuery(qry);
				string filepath = orec.Fields.Item("U_TCXmlPath").Value.ToString();
				string cntstr = orec.Fields.Item("U_XmlCnt").Value.ToString();
				string ftpuser = orec.Fields.Item("U_FTPUser").Value.ToString();
				string ftppassw = orec.Fields.Item("U_FTPpssw").Value.ToString();
				ftppassw = Logger.Decrypt(ftppassw, true);
				int cnt = Convert.ToInt32(cntstr);
				if (filepath.Length >0 && !filepath.EndsWith(@"\") )
					filepath += @"\";
				
				for (int i = 0; i < dt0.Rows.Count; i++)
				{
					if (dt0.GetValue("Sel", i).ToString() == "Y")
					{
						Invoice2XML cXML = new Invoice2XML();
						docentries = dt0.GetValue("DocEntry",i).ToString();
						string docnum =  dt0.GetValue("DocNum", i).ToString();
						
						cXML.process(docentries, filepath, cnt,ftpuser,ftppassw);
						
						



					}
				}
				conjfilter();

			}
			catch (Exception e)
			{
				Logger.Log(e);
			}
		}
		private async Task<string> Send(string path, Param1 p)
		{


			string ret = "";
			try
			{

				var json = JsonConvert.SerializeObject(p);
				var request = new HttpRequestMessage(HttpMethod.Post, path);

				using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
				{
					request.Content = stringContent;

					using (var response = await client
						.SendAsync(request, HttpCompletionOption.ResponseHeadersRead)
						.ConfigureAwait(false))
					{

						response.EnsureSuccessStatusCode();
						string res = await response.Content.ReadAsStringAsync();
						ret = JsonConvert.DeserializeObject<string>(res);
					}
				}
			}
			catch (TaskCanceledException ex)
			{
				Logger.Log(ex);
			}
			catch (Exception er)
			{
				Logger.Log(er);
			}
			return ret;
		}

		private void ConnectApi()
		{

			try
			{
				Dictionary<string, string> ayar = new Dictionary<string, string>();
				client = new HttpClient();


				string Folder = AppDomain.CurrentDomain.BaseDirectory;
				using (StreamReader r = new StreamReader(Folder + @"\process.config"))
				{
					string pconfig = "";
					while (r.Peek() >= 0)
					{
						pconfig = r.ReadLine();
						string[] conf = pconfig.Split('=');
						if (conf.Length > 1)
							ayar.Add(conf[0], conf[1]);

					}





				}
				//   var webapi = System.Configuration.ConfigurationManager.AppSettings["WebApi"];
				client.BaseAddress = new Uri(ayar["WebApi"]);
				client.DefaultRequestHeaders.Accept.Clear();

				client.DefaultRequestHeaders.Accept.Add(
					new MediaTypeWithQualityHeaderValue("application/json"));
				ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

			}
			catch (Exception e)
			{

			}

		}
		private void changeselect()
		{
			CheckBox cbx = (CheckBox)oForm.Items.Item("chkDS").Specific;
			string sel = "N";
			if (cbx.Checked)
				sel = "Y";
			for (int i = 0; i < dt0.Rows.Count; i++)
			{
				dt0.SetValue("Sel", i, sel);

			}
			conjfilter();

		}
		public void EventAll(ItemEvent pVal)
		{
			if (install == 0)
				return;
			if (pVal.BeforeAction == false && (pVal.ItemUID == "itEdt2" || pVal.ItemUID == "itEdt4" 
				 || pVal.ItemUID == "itEdt1" || pVal.ItemUID == "itEdt3"||pVal.ItemUID =="cmbpr")
				   && (pVal.EventType == BoEventTypes.et_LOST_FOCUS))
			{
				conjfilter();
				renk = true;
				var task = Task.Run(async () => await renklendir(1));
				//renklendir2(1);
			}
			//else
			//	if (pVal.BeforeAction == false && pVal.ItemUID == "Grid0" && pVal.EventType == BoEventTypes.et_CLICK)
			//{
			//	SelectedGrid0(pVal);
			//}
			if (pVal.BeforeAction == false && pVal.ItemUID == "pbtn" && pVal.EventType == BoEventTypes.et_CLICK)
			{
				process();
			}
			else
			if (pVal.BeforeAction == false && pVal.ItemUID == "chkDS" && pVal.EventType == BoEventTypes.et_CLICK)
			{
				changeselect();
			}
			else
				if (pVal.BeforeAction == false && pVal.ItemUID == "refbtn" && pVal.EventType == BoEventTypes.et_CLICK)
			{
				conjfilter();
			}


		}

		public void Menu(ref MenuEvent pVal)
		{
			throw new NotImplementedException();
		}
	}

}
