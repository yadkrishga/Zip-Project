Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Net
Imports System.Net.Mail
Imports System.IO 'FileStream
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports System.Configuration
Imports System
Imports System.Threading
Imports System.Xml


Public Class ApprovalInterface

    Dim frmApprovalInterface As SAPbouiCOM.Form
    Dim oMatrix1 As SAPbouiCOM.Matrix
    Dim oDBDSHeader, oDBDSDetail1, oDBDSDetail2 As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "OAIF"
    Dim sDelRowMatrix As String = ""
    Dim row As Integer
    Dim boolFilterItem As Boolean = False
    Dim SubGridCurRow As Integer

    Dim GDays As Integer
    Public dtTemp As SAPbouiCOM.DataTable
    Dim TableCount As Integer = 0
    Dim sPaySlipSourcePath As String = ""
    Public RunTime As String = Now.ToString("HH_mm_ss")
    Public time As String = ""

    Sub LoadApprovalInterface()
        Try
            oGfun.LoadXML(frmApprovalInterface, ApprovalInterfaceFormID, ApprovalInterfaceXML)
            frmApprovalInterface = oApplication.Forms.Item(ApprovalInterfaceFormID)
            oDBDSHeader = frmApprovalInterface.DataSources.DBDataSources.Item("@INS_OAIF")
            oDBDSDetail1 = frmApprovalInterface.DataSources.DBDataSources.Item("@INS_AIF1")

            oMatrix1 = frmApprovalInterface.Items.Item("Matrix1").Specific

            'oMatrix1.Columns.Item("DocTotal").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto

            Me.DefineModesForFields()
            Me.InitForm()
        Catch ex As Exception
            oGfun.StatusBarWarningMsg("Load ApprovalInterface Form Failed")
        Finally
        End Try
    End Sub

    Sub DefineModesForFields()
        Try
            frmApprovalInterface.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmApprovalInterface.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmApprovalInterface.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmApprovalInterface.Items.Item("t_Duedate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmApprovalInterface.Items.Item("t_Duedate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try
            frmApprovalInterface.Freeze(True)
            oGfun.LoadComboBoxSeries(frmApprovalInterface.Items.Item("c_series").Specific, UDOID, oDBDSHeader.GetValue("U_Duedate", 0), oCompany.UserSignature)
            oGfun.LoadDocumentDate(frmApprovalInterface.Items.Item("t_Duedate").Specific)

            oGfun.SetNewLine(oMatrix1, oDBDSDetail1)
            'For i As Integer = 1 To oMatrix1.VisualRowCount
            '    oGfun.setComboBoxValue(oMatrix1.Columns.Item("AppStatus").Cells.Item(i).Specific, "P")
            'Next

            oMatrix1.AutoResizeColumns()

            frmApprovalInterface.ActiveItem = "t_ReqDate"

            'Dim Str As String = "Select * From ODRF Where ""ObjType""='23'"
            'Me.LoadDraft(Str)

            frmApprovalInterface.Items.Item("b_Load").Click()

            sQuery = String.Empty
            sQuery = "SELECT  * FROM OUSR WHERE ""USERID""='" & oCompany.UserSignature & "' and IFNULL(""U_AppReport"",'N')='Y'"
            Dim RstChkUser As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            If RstChkUser.RecordCount = 0 Then
                frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
            End If

            frmApprovalInterface.Freeze(False)
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            frmApprovalInterface.Freeze(False)
        Finally
        End Try
    End Sub
    Function ValidateAll() As Boolean
        Try
            Return True

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            ValidateAll = False
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False Then
                            Select Case pVal.ItemUID
                                Case "t_OriginNm"
                                    oDBDSHeader.SetValue("U_OriginCd", 0, oDataTable.GetValue("USERID", 0))
                                    oDBDSHeader.SetValue("U_OriginNm", 0, oDataTable.GetValue("USER_CODE", 0))
                                Case "t_AuthoNm"
                                    oDBDSHeader.SetValue("U_AuthoCd", 0, oDataTable.GetValue("USERID", 0))
                                    oDBDSHeader.SetValue("U_AuthoNm", 0, oDataTable.GetValue("USER_CODE", 0))
                                Case "t_CardCode"
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    'oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))

                                Case "t_apinv1"
                                    oDBDSHeader.SetValue("U_APDocNum", 0, oDataTable.GetValue("DocNum", 0))
                                    oDBDSHeader.SetValue("U_APDocEntry", 0, oDataTable.GetValue("DocEntry", 0))
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_Curency", 0, oDataTable.GetValue("DocCur", 0))

                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    Dim sQuery As String = "Select a.""ItemCode"",b.""WhsCode"",a.""INMPrice"",a.""StockSum"",a.""StockSumSc"",a.""Quantity"",a.""LineNum"",a.""UomCode"",a.""OcrCode"" from pch1 a inner join oitw b on a.""ItemCode""=b.""ItemCode"" and b.""WhsCode""=a.""WhsCode"""
                                    sQuery += " where ""DocEntry"" ='" & oDataTable.GetValue("DocEntry", 0) & "' "
                                    Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    rset.MoveFirst()
                                    If rset.RecordCount > 0 Then
                                        For j As Integer = 1 To rset.RecordCount
                                            oApplication.StatusBar.SetText("Please Wait System checking & Loading Data " & j & " Out Of " & rset.RecordCount & "......", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                                            oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                                            oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                                            oDBDSDetail1.SetValue("U_ItemCode", oDBDSDetail1.Offset, rset.Fields.Item("ItemCode").Value)
                                            oDBDSDetail1.SetValue("U_Quantity", oDBDSDetail1.Offset, rset.Fields.Item("Quantity").Value)
                                            oDBDSDetail1.SetValue("U_Docprice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_DocValue", oDBDSDetail1.Offset, rset.Fields.Item("StockSum").Value)
                                            oDBDSDetail1.SetValue("U_WhsPrice", oDBDSDetail1.Offset, rset.Fields.Item("INMPrice").Value)
                                            oDBDSDetail1.SetValue("U_Total", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_BaseEntry", oDBDSDetail1.Offset, oDataTable.GetValue("DocEntry", 0))
                                            oDBDSDetail1.SetValue("U_BaseNum", oDBDSDetail1.Offset, oDataTable.GetValue("DocNum", 0))
                                            oDBDSDetail1.SetValue("U_BaseLine", oDBDSDetail1.Offset, rset.Fields.Item("LineNum").Value)
                                            oDBDSDetail1.SetValue("U_FobnLac", oDBDSDetail1.Offset, rset.Fields.Item("StockSumSc").Value)
                                            oDBDSDetail1.SetValue("U_Warehous", oDBDSDetail1.Offset, rset.Fields.Item("WhsCode").Value)
                                            oDBDSDetail1.SetValue("U_DistrRule", oDBDSDetail1.Offset, rset.Fields.Item("OcrCode").Value)
                                            oDBDSDetail1.SetValue("U_UoMCode", oDBDSDetail1.Offset, rset.Fields.Item("UomCode").Value)
                                            rset.MoveNext()
                                        Next
                                    End If
                                    oMatrix1.LoadFromDataSource()
                                    oApplication.StatusBar.SetText("Operation completed....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                Case "Matrix1"
                                    Select Case pVal.ColUID
                                        Case "Project"
                                            oMatrix1.FlushToDataSource()
                                            oDBDSDetail1.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue("PrjCode", 0))
                                            'oDBDSDetail1.SetValue("U_Sizename", pVal.Row - 1, oDataTable.GetValue("U_Clrname", 0))
                                            oMatrix1.LoadFromDataSource()
                                            oMatrix1.AutoResizeColumns()
                                            oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End Select
                            End Select
                        End If
                    Catch ex As Exception
                        frmApprovalInterface.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            Case "Matrix1"
                                Select Case pVal.ColUID
                                    Case "DraftKey"
                                        If pVal.BeforeAction = False Then
                                            oGfun.SetNewLine(oMatrix1, oDBDSDetail1, pVal.Row, pVal.ColUID)
                                        End If
                                End Select

                        End Select
                    Catch ex As Exception
                        frmApprovalInterface.Freeze(False)
                        oApplication.StatusBar.SetText("Lost focus event fail", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "t_Vat1", "t_Vat2"
                                If pVal.BeforeAction = False Then
                                    Dim Vat2 As Double = 0.0
                                    Dim Vat1 As Double = 0.0
                                    Vat2 = CDbl(frmApprovalInterface.Items.Item("t_Vat2").Specific.value)
                                    Vat1 = CDbl(frmApprovalInterface.Items.Item("t_Vat1").Specific.value)
                                    Dim Sum1 As Double = 0.0
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        Dim a As Double = CDbl(oMatrix1.Columns.Item("Total").Cells.Item(i).Specific.value)
                                        Sum1 += a
                                    Next

                                    oDBDSHeader.SetValue("U_BeforeVat", 0, (Sum1))
                                    oDBDSHeader.SetValue("U_DocTotal", 0, (Sum1 + Vat1 + Vat2))
                                End If
                            Case "Matrix1"
                                Select Case pVal.ColUID

                                  
                                End Select
                        End Select
                    Catch ex As Exception
                        frmApprovalInterface.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub
                                    End If
                                End If
                            Case "b_Load"
                                If pVal.BeforeAction Then
                                    frmApprovalInterface.Freeze(True)

                                    'Dim FromDate As String = oDBDSHeader.GetValue("U_FromDate", 0).Trim
                                    oMatrix1.Clear()
                                    oDBDSDetail1.Clear()
                                    Dim Str As String = "CALL ""@INSPL_APPROVAL_GET_DRAFTINTERFACE"" ('" & oDBDSHeader.GetValue("U_ReqDate", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_ReqDateT", 0).Trim & "','" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_CardCdeT", 0).Trim & "','" & oCompany.UserSignature & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_Accept", 0).Trim & "','" & oDBDSHeader.GetValue("U_Reject", 0).Trim & "',"
                                    Str += "'" & oDBDSHeader.GetValue("U_Clear", 0).Trim & "'"
                                    Str += " )"
                                    ' Dim Str As String = "SELECT Top 10 * FROM ODRF"
                                    Me.LoadDraft(Str)
                                    oMatrix1.LoadFromDataSource()
                                    frmApprovalInterface.Freeze(False)
                                End If

                        End Select
                    Catch ex As Exception
                        frmApprovalInterface.Freeze(False)
                        oGfun.StatusBarErrorMsg("Click Event Failed:" & ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK
                    Try
                        Select Case pVal.ItemUID

                        End Select
                        Select Case pVal.ItemUID
                            Case "Matrix1"
                                If pVal.BeforeAction = False Then oGfun.OpenAttachment(oMatrix1, oDBDSDetail1, pVal.Row)
                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Item Double Click Event Failed : " & ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "c_series"
                                If frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    'Get the Serial Number Based On Series...
                                    Dim oCmbSerial As SAPbouiCOM.ComboBox = frmApprovalInterface.Items.Item("c_series").Specific
                                    Dim strSerialCode As String = oCmbSerial.Selected.Value
                                    Dim strDocNum As Long = frmApprovalInterface.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                                    oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                                End If
                        End Select
                    Catch ex As Exception
                        frmApprovalInterface.Freeze(False)
                        oGfun.StatusBarErrorMsg("Combobox Event Failed")
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.ActionSuccess And frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If

                            Case "b_Copy"
                                If pVal.Before_Action = False Then
                                    'Me.CreateMySimpleForm()
                                End If
                            Case "t_Select"
                                If pVal.BeforeAction = False Then
                                    frmApprovalInterface.Freeze(True)
                                    Dim isAvail As Boolean = False
                                    For i As Integer = 1 To oMatrix1.VisualRowCount
                                        oGfun.StatusBarWarningMsg("Please Wait !!!!!!! System is Reflect (Select All OR UnSelect All) Hide Header to line--'" & i & "'Out of'" & oMatrix1.VisualRowCount - 1 & "'")

                                        Dim chk As SAPbouiCOM.CheckBox = frmApprovalInterface.Items.Item("t_Select").Specific
                                        Dim Checkhide As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific

                                        If chk.Checked = True Then
                                            If oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then
                                                Checkhide.Checked = True
                                            End If
                                        Else
                                            Checkhide.Checked = False
                                            'oMatSale.Columns.Item("Hide").Cells.Item(i).Specific.Value = "N"
                                            ' oGrid.DataTable.Columns.Item("Chk").Cells.Item(i - 1).Value = "N"
                                        End If
                                    Next
                                    oApplication.StatusBar.SetText("Reflect (Select All OR UnSelect All) Hide to line Operation Completed...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                    frmApprovalInterface.Freeze(False)
                                End If
                        End Select
                    Catch ex As Exception
                        frmApprovalInterface.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
            End Select

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Function Transaction_Managment() As Boolean
        sQuery = String.Empty
        sQuery = "  SELECT * FROM " & oCompany.CompanyDB & ".""@INS_AIF1"" WHERE IFNULL(""U_DraftKey"",'')<>'' and IFNULL(""U_AppStatus"",'P')='A' "
        sQuery += " and IFNULL(""U_Select"",'N')='Y'"
        sQuery += " and ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
        Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
        If Rst.RecordCount > 0 Then
            Rst.MoveFirst()
            For i As Integer = 1 To Rst.RecordCount
                Try
                    Me.CreateDocumentFromDraft(Rst.Fields.Item("U_DraftKey").Value)
                    'ConfermaBozza(Rst.Fields.Item("U_DraftKey").Value)
                Catch ex As Exception

                End Try

                Rst.MoveNext()
            Next
        End If

    End Function
    Function DraftToSalesInvoice(ByVal DraftKey As String) As Boolean

        Try

            DraftToSalesInvoice = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("FuntionDraftToSalesInvoice Filed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            frmApprovalInterface.Freeze(False)
            Return False
        End Try

        sPaySlipSourcePath = (AppDomain.CurrentDomain.BaseDirectory).ToString
        sPaySlipSourcePath += "Invoice-Temp"
        CreateInvoiceFolder()

        Dim pDraft As SAPbobsCOM.Documents
        pDraft = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts)
        Dim SaleInnvoice As SAPbobsCOM.Documents
        'SaleInnvoice = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts)
        oCompany.XmlExportType = SAPbobsCOM.BoXmlExportTypes.xet_ExportImportMode
        oCompany.XMLAsString = False
        pDraft.GetByKey(DraftKey)
        pDraft.SaveXML(sPaySlipSourcePath & "\InvoiceTemp.xml")
        Dim fs As New FileStream(sPaySlipSourcePath & "\InvoiceTemp.xml", FileMode.Open, FileAccess.Read)
        Dim PostingXMLFile As New XmlDocument
        PostingXMLFile.Load(fs)
        PostingXMLFile.InnerXml = PostingXMLFile.InnerXml

        'Here you should add a code that will change the Object's
        'value from 112 (Drafts) to 17 (Orders) (Delivery is 15) and also you should
        'remove the DocObjectCode node from the xml. You can use any
        'xml parser.
        '
        'Create a new order

        SaleInnvoice = oCompany.GetBusinessObjectFromXML(sPaySlipSourcePath & "\InvoiceTemp.xml", 0)

        SaleInnvoice.Add()

    End Function
    Sub LoadDraft(ByVal Str As String)

        Try
            Dim Rset1 As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

            For i As Integer = 1 To Rset1.RecordCount
                oGfun.StatusBarWarningMsg("Please Wait !!!!!!! Draft Details List Loading Please Wait--'" & i & "'Out of'" & Rset1.RecordCount & "'")

                oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                oDBDSDetail1.Offset = oDBDSDetail1.Size - 1
                oDBDSDetail1.SetValue("LineID", oDBDSDetail1.Offset, oDBDSDetail1.Size)
                oDBDSDetail1.SetValue("U_DraftKey", oDBDSDetail1.Offset, Rset1.Fields.Item("DocEntry").Value)
                oDBDSDetail1.SetValue("U_CardCode", oDBDSDetail1.Offset, Rset1.Fields.Item("CardCode").Value)
                oDBDSDetail1.SetValue("U_CardName", oDBDSDetail1.Offset, Rset1.Fields.Item("CardName").Value)
                oDBDSDetail1.SetValue("U_DocDate", oDBDSDetail1.Offset, CDate(Rset1.Fields.Item("DocDate").Value).ToString("yyyyMMdd"))
                oDBDSDetail1.SetValue("U_TaxDate", oDBDSDetail1.Offset, CDate(Rset1.Fields.Item("TaxDate").Value).ToString("yyyyMMdd"))
                oDBDSDetail1.SetValue("U_DueDate", oDBDSDetail1.Offset, CDate(Rset1.Fields.Item("DocDueDate").Value).ToString("yyyyMMdd"))
                oDBDSDetail1.SetValue("U_DocTotal", oDBDSDetail1.Offset, Rset1.Fields.Item("DocTotal").Value)
                'Dim chkA As SAPbouiCOM.CheckBox = frmApprovalInterface.Items.Item("t_Accept").Specific
                'Dim chkR As SAPbouiCOM.CheckBox = frmApprovalInterface.Items.Item("t_Reject").Specific
                'Dim chkP As SAPbouiCOM.CheckBox = frmApprovalInterface.Items.Item("t_Clear").Specific
                oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, Rset1.Fields.Item("U_Approval").Value)
                oDBDSDetail1.SetValue("U_Remark", oDBDSDetail1.Offset, Rset1.Fields.Item("U_AppRemarks").Value)

                'oDBDSDetail1.SetValue("U_RequBy", oDBDSDetail1.Offset, Rset1.Fields.Item("U_RequBy").Value)
                'Dim Checkhide As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific
                'If oMatrix1.Columns.Item("DraftKey").Cells.Item(i).Specific.Value <> "" Then

                'If chkA.Checked = True And chkR.Checked = False And chkP.Checked = False Then
                '    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "A")
                'ElseIf chkA.Checked = False And chkR.Checked = True And chkP.Checked = False Then
                '    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "R")
                'ElseIf chkA.Checked = False And chkR.Checked = False And chkP.Checked = True Then
                '    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "P")
                'Else
                '    oDBDSDetail1.SetValue("U_AppStatus", oDBDSDetail1.Offset, "P")
                'End If
                Rset1.MoveNext()
            Next
            oMatrix1.LoadFromDataSource()
            oGfun.StatusBarWarningMsg("Operation Completed.....")
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        End Try
    End Sub
    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1281"
                    frmApprovalInterface.ActiveItem = ("t_docnum")
                Case "1293"
                    Select Case sDelRowMatrix
                        Case "Matrix1"
                            oGfun.DeleteRow(oMatrix1, oDBDSDetail1)

                    End Select

                Case "1282"
                    Me.InitForm()
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If ValidateAll() = False Then
                                BubbleEvent = False
                                Exit Sub
                            End If
                        End If
                        If BusinessObjectInfo.ActionSuccess Then
                            Me.Transaction_Managment()
                        End If

                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    Try
                        If BusinessObjectInfo.ActionSuccess Then
                            If frmApprovalInterface.Mode <> SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
                            Else
                                frmApprovalInterface.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form data load event fail...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    sDelRowMatrix = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                        Case "Matrix1"
                            If EventInfo.Row = oMatrix1.VisualRowCount Then
                                frmApprovalInterface.EnableMenu("1293", False)
                            Else
                                frmApprovalInterface.EnableMenu("1293", True)
                            End If
                    End Select
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub CreateInvoiceFolder()
        Try
            Dim di As DirectoryInfo = New DirectoryInfo(sPaySlipSourcePath)
            ' Determine whether the directory exists.
            If di.Exists = False Then
                ' Try to create the directory.
                di.Create()
            End If
        Catch ex As Exception
            oApplication.MessageBox("CreateInvoiceFolder " & ex.Message)
            'Dim strFile As String = String.Format("E:\ErrorLog.txt", ex.Message & "-" & DateTime.Now.ToString)
            'File.AppendAllText(strFile, String.Format(ex.Message & "-" & DateTime.Now.ToString, Environment.NewLine))
        Finally
        End Try
    End Sub
    Sub DeleteInvoiceFolder()
        Try
            Dim di As DirectoryInfo = New DirectoryInfo(sPaySlipSourcePath)
            ' Determine whether the directory exists.
            If di.Exists = True Then
                ' Try to create the directory.
                di.Delete()
            End If
        Catch ex As Exception
            'Dim strFile As String = String.Format("E:\ErrorLog.txt", ex.Message & "-" & DateTime.Now.ToString)
            'File.AppendAllText(strFile, String.Format(ex.Message & "-" & DateTime.Now.ToString, Environment.NewLine))
        Finally
        End Try
    End Sub

#Region "Draft to Documnet"

    Private Enum EnumofXMLFiles
        XMLDDT
        XMLINVDraft
        XMLInvoice
    End Enum
    Private ReadOnly XMLINVDraftName As String = "InvoiceDraft.xml"
    Private ReadOnly XMLInvoiceName As String = "InvoiceDraftToDef.xml"

    Private ReadOnly XMLINVDraftFullPath As String = sPaySlipSourcePath & "\" & XMLINVDraftName
    Private ReadOnly XMLInvoiceFullPath As String = sPaySlipSourcePath & "\" & XMLInvoiceName
    Public Sub CreateDocumentFromDraft(ByVal DraftKey As Integer)

        sPaySlipSourcePath = (AppDomain.CurrentDomain.BaseDirectory).ToString
        sPaySlipSourcePath += "Invoice-Temp"

        Me.write_log("Path : " & sPaySlipSourcePath)

        CreateInvoiceFolder()

        Dim oRPS As SAPbobsCOM.Documents = Nothing
        Dim oNFSE As SAPbobsCOM.Documents = Nothing

        Dim CodErro As Integer = 0
        Dim MsgErro As String = ""

        Try
            oRPS = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts)
            oNFSE = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInvoices)

            oRPS.GetByKey(DraftKey)

            '' SAPbobsCOM.BoXmlExportTypes.xet_ExportImportMode
            oCompany.XmlExportType = SAPbobsCOM.BoXmlExportTypes.xet_ExportImportMode

            oRPS.SaveXML(sPaySlipSourcePath & "\InvoiceTemp.xml")

            Me.write_log("XML1 : " & oRPS.GetAsXML)

            'Modifico il file XML
            ModifyXML(sPaySlipSourcePath & "\InvoiceTemp.xml", EnumofXMLFiles.XMLINVDraft)

            'oNFSE.Browser.ReadXml(XmlRPS, 0)
            oNFSE = oCompany.GetBusinessObjectFromXML(sPaySlipSourcePath & "\" & XMLInvoiceFullPath, 0)

            CodErro = oNFSE.Add()

            If (CodErro = 0) Then
                Dim NewObjectKey As String = oCompany.GetNewObjectKey()
                Me.write_log("Draft Key : " & NewObjectKey)
                'oGfun.StatusBarErrorMsg("DocEntry : " & NewObjectKey)

                'MessageBox.Show("Doc creato con successo! (" & NewObjectKey & ")")

                sQuery = String.Empty
                sQuery = "UPDATE ODRF SET ""U_Approval""='C' WHERE ""DocEntry""='" & DraftKey & " '"

                Me.write_log("Update 1 : " & sQuery)

                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                sQuery = String.Empty
                sQuery = "UPDATE ""@INS_AIF1"" SET ""U_InvEntry""='" & NewObjectKey.ToString & "' WHERE ""U_DraftKey""='" & DraftKey.ToString & "' and  ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Me.write_log("Update 2 : " & sQuery)
                RstUpdate.DoQuery(sQuery)

                sQuery = String.Empty
                sQuery = "  UPDATE B SET B.""U_InvEntry""=A.""DocEntry"",B.""U_InvNo""=A.""DocNum"",""U_Status""='I' "
                sQuery += " FROM OINV A,""@INS_INV1"" B,ODRF C "
                sQuery += " WHERE A.""U_BaseEntry""=B.""DocEntry"" AND C.""U_BaseEntry""=CAST(B.""DocEntry"" AS NVARCHAR(50)) "
                sQuery += " and  A.""U_BaseLine""=B.""LineId""  AND A.""U_BaseType""='OINV' "
                sQuery += " and C.""DocEntry""='" & DraftKey.ToString & "'" ' and B.""LineId""='" & LineID & "'"

                Me.write_log("Update 3 : " & sQuery)
                RstUpdate.DoQuery(sQuery)

                Return
            Else
                oCompany.GetLastError(CodErro, MsgErro)
                oGfun.StatusBarErrorMsg("Error (" & CodErro & "): " & MsgErro)
            End If

        Catch ex As Exception
            oGfun.StatusBarErrorMsg(ex.Message)
            'MessageBox.Show(ex.Message)
        End Try

    End Sub

    ''' <summary>
    ''' Procedura demandata alla modifica dei vari file XML esportati al fine di creare i corrispondenti
    ''' per importazione.
    ''' </summary>
    ''' <param name="XMLFilePath">Percorso completo del file XML esportato da utilizzare come base di elaborazione</param>
    ''' <param name="XMLFileSource">Tipo di file XML; determina come va interpretato.</param>
    ''' <remarks></remarks>
    Private Sub ModifyXML(ByVal XMLFilePath As String, ByRef XMLFileSource As EnumofXMLFiles)
        Dim XMLDoc As New Xml.XmlDocument
        Dim XMLElement As Xml.XmlElement = Nothing
        Dim XMLNode As Xml.XmlNode = Nothing
        Dim InvLineNum As Long = 0
        Dim DDTLineNum As String = "0"
        Try

            Select Case XMLFileSource

                Case EnumofXMLFiles.XMLINVDraft
                    'Apertura del file XML
                    XMLDoc.Load(XMLFilePath)
                    'Posizionamento 
                    XMLNode = XMLDoc.LastChild
                    XMLNode = XMLNode.Item("BO")
                    '------------------------------
                    'Gestione informazioni generali
                    '------------------------------
                    XMLNode = XMLNode.Item("AdmInfo")
                    UpdateNode(XMLNode, "Object", "13") 'Impongo che il documento sia una fattura in definitivo
                    ''DeleteNode(XMLNode, "ReqType") 'Elimino il nodo

                    XMLNode = XMLNode.ParentNode 'Passo a BO
                    XMLNode = XMLNode.Item("Documents") 'Passo direttamente a Document_Lines 
                    For Each XMLNodeCicle As Xml.XmlNode In XMLNode.ChildNodes
                        DeleteNode(XMLNodeCicle, "ReqType") 'Elimino il nodo
                        'DeleteNode(XMLNodeCicle, "DocEntry") 'Elimino il nodo
                        sQuery = String.Empty
                        sQuery = "SELECT MAX(CAST(""DocEntry"" AS INT))+1 FROM OINV"
                        Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                        sQuery = String.Empty
                        sQuery = "SELECT MAX(CAST(""DocNum"" AS INT)) FROM OINV  WHERE ""Series""='4'"
                        Dim Rst1 As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                        UpdateNode(XMLNodeCicle, "DocEntry", Rst.Fields.Item(0).Value)
                        UpdateNode(XMLNodeCicle, "DocNum", Rst1.Fields.Item(0).Value)
                    Next
                    '---------------------------------------------
                    'Gestione righe
                    '---------------------------------------------
                    XMLNode = XMLNode.ParentNode 'Passo a BO
                    XMLNode = XMLNode.Item("Document_Lines") 'Passo direttamente a Document_Lines 
                    'Questa sezione si ripete per tutte le righe presenti nel documento
                    For Each XMLNodeCicle As Xml.XmlNode In XMLNode.ChildNodes
                        DeleteNode(XMLNodeCicle, "COGSAccountCode") 'Elimino il nodo
                        DeleteNode(XMLNodeCicle, "EnableReturnCost") 'Elimino il nodo
                        DeleteNode(XMLNodeCicle, "ReturnCost") 'Elimino il nodo
                        DeleteNode(XMLNodeCicle, "LineVendor") 'Elimino il nodo
                        'LineVendor
                        'ReturnCost' 
                    Next
                    'Effettuo il salvataggio del documento XML
                    XMLDoc.Save(Replace(XMLFilePath, "InvoiceTemp.xml", XMLInvoiceName))
            End Select

            XMLDoc = Nothing

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub UpdateNode(ByRef XMLNode As Xml.XmlNode, ByVal NameNode As String, ByVal value As String)
        Dim XMLTempNode As Xml.XmlNode = Nothing
        Try
            XMLTempNode = XMLNode.Item(NameNode)
            If XMLTempNode Is Nothing Then 'Se � Nothing significa che il nodo figlio cercato non esiste. Procedo quindi a crearlo
                Dim elem As Xml.XmlElement = XMLNode.OwnerDocument.CreateElement(NameNode)
                'elem.InnerText = value ' Potrei gi� attribuire il valore ma lo faccio successivamente
                'Add the node to the document.
                XMLNode.AppendChild(elem)
            End If
            'A questo punto il nodo esiste certamente e quindi procedo con il suo aggiornamento
            XMLNode = XMLNode.Item(NameNode) 'Mi posiziono sul nodo figlio in questione 
            XMLNode.InnerText = value 'Impongo il valore
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            XMLNode = XMLNode.ParentNode 'Torno al padre
            XMLTempNode = Nothing
        End Try
    End Sub


    Private Sub DeleteNode(ByRef XMLNode As Xml.XmlNode, ByVal NameNode As String)
        Dim XMLTempNode As Xml.XmlNode = Nothing
        Try
            XMLTempNode = XMLNode.Item(NameNode)
            If XMLTempNode IsNot Nothing Then 'Se � Nothing significa che il nodo figlio cercato non esiste. Procedo quindi solo se esiste.
                'Effettuo l'eliminazione del nodo figlio in esame  
                XMLNode.RemoveChild(XMLNode.Item(NameNode))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            XMLTempNode = Nothing
        End Try
    End Sub

#End Region

    Private Sub ConfermaBozza(ByVal DraftKey As String)
        Dim empID As Integer = 1
        Dim x As XmlDocument = New XmlDocument()
        Dim rs_emp As SAPbobsCOM.Recordset = CType(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset), SAPbobsCOM.Recordset)
        rs_emp.DoQuery("SELECT empID FROM OHEM")
        If Not rs_emp.EoF Then empID = CInt(rs_emp.Fields.Item("empID").Value)
        Dim rs As SAPbobsCOM.Recordset = CType(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset), SAPbobsCOM.Recordset)
        rs.DoQuery("SELECT ""DocEntry"" FROM ODRF WHERE ""ObjType""='13' AND ""DocStatus"" <> 'C' and ""DocEntry""='" & DraftKey & "'")
        Dim pb As SAPbouiCOM.ProgressBar = oApplication.StatusBar.CreateProgressBar("Applicazione spese a tutti i documenti in bozza", rs.RecordCount, False)
        Dim i As Integer = 1

        While Not rs.EoF
            pb.Value = Math.Min(System.Threading.Interlocked.Increment(i), i - 1)

            Try
                Dim docs As SAPbobsCOM.Documents = CType(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts), SAPbobsCOM.Documents)

                If docs.GetByKey(CInt(rs.Fields.Item(0).Value)) Then
                    Dim filename As String = "bozza.xml"
                    docs.SaveXML(filename)
                    x.Load(filename)
                    Dim n As XmlNode = x.DocumentElement
                    n = n.FirstChild
                    n = n.FirstChild
                    n = n.FirstChild
                    n.InnerText = "13"
                    x.InnerXml = x.InnerXml.Replace("DRF", "INV")
                    x.InnerXml = x.InnerXml.Replace("<OwnerCode>0</OwnerCode>", "")
                    x.Save(filename)
                    Dim fattura As SAPbobsCOM.Documents = CType(oCompany.GetBusinessObjectFromXML(filename, 0), SAPbobsCOM.Documents)
                    fattura.DocumentsOwner = empID

                    If fattura.Add() <> 0 Then
                        Dim err As Integer
                        Dim msg As String
                        oCompany.GetLastError(err, msg)
                        oApplication.MessageBox(msg, 0, "OK", "", "")
                    End If
                End If

            Catch e As Exception
                oApplication.MessageBox(e.Message, 0, "OK", "", "")
                Exit While
            End Try

            rs.MoveNext()
        End While

        pb.Stop()
        System.Runtime.InteropServices.Marshal.ReleaseComObject(pb)
    End Sub
    Public Sub write_log(ByVal status As String)
        Dim fs As FileStream
        Dim objWriter As System.IO.StreamWriter
        Dim chatlog As String
        Try
            If time = "" Then time = Today.ToString("yyyyMMdd") & "\Log_" & Runtime 'Now.ToString("HH_mm_ss")
            Dim di As DirectoryInfo = New DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory + "ErrorLog\Integration_" & Today.ToString("yyyyMMdd") & "")
            If di.Exists Then
            Else
                di.Create()
            End If
            chatlog = AppDomain.CurrentDomain.BaseDirectory + "ErrorLog\Integration_" & time & ".txt"
            If File.Exists(chatlog) Then
            Else
                fs = New FileStream(chatlog, FileMode.Create, FileAccess.Write)
                fs.Close()
            End If
            objWriter = New System.IO.StreamWriter(chatlog, True)
            If status <> "" Then objWriter.WriteLine(Now & " : " & status)
            objWriter.Close()
        Catch ex As Exception
            ' MsgBox("createlog :" + ex.ToString)
        End Try
    End Sub
End Class