Imports System.IO
Imports System.Net
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

Public Class SalesOrderAdd
    Dim frmSaleOrderAdd, frmGloSaleAddOrder As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer
    Dim GblDocEntry As String = ""
    Dim GblSelRow As Integer = 0
    Dim GblSelRow1 As Integer = 0
    Dim GblItemCode As String = ""
    Dim GblPlanQty As Double = 0
    Dim GblLineNum As Integer = 0
    Dim GblWhse As String = ""
    Dim GblModel As String = ""
    Dim GblSQry As String = ""



    Sub LoadSaleOrderAdd(ByVal FormUID As String)
        Try
            boolFormLoaded = False
            Dim oItem As SAPbouiCOM.Item
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oComboBox As SAPbouiCOM.ComboBox
            Dim oEditText As SAPbouiCOM.EditText


            frmSaleOrderAdd = oApplication.Forms.Item(FormUID)
            frmGloSaleAddOrder = oApplication.Forms.Item(FormUID)



            frmSaleOrderAdd.Freeze(True)

            ' Purchase Indent Copy From Button ...
            '------------------------------------

            oItem = frmSaleOrderAdd.Items.Add("b_GA_FIND", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmSaleOrderAdd.Items.Item("10000002").Left + frmSaleOrderAdd.Items.Item("10000002").Width + 5
            oItem.Width = frmSaleOrderAdd.Items.Item("10000002").Width + frmSaleOrderAdd.Items.Item("10000002").Width + 5
            oItem.Height = frmSaleOrderAdd.Items.Item("10000002").Height
            oItem.Top = frmSaleOrderAdd.Items.Item("10000002").Top

            If (CardPost <> "") Then
                oItem.Visible = True

                oItem.Enabled = True
            Else
                oItem.Visible = True

                oItem.Enabled = False
            End If
            oButton = oItem.Specific
            oButton.Caption = "Find Postcode"
            oItem.LinkTo = "10000002"






            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmSaleOrderAdd.Freeze(False)
        Catch ex As Exception
            frmSaleOrderAdd.Freeze(False)
            'oApplication.StatusBar.SetText("Load SalesOrder Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmSaleOrderAdd.Freeze(True)

            frmSaleOrderAdd.Freeze(False)
        Catch ex As Exception
            frmSaleOrderAdd.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmSaleOrderAdd.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub Calculation()
        Try
            Dim TotCBMQty As Double = 0.0
            Dim TotCartonQty As Double = 0.0
            'Dim CartonQty As Double = 0.0
            For i As Integer = 1 To oMatrix.VisualRowCount
                If oMatrix.Columns.Item("1").Cells.Item(i).Specific.value <> "" Then
                    sQuery = String.Empty
                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value & "'"
                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    Dim CBMQty As Double = Rst.Fields.Item("U_CBM").Value
                    Dim CartonQty As Double = Rst.Fields.Item("U_CartQty").Value
                    TotCBMQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value
                    TotCartonQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value / CartonQty
                End If
            Next

            frmSaleOrderAdd.Items.Item("t_cbm").Enabled = True
            frmSaleOrderAdd.Items.Item("t_carton").Enabled = True
            frmSaleOrderAdd.Items.Item("t_cbm").Specific.value = TotCBMQty
            frmSaleOrderAdd.Items.Item("t_carton").Specific.value = TotCartonQty
            frmSaleOrderAdd.Items.Item("16").Specific.value = frmSaleOrderAdd.Items.Item("16").Specific.value
            frmSaleOrderAdd.Items.Item("t_cbm").Enabled = False
            frmSaleOrderAdd.Items.Item("t_carton").Enabled = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("Calculation Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Function Validation() As Boolean
        Try
            Dim flag As Boolean = True
            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
            Dim Status As String = oDBDSHeader.GetValue("Status", 0)
            Dim SqlWipExist As String = "Select *  from [@GA_WIPN] WHERE U_GA_PoEnt='" & DocEntry & "'"
            Dim RsWIP As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RsWIP.DoQuery(SqlWipExist)
            If (RsWIP.RecordCount > 0 And Status = "P") Then
                flag = False
                oApplication.MessageBox("Saleuction order status change is not permitted after WIP number is generated", 1, "Ok")
            Else
                flag = True

            End If

            Return flag
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validation Function Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmSaleOrderAdd = oApplication.Forms.Item(FormUID)
                '   oForm = frmSaleOrderAdd
            Catch ex As Exception

            End Try

            Try
                frmSaleOrderAdd = oApplication.Forms.Item(FormUID)
                '   oForm = frmSaleOrder
                If (CardPost <> "") Then
                    frmSaleOrderAdd.Items.Item("b_GA_FIND").Visible = True

                    frmSaleOrderAdd.Items.Item("b_GA_FIND").Enabled = True
                Else
                    frmSaleOrderAdd.Items.Item("b_GA_FIND").Visible = True

                    frmSaleOrderAdd.Items.Item("b_GA_FIND").Enabled = False
                End If
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = SaleOrderAddTypeEx Then
                Select Case pVal.EventType

                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadSaleOrderAdd(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.ActionSuccess And frmSaleOrderAdd.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Me.InitForm()
                                    End If
                                    'Case "lk_grp"
                                    '    If pVal.BeforeAction = False Then
                                    '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", frmSaleOrderAdd.Items.Item("t_docentry").Specific.value)
                                    '    End If


                                Case "b_GA_FIND"
                                    If pVal.BeforeAction = False Then
                                        If frmSaleOrderAdd.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmSaleOrderAdd.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                            Try


                                                Dim Matrix As SAPbouiCOM.Matrix
                                                Matrix = frmSaleOrderAdd.Items.Item("10000003").Specific
                                                Dim oEdit As SAPbouiCOM.EditText = Matrix.Columns.Item("10000013").Cells.Item(1).Specific
                                                Dim PostCode As String = oEdit.Value.ToString()
                                                Dim request As HttpWebRequest = HttpWebRequest.Create("https://pafdev.groupe-atlantic.co.uk/v2/addresses/by-postcode/" + PostCode)


                                                request.AllowAutoRedirect = False
                                                request.Credentials = New NetworkCredential("GAUK_PAF", "gPY9nr!B=#")
                                                request.KeepAlive = True
                                                request.ServicePoint.Expect100Continue = False
                                                request.CookieContainer = New CookieContainer()
                                                System.Net.ServicePointManager.ServerCertificateValidationCallback = Function(se As Object, cert As System.Security.Cryptography.X509Certificates.X509Certificate, chain As System.Security.Cryptography.X509Certificates.X509Chain, sslerror As System.Net.Security.SslPolicyErrors) True

                                                request.Method = "GET"
                                                request.ContentType = "application/json"
                                                Dim response As HttpWebResponse = request.GetResponse()






                                                If (response.StatusCode = "200") Then
                                                    Dim responsedata As Stream = response.GetResponseStream
                                                    Dim responsereader As StreamReader = New StreamReader(responsedata)
                                                    Dim xResponse = responsereader.ReadToEnd
                                                    Dim json As String = xResponse
                                                    Dim jo = JObject.Parse(json)

                                                    Dim jsonData As JArray = jo("Addresses")
                                                    Dim StrQry As String = ""
                                                    Dim Strfeild As String = "SELECT (Select Count(*) FROM [@GA_APIM]) as [Cnt],T0.[U_GA_APIF], T0.[U_GA_SAPF] FROM [dbo].[@GA_APIM]  T0 Order by CAST(Code as int)"
                                                    Dim RsFeild As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

                                                    RsFeild.DoQuery(Strfeild)

                                                    For i As Integer = 1 To jsonData.Count
                                                        If (i > 1) Then
                                                            StrQry += " UNION ALL "
                                                        End If
                                                        Dim street As String = jsonData(i - 1)("Formatted")("Lines").ToString().Replace("[", "").Replace("]", "")
                                                        Dim streetNo As String = street.Replace("'", "''")
                                                        Dim streetNo1 As String = streetNo.Replace(ControlChars.Quote, "")
                                                        StrQry += "Select 'N' as[Select],"




                                                        StrQry += "'" + streetNo1 + "' as [Street],"

                                                        StrQry += "'" + jsonData(i - 1)("Formatted")("Town").ToString() + "' as [Town],"

                                                        StrQry += "'" + jsonData(i - 1)("Formatted")("Postcode").ToString() + "' as [Postcode]"





                                                    Next

                                                    GblSQry = StrQry
                                                    If (GblSQry <> "") Then
                                                        Me.CreateMySimpleForm_PostCodeList()
                                                    Else
                                                        oApplication.StatusBar.SetText("No Address Found", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                    End If
                                                End If
                                            Catch ex As Exception
                                                oApplication.StatusBar.SetText("No Address Found", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                            End Try
                                        End If

                                    End If

                                Case "b_copy"
                                    If pVal.BeforeAction = False Then
                                        Me.CreateMySimpleForm_SODetails()
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.BeforeAction = True And (frmSaleOrderAdd.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then

                                    Else

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID
                                Case "15"
                                    If pVal.BeforeAction = False Then

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmSaleOrderAdd = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            'If pVal.FormTypeEx = SalesOrderTypeEx Then
            Select Case pVal.MenuUID
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
            End Select
            'End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmSaleOrderAdd = frmGloSaleAddOrder
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then

                        End If
                        If BusinessObjectInfo.ActionSuccess Then

                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then

                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                    End Select
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub ProductionOrder(ByVal DocEntry As String, ByVal ItemCode As String, ByVal Qty As Integer, ByVal Whse As String, ByVal Model As String)
        Try
            Dim Error1 As Integer = 0
            Dim Prod As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
            Prod.PostingDate = Now()
            Prod.ItemNo = ItemCode
            Prod.PlannedQuantity = Qty
            Prod.Warehouse = Whse
            Prod.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned
            Prod.ProductionOrderOrigin = SAPbobsCOM.BoProductionOrderOriginEnum.bopooSalesOrder
            Prod.ProductionOrderOriginEntry = DocEntry
            Prod.UserFields.Fields.Item("U_GA_MODEL").Value = Model
            Error1 = Prod.Add()
            If (Error1 <> 0) Then
                oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Else
                oApplication.MessageBox("Production Order Created successfully", 1, "Ok")
            End If
            'Dim ithReturnValue As Integer
            'ithReturnValue = oApplication.MessageBox("Do you want to Scrap the Item ?", 1, "Continue", "Cancel", "")
            'If (ithReturnValue = 1) Then
            '    CreateMySimpleForm_QtyScrap()
            'End If

        Catch ex As Exception

        End Try
    End Sub
    Sub CreateMySimpleForm_Whse()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_WHSE"
            CP.FormType = "300"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 120
            oForm.Width = 300
            oForm.Title = "Warehouse"
            '' Add a Grid item to the form 


            ' Add OK Button 
            oItem = oForm.Items.Add("1", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Ok"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_Whse", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 85
            oItem.Height = 15
            oItem.LinkTo = "edtWhse"
            oLabel = oItem.Specific
            oLabel.Caption = "Enter Whse"


            '----------------------------------------




            oItem = oForm.Items.Add("edtWhse", SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX)
            oItem.Left = 100
            oItem.Top = 10
            oItem.Width = 150
            oItem.Height = 15
            oCombo = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_Whse", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oCombo.DataBind.SetBound(True, "", "U_Whse")
            oItem.DisplayDesc = True
            oItem.Enabled = True
            oCombo.ValidValues.Add("H01", "Blackpool warehouse")
            oCombo.ValidValues.Add("H03", "Oldbury Warehouse")

            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub CreateMySimpleForm_PostCodeList()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim ocheckbox As SAPbouiCOM.CheckBox
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_POST"
            CP.FormType = "505"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height  
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Post Details"
            '' Add a Grid item to the form  
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position  
            oItem.Left = 5
            oItem.Top = 25
            oItem.Width = 675
            oItem.Height = 240
            ' Set the grid data  
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button  
            oItem = oForm.Items.Add("Add", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button  
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific


            sQuery = GblSQry


            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()

            For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                    oGrid.Columns.Item(i).Editable = True
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Purchase Order Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    Sub CreateMySimpleForm_QtyScrap()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_SCRP"
            CP.FormType = "201"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 120
            oForm.Width = 200
            oForm.Title = "Scrap Qty"
            '' Add a Grid item to the form 


            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_Qty", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 85
            oItem.Height = 15
            oItem.LinkTo = "edtQty"
            oLabel = oItem.Specific
            oLabel.Caption = "Enter Quantity"


            '----------------------------------------




            oItem = oForm.Items.Add("edtQty", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 100
            oItem.Top = 10
            oItem.Width = 40
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_Qty", SAPbouiCOM.BoDataType.dt_SHORT_NUMBER)
            oEditBox.DataBind.SetBound(True, "", "U_Qty")
            oItem.Enabled = True


            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub CreateMySimpleForm_SODetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SODetails"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Sale Order Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 675
            oItem.Height = 260
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"

            sQuery = String.Empty
            sQuery = "CALL ""@INSPL_GET_SO_DETAILS""  ('" & oDBDSHeader.GetValue("U_PickWhs", 0).Trim & "')"
            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_Whse(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType




                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = False Then
                                    Dim Whse = oForm.DataSources.UserDataSources.Item("U_Whse").ValueEx
                                    If (Whse <> "") Then
                                        Me.ProductionOrder(GblDocEntry, GblItemCode, GblPlanQty, Whse, GblModel)
                                        oForm.Close()
                                    Else

                                        oApplication.MessageBox("Select One Whse", 1, "OK")
                                    End If


                                End If


                        End Select
                    Catch ex As Exception
                        frmSaleOrderAdd.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try





            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub

    Sub ItemEvent_Scrap(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType




                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim Error1 As Integer = 0
                                    Dim EditText As SAPbouiCOM.EditText
                                    EditText = oMatrix.Columns.Item("4").Cells.Item(GblSelRow1).Specific
                                    Dim Getitem As String = EditText.Value

                                    Dim SqlLine As String = "Select [LineNum]  from [WOR1] WHERE DocEntry='" & GblDocEntry & "' and ItemCode='" & Getitem & "'"
                                    Dim RsLine As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                    RsLine.DoQuery(SqlLine)
                                    Dim Qty As Integer = Convert.ToInt32(oForm.DataSources.UserDataSources.Item("U_Qty").ValueEx)
                                    Dim Gissue As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit)
                                    Gissue.DocDate = Now()
                                    Gissue.Lines.BaseType = 202
                                    Gissue.Lines.BaseEntry = GblDocEntry
                                    Gissue.Lines.BaseLine = Convert.ToInt32(RsLine.Fields.Item(0).Value.ToString())
                                    Dim LineNum As Integer = Convert.ToInt32(RsLine.Fields.Item(0).Value.ToString())
                                    Gissue.Lines.Quantity = Qty
                                    Gissue.Lines.UserFields.Fields.Item("U_PMX_LOCO").Value = "DZ1"
                                    Gissue.Lines.UserFields.Fields.Item("U_PMX_QYSC").Value = "RELEASED"
                                    Error1 = Gissue.Add()
                                    If (Error1 <> 0) Then
                                        oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                    Else

                                        sQuery = "Update WOR1 SET PlannedQty=PlannedQty+" & Qty & " WHERE DocEntry='" & GblDocEntry & "' and LineNum='" & LineNum & "'"
                                        Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                        oApplication.StatusBar.SetText("Scrap posted successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                        oApplication.MessageBox("Scrap posted successfully", 1, "Ok")
                                        frmGloSaleAddOrder.Refresh()
                                    End If


                                    oForm.Close()
                                End If


                        End Select
                    Catch ex As Exception
                        frmSaleOrderAdd.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try





            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub


    Sub ItemEvent_PostDetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "Add"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific

                                    'GoTo M 
                                    Dim RowID As Integer = 1


                                    For j As Integer = 1 To oGrid.Rows.Count

                                        Dim Status As String = oGrid.DataTable.Columns.Item("Select").Cells.Item(j - 1).Value
                                        If (Status = "Y") Then
                                            sQuery = String.Empty
                                            sQuery = "SELECT * FROM [@GA_APIM]"
                                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)



                                            Dim Matrix As SAPbouiCOM.Matrix
                                                    Matrix = frmSaleOrderAdd.Items.Item("10000003").Specific
                                            Dim oEdit As SAPbouiCOM.EditText
                                            oEdit = Matrix.Columns.Item("10000007").Cells.Item(1).Specific
                                            oEdit.Value = oGrid.DataTable.Columns.Item("Street").Cells.Item(j - 1).Value
                                            oEdit = Matrix.Columns.Item("10000011").Cells.Item(1).Specific
                                            oEdit.Value = oGrid.DataTable.Columns.Item("Town").Cells.Item(j - 1).Value
                                            oEdit = Matrix.Columns.Item("10000013").Cells.Item(1).Specific
                                            oEdit.Value = oGrid.DataTable.Columns.Item("Postcode").Cells.Item(j - 1).Value


                                            Dim Matrix2 As SAPbouiCOM.Matrix = frmSaleOrderAdd.Items.Item("10000003").Specific
                                                    Dim oEdit2 As SAPbouiCOM.EditText = Matrix2.Columns.Item("10000005").Cells.Item(1).Specific
                                                    oEdit2.Value = ""
                                                    oEdit2 = Matrix2.Columns.Item("10000009").Cells.Item(1).Specific
                                                    oEdit2.Value = ""

                                            oEdit2 = Matrix2.Columns.Item("1470000029").Cells.Item(1).Specific
                                            oEdit2.Value = ""
                                                    oEdit2 = Matrix2.Columns.Item("U_GA_DelDayS").Cells.Item(1).Specific
                                                    oEdit2.Value = ""
                                                    Dim oCombo2 As SAPbouiCOM.ComboBox = Matrix2.Columns.Item("10000017").Cells.Item(1).Specific
                                                    oCombo2.Select("", SAPbouiCOM.BoSearchKey.psk_ByDescription)
                                                    'oCombo2 = Matrix2.Columns.Item("10000019").Cells.Item(1).Specific
                                                    'oCombo2.Select("XX", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                    GoTo ForEnd
                                        End If

                                    Next
ForEnd:
                                    oApplication.StatusBar.SetText("Address Selected", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oForm.Close()

                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("ComboBox Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                Select Case pVal.ColUID
                                    Case "Select"
                                        Try
                                            oForm.Freeze(True)

                                            If (pVal.BeforeAction = False) Then
                                                Dim RowLine As Integer = oGrid.GetDataTableRowIndex(pVal.Row)
                                                Dim Chk As String = oGrid.DataTable.Columns.Item("Select").Cells.Item(RowLine).Value
                                                If Chk = "Y" Then


                                                    For i As Integer = 1 To oGrid.Rows.Count
                                                        If i <> RowLine + 1 Then


                                                            oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value = "N"
                                                        End If

                                                    Next
                                                End If
                                            End If
                                        Catch ex As Exception
                                            oForm.Freeze(False)
                                        Finally
                                            oForm.Freeze(False)
                                        End Try
                                End Select
                            Case "c_select"
                                oForm.Freeze(True)
                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                If pVal.BeforeAction = False Then
                                    Dim RowID As Integer = 1
                                    Dim s1 As SAPbouiCOM.CheckBox = oForm.Items.Item("c_select").Specific
                                    s1.ValOn = "Y"
                                    s1.ValOff = "N"
                                    If s1.Checked = True Then
                                        For i As Integer = 1 To oGrid.Rows.Count
                                            oGrid.DataTable.Columns.Item("Print").Cells.Item(i - 1).Value = "Y"
                                            RowID += 1
                                        Next
                                    ElseIf s1.Checked = False Then
                                        For i As Integer = 1 To oGrid.Rows.Count
                                            oGrid.DataTable.Columns.Item("Print").Cells.Item(i - 1).Value = "N"
                                            RowID += 1
                                        Next
                                    End If
                                End If
                                oForm.Freeze(False)
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                'Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific 
                                Select Case pVal.ColUID

                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Validate Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    'Dim oCompanyService As SAPbobsCOM.CompanyService
    'Dim oTimeSheetService As SAPbobsCOM.ProjectManagementTimeSheetService
    'Dim oTimeSheet As SAPbobsCOM.PM_TimeSheetData
    'Dim oTimeSheetLine As SAPbobsCOM.PM_TimeSheetLineData
    'Dim oTimeSheetParam As SAPbobsCOM.PM_TimeSheetParams
    'Dim StartTime As Date
    'Dim EndTime As Date
    'Dim breakTime As Date
    'Dim NonBillableTime As Date

    'Dim oCompanySer As SAPbobsCOM.CompanyService = oCompany.GetCompanyService
    'Dim oTimeShee As SAPbobsCOM.ProjectManagementTimeSheetService = oCompanyService.GetBusinessService(SAPbobsCOM.ServiceTypes.ProjectManagementTimeSheetService)
    'Dim oTimeSheet As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetData)
    'Dim oTimeSheetLine As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetLineData)
    'Dim oTimeSheetParam As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetParams)

    'oTimeSheet.TimeSheetType = SAPbobsCOM.TimeSheetTypeEnum.tsh_Employee
    'oTimeSheet.UserId = 2


    'StartTime = VBA.DateAdd("h", 7, VBA.Int(Now)) 'start a 7.00
    'EndTime = VBA.DateAdd("n", 90, StartTime) 'add 90 minutes
    'breakTime = VBA.DateAdd("n", 45, VBA.Int(Now)) 'pause  45 minutes


    'NonBillableTime = VBA.DateAdd("n", 15, VBA.Int(Now))
    'oTimeSheetLine.Date = Now
    'oTimeSheetLine.StartTime = StartTime
    'oTimeSheetLine.EndTime = EndTime
    'oTimeSheetLine.Break = breakTime
    'oTimeSheetLine.NonBillableTime = NonBillableTime
    'oTimeSheetLine.ActivityType = 1
    'oTimeSheetLine.CostCenter = ""
    'oTimeSheetLine.FinancialProject = "090"

    'oTimeSheetLine = oTimeSheet.PM_TimeSheetLineDataCollection.Add()

    'oTimeSheetParam = oTimeSheetService.AddTimeSheet(oTimeSheet)

End Class
