﻿
''' <summary>
''' This Application Sarted from here
''' This is Used for to connect the SAP and dot net console
''' And create menu
''' 1)SetApplication
'''  It is used to get connection to SAP.
'''  Here we are using SAPbouiCOM.SboGuiApi, it is part of the SAP Business One Software Development Kit (SDK), and exposes user 
'''  Collection elements of the SAP Business One front end
''' 2)SetFilter
'''   Sets an EventFilter object that filters in events on specific forms
''' 3)CookieConnect
'''  It is represent the one of the Company Data base
'''  It is enable to connect the company and Create the Business Object to use the company data base
''' 4)ConnectionContext
'''   It is used for to connect the company
''' 5)TableCreation
'''   It is used for to craete user tables and user define objects
''' 6)SetEventFilter
'''   User to filder the events for particilar forms
'''   it is used to high performance 
''' 7)AddXML
'''   It is used to add memu XML 
''' </summary>
''' <remarks></remarks>
''' 

Module Menu


#Region "... Main ..."

    Sub Main()
        Try

            'Welcom.Show()
            oGfun.SetApplication() '1)
            ' oApplication.SetFilter(New SAPbouiCOM.EventFilter) '2)
            If Not oGfun.CookieConnect() = 0 Then '3)
                oApplication.MessageBox("DI Api Conection Failed")
                End
            End If
            If Not oGfun.ConnectionContext() = 0 Then '4)
                oApplication.MessageBox("Failed to Connect Company")
                End
            End If
            'Welcom.Close()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show("Application Not Found", AddOnName)
            System.Windows.Forms.Application.ExitThread()
        Finally
        End Try
        Try
            Try






                Dim oTableCreation As New TableCreation     '5)              
                EventHandler.SetEventFilter()               '6)
                '' oGfun.AddXML("Menu.xml")                    '7)
                ''Dim oMeniItem As SAPbouiCOM.MenuItem = EventHandler.oApplication.Menus.Item("OITMC")
                ''oMeniItem.Image = System.Windows.Forms.Application.StartupPath & "\icons8-process-15.png"

            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show(ex.Message)
                System.Windows.Forms.Application.ExitThread()
            Finally
            End Try
            oApplication.StatusBar.SetText("Ready to Use.....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            System.Windows.Forms.Application.Run()
        Catch ex As Exception
            oApplication.StatusBar.SetText(AddOnName & "Main Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub
#End Region

End Module
