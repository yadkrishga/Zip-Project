Public Class ProductionOrder
    Dim frmProdOrder, frmGloProdOrder As SAPbouiCOM.Form
    Dim oDBDSHeader, oDBDSDetail As SAPbouiCOM.DBDataSource
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim boolFormLoaded = False, boolFilterItem As Boolean = False
    Dim DeleteRowITEMUID As String = ""
    Dim row As Integer
    Dim sDelRowMatrix As String = ""
    Dim GlobalDocEntry As Integer
    Dim GblDocEntry As String = ""
    Dim GblSelRow As Integer = 0
    Dim GblSelRow1 As Integer = 0
    Dim GblItemCode As String = ""
    Dim GblPlanQty As Double = 0
    Dim GblLineNum As Integer = 0

    Private Sub AddChooseFromList()
        Try

            Dim oCFLs As SAPbouiCOM.ChooseFromListCollection
            Dim oCons As SAPbouiCOM.Conditions
            Dim oCon As SAPbouiCOM.Condition

            oCFLs = frmProdOrder.ChooseFromLists

            Dim oCFL As SAPbouiCOM.ChooseFromList
            Dim oCFLCreationParams As SAPbouiCOM.ChooseFromListCreationParams
            oCFLCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)

            ' Adding 2 CFL, one for the button and one for the edit text.
            oCFLCreationParams.MultiSelection = False
            oCFLCreationParams.ObjectType = "4"
            oCFLCreationParams.UniqueID = "CFL1"

            oCFL = oCFLs.Add(oCFLCreationParams)

            ' Adding Conditions to CFL1

            oCons = oCFL.GetConditions()

            oCon = oCons.Add()
            oCon.Alias = "TreeType"
            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL
            oCon.CondVal = "P"
            oCFL.SetConditions(oCons)



        Catch
            MsgBox(Err.Description)
        End Try
    End Sub

    Sub LoadProdOrder(ByVal FormUID As String)
        Try
            boolFormLoaded = False
            Dim oItem As SAPbouiCOM.Item
            Dim oButton As SAPbouiCOM.Button
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oComboBox As SAPbouiCOM.ComboBox
            Dim oEditText As SAPbouiCOM.EditText


            frmProdOrder = oApplication.Forms.Item(FormUID)
            frmGloProdOrder = oApplication.Forms.Item(FormUID)
            AddChooseFromList()
            oMatrix = frmProdOrder.Items.Item("37").Specific
            oDBDSHeader = frmProdOrder.DataSources.DBDataSources.Item("OWOR")
            oDBDSDetail = frmProdOrder.DataSources.DBDataSources.Item("WOR1")


            frmProdOrder.Freeze(True)

            ' Purchase Indent Copy From Button ...
            '------------------------------------

            oItem = frmProdOrder.Items.Add("b_GA_WIP", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmProdOrder.Items.Item("2").Left + frmProdOrder.Items.Item("2").Width + 5
            oItem.Width = frmProdOrder.Items.Item("2").Width
            oItem.Height = frmProdOrder.Items.Item("2").Height
            oItem.Top = frmProdOrder.Items.Item("2").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "Create WIP"


            oItem = frmProdOrder.Items.Add("b_GA_SCRP", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmProdOrder.Items.Item("2").Left + frmProdOrder.Items.Item("2").Width + 5 + frmProdOrder.Items.Item("2").Width + 5
            oItem.Width = frmProdOrder.Items.Item("2").Width + 50
            oItem.Height = frmProdOrder.Items.Item("2").Height
            oItem.Top = frmProdOrder.Items.Item("2").Top
            oItem.Visible = False
            oItem.Enabled = False
            oButton = oItem.Specific
            oButton.Caption = "Scrap Item"

            oItem = frmProdOrder.Items.Add("b_GA_WDET", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmProdOrder.Items.Item("b_GA_WIP").Left + frmProdOrder.Items.Item("b_GA_WIP").Width + 5
            oItem.Width = frmProdOrder.Items.Item("b_GA_WIP").Width
            oItem.Height = frmProdOrder.Items.Item("b_GA_WIP").Height
            oItem.Top = frmProdOrder.Items.Item("b_GA_WIP").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "WIP Details"

            'oItem = frmProdOrder.Items.Add("b_GA_PRNT", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = frmProdOrder.Items.Item("b_GA_WDET").Left + frmProdOrder.Items.Item("b_GA_WDET").Width + 5
            'oItem.Width = frmProdOrder.Items.Item("b_GA_WDET").Width
            'oItem.Height = frmProdOrder.Items.Item("b_GA_WDET").Height
            'oItem.Top = frmProdOrder.Items.Item("b_GA_WDET").Top
            'oItem.Visible = True
            'oItem.Enabled = True
            'oItem.LinkTo = "b_GA_WDET"
            'oButton = oItem.Specific
            'oButton.Caption = "WIP Print"


            oItem = frmProdOrder.Items.Add("l_GA_WQty", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmProdOrder.Items.Item("540000152").Left
            oItem.Width = frmProdOrder.Items.Item("540000152").Width
            oItem.Height = frmProdOrder.Items.Item("540000152").Height
            oItem.Top = frmProdOrder.Items.Item("540000152").Top + 16 + 16
            oLabel = oItem.Specific
            oLabel.Caption = "WIP Quantity"

            oItem = frmProdOrder.Items.Add("t_GA_WQty", SAPbouiCOM.BoFormItemTypes.it_EXTEDIT)
            oItem.Left = frmProdOrder.Items.Item("540000153").Left
            oItem.Width = frmProdOrder.Items.Item("540000153").Width
            oItem.Height = frmProdOrder.Items.Item("540000153").Height
            oItem.Top = frmProdOrder.Items.Item("540000153").Top + 16 + 16
            oEditText = oItem.Specific
            oEditText.DataBind.SetBound(True, "OWOR", "U_GA_ADDITEM")
            oItem.Enabled = True
            frmProdOrder.Items.Item("l_GA_WQty").LinkTo = "t_GA_WQty"

            oItem = frmProdOrder.Items.Add("l_GA_BBOM", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = frmProdOrder.Items.Item("20").Left + frmProdOrder.Items.Item("20").Width + 5
            oItem.Width = frmProdOrder.Items.Item("20").Width
            oItem.Height = frmProdOrder.Items.Item("20").Height
            oItem.Top = frmProdOrder.Items.Item("20").Top
            oLabel = oItem.Specific
            frmProdOrder.Items.Item("l_GA_BBOM").LinkTo = "20"
            oLabel.Caption = "Base Model"

            oItem = frmProdOrder.Items.Add("t_GA_BBOM", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = frmProdOrder.Items.Item("l_GA_BBOM").Left + frmProdOrder.Items.Item("l_GA_BBOM").Width + 5
            oItem.Width = frmProdOrder.Items.Item("l_GA_BBOM").Width
            oItem.Height = frmProdOrder.Items.Item("l_GA_BBOM").Height
            oItem.Top = frmProdOrder.Items.Item("l_GA_BBOM").Top
            oEditText = oItem.Specific
            oEditText.DataBind.SetBound(True, "OWOR", "U_GA_BBOM")
            oItem.Enabled = True
            oEditText.ChooseFromListUID = "CFL1"


            oEditText.ChooseFromListAlias = "ItemCode"
            frmProdOrder.Items.Item("t_GA_BBOM").LinkTo = "l_GA_BBOM"

            oItem = frmProdOrder.Items.Add("b_GA_COMP", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = frmProdOrder.Items.Item("t_GA_BBOM").Left + frmProdOrder.Items.Item("t_GA_BBOM").Width + 5
            oItem.Width = frmProdOrder.Items.Item("t_GA_BBOM").Width - 20
            oItem.Height = frmProdOrder.Items.Item("t_GA_BBOM").Height
            oItem.Top = frmProdOrder.Items.Item("t_GA_BBOM").Top
            oItem.Visible = True
            oItem.Enabled = True
            oButton = oItem.Specific
            oButton.Caption = "Fill BOM"
            frmProdOrder.Items.Item("b_GA_COMP").LinkTo = "t_GA_BBOM"














            ' ''***********************************
            Me.InitForm()
            Me.DefineModeForFields()

            boolFormLoaded = True
            frmProdOrder.Freeze(False)
        Catch ex As Exception
            frmProdOrder.Freeze(False)
            'oApplication.StatusBar.SetText("Load SalesOrder Form Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub InitForm()
        Try
            frmProdOrder.Freeze(True)

            frmProdOrder.Freeze(False)
        Catch ex As Exception
            frmProdOrder.Freeze(False)
            oApplication.StatusBar.SetText("Set Default Value Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub DefineModeForFields()
        Try
            'frmProdOrder.Items.Item("b_focform").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("Define Mode For Fields Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub Calculation()
        Try
            Dim TotCBMQty As Double = 0.0
            Dim TotCartonQty As Double = 0.0
            'Dim CartonQty As Double = 0.0
            For i As Integer = 1 To oMatrix.VisualRowCount
                If oMatrix.Columns.Item("1").Cells.Item(i).Specific.value <> "" Then
                    sQuery = String.Empty
                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oMatrix.Columns.Item("1").Cells.Item(i).Specific.value & "'"
                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    Dim CBMQty As Double = Rst.Fields.Item("U_CBM").Value
                    Dim CartonQty As Double = Rst.Fields.Item("U_CartQty").Value
                    TotCBMQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value
                    TotCartonQty += CBMQty * oMatrix.Columns.Item("11").Cells.Item(i).Specific.value / CartonQty
                End If
            Next

            frmProdOrder.Items.Item("t_cbm").Enabled = True
            frmProdOrder.Items.Item("t_carton").Enabled = True
            frmProdOrder.Items.Item("t_cbm").Specific.value = TotCBMQty
            frmProdOrder.Items.Item("t_carton").Specific.value = TotCartonQty
            frmProdOrder.Items.Item("16").Specific.value = frmProdOrder.Items.Item("16").Specific.value
            frmProdOrder.Items.Item("t_cbm").Enabled = False
            frmProdOrder.Items.Item("t_carton").Enabled = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("Calculation Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Function Validation() As Boolean
        Try
            Dim flag As Boolean = True
            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
            Dim Status As String = oDBDSHeader.GetValue("Status", 0)
            Dim SqlWipExist As String = "Select *  from [@GA_WIPN] WHERE U_GA_PoEnt='" & DocEntry & "'"
            Dim RsWIP As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RsWIP.DoQuery(SqlWipExist)
            If (RsWIP.RecordCount > 0 And Status = "P") Then
                flag = False
                oApplication.MessageBox("Production order status change is not permitted after WIP number is generated", 1, "Ok")
            Else
                flag = True

            End If

            Return flag
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validation Function Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmProdOrder = oApplication.Forms.Item(FormUID)
                '   oForm = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = ProdOrderTypeEx Then
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                        Try

                            If (pVal.ItemUID = "t_GA_BBOM") Then
                                Dim oCFLEvento As SAPbouiCOM.IChooseFromListEvent
                                oCFLEvento = pVal
                                Dim sCFL_ID As String
                                sCFL_ID = oCFLEvento.ChooseFromListUID

                                Dim oCFL As SAPbouiCOM.ChooseFromList
                                oCFL = frmProdOrder.ChooseFromLists.Item(sCFL_ID)
                                If oCFLEvento.BeforeAction = False Then
                                    Dim oDataTable As SAPbouiCOM.DataTable
                                    oDataTable = oCFLEvento.SelectedObjects
                                    Dim val As String
                                    Try
                                        val = oDataTable.GetValue("ItemCode", 0)
                                    Catch ex As Exception

                                    End Try
                                    Dim oEditBOM As SAPbouiCOM.EditText = frmProdOrder.Items.Item("t_GA_BBOM").Specific

                                    oEditBOM.Value = val
                                End If

                            End If
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Choose from List Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                        Try
                            If pVal.BeforeAction = False Then Me.LoadProdOrder(pVal.FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Form Load Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "b_GA_COMP"
                                    Try

                                        frmProdOrder.Freeze(True)
                                        If pVal.BeforeAction = False Then
                                            If frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then
                                                Dim ItemCode As String = oDBDSHeader.GetValue("U_GA_BBOM", 0)
                                                Dim PType As String = oDBDSHeader.GetValue("Type", 0)
                                                Dim PStatus As String = oDBDSHeader.GetValue("Status", 0)
                                                Dim PlanQty As Double = Convert.ToDouble(oDBDSHeader.GetValue("PlannedQty", 0))
                                                Dim sQueryLoc As String = String.Empty
                                                sQueryLoc = "Select C.Location FROM ORDR A INNER JOIN RDR1 B ON A.DocEntry=B.DocEntry INNER JOIN OWHS C ON B.WhsCode=C.WhsCode WHERE A.DocEntry='" & oDBDSHeader.GetValue("OriginAbs", 0) & "' and B.ItemCode='" & ItemCode & "' "
                                                Dim RstLoc As SAPbobsCOM.Recordset = oGfun.DoQuery(sQueryLoc)
                                                Dim LocCode As String = ""
                                                If (RstLoc.RecordCount > 0) Then
                                                    LocCode = RstLoc.Fields.Item(0).Value.ToString()
                                                End If
                                                If (ItemCode <> "" And PType = "P" And PStatus = "P") Then
                                                        Dim sQuery2 As String = String.Empty
                                                    sQuery2 = " SELECT T0.[Code],(SELECT MAX(U_GA_PWhs) FROM [@GA_LOCM] WHERE U_GA_SWhs='" + oDBDSHeader.GetValue("Warehouse", 0) + "'"
                                                    If (LocCode <> "") Then
                                                        sQuery2 += " and Name ='" & LocCode & "'"
                                                    End If
                                                    sQuery2 += ")[Warehouse], T0.[Quantity]  , T0.[IssueMthd], T0.[Type] FROM ITT1 T0 WHERE T0.[Father]='" + ItemCode + "' and ISNULL(T0.[Code],'')<>''"

                                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery2)
                                                        If (Rst.RecordCount > 0) Then
                                                            oApplication.StatusBar.SetText("Filling Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                                            If (oMatrix.VisualRowCount > 1) Then
                                                                For x As Integer = oMatrix.VisualRowCount - 1 To 2 Step -1
                                                                    oMatrix.Columns.Item("0").Cells.Item(x).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0)
                                                                    oApplication.ActivateMenuItem("1293")
                                                                Next
                                                            End If
                                                            For i As Integer = 1 To Rst.RecordCount
                                                                Dim mEdit As SAPbouiCOM.EditText
                                                                Dim mCombo As SAPbouiCOM.ComboBox
                                                                mCombo = oMatrix.Columns.Item("1880000002").Cells.Item(i).Specific
                                                                mCombo.Select(Rst.Fields.Item("Type").Value.ToString().Trim(), SAPbouiCOM.BoSearchKey.psk_ByValue)
                                                                mEdit = oMatrix.Columns.Item("4").Cells.Item(i).Specific
                                                                mEdit.Value = Rst.Fields.Item("Code").Value.ToString().Trim()
                                                                mEdit = oMatrix.Columns.Item("10").Cells.Item(i).Specific
                                                                mEdit.Value = Rst.Fields.Item("Warehouse").Value.ToString().Trim()
                                                                mEdit = oMatrix.Columns.Item("14").Cells.Item(i).Specific
                                                                Dim PlanQtyLine As Double = Convert.ToDouble(Rst.Fields.Item("Quantity").Value.ToString().Trim()) * PlanQty
                                                                mEdit.Value = PlanQtyLine.ToString().Trim()

                                                                Rst.MoveNext()
                                                            Next



                                                            oApplication.StatusBar.SetText("Filling Data,Completed", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                                        End If
                                                    Else
                                                        oApplication.StatusBar.SetText("Production Order should be Special and Status should be Planned", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                                    End If
                                                End If
                                            End If
                                    Catch ex As Exception
                                        oApplication.StatusBar.SetText("Filling Data,Error", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        frmProdOrder.Freeze(False)
                                    Finally

                                        frmProdOrder.Freeze(False)
                                    End Try
                                Case "1"
                                    If pVal.ActionSuccess And frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        Me.InitForm()
                                    End If
                                    'Case "lk_grp"
                                    '    If pVal.BeforeAction = False Then
                                    '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", frmProdOrder.Items.Item("t_docentry").Specific.value)
                                    '    End If
                                Case "b_GA_PRNT"
                                    If pVal.BeforeAction = False Then
                                        If frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                            oApplication.ActivateMenuItem("519")
                                        End If
                                    End If
                                Case "b_GA_WIP"
                                    If pVal.BeforeAction = False Then
                                        If frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                            ' Me.CreateMySimpleForm_ItemList()
                                            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
                                            GblDocEntry = oDBDSHeader.GetValue("DocEntry", 0)

                                            Dim Sqlstatus As String = "Select [Status]  from [OWOR] WHERE DocEntry='" & DocEntry & "'"
                                            Dim RsStat As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                            RsStat.DoQuery(Sqlstatus)
                                            Dim Status As String = RsStat.Fields.Item(0).Value.ToString().Trim()
                                            If (DocEntry <> "" And Status = "R") Then
                                                Me.WIPCreate(DocEntry, Status)
                                            Else
                                                oApplication.MessageBox("WIP number cannot be generated in Planned Status. Change the Status to Release and try again", 1, "Ok")
                                                oApplication.StatusBar.SetText("WIP number cannot be generated in Planned Status. Change the Status to Release and try again", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            End If
                                        End If
                                    End If


                                Case "b_GA_WDET"
                                    If pVal.BeforeAction = False Then
                                        If frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                            ' Me.CreateMySimpleForm_ItemList()
                                            frmProdOrder = oApplication.Forms.ActiveForm
                                            oDBDSHeader = frmProdOrder.DataSources.DBDataSources.Item("OWOR")
                                            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
                                            GblDocEntry = oDBDSHeader.GetValue("DocEntry", 0)
                                            CreateMySimpleForm_WIPDetails()


                                        End If
                                    End If
                                Case "b_GA_SCRP"
                                    If pVal.BeforeAction = False Then
                                        If frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then
                                            ' Me.CreateMySimpleForm_ItemList()
                                            Dim DocEntry As String = oDBDSHeader.GetValue("DocEntry", 0)
                                            GblDocEntry = oDBDSHeader.GetValue("DocEntry", 0)
                                            GblSelRow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                            GblSelRow1 = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_SelectionOrder)
                                            Dim Sqlstatus As String = "Select [Status]  from [OWOR] WHERE DocEntry='" & DocEntry & "'"
                                            Dim RsStat As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                            RsStat.DoQuery(Sqlstatus)
                                            Dim Status As String = RsStat.Fields.Item(0).Value.ToString().Trim()
                                            Dim Rowsel = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                            If (DocEntry <> "" And Status = "R" And Rowsel > -1) Then
                                                Dim oEdit As SAPbouiCOM.EditText = oMatrix.Columns.Item("4").Cells.Item(Rowsel).Specific
                                                GblItemCode = oEdit.Value
                                                oEdit = oMatrix.Columns.Item("14").Cells.Item(Rowsel).Specific
                                                GblPlanQty = Convert.ToDouble(oEdit.Value.ToString())
                                                Me.Scrap(DocEntry, Status, Rowsel)
                                            Else
                                                oApplication.MessageBox("Scrap Item Issue cannot be generated in Planned Status. Change the Status to Release and try again", 1, "Ok")
                                                ''oApplication.StatusBar.SetText("Check Production Order in Released status,or Update the Document to Released", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_None)
                                            End If
                                        End If
                                    End If
                                Case "b_copy"
                                    If pVal.BeforeAction = False Then
                                        Me.CreateMySimpleForm_SODetails()
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID
                                Case "1"
                                    If pVal.BeforeAction = True And (frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                        If Me.Validation() = False Then
                                            System.Media.SystemSounds.Asterisk.Play()
                                            BubbleEvent = False
                                            Exit Sub
                                        End If
                                    Else

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID
                                Case "15"
                                    If pVal.BeforeAction = False Then

                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try
                            frmProdOrder = oApplication.Forms.Item(FormUID)
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            'If pVal.FormTypeEx = SalesOrderTypeEx Then
            Select Case pVal.MenuUID
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
            End Select
            'End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            frmProdOrder = frmGloProdOrder
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD

                    Try

                        If BusinessObjectInfo.ActionSuccess And frmProdOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then


                            Dim DocEntry2 As String = oDBDSHeader.GetValue("DocEntry", 0)
                            Dim StrQry As String = "Select AtcEntry,DocEntry from ORDR WHERE DocEntry IN(SELECT T0.[OriginAbs] FROM OWOR T0 WHERE T0.[DocEntry]='" + DocEntry2 + "' and T0.[LinkToObj]='17' and ISNULL(T0.AtcEntry,'')='')"
                            Dim RsAtc As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                            RsAtc.DoQuery(StrQry)

                            If (RsAtc.RecordCount > 0) Then
                                Dim SOEntry As String = RsAtc.Fields.Item(1).Value.ToString().Trim()
                                Dim AtcEntry2 As String = RsAtc.Fields.Item(0).Value.ToString().Trim()
                                Dim strQry2 As String = "Select T0.[srcPath], T0.[trgtPath], T0.[FileName], T0.[FileExt], T0.[FreeText] FROM ATC1 T0 where T0. AbsEntry='" & AtcEntry2 & "'"
                                Dim RsAtc2 As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                RsAtc2.DoQuery(strQry2)
                                Dim Production2 As SAPbobsCOM.ProductionOrders = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders)
                                If (RsAtc2.RecordCount > 0) Then

                                    Production2.GetByKey(DocEntry2)
                                    Dim Attachment2 As SAPbobsCOM.Attachments2 = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oAttachments2)
                                    For i As Integer = 1 To RsAtc2.RecordCount
                                        Attachment2.Lines.Add()
                                        Attachment2.Lines.SourcePath = RsAtc2.Fields.Item("srcPath").Value.ToString()
                                        Attachment2.Lines.FileName = RsAtc2.Fields.Item("FileName").Value.ToString()
                                        Attachment2.Lines.FileExtension = RsAtc2.Fields.Item("FileExt").Value.ToString()
                                        Attachment2.Lines.Override = SAPbobsCOM.BoYesNoEnum.tYES
                                        RsAtc2.MoveNext()
                                    Next
                                    Dim Error1 = Attachment2.Add()
                                    If (Error1 <> 0) Then
                                        oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                    Else

                                        Dim DocEntry3 As String = oCompany.GetNewObjectKey()
                                        Production2.AttachmentEntry = DocEntry3
                                        Production2.Update()
                                    End If
                                End If
                            End If
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then

                    End If

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                    End Select
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub WIPCreate(ByVal DocEntry As String, ByVal Status As String)
        Try
            Dim SqlWipExist As String = "Select *  from [@GA_WIPN] WHERE U_GA_PoEnt='" & DocEntry & "'"
            Dim RsWIP As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            RsWIP.DoQuery(SqlWipExist)
            If (RsWIP.RecordCount > 0) Then
                Dim ithReturnValue As Integer
                ithReturnValue = oApplication.MessageBox("Do you want to recreate WIP ?", 1, "Continue", "Cancel", "")
                If (ithReturnValue = 1) Then
                    CreateMySimpleForm_QtyWIP()
                End If
            Else
                Dim Qty As Double = Convert.ToDouble(oDBDSHeader.GetValue("PlannedQty", 0))
                Dim SqlWipInsert As String = "Exec GA_SP_WIPINSERT" & " " & DocEntry & "," & Qty & ""
                Dim RsWIPInsert As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                RsWIPInsert.DoQuery(SqlWipInsert)
                oApplication.StatusBar.SetText("WIP Created successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub Scrap(ByVal DocEntry As String, ByVal Status As String, ByVal RowSel As Integer)
        Try


            Dim ithReturnValue As Integer
            ithReturnValue = oApplication.MessageBox("Do you want to Scrap the Item ?", 1, "Continue", "Cancel", "")
            If (ithReturnValue = 1) Then
                CreateMySimpleForm_QtyScrap()
            End If

        Catch ex As Exception

        End Try
    End Sub
    Sub CreateMySimpleForm_QtyWIP()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_WIP"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 120
            oForm.Width = 200
            oForm.Title = "Additional WIP Qty"
            '' Add a Grid item to the form 


            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_Qty", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 85
            oItem.Height = 15
            oItem.LinkTo = "edtQty"
            oLabel = oItem.Specific
            oLabel.Caption = "Enter Quantity"


            '----------------------------------------




            oItem = oForm.Items.Add("edtQty", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 100
            oItem.Top = 10
            oItem.Width = 40
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_Qty", SAPbouiCOM.BoDataType.dt_SHORT_NUMBER)
            oEditBox.DataBind.SetBound(True, "", "U_Qty")
            oItem.Enabled = True


            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub CreateMySimpleForm_WIPDetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim ocheckbox As SAPbouiCOM.CheckBox
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_WIPLST"
            CP.FormType = "205"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height  
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "WIP Details"
            '' Add a Grid item to the form  
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position  
            oItem.Left = 5
            oItem.Top = 25
            oItem.Width = 675
            oItem.Height = 240
            ' Set the grid data  
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button  
            oItem = oForm.Items.Add("btn_Print", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Print"
            ' Add CANCEL Button  
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            oForm.DataSources.UserDataSources.Add("Accept", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oItem = oForm.Items.Add("c_select", SAPbouiCOM.BoFormItemTypes.it_CHECK_BOX)
            oItem.Left = 30
            oItem.Top = 8
            oItem.Width = 120
            oItem.Height = 15
            oItem.Enabled = True
            oItem.Visible = True
            oItem.DisplayDesc = False
            oItem.AffectsFormMode = False
            ocheckbox = oItem.Specific
            ocheckbox.Caption = "Select All"
            ocheckbox.ValOn = "Y"
            ocheckbox.ValOff = "N"
            ocheckbox.DataBind.SetBound(True, "", "Accept")
            ocheckbox.Checked = False
            sQuery = String.Empty

            sQuery = " Select 'N' as [Print],U_GA_PONo as [PO No] ,U_GA_Date [PO Date],U_GA_WipNo  [WIP No],U_GA_PoEnt [PO Entry],CASE WHEN [U_GA_Status]='C' THEN 'Completed' WHEN [U_GA_Status]='S' THEN 'Scrap' WHEN [U_GA_Status]='R' THEN 'Rework' WHEN [U_GA_Status]='P' THEN 'In Production' WHEN [U_GA_Status]='O' THEN 'Generated'  END [Status],[U_GA_RecNo] as [Receipt No] from [@GA_WIPN] WHERE U_GA_PoEnt='" & GblDocEntry & "'"

            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()

            For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                    oGrid.Columns.Item(i).Editable = True
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Purchase Order Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    Sub CreateMySimpleForm_QtyScrap()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "GA_SCRP"
            CP.FormType = "201"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 120
            oForm.Width = 200
            oForm.Title = "Scrap Qty"
            '' Add a Grid item to the form 


            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 60
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific



            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_Qty", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 85
            oItem.Height = 15
            oItem.LinkTo = "edtQty"
            oLabel = oItem.Specific
            oLabel.Caption = "Enter Quantity"


            '----------------------------------------




            oItem = oForm.Items.Add("edtQty", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 100
            oItem.Top = 10
            oItem.Width = 40
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_Qty", SAPbouiCOM.BoDataType.dt_SHORT_NUMBER)
            oEditBox.DataBind.SetBound(True, "", "U_Qty")
            oItem.Enabled = True


            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub CreateMySimpleForm_SODetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SODetails"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Sale Order Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 675
            oItem.Height = 260
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"

            sQuery = String.Empty
            sQuery = "CALL ""@INSPL_GET_SO_DETAILS""  ('" & oDBDSHeader.GetValue("U_PickWhs", 0).Trim & "')"
            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_WIPQty(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType




                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then

                                    Dim Qty As Integer = Convert.ToInt32(oForm.DataSources.UserDataSources.Item("U_Qty").ValueEx)
                                    Dim SqlWipInsert As String = "Exec GA_SP_WIPINSERT" & " " & GblDocEntry & "," & Qty & ""
                                    Dim RsWIPInsert As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                    RsWIPInsert.DoQuery(SqlWipInsert)
                                    oApplication.StatusBar.SetText("WIP Created successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                    oForm.Close()
                                End If


                        End Select
                    Catch ex As Exception
                        frmProdOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try





            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub

    Sub ItemEvent_Scrap(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType




                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim Error1 As Integer = 0
                                    Dim EditText As SAPbouiCOM.EditText
                                    EditText = oMatrix.Columns.Item("4").Cells.Item(GblSelRow1).Specific
                                    Dim Getitem As String = EditText.Value

                                    Dim SqlLine As String = "Select [LineNum]  from [WOR1] WHERE DocEntry='" & GblDocEntry & "' and ItemCode='" & Getitem & "'"
                                    Dim RsLine As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                    RsLine.DoQuery(SqlLine)
                                    Dim Qty As Integer = Convert.ToInt32(oForm.DataSources.UserDataSources.Item("U_Qty").ValueEx)
                                    Dim Gissue As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit)
                                    Gissue.DocDate = Now()
                                    Gissue.Lines.BaseType = 202
                                    Gissue.Lines.BaseEntry = GblDocEntry
                                    Gissue.Lines.BaseLine = Convert.ToInt32(RsLine.Fields.Item(0).Value.ToString())
                                    Dim LineNum As Integer = Convert.ToInt32(RsLine.Fields.Item(0).Value.ToString())
                                    Gissue.Lines.Quantity = Qty
                                    ' Gissue.Lines.UserFields.Fields.Item("U_PMX_LOCO").Value = "DZ1"
                                    ' Gissue.Lines.UserFields.Fields.Item("U_PMX_QYSC").Value = "RELEASED"
                                    Error1 = Gissue.Add()
                                    If (Error1 <> 0) Then
                                        oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                    Else

                                        sQuery = "Update WOR1 SET PlannedQty=PlannedQty+" & Qty & " WHERE DocEntry='" & GblDocEntry & "' and LineNum='" & LineNum & "'"
                                        Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                        oApplication.StatusBar.SetText("Scrap posted successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                        oApplication.MessageBox("Scrap posted successfully", 1, "Ok")
                                        frmGloProdOrder.Refresh()
                                    End If


                                    oForm.Close()
                                End If


                        End Select
                    Catch ex As Exception
                        frmProdOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try





            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub


    Sub ItemEvent_WIPDetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "btn_Print"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    oGrid.Columns.Item("Print").TitleObject.Click(SAPbouiCOM.BoCellClickType.ct_Double)
                                    oGrid.Columns.Item("Print").TitleObject.Click(SAPbouiCOM.BoCellClickType.ct_Double)
                                    oGrid.Columns.Item("Print").TitleObject.Sortable = False
                                    'GoTo M 
                                    Dim RowID As Integer = 1

                                    Dim tot As Double

                                    Dim TotalQty As Double = 0
                                    Dim TotalPrice As Double
                                    For j As Integer = 1 To oGrid.Rows.Count
                                        Dim WIPNo As String = oGrid.DataTable.Columns.Item("WIP No").Cells.Item(j - 1).Value
                                        Dim DocEntry As String = oGrid.DataTable.Columns.Item("PO Entry").Cells.Item(j - 1).Value
                                        Dim Status As String = oGrid.DataTable.Columns.Item("Print").Cells.Item(j - 1).Value
                                        Dim Sqlstatus As String = "Update [@GA_WIPN] set [U_GA_Print]='" & Status & "' WHERE [U_GA_PoEnt]='" & DocEntry & "' and [U_GA_WipNo]='" & WIPNo & "'"
                                        Dim RsStat As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                                        RsStat.DoQuery(Sqlstatus)

                                    Next
                                    oApplication.StatusBar.SetText("Print Status Updated", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oForm.Close()
                                    oApplication.ActivateMenuItem("519")
                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("ComboBox Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "c_select"
                                oForm.Freeze(True)
                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                If pVal.BeforeAction = False Then
                                    Dim RowID As Integer = 1
                                    Dim s1 As SAPbouiCOM.CheckBox = oForm.Items.Item("c_select").Specific
                                    s1.ValOn = "Y"
                                    s1.ValOff = "N"
                                    If s1.Checked = True Then
                                        For i As Integer = 1 To oGrid.Rows.Count
                                            oGrid.DataTable.Columns.Item("Print").Cells.Item(i - 1).Value = "Y"
                                            RowID += 1
                                        Next
                                    ElseIf s1.Checked = False Then
                                        For i As Integer = 1 To oGrid.Rows.Count
                                            oGrid.DataTable.Columns.Item("Print").Cells.Item(i - 1).Value = "N"
                                            RowID += 1
                                        Next
                                    End If
                                End If
                                oForm.Freeze(False)
                                oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Lost Focus Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                'Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific 
                                Select Case pVal.ColUID

                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Validate Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub


    'Dim oCompanyService As SAPbobsCOM.CompanyService
    'Dim oTimeSheetService As SAPbobsCOM.ProjectManagementTimeSheetService
    'Dim oTimeSheet As SAPbobsCOM.PM_TimeSheetData
    'Dim oTimeSheetLine As SAPbobsCOM.PM_TimeSheetLineData
    'Dim oTimeSheetParam As SAPbobsCOM.PM_TimeSheetParams
    'Dim StartTime As Date
    'Dim EndTime As Date
    'Dim breakTime As Date
    'Dim NonBillableTime As Date

    'Dim oCompanySer As SAPbobsCOM.CompanyService = oCompany.GetCompanyService
    'Dim oTimeShee As SAPbobsCOM.ProjectManagementTimeSheetService = oCompanyService.GetBusinessService(SAPbobsCOM.ServiceTypes.ProjectManagementTimeSheetService)
    'Dim oTimeSheet As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetData)
    'Dim oTimeSheetLine As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetLineData)
    'Dim oTimeSheetParam As   = oTimeSheetService.GetDataInterface(pmtssPM_TimeSheetParams)

    'oTimeSheet.TimeSheetType = SAPbobsCOM.TimeSheetTypeEnum.tsh_Employee
    'oTimeSheet.UserId = 2


    'StartTime = VBA.DateAdd("h", 7, VBA.Int(Now)) 'start a 7.00
    'EndTime = VBA.DateAdd("n", 90, StartTime) 'add 90 minutes
    'breakTime = VBA.DateAdd("n", 45, VBA.Int(Now)) 'pause  45 minutes


    'NonBillableTime = VBA.DateAdd("n", 15, VBA.Int(Now))
    'oTimeSheetLine.Date = Now
    'oTimeSheetLine.StartTime = StartTime
    'oTimeSheetLine.EndTime = EndTime
    'oTimeSheetLine.Break = breakTime
    'oTimeSheetLine.NonBillableTime = NonBillableTime
    'oTimeSheetLine.ActivityType = 1
    'oTimeSheetLine.CostCenter = ""
    'oTimeSheetLine.FinancialProject = "090"

    'oTimeSheetLine = oTimeSheet.PM_TimeSheetLineDataCollection.Add()

    'oTimeSheetParam = oTimeSheetService.AddTimeSheet(oTimeSheet)

End Class
