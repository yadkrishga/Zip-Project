﻿Public Class TableCreation

    Public oGFun As New GlobalFunctions
    Dim ValidValueYesORNo = New String(,) {{"N", "No"}, {"Y", "Yes"}}
    Dim ValidValueYesORNoBln = New String(,) {{"-", "-"}, {"N", "No"}, {"Y", "Yes"}}
    Dim ValidValueCell = New String(,) {{"-", "-"}, {"C1", "Cell 1"}, {"C2", "Cell 2"}, {"C3", "Cell 3"}}
    Dim ValidValueItemType = New String(,) {{"101", "Barrel"}, {"102", "Finished"}, {"103", "Sheet"}}
    Dim ValidValueStatus = New String(,) {{"O", "Generated"}, {"P", "In Production"}, {"C", "Completed"}, {"S", "Scrapped"}, {"R", "Rework"}}
    Sub New()
        Try
            Me.ProdHeaderPlan()
            Me.WIPCreation()

            Me.UDF()
            Me.RoutePlan()
            Me.LocationMappingHead()
            Me.ProdCLosureData()
        Catch ex As Exception
            oGFun.StatusBarErrorMsg("New Method Failed : " & ex.Message)
        Finally
        End Try
    End Sub

    Sub WIPCreation()
        Try
            Me.WIPCreationHead()

        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation Item Creation Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub WIPCreationHead()
        Try

            oGFun.CreateTable("GA_WIPN", "GA WipNo", SAPbobsCOM.BoUTBTableType.bott_NoObjectAutoIncrement)
            oGFun.CreateUserFields("@GA_WIPN", "GA_PONo", "GA PO No", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None)
            oGFun.CreateUserFields("@GA_WIPN", "GA_Date", "GA Date", SAPbobsCOM.BoFieldTypes.db_Date, 0, SAPbobsCOM.BoFldSubTypes.st_None)
            oGFun.CreateUserFields("@GA_WIPN", "GA_PoEnt", "GA PO Entry", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None)
            oGFun.CreateUserFields("@GA_WIPN", "GA_WipNo", "GA Wip No", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None)
            oGFun.CreateUserFields("@GA_WIPN", "GA_SeqNo", "GA Seq No", SAPbobsCOM.BoFieldTypes.db_Numeric, 0, SAPbobsCOM.BoFldSubTypes.st_None)
            oGFun.CreateUserFieldsComboBox("@GA_WIPN", "GA_Status", "GA_Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueStatus, "O")
            oGFun.CreateUserFields("@GA_WIPN", "GA_RecNo", "GA Receipt No", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None)
            oGFun.CreateUserFieldsComboBox("@GA_WIPN", "GA_Print", "GA_Print", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueYesORNo, "Y")
        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
#Region " ...RoutePlan()... "

    Sub RoutePlan()
        Try
            Me.RoutePlan_Header()
            Me.RoutePlan_Detail()

            If Not oGFun.UDOExists("GA_ROUTED") Then
                Dim FindField As String(,) = New String(,) {{"DocNum", "DocNum"}}
                oGFun.RegisterUDO("GA_ROUTED", "ROUTEPD", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "GA_ROUTE_HD", "GA_ROUTE_LD")
                FindField = Nothing
            End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation Other Pending For Confirmation Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub RoutePlan_Header()

        oGFun.CreateTable("GA_ROUTE_HD", "GA RouteP data ", SAPbobsCOM.BoUTBTableType.bott_Document)
        oGFun.CreateUserFields("@GA_ROUTE_HD", "GA_FileName", "GA FileName", SAPbobsCOM.BoFieldTypes.db_Alpha, 200)
        oGFun.CreateUserFields("@GA_ROUTE_HD", "GA_Date", "GA Date", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)

        oGFun.CreateUserFields("@GA_ROUTE_HD", "GA_TRouteNo", "GA Total Route No", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("@GA_ROUTE_HD", "GA_HHubCode", "GA HubCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("@GA_ROUTE_HD", "GA_Date2", "GA Date2", SAPbobsCOM.BoFieldTypes.db_Date)

    End Sub
    Sub RoutePlan_Detail()

        oGFun.CreateTable("GA_ROUTE_LD", "GA RouteL data ", SAPbobsCOM.BoUTBTableType.bott_DocumentLines)

        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_Address", "GA Address", SAPbobsCOM.BoFieldTypes.db_Alpha, 250)

        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_RouteNo", "GA Route No", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_ZipCode", "GA ZipCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_DocNum", "GA DocNum", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_DocEntry", "GA DocEntry", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFieldsComboBox("@GA_ROUTE_LD", "GA_SOStatus", "GA SOStatus", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueYesORNo, "N")
        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_DRIVER", "GA Driver", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)

        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_TRUCKNO", "GA Truck", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_DocType", "GA DocType", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("@GA_ROUTE_LD", "GA_Seq", "GA Sequence", SAPbobsCOM.BoFieldTypes.db_Numeric, 0)
        oGFun.CreateUserFields("ORDR", "GA_Seq", "GA Sequence", SAPbobsCOM.BoFieldTypes.db_Numeric, 0)
    End Sub

#End Region

#Region " ...RoutePlan()... "

    Sub ProdHeaderPlan()
        Try
            Me.ProdCloseAdmin_Header()


            If Not oGFun.UDOExists("GA_PROCL") Then
                Dim FindField As String(,) = New String(,) {{"Code", "Code"}}
                oGFun.RegisterUDO("GA_PROCL", "Production AutoClosure Admin", SAPbobsCOM.BoUDOObjType.boud_MasterData, FindField, "GA_PROCL_H")
                FindField = Nothing
            End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation Other Pending For Confirmation Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub ProdCloseAdmin_Header()

        oGFun.CreateTable("GA_PROCL_H", "GA Prod Admin Header", SAPbobsCOM.BoUTBTableType.bott_MasterData)
        oGFun.CreateUserFieldsComboBox("@GA_PROCL_H", "GA_Auto", "GA AutoClosure", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueYesORNo, "N")




    End Sub

    Sub ProdCLosureData()
        Try


            Dim Qry As String = ""
        Qry += "Select B.FldValue ,B.Descr   from CUFD A INNER JOIN UFD1 B On A.FieldID =B.FieldID and A.TableID =B.TableID"
        Qry += " WHERE A.TableID ='OITM' and A.AliasID ='GA_ItemType' and B.FldValue NOT  IN(Select Code FROM [@GA_PROCL_H])"
        Dim RecSt As SAPbobsCOM.Recordset = oGFun.DoQuery(Qry)
        If (RecSt.RecordCount > 0) Then

                For i As Integer = 1 To RecSt.RecordCount
                    Dim oGeneralservice As SAPbobsCOM.GeneralService
                    Dim oGeneralData As SAPbobsCOM.GeneralData

                    Dim oCompanyService As SAPbobsCOM.CompanyService
                    Try



                        oCompanyService = oCompany.GetCompanyService()
                        oGeneralservice = oCompanyService.GetGeneralService("GA_PROCL")
                        oGeneralData = oGeneralservice.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData)
                        oGeneralData.SetProperty("Code", RecSt.Fields.Item(0).Value.ToString())
                        oGeneralData.SetProperty("Name", RecSt.Fields.Item(1).Value.ToString())
                        oGeneralData.SetProperty("U_GA_Auto", "N")
                        oGeneralservice.Add(oGeneralData)
                        RecSt.MoveNext()
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompanyService)
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralservice)
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralData)
                    Catch ex As Exception
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompanyService)
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralservice)
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralData)
                    End Try
                Next

            End If


        Catch ex As Exception

        End Try


    End Sub


#End Region
    Sub LocationMappingHead()
        Try
            oGFun.CreateTable("GA_LOCM", "GA Location Mapping", SAPbobsCOM.BoUTBTableType.bott_NoObjectAutoIncrement)

            oGFun.CreateUserFields("@GA_LOCM", "GA_LName", "Location Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@GA_LOCM", "GA_SWhs", "Store Whse", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@GA_LOCM", "GA_PWhs", "Production Whse", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
            oGFun.CreateUserFields("@GA_LOCM", "GA_RWhs", "Rework Whse", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
    Sub UDF()
        oGFun.CreateUserFieldsComboBox("OWOR", "GA_Cell", "Cell", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueCell, "-")
        oGFun.CreateUserFieldsComboBox("OITM", "GA_Cell", "Cell", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueCell, "-")
        oGFun.CreateUserFieldsComboBox("OITM", "GA_ItemType", "ItemType", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueItemType)
        oGFun.CreateUserFieldsComboBox("ITT1", "GA_Packaging", "GA_Packaging", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueYesORNoBln, "-")
        oGFun.CreateUserFields("OWOR", "GA_BBOM", "Base BOM", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("OWOR", "GA_ADDITEM", "Base BOM", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFieldsComboBox("ORDR", "GA_ResRoute", "GA_ReserveRoute", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, SAPbobsCOM.BoFldSubTypes.st_None, "", ValidValueYesORNo, "N")

        oGFun.CreateUserFields("RDR1", "GA_MODEL", "ModelType", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("OWOR", "GA_MODEL", "ModelType", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)
        oGFun.CreateUserFields("OSRN", "GA_BWIP", "BARREL WIP", SAPbobsCOM.BoFieldTypes.db_Alpha, 30)
        oGFun.CreateUserFields("OWHS", "GA_SWHS", "Scrap Whse", SAPbobsCOM.BoFieldTypes.db_Alpha, 10)
        oGFun.CreateUserFields("OWHS", "GA_RWHS", "Rework Whse", SAPbobsCOM.BoFieldTypes.db_Alpha, 10)
        oGFun.CreateUserFields("OWHS", "GA_BINL", "Bin location", SAPbobsCOM.BoFieldTypes.db_Alpha, 50)
        oGFun.CreateUserFields("ORDR", "GA_ROUTENO", "Route No", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
        oGFun.CreateUserFields("ORDR", "GA_DRIVER", "Driver", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
        oGFun.CreateUserFields("ORDR", "GA_TRUCKNO", "Truck No", SAPbobsCOM.BoFieldTypes.db_Alpha, 100)
    End Sub


End Class


