﻿''' <summary>
''' GGlobally whatever variable do you want declare here 
''' We can use any class and module from here  
''' </summary>
''' <remarks></remarks>
Module GolabalVariables



#Region " ... Common For SAP ..."
    Public oCompany As SAPbobsCOM.Company
    Public oGfun As New GlobalFunctions
    'Public oDBFun As New DataBase_Proc_Functions
    Public oForm As SAPbouiCOM.Form
    Public AddOnName As String = "Production Customization Addon"
    Public ErrCode As Long
    Public ErrMsg As String = ""
    Public oCompanySrv As SAPbobsCOM.CompanyService


#End Region

#Region " ... Common For Forms ..."
    'Import

    'ItemCreation
    Public WIPQtyForm As String = "GA_WIP"
    Public ScrapForm As String = "GA_SCRP"

    Public WIPWhseForm As String = "GA_WHSE"
    Public WIPDetailsForm As String = "GA_WIPLST"
    Public ExtDetailsForm As String = "GA_EXTLST"
    'Production Order
    Public oProdOrder As New ProductionOrder
    Public ProdOrderTypeEx As String = "65211"


    Public oReceipt As New ReceiptProd
    Public ReceiptTypeEx As String = "65214"

    Public oGIssue As New GoodsIssue
    Public GIssueTypeEx As String = "720"

    'sales Order
    Public oSaleOrder As New SalesOrder
    Public SaleOrderTypeEx As String = "139"

    'RoutePlan
    Public RoutePlanFormID As String = "GA_ROUTEPL"
    Public RoutePlanXML As String = "RoutePlanning.xml"
    Public oRoutePlan As New RoutePlan

    Public RouteResFormID As String = "GA_ROUTERS"
    Public RouteResXML As String = "RouteRes.xml"
    Public oRouteRes As New RouteRes

    Public ProdPlanFormID As String = "GA_PRODPL"
    Public ProdPlanXML As String = "ProdPlanning.xml"
    Public oProdPlan As New ProdPlan

    'Auto CLosure
    Public AutoCloseFormID As String = "GA_PROCL"
    Public AutoCloseXML As String = "ProdAuto.xml"
    Public oAutoClose As New AutoClose




#End Region

#Region " ... Gentral Purpose ..."

    Public v_RetVal, v_ErrCode As Long
    Public v_ErrMsg As String = ""
    'Attachment Option
    Public ShowFolderBrowserThread As Threading.Thread
    Public BankFileName As String
    Public boolModelForm As Boolean = False
    Public boolModelFormID As String = ""
    Public ShouldNotErrorMsg As String = " Should Not be Left Empty"
    Public sQuery As String = ""
    Public boolTripStatusCanceled As Boolean = False

#End Region

End Module
