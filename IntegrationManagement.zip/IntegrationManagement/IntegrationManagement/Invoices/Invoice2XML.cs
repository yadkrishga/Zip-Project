﻿using Newtonsoft.Json;
using SAPbobsCOM;
using SAPbouiCOM;
using Shared;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Invoices
{
	internal class Invoice2XML
	{
		string filename;
		 public void  process(string docentry,string filepath,int counter,string ftpuser,string ftppssw)
		{
			SalesInvoices salesInvoices = new SalesInvoices();
			counter++;
			string strcnt = ("0000" + counter.ToString());
			strcnt = strcnt.Substring(counter.ToString().Length , 4);
			string TransRef = "";
			int RecCode = 1;
			TransmissionHeader th = new TransmissionHeader()
			{
				CustInvCounter = strcnt,
				TransmissionReference = TransRef,
				Version = "1.00",
				ReceiverCode = RecCode.ToString(),
				DatePrepared = DateTime.Today.ToString("yyyy-MM-dd"),
				TimePrepared = DateTime.Now.ToString("HH:mm"),
				SenderCode = ProgData.B1Company.CompanyName


			};
			salesInvoices.TransmissionHeader = th;
			salesInvoices.SalesInvoice = new SalesInvoice();
			
			salesInvoices.SalesInvoice = createSalesInvoice(docentry);
			string json = JsonConvert.SerializeObject(salesInvoices);
			salesInvoices = JsonConvert.DeserializeObject<SalesInvoices>(json);
			
			var doc = JsonConvert.DeserializeXmlNode(json, "SalesInvoices");
			filename = filename + ".XML";
			//filepath = @"https://gauri.sharepoint.com/customers/Groupe-Atlantic/Projects/Forms/AllItems.aspx?id=%2Fcustomers%2FGroupe%2DAtlantic%2FProjects%2FGledhill%20SAP%20Business%20one%2FInvoices&viewid=9b193a39%2D668a%2D42db%2Daac5%2D65a47af7be77";

			if (filepath.IndexOf(@"ftp:") > -1 || filepath.IndexOf(@"http:") > -1 || filepath.IndexOf(@"https:") > -1)
			{
					
				var task = Task.Run(async () => await UploadFile(filepath, doc.InnerXml, ftpuser, ftppssw));
			}
			else
			{
				filename = filepath + filename;
				doc.Save(filename);
			}
			string qry = $"UPDATE \"@G_Mng\" SET U_XmlCnt={counter}";
			qry += $" WHERE Code = '1'";
			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			rs.DoQuery(qry);
			qry = $"UPDATE OINV Set U_ExportXML='{filename}' where DocEntry = {docentry}";
			rs.DoQuery(qry);

		}
/*		private void UploadSharePoint()
		{
			string userName = "user@Tenant.onmicrosoft.com";
			string Password = "*******";
			var securePassword = new SecureString();
			foreach (char c in Password)
			{
				securePassword.AppendChar(c);
			}
			using (var ctx = new Microsoft.SharePoint.Client.ClientContext("https://tenant.sharepoint.com/"))
			{
				ctx.Credentials = new Microsoft.SharePoint.Client.Cli(userName, securePassword);
				Web web = ctx.Web;
				ctx.Load(web);
				ctx.ExecuteQuery();
				FileCreationInformation newFile = new FileCreationInformation();
				newFile.Content = System.IO.File.ReadAllBytes("D:\\document.pdf");
				newFile.Url = @"document.pdf";
				List byTitle = ctx.Web.Lists.GetByTitle("Documents");
				Folder folder = byTitle.RootFolder.Folders.GetByUrl("NewFolderFromCSOM");
				ctx.Load(folder);
				ctx.ExecuteQuery();
				Microsoft.SharePoint.Client.File uploadFile = folder.Files.Add(newFile);
				uploadFile.CheckIn("checkin", CheckinType.MajorCheckIn);
				ctx.Load(byTitle);
				ctx.Load(uploadFile);
				ctx.ExecuteQuery();
				Console.WriteLine("done");
			}
		}
*/
		private async Task UploadFile(string filepath,string xml,string ftpuser,string ftppassw)
		{
			//filename = filepath + filename;
			FtpWebRequest request = (FtpWebRequest)WebRequest.Create(filepath);
			request.Method = WebRequestMethods.Ftp.UploadFile;

			// This example assumes the FTP site uses anonymous logon.
			request.Credentials = new NetworkCredential(ftpuser, ftppassw);

			// Copy the contents of the file to the request stream.
			using (FileStream fileStream = File.Open(filename, FileMode.Open, FileAccess.Read))
			{
				using (Stream requestStream = request.GetRequestStream())
				{
					await fileStream.CopyToAsync(requestStream);
					using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
					{
						Logger.Log("Upload:"+response.StatusDescription);
					}
				}
			}
			//var request = WebRequest.Create(filename);
			//request.Method = WebRequestMethods.Ftp.UploadFile;
			//// This example assumes the FTP site uses anonymous logon.  
			//request.Credentials = new NetworkCredential(ftpuser, ftppassw); //"alicelal.bozatli@gauri.com", "Put90282");
			//request.Proxy = null;
			////request.KeepAlive = true;
			////request.UseBinary = true;
			//request.Method = WebRequestMethods.Ftp.UploadFile;

			//// Copy the contents of the file to the request stream.  
			////StreamReader sourceStream = new StreamReader(@ "D:\Sapmle applications\TotalAmount.txt");
			////byte[] fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
			////sourceStream.Close();
			//byte[] fileContents = Encoding.UTF8.GetBytes(xml);
		
			//request.ContentLength = fileContents.Length;
			//Stream requestStream = request.GetRequestStream();
			//requestStream.Write(fileContents, 0, fileContents.Length);
			//requestStream.Close();
			//FtpWebResponse response = (FtpWebResponse)request.GetResponse();
		}

		private  SalesInvoice  createSalesInvoice(string docentry)
		{
			int docEntry = Convert.ToInt32(docentry);
			SalesInvoice slsInv = new SalesInvoice();
			SAPbobsCOM.Documents SapInv = (SAPbobsCOM.Documents)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInvoices);
			try
			{
				if (SapInv.GetByKey(docEntry))
				{
					slsInv = GetHeader(SapInv, slsInv);
					SAPbobsCOM.Recordset orec = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

					string qry = $"select * from \"NNM1\" Where \"ObjectCode\"=13 AND  \"Series\"={SapInv.Series}";
					orec.DoQuery(qry);

					string fstr = "";
					string lstr = "";
					try
					{
						fstr = orec.Fields.Item("BeginStr").Value.ToString();
					}
					catch (Exception ex)
					{

					}
					try
					{
						lstr = orec.Fields.Item("EndStr").Value.ToString();
					}
					catch (Exception ex)
					{

					}
					filename = "00000" + SapInv.DocNum.ToString();
					filename = fstr + filename.Substring(SapInv.DocNum.ToString().Length, 5) + lstr;

				}
			} catch (Exception ex) {
				Logger.Log(ex);
					
					}
			return slsInv;
		}
		private SalesInvoice GetHeader(SAPbobsCOM.Documents SapInv, SalesInvoice slsInv)
		{
			SAPbobsCOM.Recordset orec = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

			string qry = "select * from ADM1";
			orec.DoQuery(qry);
			string CompanyAddress1 = orec.Fields.Item("Street").Value.ToString();
			string CompanyAddress2 = orec.Fields.Item("Block").Value.ToString();
			string CompanyAddress3 = orec.Fields.Item("City").Value.ToString();
			//string CompanyRegNumber = orec.Fields.Item("Street").Value.ToString();
			//string CompanyTaxRegNumber = orec.Fields.Item("Street").Value.ToString();
			//string CompanyTaxNo = orec.Fields.Item("Street").Value.ToString();

			qry = $"Select SlpName FROM OSLP WHERE SlpCode = '{SapInv.SalesPersonCode}'";
			orec.DoQuery(qry);
			string salesman = orec.Fields.Item(0).Value.ToString();
			qry = $"Select CurrName FROM OCRN WHERE CurrCode = '{SapInv.DocCurrency}'";
			orec.DoQuery(qry);
			string CurrName = orec.Fields.Item(0).Value.ToString();

			qry = $"SELECT DISTINCT T4.DocNum as INVDocNum,T2.DocNum Docnum,T2.DocDueDate DocDate,T0.DocNum OrdrNum,T0.DocDate OrdDate FROM ORDR T0 INNER JOIN RDR1 T1 ON T0.DocEntry = T1.DocEntry  INNER JOIN ODLN T2 ON T2.DocEntry = T1.TrgetEntry";
			qry += " INNER JOIN DLN1 T3 on T3.DocEntry = T2.Docentry INNER JOIN OINV T4 ON T4.DocEntry = T3.TrgetEntry INNER JOIN INV1 T5 ON T5.DocEntry = T4.DocEntry";
			qry += $" LEFT JOIN ORDN T6 ON T6.DocEntry = T5.TrgetEntry LEFT JOIN RDN1 T7 ON T7.DocEntry = T6.DocEntry WHERE T4.DocEntry = {SapInv.DocEntry}";

			string DeliveryNoteNumber = "";
				string DispatchDate = "";
			string OrderNum = "";
			string OrderDate = "";
			qry = $"SELECT DISTINCT T2.DocEntry,T2.DocNum Docnum, T2.DocDueDate DocDate FROM ODLN T2 INNER JOIN DLN1 T1 ON T2.DocEntry = T1.DocEntry WHERE T1.TrgetEntry = {SapInv.DocEntry}";
			orec.DoQuery(qry);
			
			if (orec.RecordCount > 0)
			{
				 DeliveryNoteNumber = orec.Fields.Item(1).Value.ToString();
				 DispatchDate = Convert.ToDateTime(orec.Fields.Item(2).Value).ToString("yyyy-MM-dd");
				OrderNum = DeliveryNoteNumber;
				OrderDate = DispatchDate;
			}
			qry = $"SELECT DISTINCT T0.DocEntry,T0.DocNum Docnum, T0.DocDueDate DocDate FROM ORDR T0 INNER JOIN RDR1 T1 ON T0.DocEntry = T1.DocEntry  WHERE T1.TrgetEntry = {SapInv.DocEntry}";
			orec.DoQuery(qry);
			if (orec.RecordCount > 0)
			{
				 OrderNum = orec.Fields.Item(1).Value.ToString();
				 OrderDate = Convert.ToDateTime(orec.Fields.Item(2).Value).ToString("yyyy-MM-dd");
			}
			if (String.IsNullOrEmpty(DeliveryNoteNumber))
				DeliveryNoteNumber = OrderNum;
			if (String.IsNullOrEmpty(DispatchDate))
				DispatchDate = OrderDate;
			if (String.IsNullOrEmpty(DeliveryNoteNumber))
			{
				DeliveryNoteNumber = "";
				OrderNum = SapInv.DocNum.ToString();
			}
			if (String.IsNullOrEmpty(DispatchDate))
			{
				 OrderDate = SapInv.DocDate.ToString("yyyy-MM-dd");
				DispatchDate = OrderDate;
			}
			AdminInfo company = ProgData.B1Company.GetCompanyService().GetAdminInfo();
			string[] adress = company.Address.Split('\n');

			slsInv.InvoiceHeader = new InvoiceHeader()
			{
				CompanyName = company.CompanyName,
				CompanyAddress1 = CompanyAddress1,
				CompanyAddress2 = CompanyAddress2,
				CompanyAddress3 = CompanyAddress3,
				CustomerPoNumber = SapInv.NumAtCard,
				CustomerPoDate = SapInv.DocDate.ToString("yyyy-MM-dd"),
				Customer = SapInv.CardCode,
				CustomerName = SapInv.CardName,
				InvoiceAddress1 = SapInv.AddressExtension.BillToStreet,
				InvoiceAddress2 = SapInv.AddressExtension.BillToStreetNo,
				InvoiceAddress3 = SapInv.AddressExtension.BillToBlock + " " + SapInv.AddressExtension.BillToState,
				InvoiceAddress4 = SapInv.AddressExtension.BillToCity,
				InvoiceAddress5 = SapInv.AddressExtension.BillToCountry,
				InvoicePostalCode = SapInv.AddressExtension.BillToZipCode,
				ShipAddress1 = SapInv.AddressExtension.ShipToStreet,
				ShipAddress2 = SapInv.AddressExtension.ShipToStreetNo,
				ShipAddress3 = SapInv.AddressExtension.ShipToBlock + " " + SapInv.AddressExtension.ShipToState,
				ShipAddress4 = SapInv.AddressExtension.ShipToCity,
				ShipAddress5 = SapInv.AddressExtension.ShipToCountry,
				ShipPostalCode = SapInv.AddressExtension.ShipToZipCode,
				SalesPersonName = salesman,
				Currency = SapInv.DocCurrency,
				CurrencyName = CurrName,
				CurrencyRate = String.Format(CultureInfo.InvariantCulture, "{0:N2}", SapInv.DocRate),

				DeliveryNoteNumber = DeliveryNoteNumber,
				DispatchDate = DispatchDate,
				SalesOrder = OrderNum,
				InvoiceDate = SapInv.DocDate.ToString("yyyy-MM-dd"),
				ShipDate = DispatchDate,
				InvoiceDueDate = SapInv.DocDueDate.ToString("yyyy-MM-dd"),
				OrderDate = OrderDate
			};

			slsInv.InvoiceTotal = new InvoiceTotal()
			{
				TotalNetAmount = SapInv.DocTotal.ToString(),
				TotalSalesTax = SapInv.VatSum.ToString(),
				TotalInvDiscAmount = SapInv.TotalDiscount.ToString(),
				TotalInvAmountExclTax = SapInv.BaseAmount.ToString(),
				TotalTermsDiscountAmount = "0.000",
				TotalForeignNetAmount = SapInv.DocTotalFc.ToString(),
				TotalForeignSalesTax = SapInv.VatSumFc.ToString(),
				TotalForeignInvDiscAmount = SapInv.TotalDiscountFC.ToString(),
				TotalForeignInvAmountExclTax = SapInv.BaseAmountFC.ToString(),
				TotalForeignTermsDiscountAmount = "0.00",
				TotalMass = "0.00",
				TotalVolume = "0.00",
				TotalQuantity = "0.00"
			};
			slsInv =  GetLines(SapInv, slsInv);
			return slsInv;
		}
		private SalesInvoice GetLines(SAPbobsCOM.Documents SapInv, SalesInvoice slsInv)
		{ 
			int linenum = 0;
			slsInv.InvoiceDetail = new List<InvoiceDetail>();
			for (int ix = 0; ix < SapInv.Lines.Count; ix++)
			{
				linenum++;
				SapInv.Lines.SetCurrentLine(ix);
				MerchandiseLine line = new MerchandiseLine()
				{
					DetailLineNumber = linenum.ToString(),
					StockCode = SapInv.Lines.ItemCode,
					StockDescription = SapInv.Lines.ItemDescription,
					StockLongDescription = SapInv.Lines.ItemDetails,
					ShipQty = SapInv.Lines.Quantity.ToString(),
					StockingUom = SapInv.Lines.UoMCode,
					OrderUom = SapInv.Lines.UoMCode,
					OrderQty = SapInv.Lines.Quantity.ToString(),
					BackorderQty = "0.00",
					StockedQtyToShip = SapInv.Lines.Quantity.ToString(),
					UnitPrice = SapInv.Lines.UnitPrice.ToString(),
					UnitPriceExDisc = SapInv.Lines.Price.ToString(),
					OrderUnitPrice = SapInv.Lines.UnitPrice.ToString(),
					OrderUnitPriceIncDisc = SapInv.Lines.Price.ToString(),
					PriceUom = SapInv.Lines.UoMCode,
					CustomerRetailPrice = "0.00",
					SalesTaxPercent = SapInv.Lines.TaxPercentagePerRow.ToString(),
					SalesTaxCode = SapInv.Lines.TaxCode,
					SalesTaxValue = SapInv.Lines.NetTaxAmount.ToString(),
					LineDiscountValue = ((SapInv.Lines.UnitPrice * SapInv.Lines.Quantity) - (SapInv.Lines.Price * SapInv.Lines.Quantity)).ToString(),
					NetValueIncTax = (SapInv.Lines.LineTotal + SapInv.Lines.NetTaxAmount).ToString(),
					NetValueExcTax = SapInv.Lines.LineTotal.ToString(),
					ForeignSalesTaxValue = "0.00",
					ForeignNetValueIncTax = "0.00",
					ForeignLineDiscountValue = "0.00",
					SoPriceUomFact = SapInv.Lines.UnitsOfMeasurment.ToString(),
					SoPriceUomMulDiv = "M"

				};
				CommentLine commline = new CommentLine();

				InvoiceDetail Invdet = new InvoiceDetail();
				Invdet.MerchandiseLine = line;
				Invdet.CommentLine = commline;
				slsInv.InvoiceDetail.Add(Invdet);


			}
			
			return slsInv;
			

		}

	}
}
