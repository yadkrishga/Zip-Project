﻿Public Class RoutePlan
    Dim frmRoutePlan As SAPbouiCOM.Form
    Dim oMatrix, oMatrix2 As SAPbouiCOM.Matrix

    Sub LoadRoutePlanning()
        oGfun.LoadXML(frmRoutePlan, RoutePlanFormID, RoutePlanXML)
        frmRoutePlan = oApplication.Forms.Item(RoutePlanFormID)
        InitForm()

    End Sub
#Region "InitForm"
    Sub InitForm()
        Try
            frmRoutePlan.Freeze(True)


            oGfun.LoadDocumentDate(frmRoutePlan.Items.Item("edt_Date").Specific)

            oMatrix = frmRoutePlan.Items.Item("mtxRoute").Specific
            oMatrix2 = frmRoutePlan.Items.Item("mtxDriver").Specific




            frmRoutePlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("InitForm Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRoutePlan.Freeze(False)
        Finally
        End Try
    End Sub
#End Region
    Sub Filldata()
        Try
            frmRoutePlan.Freeze(True)
            Dim ComboQry2 As String = ""
            Dim oColumns As SAPbouiCOM.Columns
            Dim oColumn As SAPbouiCOM.Column
            Dim oUserDataSource As SAPbouiCOM.UserDataSource
            If (oMatrix.RowCount > 0) Then
                oMatrix.Clear()
            End If
            If (oMatrix.Columns.Count > 1) Then
                Dim Countm1c As Integer = oMatrix.Columns.Count
                For m1c As Integer = Countm1c To 2 Step -1
                    oMatrix.Columns.Remove(m1c - 1)
                Next
            End If
            Dim Count As Integer = 0
            If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                Count = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
            End If
            For i As Integer = 1 To Count
                Dim ColName As String = ""
                Dim ColName2 As String = ""
                Dim ColNameD2 As String = ""
                ColName = "R" + i.ToString()
                ColName2 = "CR" + i.ToString()
                ColNameD2 = "Change Route" + i.ToString()

                Dim ColNameD3 As String = "DR" + i.ToString()
                Dim ColName3 As String = "DocNum R" + i.ToString()
                Dim ColNameD4 As String = "PR" + i.ToString()
                Dim ColName4 As String = "PostCode R" + i.ToString()
                Dim ColNameD5 As String = "SE" + i.ToString()
                Dim ColName5 As String = "Sequence R" + i.ToString()
                Dim ColNameD6 As String = "DO" + i.ToString()
                Dim ColName6 As String = "DocType R" + i.ToString()
                If (i = 1) Then
                    ComboQry2 = "Select '-'[RouteC],'-' as [RouteN] Union all "
                End If

                If (i < Count) Then
                    ComboQry2 += "Select '" & ColName & "' as [RouteC],'" & ColName & "' as [RouteN] Union all "
                Else
                    ComboQry2 += "Select '" & ColName & "' as [RouteC],'" & ColName & "' as [RouteN]"
                End If

                oColumns = oMatrix.Columns
                oColumn = oColumns.Add(ColName, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColName
                oColumn.Width = 30
                oColumn.Editable = False
                oColumn.Visible = False
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColName, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try
                oColumn = oColumns.Item(ColName)
                oColumn.DataBind.SetBound(True, "", ColName)
                ''DocNum
                oColumns = oMatrix.Columns
                oColumn = oColumns.Add(ColNameD3, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColName3
                oColumn.Width = 40
                oColumn.Editable = False
                oColumn.Visible = True
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColNameD3, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try
                oColumn = oColumns.Item(ColNameD3)
                oColumn.DataBind.SetBound(True, "", ColNameD3)

                ''Post
                oColumns = oMatrix.Columns
                oColumn = oColumns.Add(ColNameD4, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColName4
                oColumn.Width = 40
                oColumn.Editable = False
                oColumn.Visible = True
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColNameD4, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try
                oColumn = oColumns.Item(ColNameD4)
                oColumn.DataBind.SetBound(True, "", ColNameD4)

                ''Sequence
                oColumns = oMatrix.Columns
                oColumn = oColumns.Add(ColNameD5, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColName5
                oColumn.Width = 40
                oColumn.Editable = True
                oColumn.Visible = True
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColNameD5, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 4)
                Catch ex As Exception

                End Try
                oColumn = oColumns.Item(ColNameD5)
                oColumn.DataBind.SetBound(True, "", ColNameD5)
                ''DocType
                oColumns = oMatrix.Columns
                oColumn = oColumns.Add(ColNameD6, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColName6
                oColumn.Width = 40
                oColumn.Editable = False
                oColumn.Visible = True
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColNameD6, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try
                oColumn = oColumns.Item(ColNameD6)
                oColumn.DataBind.SetBound(True, "", ColNameD6)

                oColumns = oMatrix.Columns
                oColumn = oColumns.Add(ColName2, SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX)
                oColumn.TitleObject.Caption = ColNameD2
                oColumn.Width = 30
                oColumn.Editable = True
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColName2, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try
                oColumn = oColumns.Item(ColName2)
                oColumn.DataBind.SetBound(True, "", ColName2)


            Next
            Dim QryRList As String = ""
            QryRList += "  Select * from("
            QryRList += "Select  x.DocEntry, x.[Ranks], x.U_GA_DocEntry, x.U_GA_RouteNo   from( "
            QryRList += "Select  A.DocEntry,CAST(B.U_GA_DocEntry as NVARCHAR(20))+';'+CAST(B.U_GA_DocNum as NVARCHAR(20))+';'+CAST(B.U_GA_ZipCode as NVARCHAR(20))+';'+CAST(B.U_GA_Seq as NVARCHAR(20))+';'+CASE WHEN CAST(B.U_GA_DocType as NVARCHAR(20))='17' THEN 'Sales Order' ELSE 'Return Request' END as [U_GA_DocEntry],B.U_GA_RouteNo,rank() over(partition by U_GA_RouteNo    order by U_GA_RouteNo,U_GA_Seq,U_GA_DocType,U_GA_DocEntry  )[Ranks] "
            QryRList += " from [@GA_ROUTE_HD] a INNER JOIN [@GA_ROUTE_LD] B On A.[DocEntry] =B.[DocEntry]"

            QryRList += " where a.[DocEntry] ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "')x)d "
            QryRList += " pivot(MAX(U_GA_DocEntry) For U_GA_RouteNo In (" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_RL").ValueEx & "))piv "
            Dim rsResult As SAPbobsCOM.Recordset = oGfun.DoQuery(QryRList)
            oMatrix.Clear()

            For r As Integer = 1 To rsResult.RecordCount

                oMatrix.AddRow()
                oMatrix.GetLineData(r)
                Dim CountR As Integer = 0
                If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                    CountR = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
                End If
                Dim ComboQry As String = ""
                For r1 As Integer = 1 To CountR
                    Dim DS As String = "R" + r1.ToString()
                    Dim DS2 As String = "DR" + r1.ToString()
                    Dim DS3 As String = "PR" + r1.ToString()
                    Dim DS4 As String = "SE" + r1.ToString()
                    Dim DS6 As String = "DO" + r1.ToString()
                    Dim CN As String = "CR" + r1.ToString()
                    If (rsResult.Fields.Item(DS).Value.ToString() <> "") Then
                        Dim Arr As String() = Split(rsResult.Fields.Item(DS).Value.ToString(), ";")
                        frmRoutePlan.DataSources.UserDataSources.Item(DS).ValueEx = Arr(0)
                        frmRoutePlan.DataSources.UserDataSources.Item(DS2).ValueEx = Arr(1)
                        frmRoutePlan.DataSources.UserDataSources.Item(DS3).ValueEx = Arr(2)
                        frmRoutePlan.DataSources.UserDataSources.Item(DS4).ValueEx = Arr(3)
                        frmRoutePlan.DataSources.UserDataSources.Item(DS6).ValueEx = Arr(4)
                    Else
                        frmRoutePlan.DataSources.UserDataSources.Item(DS).ValueEx = ""
                        frmRoutePlan.DataSources.UserDataSources.Item(DS2).ValueEx = ""
                        frmRoutePlan.DataSources.UserDataSources.Item(DS3).ValueEx = ""
                        frmRoutePlan.DataSources.UserDataSources.Item(DS4).ValueEx = ""
                        frmRoutePlan.DataSources.UserDataSources.Item(DS6).ValueEx = ""
                    End If
                    Dim oComboBox As SAPbouiCOM.ComboBox = oMatrix.Columns.Item(CN).Cells.Item(r).Specific
                    oGfun.SetComboBoxValueRefresh(oComboBox, ComboQry2)
                    oComboBox.Select(" - ", SAPbouiCOM.BoSearchKey.psk_ByValue)
                    frmRoutePlan.DataSources.UserDataSources.Item(CN).ValueEx = " - "
                Next

                oMatrix.SetLineData(r)
                rsResult.MoveNext()
            Next
            oMatrix.AutoResizeColumns()





            frmRoutePlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("Fill Data Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRoutePlan.Freeze(False)
        Finally
        End Try
    End Sub

    Sub SaveDataRoute()
        Try
            frmRoutePlan.Freeze(True)
            Dim ComboQry2 As String = ""
            Dim oColumns As SAPbouiCOM.Columns
            Dim oColumn As SAPbouiCOM.Column
            Dim oUserDataSource As SAPbouiCOM.UserDataSource

            If (oMatrix.RowCount > 0) Then

                For i As Integer = 1 To oMatrix.RowCount
                    Dim Count As Integer = 0
                    If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                        Count = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
                    End If
                    oMatrix.GetLineData(i)
                    oMatrix2.GetLineData(1)
                    For j As Integer = 1 To Count
                        Dim ColName As String = ""
                        Dim ColName2 As String = ""
                        Dim ColNameD2 As String = ""
                        Dim Driver As String = ""
                        Dim Truck As String = ""
                        Dim ColName5 As String = ""
                        Dim ColName6 As String = ""
                        ColName = "R" + j.ToString()
                        ColName2 = "CR" + j.ToString()
                        ColName5 = "SE" + j.ToString()
                        ColName6 = "DO" + j.ToString()
                        Dim RouteNo As String = ""
                        Dim x As String = ""
                        If (frmRoutePlan.DataSources.UserDataSources.Item(ColName2).ValueEx <> "" And frmRoutePlan.DataSources.UserDataSources.Item(ColName2).ValueEx <> "-") Then
                            RouteNo = frmRoutePlan.DataSources.UserDataSources.Item(ColName2).ValueEx
                            x = frmRoutePlan.DataSources.UserDataSources.Item(ColName2).ValueEx.ToString().Replace("R", "")
                        Else
                            RouteNo = "R" + j.ToString()
                            x = j.ToString()
                        End If
                        Dim DocType As String = ""
                        If (frmRoutePlan.DataSources.UserDataSources.Item(ColName6).ValueEx.Trim = "Sales Order") Then
                            DocType = "17"
                        ElseIf (frmRoutePlan.DataSources.UserDataSources.Item(ColName6).ValueEx.Trim = "Return Request") Then
                            DocType = "234000031"

                        End If
                        Driver = "D" + x.ToString()
                        Truck = "T" + x.ToString()
                        oGfun.DoQuery("Update [@GA_ROUTE_LD] set [U_GA_Seq]='" & frmRoutePlan.DataSources.UserDataSources.Item(ColName5).ValueEx & "', [U_GA_DRIVER]='" & frmRoutePlan.DataSources.UserDataSources.Item(Driver).ValueEx & "',[U_GA_TRUCKNO]='" & frmRoutePlan.DataSources.UserDataSources.Item(Truck).ValueEx & "', [U_GA_RouteNo]='" & RouteNo & "' where [U_GA_DocEntry]='" & frmRoutePlan.DataSources.UserDataSources.Item(ColName).ValueEx & "' and [U_GA_DocType]='" & DocType & "' and [DocEntry]='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")


                    Next
                Next
                oGfun.DoQuery("UPDATE B SET B.U_GA_Seq=A.U_GA_Seq,B.U_GA_RouteNo=A.U_GA_RouteNo ,B.[U_GA_DRIVER]=A.[U_GA_DRIVER],B.[U_GA_TRUCKNO]=A.[U_GA_TRUCKNO] FROM [@GA_ROUTE_LD] A INNER JOIN [ORDR] B On A.U_GA_DocEntry=B.DocEntry and A.U_GA_DocType=B.ObjType WHERE  a.DocEntry ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")
                oGfun.DoQuery("UPDATE B SET B.U_GA_Seq=A.U_GA_Seq,B.U_GA_RouteNo=A.U_GA_RouteNo ,B.[U_GA_DRIVER]=A.[U_GA_DRIVER],B.[U_GA_TRUCKNO]=A.[U_GA_TRUCKNO] FROM [@GA_ROUTE_LD] A INNER JOIN [ORRR] B On A.U_GA_DocEntry=B.DocEntry and A.U_GA_DocType=B.ObjType WHERE  a.DocEntry ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")

            End If

            frmRoutePlan.Items.Item("btn_Fill").Click(SAPbouiCOM.BoCellClickType.ct_Regular)






            frmRoutePlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("Save Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRoutePlan.Freeze(False)
        Finally
        End Try
    End Sub


    Sub SaveDataDriver()
        Try
            frmRoutePlan.Freeze(True)
            Dim ComboQry2 As String = ""
            Dim oColumns As SAPbouiCOM.Columns
            Dim oColumn As SAPbouiCOM.Column
            Dim oUserDataSource As SAPbouiCOM.UserDataSource

            If (oMatrix2.RowCount > 0) Then

                For i As Integer = 1 To oMatrix2.RowCount
                    Dim Count As Integer = 0
                    If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                        Count = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
                    End If
                    oMatrix2.GetLineData(i)
                    For j As Integer = 1 To Count
                        Dim ColName As String = ""
                        Dim ColName2 As String = ""
                        Dim RouteId As String = ""
                        ColName = "D" + j.ToString()
                        ColName2 = "T" + j.ToString()
                        RouteId = "R" + j.ToString()

                        oGfun.DoQuery("Update [@GA_ROUTE_LD] set [U_GA_TRUCKNO]='" & frmRoutePlan.DataSources.UserDataSources.Item(ColName2).ValueEx & "' where [U_GA_RouteNo]='" & RouteId & "' and [DocEntry]='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")



                        oGfun.DoQuery("Update [@GA_ROUTE_LD] set [U_GA_DRIVER]='" & frmRoutePlan.DataSources.UserDataSources.Item(ColName).ValueEx & "' where [U_GA_RouteNo]='" & RouteId & "' and [DocEntry]='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")


                    Next
                Next
                oGfun.DoQuery("UPDATE B SET B.U_GA_DRIVER=A.U_GA_DRIVER,B.U_GA_TRUCKNO=A.U_GA_TRUCKNO FROM [@GA_ROUTE_LD] A INNER JOIN [ORDR] B On A.U_GA_DocEntry=B.DocEntry and A.U_GA_DocType=B.ObjType WHERE   a.DocEntry ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")
                oGfun.DoQuery("UPDATE B SET B.U_GA_DRIVER=A.U_GA_DRIVER,B.U_GA_TRUCKNO=A.U_GA_TRUCKNO FROM [@GA_ROUTE_LD] A INNER JOIN [ORRR] B On A.U_GA_DocEntry=B.DocEntry and A.U_GA_DocType=B.ObjType WHERE   a.DocEntry ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "'")

            End If

            frmRoutePlan.Items.Item("btn_Fill").Click(SAPbouiCOM.BoCellClickType.ct_Regular)






            frmRoutePlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("Save Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRoutePlan.Freeze(False)
        Finally
        End Try
    End Sub


    Sub Filldata2()
        Try
            frmRoutePlan.Freeze(True)
            Dim ComboQry2 As String = ""
            Dim oColumns As SAPbouiCOM.Columns
            Dim oColumn As SAPbouiCOM.Column
            Dim oUserDataSource As SAPbouiCOM.UserDataSource
            If (oMatrix2.RowCount > 0) Then
                oMatrix2.Clear()
            End If
            If (oMatrix2.Columns.Count > 1) Then
                Dim Countm1c As Integer = oMatrix2.Columns.Count
                For m1c As Integer = Countm1c To 2 Step -1
                    oMatrix2.Columns.Remove(m1c - 1)
                Next
            End If
            Dim Count As Integer = 0
            If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                Count = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
            End If
            For i As Integer = 1 To Count
                Dim ColName As String = ""
                Dim ColName2 As String = ""
                Dim ColNameD2 As String = ""
                Dim ColNameD1 As String = ""
                ColName = "D" + i.ToString()
                ColName2 = "T" + i.ToString()
                ColNameD1 = "Driver Route" + i.ToString()
                ColNameD2 = "Truck Route" + i.ToString()
                If (i = 1) Then
                    ComboQry2 = "Select '-'[RouteC],'-' as [RouteN] Union all "
                End If

                If (i < Count) Then
                    ComboQry2 += "Select '" & ColName & "' as [RouteC],'" & ColName & "' as [RouteN] Union all "
                Else
                    ComboQry2 += "Select '" & ColName & "' as [RouteC],'" & ColName & "' as [RouteN]"
                End If
                Dim oCFLs As SAPbouiCOM.ChooseFromListCollection
                Dim oCons As SAPbouiCOM.Conditions
                Dim oCon As SAPbouiCOM.Condition

                oCFLs = oForm.ChooseFromLists

                Dim oCFL As SAPbouiCOM.ChooseFromList
                Dim oCFLCreationParams As SAPbouiCOM.ChooseFromListCreationParams
                oCFLCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)

                ' Adding 2 CFL, one for the button and one for the edit text.
                oCFLCreationParams.MultiSelection = False
                oCFLCreationParams.ObjectType = "PMX_DRIV"
                oCFLCreationParams.UniqueID = ColName
                Try
                    oCFL = oCFLs.Add(oCFLCreationParams)
                Catch ex As Exception

                End Try



                Dim oCFL2 As SAPbouiCOM.ChooseFromList
                Dim oCFLCreationParams2 As SAPbouiCOM.ChooseFromListCreationParams
                oCFLCreationParams2 = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)

                ' Adding 2 CFL, one for the button and one for the edit text.
                oCFLCreationParams2.MultiSelection = False
                oCFLCreationParams2.ObjectType = "PMX_LIPL"
                oCFLCreationParams2.UniqueID = ColName2
                Try
                    oCFL2 = oCFLs.Add(oCFLCreationParams2)
                Catch ex As Exception

                End Try


                oColumns = oMatrix2.Columns
                oColumn = oColumns.Add(ColName, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColNameD1
                oColumn.Width = 50
                oColumn.Editable = True

                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColName, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try

                oColumn = oColumns.Item(ColName)
                oColumn.DataBind.SetBound(True, "", ColName)
                oColumn.ChooseFromListUID = ColName
                oColumn.ChooseFromListAlias = "Name"

                oColumns = oMatrix2.Columns
                oColumn = oColumns.Add(ColName2, SAPbouiCOM.BoFormItemTypes.it_EDIT)
                oColumn.TitleObject.Caption = ColNameD2
                oColumn.Width = 50
                oColumn.Editable = True
                Try
                    oUserDataSource = oForm.DataSources.UserDataSources.Add(ColName2, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50)
                Catch ex As Exception

                End Try

                oColumn = oColumns.Item(ColName2)
                oColumn.DataBind.SetBound(True, "", ColName2)
                oColumn.ChooseFromListUID = ColName2
                oColumn.ChooseFromListAlias = "Name"

            Next
            Dim QryRList As String = ""
            QryRList += "  Select * from("
            QryRList += "Select  x.DocEntry, x.[Ranks], x.U_GA_DRIVER, x.U_GA_RouteNo   from( "
            QryRList += "Select  A.DocEntry,B.U_GA_DRIVER,B.U_GA_RouteNo,rank() over(partition by U_GA_RouteNo order by U_GA_DRIVER )[Ranks] "
            QryRList += " from [@GA_ROUTE_HD] a INNER JOIN [@GA_ROUTE_LD] B On A.[DocEntry] =B.[DocEntry]"

            QryRList += " where a.[DocEntry] ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "')x)d "
            QryRList += " pivot(MAX(U_GA_DRIVER) For U_GA_RouteNo In (" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_RL").ValueEx & "))piv "

            Dim QryRList2 As String = ""
            QryRList2 += "  Select * from("
            QryRList2 += "Select  x.DocEntry, x.[Ranks], x.U_GA_TRUCKNO, x.U_GA_RouteNo   from( "
            QryRList2 += "Select  A.DocEntry,B.U_GA_TRUCKNO,B.U_GA_RouteNo,rank() over(partition by U_GA_RouteNo order by U_GA_TRUCKNO )[Ranks] "
            QryRList2 += " from [@GA_ROUTE_HD] a INNER JOIN [@GA_ROUTE_LD] B On A.[DocEntry] =B.[DocEntry]"

            QryRList2 += " where a.[DocEntry] ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx & "')x)d "
            QryRList2 += " pivot(MAX(U_GA_TRUCKNO) For U_GA_RouteNo In (" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_RL").ValueEx & "))piv "

            Dim rsResult As SAPbobsCOM.Recordset = oGfun.DoQuery(QryRList)
            Dim rsResult2 As SAPbobsCOM.Recordset = oGfun.DoQuery(QryRList2)
            oMatrix2.Clear()
            For r As Integer = 1 To rsResult.RecordCount

                oMatrix2.AddRow()
                oMatrix2.GetLineData(r)
                Dim CountR As Integer = 0
                If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                    CountR = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
                End If
                Dim ComboQry As String = ""
                For r1 As Integer = 1 To CountR
                    Dim DS As String = "R" + r1.ToString()
                    Dim DSN As String = "D" + r1.ToString()
                    Dim DSN2 As String = "T" + r1.ToString()
                    frmRoutePlan.DataSources.UserDataSources.Item(DSN).ValueEx = rsResult.Fields.Item(DS).Value.ToString()
                    frmRoutePlan.DataSources.UserDataSources.Item(DSN2).ValueEx = rsResult2.Fields.Item(DS).Value.ToString()
                Next

                oMatrix2.SetLineData(r)
                rsResult.MoveNext()
                rsResult2.MoveNext()
            Next
            oMatrix2.AutoResizeColumns()





            frmRoutePlan.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("Fill Data Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRoutePlan.Freeze(False)
        Finally
        End Try
    End Sub
    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmRoutePlan = oApplication.Forms.Item(FormUID)

                '   oForm = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = RoutePlanFormID Then
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_FORM_RESIZE
                        Try
                            Dim Matrix As SAPbouiCOM.Matrix
                            Dim Item As SAPbouiCOM.Item = frmRoutePlan.Items.Item("mtxRoute")
                            Item.Height = 210
                            Item.Width = frmRoutePlan.Width - 30
                            Matrix = frmRoutePlan.Items.Item("mtxRoute").Specific
                            Matrix.AutoResizeColumns()
                            Item = frmRoutePlan.Items.Item("mtxDriver")
                            Item.Height = 80
                            Item.Width = frmRoutePlan.Width - 30
                            Matrix = frmRoutePlan.Items.Item("mtxDriver").Specific
                            Matrix.AutoResizeColumns()
                            Item = frmRoutePlan.Items.Item("btn_Save1")
                            Item.Top = frmRoutePlan.Height - 70
                            Item = frmRoutePlan.Items.Item("btn_Save2")
                            Item.Top = frmRoutePlan.Height - 70
                            Item = frmRoutePlan.Items.Item("2")
                            Item.Top = frmRoutePlan.Height - 70
                        Catch ex As Exception

                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                        Try
                            If (pVal.ItemUID = "mtxDriver") Then
                                Dim oCFLEvento As SAPbouiCOM.IChooseFromListEvent
                                oCFLEvento = pVal
                                Dim sCFL_ID As String
                                sCFL_ID = oCFLEvento.ChooseFromListUID

                                Dim oCFL As SAPbouiCOM.ChooseFromList
                                oCFL = frmRoutePlan.ChooseFromLists.Item(sCFL_ID)
                                If (oCFLEvento.BeforeAction = True) Then
                                    Dim Count As Integer = 0
                                    If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                                        Count = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
                                    End If
                                    If (sCFL_ID.StartsWith("D")) Then


                                        oMatrix2.GetLineData(1)
                                        Dim DrivList As String = ""
                                        For j As Integer = 1 To Count
                                            Dim CFLID As String = "D" + j.ToString()
                                            If (CFLID <> sCFL_ID And frmRoutePlan.DataSources.UserDataSources.Item(CFLID).ValueEx <> "") Then


                                                If (j < Count) Then
                                                    DrivList += "'" + frmRoutePlan.DataSources.UserDataSources.Item(CFLID).ValueEx + "',"
                                                Else
                                                    DrivList += "'" + frmRoutePlan.DataSources.UserDataSources.Item(CFLID).ValueEx + "',"
                                                End If
                                            End If
                                        Next
                                        If (DrivList.Length > 0) Then
                                            DrivList = DrivList.Substring(0, DrivList.Length - 1)
                                        End If
                                        Dim queryList As String = "Select Name from [@PMX_DRIV] WHERE Name Not IN(" & DrivList & ")"
                                        If (DrivList <> "") Then
                                            oGfun.ChooseFromListFilteration(frmRoutePlan, sCFL_ID, "Name", queryList)
                                        End If
                                    Else

                                        oMatrix2.GetLineData(1)
                                        Dim DrivList As String = ""
                                        For j As Integer = 1 To Count
                                            Dim CFLID As String = "T" + j.ToString()
                                            If (CFLID <> sCFL_ID And frmRoutePlan.DataSources.UserDataSources.Item(CFLID).ValueEx <> "") Then


                                                If (j < Count) Then
                                                    DrivList += "'" + frmRoutePlan.DataSources.UserDataSources.Item(CFLID).ValueEx + "',"
                                                Else
                                                    DrivList += "'" + frmRoutePlan.DataSources.UserDataSources.Item(CFLID).ValueEx + "',"
                                                End If
                                            End If
                                        Next
                                        If (DrivList.Length > 0) Then
                                            DrivList = DrivList.Substring(0, DrivList.Length - 1)
                                        End If
                                        Dim queryList As String = "Select Name from [@PMX_LIPL] WHERE Name Not IN(" & DrivList & ")"
                                        If (DrivList <> "") Then
                                            oGfun.ChooseFromListFilteration(frmRoutePlan, sCFL_ID, "Name", queryList)
                                        End If
                                    End If
                                End If
                                If oCFLEvento.BeforeAction = False And oCFLEvento.SelectedObjects IsNot Nothing Then
                                    Dim oDataTable As SAPbouiCOM.DataTable
                                    oDataTable = oCFLEvento.SelectedObjects
                                    Dim val As String
                                    Try
                                        val = oDataTable.GetValue("Name", 0)
                                    Catch ex As Exception

                                    End Try
                                    oMatrix2.GetLineData(1)
                                    frmRoutePlan.DataSources.UserDataSources.Item(sCFL_ID).ValueEx = val
                                    oMatrix2.SetLineData(1)
                                End If
                            End If
                            If (pVal.ItemUID = "edt_HCode") Then
                                Dim oCFLEvento As SAPbouiCOM.IChooseFromListEvent
                                oCFLEvento = pVal
                                Dim sCFL_ID As String
                                sCFL_ID = oCFLEvento.ChooseFromListUID

                                Dim oCFL As SAPbouiCOM.ChooseFromList
                                oCFL = frmRoutePlan.ChooseFromLists.Item(sCFL_ID)
                                If oCFLEvento.BeforeAction = False And oCFLEvento.SelectedObjects IsNot Nothing Then
                                    Dim oDataTable As SAPbouiCOM.DataTable
                                    oDataTable = oCFLEvento.SelectedObjects
                                    Dim val As String = ""
                                    Dim val2 As String = ""
                                    Try
                                        val = oDataTable.GetValue("WhsCode", 0)
                                        val2 = oDataTable.GetValue("ZipCode", 0)
                                    Catch ex As Exception

                                    End Try

                                    frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_PC").ValueEx = val
                                    frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_PC1").ValueEx = val2
                                End If

                            End If

                            If (pVal.ItemUID = "edt_FName") Then
                                Dim oCFLEvento As SAPbouiCOM.IChooseFromListEvent
                                oCFLEvento = pVal
                                Dim sCFL_ID As String
                                sCFL_ID = oCFLEvento.ChooseFromListUID

                                Dim oCFL As SAPbouiCOM.ChooseFromList
                                oCFL = frmRoutePlan.ChooseFromLists.Item(sCFL_ID)
                                If oCFLEvento.BeforeAction = False And oCFLEvento.SelectedObjects IsNot Nothing Then
                                    Dim oDataTable As SAPbouiCOM.DataTable
                                    oDataTable = oCFLEvento.SelectedObjects
                                    Dim val As String
                                    Try
                                        val = oDataTable.GetValue("U_GA_FileName", 0)
                                    Catch ex As Exception

                                    End Try

                                    frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_FN").ValueEx = val
                                    frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DE").ValueEx = oDataTable.GetValue("DocEntry", 0)
                                    frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx = oDataTable.GetValue("U_GA_TRouteNo", 0)
                                    Dim Count As Integer = 0
                                    If (frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx <> "") Then
                                        Count = frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_TR").ValueEx
                                    End If
                                    Dim RList As String = ""
                                    Dim DList As String = ""
                                    Dim TList As String = ""
                                    For i As Integer = 1 To Count
                                        If i <> Count Then
                                            RList += "R" + i.ToString() + ","
                                        Else
                                            RList += "R" + i.ToString()
                                        End If

                                    Next
                                    frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_RL").ValueEx = RList
                                End If

                            End If
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Choose from List Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID
                                Case "edt_HCode"
                                    Dim Dt As DateTime = DateTime.ParseExact(frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DT").ValueEx, "yyyyMMdd", Nothing)

                                    Dim StrQry As String = "Select WhsCode FROM [OWHS] WHERE CONVERT(VARCHAR(20),ZipCode)<>''"
                                    oGfun.ChooseFromListFilteration(frmRoutePlan, "CFL_RP1", "WhsCode", StrQry)
                                Case "edt_FName"
                                    Dim Dt As DateTime = DateTime.ParseExact(frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_DT").ValueEx, "yyyyMMdd", Nothing)

                                    Dim StrQry As String = "Select U_GA_FileName FROM [@GA_ROUTE_HD] WHERE CONVERT(VARCHAR(20),U_GA_Date2,112)='" & Dt.ToString("yyyyMMdd") & "' and UPPER(Replace(U_GA_HHubCode,' ','')) ='" & frmRoutePlan.DataSources.UserDataSources.Item("GA_UD_PC1").ValueEx.Replace(" ", "").ToUpper() & "'"
                                    oGfun.ChooseFromListFilteration(frmRoutePlan, "CFL_RP2", "U_GA_FileName", StrQry)
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Got focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID

                            End Select

                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Lost Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "btn_Fill"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Filling Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.Filldata()
                                        Me.Filldata2()
                                        oApplication.StatusBar.SetText("Operation Completed", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                                Case "btn_Save1"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Updating Route Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.SaveDataRoute()
                                        oApplication.StatusBar.SetText("Operation Completed", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                                Case "btn_Save2"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Updating Driver and Truck Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.SaveDataDriver()
                                        oApplication.StatusBar.SetText("Operation Completed", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try

                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
