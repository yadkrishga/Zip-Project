﻿using Newtonsoft.Json;
using SAPbouiCOM;
using Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SalesIntegration
{
	public class config
	{
		public string Uri { get; set; }
		public string UserName { get; set; }
		public string Password { get; set; }
		public string SapDbName { get; set; }
		public string DbName { get; set; }

		public string DbServer { get; set; }
		public string DbUserName { get; set; }
		public string DbPassword { get; set; }
		public string Issuer { get; set; }	

	}

	public class AdminForm: IBForm
	{
		Form oForm;
		private string formType;

		//private DBDataSource ds;

		public AdminForm() {
			
		}
		public int findFormSeq(string ftype)
		{
		
			int fnum = 0;
			IEnumerator forms = ProgData.B1Application.Forms.GetEnumerator();
			SAPbouiCOM.Form bForm = null;
			try
			{
				forms.Reset();
				while (forms.MoveNext())
				{
					try
					{
						bForm = (SAPbouiCOM.Form)forms.Current;
					}
					catch (Exception err)
					{
						continue;
					}
#pragma warning restore CS0168 // Variable is declared but never used
					if (ftype != null && bForm.UniqueID.Length >= ftype.Length && bForm.UniqueID.Substring(0, ftype.Length) == ftype
						  && bForm.TypeEx == ftype)
					{
						string scnt = bForm.UniqueID.Substring(ftype.Length, bForm.UniqueID.Length - ftype.Length);
						int icnt = Convert.ToInt32(scnt);
						if (fnum < icnt)
							fnum = icnt;


					}
				}



			}
			catch (Exception et)
			{


			}
#pragma warning restore CS0168 // Variable is declared but never used
			fnum++;
			return fnum;



		}
		private void AddSAPTables()
		{

			if (!TableCreate.TableExists("G_Mng"))
			{
				TableCreate.CreateTable("G_Mng", "Sales Integration Management", SAPbobsCOM.BoUTBTableType.bott_NoObject);
			}
			
		
			if (TableCreate.TableExists("G_Mng"))
			{
				TableCreate.CreateUserFields("@G_Mng", "SLAddr", "Service Layer Url", SAPbobsCOM.BoFieldTypes.db_Alpha, 50, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "SLUser", "Service Layer User", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "SLPssw", "Service Layer Password", SAPbobsCOM.BoFieldTypes.db_Alpha, 100, SAPbobsCOM.BoFldSubTypes.st_None);

				TableCreate.CreateUserFields("@G_Mng", "TrcDBSrv", "Track DB Server", SAPbobsCOM.BoFieldTypes.db_Alpha, 60, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "TrcDBName", "Track DB Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 40, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "TrcDBUser", "Track DB User", SAPbobsCOM.BoFieldTypes.db_Alpha, 40, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "TrcDBpssw", "Track DB Password", SAPbobsCOM.BoFieldTypes.db_Alpha, 100, SAPbobsCOM.BoFldSubTypes.st_None);

				TableCreate.CreateUserFields("@G_Mng", "APIUser", "API User", SAPbobsCOM.BoFieldTypes.db_Alpha, 40, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "APIpssw", "API Password", SAPbobsCOM.BoFieldTypes.db_Alpha, 100, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "TCXmlPath", "TrueCommerce XML file Path", SAPbobsCOM.BoFieldTypes.db_Alpha, 100, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "XmlCnt", "XML Counter", SAPbobsCOM.BoFieldTypes.db_Numeric);
				TableCreate.CreateUserFields("@G_Mng", "FTPUser", "TrueCommerce FTP UserName", SAPbobsCOM.BoFieldTypes.db_Alpha, 50, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mng", "FTPpssw", "TrueCommerce FTP Password", SAPbobsCOM.BoFieldTypes.db_Alpha, 100, SAPbobsCOM.BoFldSubTypes.st_None);

				TableCreate.CreateUserFields("@G_Mng", "HQry", "HeaderQry", SAPbobsCOM.BoFieldTypes.db_Memo, 0, SAPbobsCOM.BoFldSubTypes.st_None );
				TableCreate.CreateUserFields("@G_Mng", "LQry", "LineQry", SAPbobsCOM.BoFieldTypes.db_Memo, 0, SAPbobsCOM.BoFldSubTypes.st_None);
			}

			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			//CompanyService oCompanyService = ProgData.B1Company.GetCompanyService();
			//AdminInfo oCompanyAdminInfo = oCompanyService.GetAdminInfo();

#pragma warning disable CS0168 // Variable is declared but never used
			try
			{
				string qry = $"INSERT INTO \"@G_Mng\" select  '1','Master','https:..../50000/b1s/v1/','B1i','','','{ProgData.B1Company.CompanyDB}','B1i','','ApiUsr',''";
				rs.DoQuery(qry);
			}
			catch (Exception ex) { }
#pragma warning restore CS0168 // Variable is declared but never used

		}
		private void crfields()
		{

			
			if (!TableCreate.TableExists("G_Mapp"))
			{
				TableCreate.CreateTable("G_Mapp", "Sales Integration matching", SAPbobsCOM.BoUTBTableType.bott_MasterData);
			}

			

			Dictionary<string, string> validvalues = new Dictionary<string, string>();
			if (TableCreate.TableExists("G_Mapp"))
			{

				TableCreate.CreateUserFields("@G_Mapp", "Type", "Mapping type", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mapp", "XFldName", "XML FieldName", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mapp", "SAPFldName", "SAPB1 FieldName", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None);

				TableCreate.CreateUserFields("@G_Mapp", "XValue", "XML Field Value", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None);
				TableCreate.CreateUserFields("@G_Mapp", "SAPFldValue", "SAPB1 FieldValue", SAPbobsCOM.BoFieldTypes.db_Alpha, 20, SAPbobsCOM.BoFldSubTypes.st_None);


			}
			TableCreate.CreateUserFields("ORDR", "ImportXML", "Import XML File ", SAPbobsCOM.BoFieldTypes.db_Alpha, 50, SAPbobsCOM.BoFldSubTypes.st_None);
			
			TableCreate.CreateUserFields("OINV", "ExportXML", "Export XML", SAPbobsCOM.BoFieldTypes.db_Alpha, 50, SAPbobsCOM.BoFldSubTypes.st_None);

			

		}

		public void CreateForm()
		{

			try
			{
				try
				{
					AddSAPTables();
				}
				catch (Exception e)
				{ }
				
				formType = "adm";
				SAPbouiCOM.FormCreationParams oCP = null;
				oCP = ((SAPbouiCOM.FormCreationParams)(ProgData.B1Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)));
				int frmcnt = findFormSeq(formType);
				oCP.UniqueID = formType + frmcnt.ToString();
				//oCP.ObjectType = "AdmObj";
				oCP.FormType = formType;
				oCP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable;

				oForm = ProgData.B1Application.Forms.AddEx(oCP);
				ProgData.Forms.Add(oForm.UniqueID, this);
				SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				string qry = "select * from \"@G_Mng\" ";
				rs.DoQuery(qry);


				oForm.Title = "Integration Admin";
				oForm.Top = 10;
				oForm.Left = 10;
				oForm.ClientWidth = 593;
				oForm.Height = 350;
				oForm.AutoManaged = true;
				try
				{
					oForm.Mode = BoFormMode.fm_OK_MODE;
				}
				catch (Exception  e)
				{ oForm.Mode = BoFormMode.fm_VIEW_MODE; }
				Item oItem = oForm.Items.Add("1", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
				oItem.Left = 5;
				oItem.Width = 65;
				oItem.Top = oForm.Height - 70;
				oItem.Height = 19;
				oItem.SetAutoManagedAttribute(BoAutoManagedAttr.ama_Editable, -1, BoModeVisualBehavior.mvb_True);
				SAPbouiCOM.Button oButton = ((SAPbouiCOM.Button)(oItem.Specific));


				oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
				oItem.Left = 80;
				oItem.Width = 65;
				oItem.Top = oForm.Height - 70;
				oItem.Height = 19;
				oItem = oForm.Items.Add("crbtn", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
				oItem.Left = oForm.Width-100;
				oItem.Width = 65;
				oItem.Top = oForm.Height - 70;
				oItem.Height = 19;
				((Button)oItem.Specific).Caption = "Create Fields";
				int top = 15;
				SAPbouiCOM.StaticText label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label01", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				label.Item.Top = top + 0;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Service Layer Url";
				UserDataSource url = oForm.DataSources.UserDataSources.Add("url", BoDataType.dt_SHORT_TEXT, 50);
				EditText pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f1", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top;
				pdEdt1.Item.Width = 250;
				pdEdt1.Value = rs.Fields.Item("U_SLAddr").Value.ToString();
				pdEdt1.Item.LinkTo = "Label01";
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label02", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top +20;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "SL User";
				label.Item.LinkTo = "Label01";
				UserDataSource slusr = oForm.DataSources.UserDataSources.Add("slusr", BoDataType.dt_SHORT_TEXT, 50);
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f2", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top+20;
				pdEdt1.Item.Width = 250;
				pdEdt1.Item.LinkTo = "Label02";
				pdEdt1.Value = rs.Fields.Item("U_SLUser").Value.ToString();
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label03", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top+40;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "SL Password";
				label.Item.LinkTo = "Label02";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f3", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top+40;
				pdEdt1.Item.Width = 250;
				pdEdt1.Item.LinkTo = "Label03";
				//	pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_SLPssw");
				try
				{
					pdEdt1.Value = Logger.Decrypt(rs.Fields.Item("U_SLPssw").Value.ToString(), true);
				} catch (Exception e)
				{

				}

			   pdEdt1.IsPassword = true;
				//
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label04", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top + 60;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Track DB Server";
				label.Item.LinkTo = "Label03";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f4", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 60;
				pdEdt1.Item.Width = 250;
				pdEdt1.Item.LinkTo = "Label04";
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_TrcDBSrv");
				pdEdt1.Value = rs.Fields.Item("U_TrcDBSrv").Value.ToString();
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label05", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top + 80;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Track DB Name";
				label.Item.LinkTo = "Label04";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f5", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 80;
				pdEdt1.Item.Width = 250;
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_TrcDBName");
				pdEdt1.Value = rs.Fields.Item("U_TrcDBName").Value.ToString();
				pdEdt1.Item.LinkTo = "Label05";
				//
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label06", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top + 100;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Track DB User";
				label.Item.LinkTo = "Label05";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f6", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 100;
				pdEdt1.Item.Width = 250;
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_TrcDBUser");
				pdEdt1.Value = rs.Fields.Item("U_TrcDBUser").Value.ToString();
				pdEdt1.Item.LinkTo = "Label06";
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label07", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;

				label.Item.Top = top + 120;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Track DB Password";
				label.Item.LinkTo = "Label06";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f7", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 120;
				pdEdt1.Item.Width = 250;
				
				pdEdt1.Item.LinkTo = "Label07";
				try { 
				pdEdt1.Value = Logger.Decrypt(rs.Fields.Item("U_TrcDBpssw").Value.ToString(), true);
				}
				catch (Exception e)
				{

				}
#pragma warning restore CS0168 // Variable is declared but never used
				pdEdt1.IsPassword = true;

				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label08", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top + 140;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Api User";
				label.Item.LinkTo = "Label07";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f8", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 140;
				pdEdt1.Item.Width = 250;
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_APIUser");
				pdEdt1.Value = rs.Fields.Item("U_APIUser").Value.ToString();
				pdEdt1.Item.LinkTo = "Label08";
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label09", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;

				label.Item.Top = top + 160;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "Api Password";
				label.Item.LinkTo = "Label08";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f9", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 160;
				pdEdt1.Item.Width = 250;
				pdEdt1.Item.LinkTo = "Label09";
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_APIpssw");
#pragma warning disable CS0168 // Variable is declared but never used
				try
				{ 
				pdEdt1.Value = Logger.Decrypt(rs.Fields.Item("U_APIpssw").Value.ToString(), true);
				}
				catch (Exception e)
				{

				}
#pragma warning restore CS0168 // Variable is declared but never used
				pdEdt1.IsPassword = true;

				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label10", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top + 180;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "TrueComm.XML Path";
				label.Item.LinkTo = "Label09";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f10", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top+180;
				pdEdt1.Item.Width = 250;
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_APIUser");
				pdEdt1.Value = rs.Fields.Item("U_TCXmlPath").Value.ToString();
				pdEdt1.Item.LinkTo = "Label10";
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label11", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;
				
				label.Item.Top = top + 200;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "XML Counter";
				label.Item.LinkTo = "Label10";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f11", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 200;
				pdEdt1.Item.Width = 250;
				pdEdt1.Item.LinkTo = "Label11";
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_APIUser");
				pdEdt1.Value = rs.Fields.Item("U_XmlCnt").Value.ToString();
				
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label081", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Top = top + 220;
				label.Item.Height = 14;
				label.Item.Left = 2;
				label.Item.Width = 80;
				label.Caption = "FTP User";
				label.Item.LinkTo = "Label11";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f81", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 220;
				pdEdt1.Item.Width = 250;
					pdEdt1.Item.LinkTo = "Label081";
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_APIUser");
				pdEdt1.Value = rs.Fields.Item("U_FTPUser").Value.ToString();
				label = (SAPbouiCOM.StaticText)oForm.Items.Add("Label091", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
				label.Item.Left = 2;

				label.Item.Top = top + 240;
				label.Item.Height = 14;
				label.Item.Width = 80;
				label.Caption = "FTP Password";
				label.Item.LinkTo = "Label081";
				pdEdt1 = (SAPbouiCOM.EditText)oForm.Items.Add("f91", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
				pdEdt1.Item.Left = 140;
				pdEdt1.Item.Top = top + 240;
				pdEdt1.Item.Width = 250;
				pdEdt1.Item.LinkTo = "Label091";
				//pdEdt1.DataBind.SetBound(true, "@G_Mng", "U_APIpssw");

				try
				{
					pdEdt1.Value = Logger.Decrypt(rs.Fields.Item("U_FTPpssw").Value.ToString(), true);
				}
				catch (Exception e)
				{

				}
				oForm.Items.Item("f1").Click();
		//		oForm.Mode = BoFormMode.fm_OK_MODE;

				pdEdt1.IsPassword = true;
				try
				{
					oForm.Mode = BoFormMode.fm_OK_MODE;
				}
				catch (Exception e)
				{ oForm.Mode = BoFormMode.fm_VIEW_MODE; }
				oForm.Visible = true;
			
			}
			catch (Exception err)
			{

			}
#pragma warning restore CS0168 // Variable is declared but never used
		}
		private void Save()
		{
			string qry = "";
			try {
				string f1 = ((EditText)oForm.Items.Item("f1").Specific).Value.ToString();
				string f2 = ((EditText)oForm.Items.Item("f2").Specific).Value.ToString();
				string f3 = ((EditText)oForm.Items.Item("f3").Specific).Value.ToString();
				try

				{
					f3 = Logger.Encrypt(f3, true);
				} catch (Exception e)
				{

				}
#pragma warning restore CS0168 // Variable is declared but never used
				string f4 = ((EditText)oForm.Items.Item("f4").Specific).Value.ToString();
				string f5 = ((EditText)oForm.Items.Item("f5").Specific).Value.ToString();
				string f6 = ((EditText)oForm.Items.Item("f6").Specific).Value.ToString();
				string f7 = ((EditText)oForm.Items.Item("f7").Specific).Value.ToString();
				string f77 = f7;
#pragma warning disable CS0168 // Variable is declared but never used
				try
				{
					f7 = Logger.Encrypt(f7, true);
				}
				catch (Exception e)
				{

				}
#pragma warning restore CS0168 // Variable is declared but never used
				
				string f8 = ((EditText)oForm.Items.Item("f8").Specific).Value.ToString();
				string f9 = ((EditText)oForm.Items.Item("f9").Specific).Value.ToString();
#pragma warning disable CS0168 // Variable is declared but never used
				try
				{
					f9 = Logger.Encrypt(f9, true);
				}
				catch (Exception e)
				{

				}
#pragma warning restore CS0168 // Variable is declared but never used
				string f10 = ((EditText)oForm.Items.Item("f10").Specific).Value.ToString();
				string f11 = ((EditText)oForm.Items.Item("f11").Specific).Value.ToString();
				string f81 = ((EditText)oForm.Items.Item("f81").Specific).Value.ToString();
				string f91 = ((EditText)oForm.Items.Item("f91").Specific).Value.ToString();
#pragma warning disable CS0168 // Variable is declared but never used
				try
				{
					f91 = Logger.Encrypt(f91, true);
				}
				catch (Exception e)
				{

				}
				qry = $"UPDATE \"@G_Mng\" SET Name='Master',U_SLAddr='{f1}',U_SLUser='{f2}',U_SLPssw='{f3}'";
				qry+=$" ,U_TrcDBSrv='{f4}',U_TrcDBName='{f5}',U_TrcDBUser='{f6}',U_TrcDBpssw='{f7}',U_APIUser='{f8}',U_APIpssw='{f9}',U_TCXmlPath='{f10}',U_XmlCnt={f11}";
				qry += $" ,U_FTPUser='{f81}',U_FTPpssw='{f91}' ";
				qry += $" WHERE Code = '1'";
				SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				rs.DoQuery(qry);
				ProgData.sqlConnectionString = $"Server = {f4}; Database = {f5}; User Id = {f6}; Password = {f77};";

				DbUtility dbutility = new DbUtility();
				dbutility.CreateTables();
				config cfg = new config()
				{
					Uri=f1,
					UserName=f2,
					Password=f3,
					SapDbName=f5,
					DbServer=f4,
					DbName=f5,
					DbUserName=f6,
					DbPassword=f7

				};
				string Jsbody = JsonConvert.SerializeObject(cfg);
				string path = AppDomain.CurrentDomain.BaseDirectory;
				string flname = path + "Config.json";
				var sr = File.CreateText(flname);
				TextWriter w = (TextWriter)sr;
				w.WriteLine( Jsbody);
				w.Flush();
				w.Close();
			}
			catch (Exception ex) {
				Logger.Log(new Exception(ex.Message+qry));
			}

		}
		public void EventAll(ItemEvent pVal)
		{
			if (pVal.BeforeAction == true)
			{

			} else
			{
				if (pVal.ItemUID == "1" && pVal.EventType == BoEventTypes.et_CLICK)
				{
					Save();

				}
				if (pVal.ItemUID == "crbtn" && pVal.EventType == BoEventTypes.et_CLICK)
				{
					crfields();

				}
			}
		}
		public void Menu(ref MenuEvent pVal)
		{
			throw new NotImplementedException();
		}
	}
}
