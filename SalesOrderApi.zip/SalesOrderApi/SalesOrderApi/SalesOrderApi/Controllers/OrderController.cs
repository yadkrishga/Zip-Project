﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SAPProc;
using Shared.Models;
using System.Xml;

namespace SalesOrderApi.Controllers
{
	public class OrderController : Controller
	{
		private readonly ISapB1 _SapB1;


		public OrderController(ISapB1 sapB1)
		{
			_SapB1 = sapB1;

		}

		[HttpPost]
		[Route("SalesOrder")]
		public ActionResult Sales([FromBody] Param1 param)
		{
			string ret = " Başla";
			if (param == null)
				ret = "null";	
			   UserInfo _userData = new UserInfo();
			_userData.UserId = param.userId;
			_userData.Password = param.password;
			var user = _SapB1.Finduser(_userData);
			 ret = "Unauthorized";
			if (user != null && !String.IsNullOrEmpty(user.UserId) && !String.IsNullOrEmpty(user.Password))
			{

				ret = _SapB1.CreateOrder(param);
			}
			return Ok(ret);
		}
		[Authorize]
		[HttpPost]
		[Route("Order")]
		public ActionResult Order([FromBody]Param1 param)
		{

			string ret = _SapB1.CreateOrder(param);
			return Ok(0);
		}
	}

}
