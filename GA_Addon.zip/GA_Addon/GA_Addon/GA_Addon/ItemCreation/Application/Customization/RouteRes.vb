﻿Public Class RouteRes
    Dim frmRouteRes As SAPbouiCOM.Form
    Dim oMatrix, oMatrix2 As SAPbouiCOM.Matrix
    Dim DocEntryList As String = ""
    Dim LineList As String = ""
    Dim LineSel As Integer = 0
    Dim ChkAll As String = "N"

    Sub LoadRouteRes()
        oGfun.LoadXML(frmRouteRes, RouteResFormID, RouteResXML)
        frmRouteRes = oApplication.Forms.Item(RouteResFormID)
        InitForm()

    End Sub
#Region "InitForm"
    Sub InitForm()
        Try
            frmRouteRes.Freeze(True)
            LineSel = 0
            LineList = ""

            Dim oCombo As SAPbouiCOM.ComboBox = frmRouteRes.Items.Item("cmbRes").Specific

            oCombo.Select("A", SAPbouiCOM.BoSearchKey.psk_ByValue)
            frmRouteRes.Items.Item("edtFDt").Click(SAPbouiCOM.BoCellClickType.ct_Regular)

            frmRouteRes.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("InitForm Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRouteRes.Freeze(False)
        Finally
        End Try
    End Sub
#End Region
    Sub SelectAll()
        Try
            frmRouteRes.Freeze(True)
            Dim cnt As Integer = 0
            If (ChkAll = "N") Then
                ChkAll = "Y"
            Else
                ChkAll = "N"
            End If
            Dim Grid0 As SAPbouiCOM.Grid = frmRouteRes.Items.Item("Grid0").Specific
            Dim dt0 As SAPbouiCOM.DataTable = frmRouteRes.DataSources.DataTables.Item("DT0")

            For i As Integer = 0 To dt0.Rows.Count - 1
                Dim Chk1 As String = dt0.GetValue("Res", i).ToString()
                oApplication.StatusBar.SetText("Please wait Production Order Selection", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                '   Dim LineNo As Integer = i
                If (Chk1 = "N") Then
                    dt0.SetValue("Reserve", i, ChkAll)
                End If
                If ChkAll = "Y" Then
                    ''DocEntryList = DocEntryList + "@" + DocEntry + "~"
                    LineSel = LineSel + 1
                Else
                    LineSel = LineSel - 1
                End If

            Next
            frmRouteRes.Freeze(False)
            '  oApplication.StatusBar.SetText("Please wait Production Order Selection", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

        Catch ex As Exception
            frmRouteRes.Freeze(False)
            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
    Sub Filldata()
        Try
            frmRouteRes.Freeze(True)
            LineList = ""
            ChkAll = "N"
            Dim Grid0 As SAPbouiCOM.Grid = frmRouteRes.Items.Item("Grid0").Specific


            Dim dt0 As SAPbouiCOM.DataTable = frmRouteRes.DataSources.DataTables.Item("DT0")
            Dim Whse As String = frmRouteRes.DataSources.UserDataSources.Item("GA_UDWH").ValueEx.Trim()
            Dim Reserve As String = frmRouteRes.DataSources.UserDataSources.Item("GA_UD_RES").ValueEx.Trim()
            Dim DateFrom As DateTime = DateTime.ParseExact(frmRouteRes.DataSources.UserDataSources.Item("GA_UD_FD").ValueEx.Trim(), "yyyyMMdd", Nothing)
            Dim DateTo As DateTime = DateTime.ParseExact(frmRouteRes.DataSources.UserDataSources.Item("GA_UD_TD").ValueEx.Trim(), "yyyyMMdd", Nothing)
            If DateFrom.ToString() <> "" And DateTo.ToString() <> "" And Whse <> "" Then

                Dim Sql As String = "Select ROW_NUMBER() OVER(ORDER BY A.ZipCode,A.DocDueDate) AS ROW,*  from(Select DISTINCT  A.U_GA_ResRoute[Reserve],A.U_GA_ResRoute[Res],A.[DocNum],B.[ZipCodeS] as [ZipCode],CASE WHEN A.[ObjType]='17' THEN A.[DocEntry] end As [DocEntry],'0'[ReqDocEntry] ,A.ObjType [DocType],'Sales Order'[Document Type],FORMAT(A.[DocDueDate],'yyyy-MM-dd') [DocDueDate] FROM ORDR A INNER JOIN RDR12 B ON A.[DocEntry]=B.[DocEntry] INNER JOIN RDR1 C ON A.DocEntry=C.DocEntry WHERE C.[LineStatus]='O' and C.WhsCode='" & Whse & "' and ISNULL(B.ZipCodeS,'')<>''  and CONVERT(VARCHAR(20),A.DocDueDate,112)>='" & DateFrom.ToString("yyyyMMdd") & "' and CONVERT(VARCHAR(20),A.DocDueDate,112)<='" & DateTo.ToString("yyyyMMdd") & "'"
                If Reserve = "N" Then
                    Sql += "and ISNULL(A.U_GA_ResRoute,'N')='N' "
                ElseIf Reserve = "Y" Then
                    Sql += "and ISNULL(A.U_GA_ResRoute,'N')='Y' "
                End If

                Sql += " UNION ALL "
                Sql += "Select DISTINCT  A.U_GA_ResRoute [Reserve],A.U_GA_ResRoute[Res],A.[DocNum],B.[ZipCodeS] as [ZipCode],'0' [DocEntry],CASE WHEN A.[ObjType]='234000031' THEN A.[DocEntry] end As[ReqDocEntry] ,A.ObjType [DocType],'Return Request'[Document Type],FORMAT(A.[DocDueDate],'yyyy-MM-dd')[DocDueDate] FROM ORRR A INNER JOIN RRR12 B ON A.[DocEntry]=B.[DocEntry] INNER JOIN RRR1 C ON A.DocEntry=C.DocEntry WHERE C.[LineStatus]='O' and C.WhsCode='" & Whse & "'   and ISNULL(B.ZipCodeS,'')<>''  and CONVERT(VARCHAR(20),A.DocDueDate,112)>='" & DateFrom.ToString("yyyyMMdd") & "' and CONVERT(VARCHAR(20),A.DocDueDate,112)<='" & DateTo.ToString("yyyyMMdd") & "'"
                If Reserve = "N" Then
                    Sql += "and ISNULL(A.U_GA_ResRoute,'N')='N' "
                ElseIf Reserve = "Y" Then
                    Sql += "and ISNULL(A.U_GA_ResRoute,'N')='Y' "
                End If
                Sql += " )A ORDER BY A.[ZipCode],A.[DocDueDate] "


                dt0.ExecuteQuery(Sql)
                Grid0.DataTable = dt0
                Dim ix As Integer = 0
                Dim oColumn As SAPbouiCOM.GridColumn = Grid0.Columns.Item(ix)
                oColumn.TitleObject.Caption = "#"
                oColumn.TitleObject.Sortable = True
                oColumn.Editable = False
                For i As Integer = 0 To Grid0.Columns.Count - 1



                    oColumn = Grid0.Columns.Item(i)
                    If (oColumn.UniqueID = "DocEntry") Then
                        oColumn.LinkedObjectType = "17"
                        oColumn.TitleObject.Caption = "Sales Order DocEntry"
                    End If
                    If (oColumn.UniqueID = "ReqDocEntry") Then
                        oColumn.LinkedObjectType = "234000031"
                        oColumn.TitleObject.Caption = "Return Request DocEntry"
                    End If
                    oColumn.TitleObject.Sortable = True
                    If (oColumn.UniqueID = "Res") Then
                        oColumn.Visible = False
                        oColumn.Editable = False
                    End If
                    If (oColumn.UniqueID = "DocType") Then
                        oColumn.Visible = False
                    End If
                    If (oColumn.UniqueID = "Reserve") Then


                        oColumn.Editable = True

                        oColumn.Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                        oColumn.Editable = True


                    Else
                        oColumn.Editable = False
                    End If



                    Grid0.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
                    LineSel = 0
                Next

                For rownum As Integer = 1 To dt0.Rows.Count
                    If dt0.GetValue("Reserve", rownum - 1).ToString() = "Y" Then


                        Grid0.CommonSetting.SetCellEditable(rownum, 2, False)
                    Else
                        Grid0.CommonSetting.SetCellEditable(rownum, 2, True)

                    End If
                Next
            Else
                Dim strSql As String = "select '1'[Row],'N' [Select] "
                dt0.ExecuteQuery(strSql)
                Grid0.DataTable = dt0
                Dim ix As Integer = 0
                Dim oColumn As SAPbouiCOM.GridColumn = Grid0.Columns.Item(ix)
                oColumn.TitleObject.Caption = "#"
                oColumn.TitleObject.Sortable = True
                oColumn.Editable = False
                For i As Integer = 0 To Grid0.Columns.Count - 1
                    oColumn = Grid0.Columns.Item(i)
                    If (oColumn.UniqueID = "Select") Then


                        oColumn.Editable = False

                        oColumn.Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox

                    End If
                Next
            End If




            frmRouteRes.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText("Fill Data Method Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmRouteRes.Freeze(False)
        Finally
        End Try
    End Sub

    Sub SelectData(ByRef pVal As SAPbouiCOM.ItemEvent)

        Dim i As Integer = pVal.Row
        Dim Grid0 As SAPbouiCOM.Grid = frmRouteRes.Items.Item("Grid0").Specific
        Dim dt0 As SAPbouiCOM.DataTable = frmRouteRes.DataSources.DataTables.Item("DT0")
        Dim Chk As String = dt0.GetValue("Reserve", i).ToString()

        If (Grid0.CommonSetting.GetCellEditable(i + 1, 2)) Then


            If Chk = "Y" Then
                ''DocEntryList = DocEntryList + "@" + DocEntry + "~"
                LineSel = LineSel + 1
            Else
                LineSel = LineSel - 1
            End If
        End If
    End Sub

    Sub UpdateDoc()
        Try


            Dim Grid0 As SAPbouiCOM.Grid = frmRouteRes.Items.Item("Grid0").Specific
            Dim dt0 As SAPbouiCOM.DataTable = frmRouteRes.DataSources.DataTables.Item("DT0")
            If Grid0.Columns.Count > 2 Then


                For i As Integer = 0 To dt0.Rows.Count - 1
                    oApplication.StatusBar.SetText("Please wait Route Reserving Processing", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Dim LineNo As Integer = i


                    Dim DocEntry As String = dt0.GetValue("DocEntry", LineNo).ToString()
                    Dim ReqDocEntry As String = dt0.GetValue("ReqDocEntry", LineNo).ToString()
                    Dim DocType As String = dt0.GetValue("DocType", LineNo).ToString()
                    Dim Chk As String = dt0.GetValue("Reserve", LineNo).ToString()
                    Dim Chk1 As String = dt0.GetValue("Res", LineNo).ToString()
                    If (Chk = "Y" And Chk1 = "N") Then


                        Dim SqlUpdate As String = ""
                        If (DocType = "17") Then
                            SqlUpdate = "Update ORDR set U_GA_ResRoute='Y' WHERE DocEntry='" & DocEntry & "'"
                        ElseIf (DocType = "234000031") Then
                            SqlUpdate = "Update ORRR set U_GA_ResRoute='Y' WHERE DocEntry='" & ReqDocEntry & "'"
                        End If
                        If (SqlUpdate <> "") Then
                            Dim RsUpdate As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                            RsUpdate.DoQuery(SqlUpdate)
                        End If
                    End If
                Next

                oApplication.StatusBar.SetText("Process Completed successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                frmRouteRes.Items.Item("btn_Fill").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            Else
                oApplication.StatusBar.SetText("No Records found", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub


    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Try
                frmRouteRes = oApplication.Forms.Item(FormUID)

                '   frmRouteRes = frmProdOrder
            Catch ex As Exception

            End Try

            If pVal.FormTypeEx = RouteResFormID Then
                Select Case pVal.EventType

                    Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                        Try

                            If (pVal.ItemUID = "edtWhs") Then
                                Dim oCFLEvento As SAPbouiCOM.IChooseFromListEvent
                                oCFLEvento = pVal
                                Dim sCFL_ID As String
                                sCFL_ID = oCFLEvento.ChooseFromListUID

                                Dim oCFL As SAPbouiCOM.ChooseFromList
                                oCFL = frmRouteRes.ChooseFromLists.Item(sCFL_ID)
                                If oCFLEvento.BeforeAction = False And oCFLEvento.SelectedObjects IsNot Nothing Then
                                    Dim oDataTable As SAPbouiCOM.DataTable
                                    oDataTable = oCFLEvento.SelectedObjects
                                    Dim val As String = ""
                                    Dim val2 As String = ""
                                    Try
                                        val = oDataTable.GetValue("WhsCode", 0)
                                        val2 = oDataTable.GetValue("ZipCode", 0)
                                    Catch ex As Exception

                                    End Try

                                    frmRouteRes.DataSources.UserDataSources.Item("GA_UDWH").ValueEx = val

                                End If

                            End If


                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Choose from List Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                        Try
                            Select Case pVal.ItemUID
                                Case "edtFDt"

                                    If (pVal.BeforeAction = True) Then
                                        If (frmRouteRes.DataSources.UserDataSources.Item("GA_UD_FD").ValueEx.Trim() <> "" And frmRouteRes.DataSources.UserDataSources.Item("GA_UD_TD").ValueEx.Trim()) Then
                                            Dim DateFrom As DateTime = DateTime.ParseExact(frmRouteRes.DataSources.UserDataSources.Item("GA_UD_FD").ValueEx.Trim(), "yyyyMMdd", Nothing)
                                            Dim DateTo As DateTime = DateTime.ParseExact(frmRouteRes.DataSources.UserDataSources.Item("GA_UD_TD").ValueEx.Trim(), "yyyyMMdd", Nothing)
                                            If (DateTo < DateFrom) Then
                                                BubbleEvent = False
                                                oApplication.StatusBar.SetText("Date range is invalid", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                            End If
                                        End If
                                    End If
                                Case "edtTDt"
                                    If (pVal.BeforeAction = True) Then
                                        Dim DateFrom As DateTime = DateTime.ParseExact(frmRouteRes.DataSources.UserDataSources.Item("GA_UD_FD").ValueEx.Trim(), "yyyyMMdd", Nothing)
                                        Dim DateTo As DateTime = DateTime.ParseExact(frmRouteRes.DataSources.UserDataSources.Item("GA_UD_TD").ValueEx.Trim(), "yyyyMMdd", Nothing)
                                        If (DateTo < DateFrom) Then
                                            BubbleEvent = False
                                            oApplication.StatusBar.SetText("Date range is invalid", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        End If
                                    End If
                            End Select
                        Catch ex As Exception
                            ''oApplication.SetStatusBarMessage("Validate Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS

                    Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                        Try
                            Select Case pVal.ItemUID
                                Case "edtWhs"

                                    Dim StrQry As String = "Select WhsCode FROM [OWHS] WHERE CONVERT(VARCHAR(20),ZipCode)<>''"
                                    oGfun.ChooseFromListFilteration(frmRouteRes, "CFL_RP1", "WhsCode", StrQry)
                            End Select
                        Catch ex As Exception
                            oApplication.SetStatusBarMessage("Got Focus Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Try
                            Select Case pVal.ItemUID
                                Case "Grid0"
                                    Select Case pVal.ColUID
                                        Case "Reserve"
                                            Try
                                                If pVal.BeforeAction = False And pVal.ActionSuccess = True And pVal.Row >= 0 Then
                                                    SelectData(pVal)
                                                End If
                                            Catch ex As Exception

                                            End Try
                                    End Select
                                Case "btn_Sel"
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Selecting Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.SelectAll()

                                        oApplication.StatusBar.SetText("Selecting Completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                                Case "btn_Fill"
                                    If pVal.BeforeAction = True Then
                                        Dim Whse As String = frmRouteRes.DataSources.UserDataSources.Item("GA_UDWH").ValueEx.Trim()
                                        Dim Reserve As String = frmRouteRes.DataSources.UserDataSources.Item("GA_UD_RES").ValueEx.Trim()
                                        Dim DateFrom As String = frmRouteRes.DataSources.UserDataSources.Item("GA_UD_FD").ValueEx.Trim()
                                        Dim DateTo As String = frmRouteRes.DataSources.UserDataSources.Item("GA_UD_TD").ValueEx.Trim()
                                        If (Whse = "" Or DateFrom = "" Or DateTo = "") Then
                                            BubbleEvent = False
                                            oApplication.StatusBar.SetText("Whse ,FromDate and ToDate are mandatory feilds", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        End If

                                    End If
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        oApplication.StatusBar.SetText("Filling Data,Please wait", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.Filldata()

                                        oApplication.StatusBar.SetText("Filling Completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End If
                                Case "btnPro"
                                    If pVal.BeforeAction = True Then


                                        If (LineSel = 0) Then
                                            BubbleEvent = False
                                            oApplication.StatusBar.SetText("Select minimum one unreserved document ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        End If
                                    End If
                                    If (pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                                        Me.UpdateDoc()
                                    End If

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Item Pressed Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try

                    Case SAPbouiCOM.BoEventTypes.et_CLICK
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                        Try
                            Select Case pVal.ItemUID

                            End Select
                        Catch ex As Exception
                            oApplication.StatusBar.SetText("Click Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                    Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                        Try

                        Catch ex As Exception
                            oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        Finally
                        End Try
                End Select
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

End Class
