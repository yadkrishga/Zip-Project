﻿using SAPbouiCOM;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemForms
{
	public class SalesOrder : IBForm
	{
		Form oForm, ORDRForm;
		string olduser, newuser;
		public void EventAll(ItemEvent pVal)
		{
			if (pVal.FormTypeEx == "139")
			{
				ORDRForm = ProgData.B1Application.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
				if (ORDRForm.Mode == BoFormMode.fm_UPDATE_MODE)
				{
					if (pVal.EventType == BoEventTypes.et_GOT_FOCUS && pVal.ItemUID == "222")
					{
						DBDataSource ds = ORDRForm.DataSources.DBDataSources.Item("ORDR");
						olduser = ds.GetValue("OwnerCode", 0);
						//olduser = ((EditText)ORDRForm.Items.Item("222").Specific).Value;
					}
					else
						if (pVal.EventType == BoEventTypes.et_LOST_FOCUS && pVal.ItemUID == "222")
					{
						DBDataSource ds = ORDRForm.DataSources.DBDataSources.Item("ORDR");
						newuser = ds.GetValue("OwnerCode", 0);
						SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

						string qry = $"Select  B.USER_CODE  FROM OHEM A INNER JOIN OUSR B ON A.UserId = B.UserId where A.empID =  {newuser}";
						rs.DoQuery(qry);
						DbUtility dbutil = new DbUtility();
						string User = rs.Fields.Item(0).Value.ToString();
						string docref = ds.GetValue("DocEntry", 0);
						dbutil.UpdateHeader(User, "", docref);
						//newuser = ((EditText)ORDRForm.Items.Item("222").Specific).Value;
					}
				}
			}
		}

		public void Menu(ref MenuEvent pVal)
		{
			throw new NotImplementedException();
		}
	}
}
