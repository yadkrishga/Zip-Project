﻿''' <summary>
''' GGlobally whatever variable do you want declare here 
''' We can use any class and module from here  
''' </summary>
''' <remarks></remarks>
Module GolabalVariables



#Region " ... Common For SAP ..."
    Public _changeMsg As Boolean = False
    Public _newMsg As String = ""
    Public _errorSAPMsg As String = ""
    Public oCompany As SAPbobsCOM.Company
    Public oGfun As New GlobalFunctions
    'Public oDBFun As New DataBase_Proc_Functions
    Public oForm As SAPbouiCOM.Form
    Public AddOnName As String = "PostCode addon"
    Public ErrCode As Long
    Public ErrMsg As String = ""
    Public oCompanySrv As SAPbobsCOM.CompanyService
    Public CardPost As String = ""

#End Region

#Region " ... Common For Forms ..."
    'Import

    'ItemCreation

    Public oSaleQuot As New SalesQuotation
    Public SaleQuotTypeEx As String = "149"
    'sales Order
    Public oSaleOrder As New SalesOrder
    Public SaleOrderTypeEx As String = "139"
    Public PostCodeID As String = "GA_POST"
    Public CardDetails As String = "GA_CARD"
    Public CardDetails1 As String = "GA_CARD1"
    'sales Order add
    Public oSaleOrderAdd As New SalesOrderAdd
    Public SaleOrderAddTypeEx As String = "13000000"







#End Region

#Region " ... Gentral Purpose ..."

    Public v_RetVal, v_ErrCode As Long
    Public v_ErrMsg As String = ""
    'Attachment Option
    Public ShowFolderBrowserThread As Threading.Thread
    Public BankFileName As String
    Public boolModelForm As Boolean = False
    Public boolModelFormID As String = ""
    Public ShouldNotErrorMsg As String = " Should Not be Left Empty"
    Public sQuery As String = ""
    Public boolTripStatusCanceled As Boolean = False

#End Region

End Module
