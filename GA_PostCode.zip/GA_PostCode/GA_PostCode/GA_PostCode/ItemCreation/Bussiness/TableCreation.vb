﻿Public Class TableCreation

    Public oGFun As New GlobalFunctions
    Dim ValidValueYesORNo = New String(,) {{"N", "No"}, {"Y", "Yes"}}
    Sub New()
        Try

            Me.APIMapping()

            Me.UDF()

            Me.HubSeries()
        Catch ex As Exception
            oGFun.StatusBarErrorMsg("New Method Failed : " & ex.Message)
        Finally
        End Try
    End Sub

    Sub APIMapping()
        Try
            Me.APIMappingHead()

        Catch ex As Exception
            oApplication.StatusBar.SetText("TableCreation Item Creation Method Failed : ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
        End Try
    End Sub

    Sub APIMappingHead()
        Try
            oGFun.CreateTable("GA_APIM", "GA API Mapping", SAPbobsCOM.BoUTBTableType.bott_NoObjectAutoIncrement)
            oGFun.CreateUserFields("@GA_APIM", "GA_APIF", "API Feild", SAPbobsCOM.BoFieldTypes.db_Alpha, 200)
            oGFun.CreateUserFields("@GA_APIM", "GA_SAPF", "SAP Feild", SAPbobsCOM.BoFieldTypes.db_Alpha, 200)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub

    Sub HubSeries()
        Try
            oGFun.CreateTable("GA_HUBSER", "GA HUB SERIES", SAPbobsCOM.BoUTBTableType.bott_NoObjectAutoIncrement)
            oGFun.CreateUserFields("@GA_HUBSER", "GA_SOSER", "SO Series", SAPbobsCOM.BoFieldTypes.db_Alpha, 30)
            oGFun.CreateUserFields("@GA_HUBSER", "GA_SQSER", "SQ Series", SAPbobsCOM.BoFieldTypes.db_Alpha, 30)

        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub


    Sub UDF()


        oGFun.CreateUserFields("ORDR", "GA_Post", "PostCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 20)


    End Sub


End Class


