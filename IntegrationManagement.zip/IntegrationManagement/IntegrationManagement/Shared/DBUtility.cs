﻿using SAPbobsCOM;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
    public class DbUtility
    {
        int ErrCode;
        string ErrMsg;
        public SqlConnection cn;

        SqlTransaction transaction;
        
        SqlConnection DBConnection
        {
            get
            {

                if (cn != null && cn.State == ConnectionState.Open)
                    return cn;
                else
                {
                    try
                    {
                        cn = new SqlConnection(ProgData.getConnectionString());
                        cn.Open();
                     

                    }
                    catch (Exception e)
                    {
                        Logger.Log(new Exception(e.Message+"***"+ ProgData.sqlConnectionString));
                    }
                }

                return cn;

            }

        }
        public void Close(bool h)
        {
            if (h)
                transaction.Commit();
            else
                transaction.Rollback();
            cn.Close();

        }
        public void CreateTables()
        {
            StringBuilder qry = new StringBuilder();
			
			try
            {
            
                qry.Append(" CREATE TABLE [dbo].[TComm_Header]([CustomerPoNumber] nvarchar(15) NOT NULL PRIMARY KEY,[Customer] nvarchar(15) NULL,[CustomerName] nvarchar(50) NULL,");
                qry.Append("[OrderDate] datetime NULL,ShipAddress1 nvarchar(40),ShipAddress2 nvarchar(40),ShipAddress3 nvarchar(40),ShipPostalCode nvarchar(10) , [RequestedShipDate] datetime NULL,Branch nvarchar(10)");
				qry.Append(" ,XmlFile nvarchar(30),XmlFolder nvarchar(100),[DocRef] int,Status nvarchar(1), Message nvarchar(150), [ImportDate] date NULL, [ImportTime] time NULL,AR nvarchar(1),AppUser nvarchar(10),[App_Date] date NULL, [App_Time] time NULL,CardCode nvarchar(15) ) ON[PRIMARY]");
                SqlCommand command = new SqlCommand(qry.ToString(), DBConnection);
                command.ExecuteNonQuery();
			
				command.Dispose();
                cn.Close();

			}
            catch (Exception er)
            {
				Logger.Log(new Exception(er.Message + qry.ToString()));
			}
            qry.Clear();
            try
            {
                qry.Append(" CREATE TABLE[dbo].[TComm_Lines]( CustomerPoNumber nvarchar(10) NOT NULL,CustomerPoLine varchar(1) , [StockCode] nvarchar(15) NULL,[StockDescription] nvarchar(50) NULL,[OrderQty] [numeric](19, 6) NULL,");
                qry.Append("[Price] [numeric](19, 6) NULL,[Comment] varchar(50) NULL,Status nvarchar(1), Message nvarchar(150)");
                 qry.Append(") ON[PRIMARY]");

                SqlCommand command = new SqlCommand(qry.ToString(), DBConnection);
                command.ExecuteNonQuery();
				
				command.Dispose();
                cn.Close();

			}
            catch (Exception er)
            {
				Logger.Log(new Exception(er.Message + qry.ToString()));
			}
            if (cn.State == ConnectionState.Open)
              cn.Close();

        }
  
        public int UpdateHeader(string User, string AR, string docref,string ponumber = "")
        {
            StringBuilder qry = new StringBuilder();
			string date = DateTime.Now.ToString("yyyy-MM-dd");
			string time = DateTime.Now.ToString("HH:mm:ss");
			int retEnrty = 0;
            try
            {
                qry.Append(" UPDATE  [dbo].[TComm_Header]  SET AR=@Reject,AppUser=@user ");
                qry.Append(",ImportDate=@date,ImportTime=@Time ");
                if (String.IsNullOrEmpty(ponumber)) {
					qry.Append(" WHERE DocRef = @DocRef");
				} else
                {
					qry.Append(" WHERE CustomerPoNumber = @custponum");
				}
              
                using (SqlCommand SqlCmd = new SqlCommand(qry.ToString(), DBConnection, transaction))
                {
                    SqlCmd.Parameters.Add("@Reject", SqlDbType.VarChar,1).Value = AR;
                    SqlCmd.Parameters.Add("@user", SqlDbType.VarChar,10).Value = User;
                    SqlCmd.Parameters.Add("@date", SqlDbType.DateTime).Value = Convert.ToDateTime(date);
                    TimeSpan timeSpan = new TimeSpan(0, 0, 0);
                    TimeSpan.TryParse(time, out timeSpan);
                    SqlCmd.Parameters.Add("@time", SqlDbType.Time).Value = timeSpan;
                    if (String.IsNullOrEmpty(ponumber))
                    {
                        SqlCmd.Parameters.Add("@DocRef", SqlDbType.Int).Value = Convert.ToInt32(docref);
                    } else
						SqlCmd.Parameters.Add("@custponum", SqlDbType.VarChar,10).Value = ponumber;


					SqlCmd.ExecuteNonQuery();
                    SqlCmd.Dispose();


                }
            }
            catch (Exception ex)
            {
                if (transaction != null)
                    transaction.Rollback();
                cn.Close();
                throw new Exception(ex.Message + qry.ToString());

            }

            return retEnrty;

        }

    }

}
