Imports System.Xml
Imports System.io
Public Class SaleOrderNew

    Dim frmSaleOrder, frmFrieghtChargesSubGrid As SAPbouiCOM.Form
    Dim oMatrix, oMatrix1, oMatrix2, oMatSub As SAPbouiCOM.Matrix
    Dim oDBDSHeader, oDBDSDetail, oDBDSDetail1, oDBDSHeaderReq, oDBDSDetail2, oDBDSSubDetail2 As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "ORDR"
    Dim sPaySlipSourcePath As String = ""
    Dim sPaySlipFileExt As String = ".pdf"
    Dim DeleteRowITEMUID As String = ""
    Dim boolFilterItem As Boolean = False
    Dim FinalTAmount As Double = 0.0
    Dim GlobalFinalTAmount As Double = 0.0
    Dim TaXcode As String
    Dim row As String
    Dim SubRowID As Integer
    Dim DocEntry As Double = 0
    Dim Createform As Boolean = True
    Dim GlbRowID As Integer = 0

    Sub LoadSaleOrder()
        Try
            oGfun.LoadXML(frmSaleOrder, SaleOrderNewFormID, SaleOrderNewXML)
            frmSaleOrder = oApplication.Forms.Item(SaleOrderNewFormID)
            oMatrix = frmSaleOrder.Items.Item("Matrix").Specific
            oMatrix2 = frmSaleOrder.Items.Item("Matrix2").Specific
            oDBDSHeader = frmSaleOrder.DataSources.DBDataSources.Item(0)
            oDBDSDetail = frmSaleOrder.DataSources.DBDataSources.Item(1)
            oDBDSDetail2 = frmSaleOrder.DataSources.DBDataSources.Item(2)
            Me.InitForm()
            'oGfun.LoadExchangeRate()
            Me.DefineModesForFields()
            oMatrix.AutoResizeColumns()
            oMatrix.CommonSetting.EnableArrowKey = True

            oMatrix2.AutoResizeColumns()
            oMatrix2.CommonSetting.EnableArrowKey = True
            'CheckUser()

        Catch ex As Exception
            oApplication.StatusBar.SetText("LoadSaleOrder", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub

    Sub DefineModesForFields()
        Try
            frmSaleOrder.Items.Item("t_docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSaleOrder.Items.Item("t_docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSaleOrder.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSaleOrder.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSaleOrder.Items.Item("t_docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSaleOrder.Items.Item("t_docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSaleOrder.Items.Item("t_docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSaleOrder.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSaleOrder.Items.Item("t_docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            'frmSaleOrder.Items.Item("c_postaus").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSaleOrder.Items.Item("bt_item").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)

            frmSaleOrder.Items.Item("t_custcode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            frmSaleOrder.Items.Item("t_custcode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            frmSaleOrder.Items.Item("t_custcode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            frmSaleOrder.Items.Item("t_custname").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            frmSaleOrder.Items.Item("t_custname").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            frmSaleOrder.Items.Item("t_custname").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            frmSaleOrder.Items.Item("44").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)   ' Add
            frmSaleOrder.Items.Item("44").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            frmSaleOrder.Items.Item("44").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try
            frmSaleOrder.Freeze(True)
            Createform = True

            frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE
            oGfun.SetNewLine(oMatrix, oDBDSDetail)

            oMatrix.CommonSetting.SetCellEditable(1, 1, True)
            oMatrix.CommonSetting.SetCellEditable(1, 3, True)
            oMatrix.CommonSetting.SetCellEditable(1, 4, True)
            oMatrix.CommonSetting.SetCellEditable(1, 5, True)
            oMatrix.CommonSetting.SetCellEditable(1, 9, True)
            oMatrix.CommonSetting.SetCellEditable(1, 11, True)
            oMatrix.CommonSetting.SetCellEditable(1, 14, True)
            oMatrix.CommonSetting.SetCellEditable(1, 15, True)
            oMatrix.CommonSetting.SetCellEditable(1, 16, True)
            oMatrix.CommonSetting.SetCellEditable(1, 17, True)

            ' oGfun.SetNewLine(oMatrix1, oDBDSDetail1)
            oGfun.LoadComboBoxSeries(frmSaleOrder.Items.Item("c_series").Specific, UDOID, "", "")
            oGfun.LoadDocumentDate(frmSaleOrder.Items.Item("t_docdate").Specific)
            oGfun.LoadDocumentDate(frmSaleOrder.Items.Item("t_postdt").Specific)
            oGfun.LoadDocumentDate(frmSaleOrder.Items.Item("t_valdt").Specific)
            'oGfun.LoadLocationComboBox(frmSaleOrder.Items.Item("c_location").Specific)
            oGfun.LoadLocationComboBox(oMatrix.Columns.Item("location").Cells.Item(1).Specific)
            'oGfun.LoadSalesEmployeeComboBox(frmSaleOrder.Items.Item("33").Specific)

            oGfun.setComboBoxValue(frmSaleOrder.Items.Item("33").Specific, "SELECT ""SlpCode"",""SlpName"" FROM OSLP")
            oGfun.setComboBoxValue(frmSaleOrder.Items.Item("c_shiptype").Specific, "SELECT ""TrnspCode"",""TrnspName"" FROM OSHP")
            oGfun.setComboBoxValue(oMatrix.Columns.Item("taxcode").Cells.Item(1).Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O'")
            oGfun.setComboBoxValue(frmSaleOrder.Items.Item("t_payterm").Specific, "SELECT ""GroupNum"",""PymntGroup"" FROM OCTG")

            '      oGfun.setComboBoxValue(frmSaleOrder.Items.Item("t_councode").Specific, "select Code,Name from [@COUNTRY]")

            'oDBDSHeader.SetValue("U_POStatus", 0, "D")
            frmSaleOrder.Items.Item("bt_item").Visible = True
            frmSaleOrder.Items.Item("bt_post").Visible = False
            'frmSaleOrder.Items.Item("b_Print").Visible = False
            '  frmSaleOrder.Items.Item("b_Print1").Visible = False

            Dim Str2 As String = "SELECT ""empID"",""lastName"" || ',' || ""firstName"" ""empName"" FROM OHEM Where ""userId"" ='" & oCompany.UserSignature & "'"
            Dim Rst2 As SAPbobsCOM.Recordset = oGfun.DoQuery(Str2)

            If Rst2.Fields.Item("empID").Value <> 0 Then
                oDBDSHeader.SetValue("U_OwnerCode", 0, Rst2.Fields.Item("empID").Value)
                oDBDSHeader.SetValue("U_OwnerName", 0, Rst2.Fields.Item("empName").Value)
            End If



            Dim sQuery As String = String.Empty
            Dim Str As String = "select * from OEXD"
            Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
            If rset.RecordCount > 0 Then
                rset.MoveFirst()
                For i As Integer = 1 To rset.RecordCount
                    oDBDSDetail2.InsertRecord(oDBDSDetail2.Size)
                    oDBDSDetail2.Offset = oDBDSDetail2.Size - 1
                    oDBDSDetail2.SetValue("LineID", oDBDSDetail2.Offset, oDBDSDetail2.Size)
                    oDBDSDetail2.SetValue("U_UniqID", oDBDSDetail2.Offset, 0)
                    oDBDSDetail2.SetValue("U_ExpnsCode", oDBDSDetail2.Offset, rset.Fields.Item("ExpnsCode").Value)
                    oDBDSDetail2.SetValue("U_ExpnsName", oDBDSDetail2.Offset, rset.Fields.Item("ExpnsName").Value)
                    oDBDSDetail2.SetValue("U_RevAcct", oDBDSDetail2.Offset, rset.Fields.Item("RevAcct").Value)
                    oDBDSDetail2.SetValue("U_DistrbMthd", oDBDSDetail2.Offset, rset.Fields.Item("DistrbMthd").Value)
                    oDBDSDetail2.SetValue("U_ExpnsAcct", oDBDSDetail2.Offset, rset.Fields.Item("ExpnsAcct").Value)
                    oDBDSDetail2.SetValue("U_VatGroup", oDBDSDetail2.Offset, rset.Fields.Item("VatGroupI").Value)
                    oDBDSDetail2.SetValue("U_TotBefDis", oDBDSDetail2.Offset, oDBDSHeader.GetValue("U_TotBefDcnt", 0).Trim)

                    'oDBDSDetail2.SetValue("U_Remarks", oDBDSDetail2.Offset, "Deffffff")

                    rset.MoveNext()
                Next
                oMatrix2.LoadFromDataSource()
            End If

            frmSaleOrder.PaneLevel = 1
            frmSaleOrder.ActiveItem = "t_custcode"

            frmSaleOrder.Freeze(False)
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            frmSaleOrder.Freeze(False)
        Finally
        End Try
    End Sub


    Sub GetDate()
        Dim StrDate As String = "  select U_PVDate from [@INS_OCMSS]  "
        Dim RsetDate As SAPbobsCOM.Recordset = oGfun.DoQuery(StrDate)
        If RsetDate.RecordCount > 0 Then
            Dim StrSetDate As String = "   Select  DateAdd(DD," & RsetDate.Fields.Item(0).Value & " , GetDate())"
            Dim RsetSetDate As SAPbobsCOM.Recordset = oGfun.DoQuery(StrSetDate)
            If RsetSetDate.RecordCount > 0 Then
                oDBDSHeader.SetValue("U_DocDueDate", 0, CDate(RsetSetDate.Fields.Item(0).Value).ToString("yyyyMMdd"))
            End If
        End If

    End Sub
    Function ValidateAll() As Boolean
        Try

            oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemname", oDBDSDetail)

            'frmSaleOrder.Items.Item("t_find").Specific.value = ""
            If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then

                If frmSaleOrder.Items.Item("t_custcode").Specific.value.Equals("") Then
                    oApplication.StatusBar.SetText("CardCode Should Not be left Empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    frmSaleOrder.Items.Item("t_custcode").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                    Return False
                End If
            End If

            If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then
                If oMatrix.VisualRowCount = 1 Then

                    If oMatrix.Columns.Item("itemcode").Cells.Item(1).Specific.value.Equals("") = True Then
                        oApplication.StatusBar.SetText(" Line ID[" & 1 & "]  ItemCode Should Not be left empty..", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                        oMatrix.Columns.Item("itemcode").Cells.Item(1).Click()
                        Return False
                    End If
                    If oMatrix.Columns.Item("qty").Cells.Item(1).Specific.value.Equals("0.0") Then
                        oApplication.StatusBar.SetText("Qty Should Not be left Empty....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                        oMatrix.Columns.Item("qty").Cells.Item(1).Click()
                        Return False
                    End If


                End If
            End If

            If oMatrix.VisualRowCount > 1 Then
                For i As Integer = 1 To oMatrix.VisualRowCount
                    'If oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value.Equals("0.0") = True Then
                    '    oApplication.StatusBar.SetText(" Line ID[" & i & "]  ItemCode Should Not be..", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    '    oMatrix.Columns.Item("itemcode").Cells.Item(i).Click()
                    '    Return False
                    'End If
                    If oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value.Equals("0.0") = True Then
                        oApplication.StatusBar.SetText(" Line ID[" & i & "]  Quantity Should Not be left Zero..", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                        oMatrix.Columns.Item("qty").Cells.Item(i).Click()
                        Return False
                    End If
                    If oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value.Equals("") = True Then
                        oApplication.StatusBar.SetText(" Line ID[" & i & "]  ItemCode Should Not be left empty..", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                        oMatrix.Columns.Item("itemcode").Cells.Item(i).Click()
                        Return False
                    End If
                    If oMatrix.Columns.Item("whscode").Cells.Item(i).Specific.value.Equals("") = True Then
                        oApplication.StatusBar.SetText(" Line ID[" & i & "]  whscode Should Not be left empty..", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                        oMatrix.Columns.Item("whscode").Cells.Item(i).Click()
                        Return False
                    End If


                Next
            End If


            'For i As Integer = 1 To oMatrix.VisualRowCount
            '    sQuery = String.Empty
            '    sQuery = "SELECT B.* FROM ORDR A, RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND  A.""U_BaseType""='ORDR' AND A.""CANCELED""='N'"
            '    sQuery += " AND CAST(B.""U_BaseEntry"" AS INT)='" & Trim(oDBDSHeader.GetValue("DocEntry", 0)) & "' and CAST(B.""U_BaseLine"" AS INT)='" & i.ToString & "'"
            '    Dim RstChkSO As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            'Next


            'Dim result1 As DialogResult = MessageBox.Show("Do You Want to Save?", "Sales System Message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

            'If result1 = DialogResult.Yes Then
            '    Return True
            'ElseIf result1 = DialogResult.No Then
            '    Return False
            'End If

            ValidateAll = True
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            ValidateAll = False
        Finally
        End Try
    End Function
    Sub LoadFrieghtChargesSubGrid(ByVal RowID As Integer)
        Try
            Dim Flag As Boolean
            'Dim HeatNoChecking As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            If oGfun.FormExist(FrieghtChargesSubFormID) = False Then
                oGfun.AddXML("FrieghtCharges.xml")
                oApplication.Forms.Item(FrieghtChargesSubFormID).Select()
            End If
            frmFrieghtChargesSubGrid = oApplication.Forms.Item(FrieghtChargesSubFormID)
            oMatSub = frmFrieghtChargesSubGrid.Items.Item("Matrix2").Specific
            oDBDSSubDetail2 = frmFrieghtChargesSubGrid.DataSources.DBDataSources.Item("@INS_FRC2")
            oMatSub.Columns.Item("NetAmt").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
            oMatSub.Columns.Item("GrsAmnt").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
            oDBDSSubDetail2.Clear()
            oMatSub.Clear()


            If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE Then frmFrieghtChargesSubGrid.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
            Dim ItemCode As String = ""

            If oMatrix2.VisualRowCount = 0 Then

10:
                Dim sQuery As String = String.Empty
                Dim Str As String = "select * from OEXD"
                Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                If rset.RecordCount > 0 Then
                    ' oMatSub.Clear()
                    ' oDBDSSubDetail2.Clear()
                    rset.MoveFirst()
                    For i As Integer = 1 To rset.RecordCount
                        oDBDSSubDetail2.InsertRecord(oDBDSSubDetail2.Size)
                        oDBDSSubDetail2.Offset = oDBDSSubDetail2.Size - 1
                        oDBDSSubDetail2.SetValue("LineID", oDBDSSubDetail2.Offset, oDBDSSubDetail2.Size)
                        oDBDSSubDetail2.SetValue("U_ExpnsCode", oDBDSSubDetail2.Offset, rset.Fields.Item("ExpnsCode").Value)
                        oDBDSSubDetail2.SetValue("U_ExpnsName", oDBDSSubDetail2.Offset, rset.Fields.Item("ExpnsName").Value)
                        oDBDSSubDetail2.SetValue("U_RevAcct", oDBDSSubDetail2.Offset, rset.Fields.Item("RevAcct").Value)
                        oDBDSSubDetail2.SetValue("U_DistrbMthd", oDBDSSubDetail2.Offset, rset.Fields.Item("DistrbMthd").Value)
                        oDBDSSubDetail2.SetValue("U_ExpnsAcct", oDBDSSubDetail2.Offset, rset.Fields.Item("ExpnsAcct").Value)
                        oDBDSSubDetail2.SetValue("U_VatGroup", oDBDSSubDetail2.Offset, rset.Fields.Item("VatGroupI").Value)
                        oDBDSSubDetail2.SetValue("U_TotBefDis", oDBDSSubDetail2.Offset, oDBDSHeader.GetValue("U_TotBefDcnt", 0).Trim)
                        rset.MoveNext()
                    Next
                    oMatSub.LoadFromDataSource()
                    oGfun.setComboBoxValue(oMatSub.Columns.Item("VatGroup").Cells.Item(1).Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O'")

                End If
            Else
                If oMatrix2.VisualRowCount >= 1 Then
                    Flag = False
                    For i As Integer = 1 To oMatrix2.VisualRowCount
                        If oMatrix2.Columns.Item("uniqid").Cells.Item(i).Specific.value <> "" Then
                            If oMatrix2.Columns.Item("uniqid").Cells.Item(i).Specific.value = RowID Then
                                oGfun.LoadSubGrid(oMatSub, oDBDSSubDetail2, oDBDSDetail2, RowID)
                                Flag = True
                                Exit For
                            End If
                        End If
                    Next
                    If Flag = False Then
                        GoTo 10
                    End If
                End If
            End If

            oGfun.setComboBoxValue(oMatSub.Columns.Item("VatGroup").Cells.Item(1).Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O'")

            If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE Then
                frmFrieghtChargesSubGrid.Mode = frmSaleOrder.Mode
            End If
        Catch ex As Exception
            frmFrieghtChargesSubGrid.Freeze(False)
            oApplication.StatusBar.SetText("FreightChargesSubGrid Form Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub

    Sub ItemEvent_FreightChargesSubGrid(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try

            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False Then
                            Select Case pVal.ItemUID


                                Case "Matrix2"
                                    Select Case pVal.ColUID
                                        Case "Location"
                                            'frmSaleOrder.Freeze(True)
                                            oMatSub.FlushToDataSource()
                                            oDBDSSubDetail2.SetValue("U_Location", pVal.Row - 1, Trim(oDataTable.GetValue("OcrCode", 0)))
                                            'oDBDSDetail.SetValue("U_Dscription", pVal.Row - 1, Trim(oDataTable.GetValue("ItemName", 0)))
                                            oMatSub.LoadFromDataSource()
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            'frmSaleOrder.Freeze(False)

                                        Case "Employee"
                                            oMatSub.FlushToDataSource()
                                            oDBDSSubDetail2.SetValue("U_Employee", pVal.Row - 1, Trim(oDataTable.GetValue("OcrCode", 0)))
                                            'oDBDSDetail.SetValue("U_Dscription", pVal.Row - 1, Trim(oDataTable.GetValue("ItemName", 0)))
                                            oMatSub.LoadFromDataSource()
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            'frmSaleOrder.Freeze(False)

                                        Case "OcrCode1"
                                            oMatSub.FlushToDataSource()
                                            oDBDSSubDetail2.SetValue("U_OcrCode1", pVal.Row - 1, oDataTable.GetValue("OcrCode", 0))
                                            'oDBDSSubDetail2.SetValue("U_Location", pVal.Row - 1, oDataTable.GetValue("Location", 0))
                                            oMatSub.LoadFromDataSource()
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        Case "OcrCode2"
                                            oMatSub.FlushToDataSource()
                                            oDBDSSubDetail2.SetValue("U_OcrCode2", pVal.Row - 1, oDataTable.GetValue("OcrCode", 0))
                                            ' oDBDSDetail.SetValue("U_FreeText", pVal.Row - 1, oDataTable.GetValue("Rate", 0))
                                            oMatSub.LoadFromDataSource()
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        Case "Project"
                                            oMatSub.FlushToDataSource()
                                            oDBDSSubDetail2.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue("PrjCode", 0))
                                            ' oDBDSDetail.SetValue("U_FreeText", pVal.Row - 1, oDataTable.GetValue("Rate", 0))
                                            oMatSub.LoadFromDataSource()
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)

                                    End Select
                            End Select
                        End If

                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
            End Select
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = False Then
                                    If Me.VisaAllocationSubValidation = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub
                                    Else
                                        oGfun.SaveSubGrid_Standard(oMatrix2, oDBDSDetail2, oMatSub, oDBDSSubDetail2, SubRowID)

                                        frmFrieghtChargesSubGrid.Close()

                                        oMatrix2.LoadFromDataSource()

                                        Dim Freigt As Double = 0.0
                                        Dim TaxAmt As Double = 0.0
                                        For i As Integer = 1 To oMatrix2.VisualRowCount
                                            If oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value.Equals("") = False Then
                                                Freigt += CDbl(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value) - CDbl(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.Value)
                                            End If
                                        Next
                                        oDBDSHeader.SetValue("U_Frieght", 0, Freigt)
                                        Me.HeaderTotal()
                                    End If
                                End If

                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed : " & ex.Message)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID

                            Case "Matrix2"
                                Select Case pVal.ColUID
                                    Case "VatGroup"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            If oMatSub.Columns.Item("VatGroup").Cells.Item(pVal.Row).Specific.value.Equals("") = False Then
                                                frmFrieghtChargesSubGrid.Freeze(True)
                                                oMatSub.FlushToDataSource()

                                                Dim Amt As Double = CDbl(oMatrix.Columns.Item("NetAmt").Cells.Item(pVal.Row).Specific.Value)
                                                Dim TaxPert As Double = 0.0 : Dim TaxAmt As Double = 0.0
                                                Dim LineTotal As Double = 0.0

                                                Dim TaxAmtStr As String = "SELECT * FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O' and ""Code""='" & oMatSub.Columns.Item("VatGroup").Cells.Item(pVal.Row).Specific.value & "'"
                                                Dim TaxRst As SAPbobsCOM.Recordset = oGfun.DoQuery(TaxAmtStr)
                                                oDBDSSubDetail2.SetValue("U_VatGroup", pVal.Row - 1, CDbl(TaxRst.Fields.Item("Rate").Value))
                                                TaxAmt = (Amt * CDbl(TaxRst.Fields.Item("Rate").Value) / 100)
                                                oDBDSSubDetail2.SetValue("U_TotVatAmt", pVal.Row - 1, TaxAmt)
                                                oDBDSDetail.SetValue("U_GrsAmnt", pVal.Row - 1, TaxAmt + Amt)

                                                LineTotal = LineTotal + TaxAmt

                                                oMatSub.LoadFromDataSource()
                                                frmFrieghtChargesSubGrid.Freeze(False)
                                                'oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            End If
                                        End If
                                    Case "NetAmt"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmFrieghtChargesSubGrid.Freeze(True)
                                            oMatSub.FlushToDataSource()

                                            Dim Amt As Double = CDbl(oMatSub.Columns.Item("NetAmt").Cells.Item(pVal.Row).Specific.Value)
                                            Dim TaxPert As Double = 0.0 : Dim TaxAmt As Double = 0.0
                                            Dim LineTotal As Double = 0.0

                                            Dim TaxAmtStr As String = "SELECT * FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O' and ""Code""='" & oMatSub.Columns.Item("VatGroup").Cells.Item(pVal.Row).Specific.value & "'"
                                            Dim TaxRst As SAPbobsCOM.Recordset = oGfun.DoQuery(TaxAmtStr)
                                            TaxAmt = (Amt * CDbl(TaxRst.Fields.Item("Rate").Value) / 100)
                                            oDBDSSubDetail2.SetValue("U_TotVatAmt", pVal.Row - 1, TaxAmt)
                                            oDBDSSubDetail2.SetValue("U_GrsAmnt", pVal.Row - 1, TaxAmt + Amt)

                                            LineTotal = LineTotal + TaxAmt

                                            oMatSub.LoadFromDataSource()
                                            frmFrieghtChargesSubGrid.Freeze(False)
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        End If

                                    Case "FrgPer"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmFrieghtChargesSubGrid.Freeze(True)
                                            oMatSub.FlushToDataSource()

                                            If CDbl(oMatSub.Columns.Item("FrgPer").Cells.Item(pVal.Row).Specific.Value) <> 0 Then

                                                Dim DocTotal As Double = 0.0
                                                DocTotal = (CDbl(oMatSub.Columns.Item("TotBefDis").Cells.Item(pVal.Row).Specific.Value) * CDbl(oMatSub.Columns.Item("FrgPer").Cells.Item(pVal.Row).Specific.Value)) / 100
                                                Dim Amt As Double = DocTotal
                                                Dim TaxPert As Double = 0.0 : Dim TaxAmt As Double = 0.0
                                                Dim LineTotal As Double = 0.0
                                                Dim TaxAmtStr As String = "SELECT * FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O' and ""Code""='" & oMatSub.Columns.Item("VatGroup").Cells.Item(pVal.Row).Specific.value & "'"
                                                Dim TaxRst As SAPbobsCOM.Recordset = oGfun.DoQuery(TaxAmtStr)
                                                TaxAmt = (Amt * CDbl(TaxRst.Fields.Item("Rate").Value) / 100)
                                                oDBDSSubDetail2.SetValue("U_TotVatAmt", pVal.Row - 1, TaxAmt)
                                                oDBDSSubDetail2.SetValue("U_GrsAmnt", pVal.Row - 1, TaxAmt + Amt)
                                            Else
                                                oDBDSSubDetail2.SetValue("U_TotVatAmt", pVal.Row - 1, 0)
                                                oDBDSSubDetail2.SetValue("U_GrsAmnt", pVal.Row - 1, 0)
                                            End If

                                            oMatSub.LoadFromDataSource()
                                            frmFrieghtChargesSubGrid.Freeze(False)
                                            oMatSub.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        End If

                                End Select


                        End Select
                    Catch ex As Exception
                        frmFrieghtChargesSubGrid.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    End Try
            End Select


        Catch ex As Exception
            frmFrieghtChargesSubGrid.Freeze(False)
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub

    Function VisaAllocationSubValidation() As Boolean
        Try
            Dim VisaQty As Double = 0.0
            Dim IssueQty As Double = 0.0


            VisaAllocationSubValidation = True
        Catch ex As Exception
            oApplication.StatusBar.SetText("  VisaAllocationSub Validation Method Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            VisaAllocationSubValidation = False
        Finally
        End Try
    End Function

    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try

            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False Then
                            Select Case pVal.ItemUID

                                Case "t_custcode", "t_custname"
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_CntCtCode", 0, oDataTable.GetValue("CntctPrsn", 0))
                                    oDBDSHeader.SetValue("U_PayToCode", 0, oDataTable.GetValue("BillToDef", 0))
                                    oDBDSHeader.SetValue("U_ShipToCode", 0, oDataTable.GetValue("ShipToDef", 0))

                                    oDBDSHeader.SetValue("U_SRemarks", 0, oDataTable.GetValue("Notes", 0))
                                    oDBDSHeader.SetValue("U_LRemarks", 0, oDataTable.GetValue("Free_Text", 0))


                                    oDBDSHeader.SetValue("U_CreditLimit", 0, oDataTable.GetValue("CreditLine", 0))
                                    oDBDSHeader.SetValue("U_Balance", 0, oDataTable.GetValue("Balance", 0))

                                    Dim Discount As String = "select ""Discount""  from OCRD where ""CardCode""='" & oDataTable.GetValue("CardCode", 0) & "'"
                                    Dim RsetDiscount As SAPbobsCOM.Recordset = oGfun.DoQuery(Discount)
                                    'oDBDSHeader.SetValue("U_DiscPrcnt", 0, RsetDiscount.Fields.Item("Discount").Value)

                                    Dim BusinessProperty As String = "Call BusinessProperty('" & Trim(oDataTable.GetValue("CardCode", 0)) & "') "
                                    Dim RsetBusinessProperty As SAPbobsCOM.Recordset = oGfun.DoQuery(BusinessProperty)
                                    Dim Groupcode As String = RsetBusinessProperty.Fields.Item("Code").Value
                                    Dim GroupName As String = RsetBusinessProperty.Fields.Item("GroupName").Value

                                    oGfun.setComboBoxValue(frmSaleOrder.Items.Item("c_Property").Specific, BusinessProperty)

                                    'sQuery = String.Empty
                                    ''sQuery = "SELECT Sum(T0.""Debit""- T0.""Credit"")  FROM JDT1 T0 WHERE T0.""DueDate"" <= CURRENT_DATE and T0.""Account"" <> T0.""ShortName"" and T0.""ShortName""='" & oDataTable.GetValue("CardCode", 0) & "'"
                                    'sQuery = " Select A.""CardCode"",Sum(A.""CheckSum"")As ""PDCBAL"",B.""CreditLine"",((Sum(A.""CheckSum"")+B.""Balance""))As ""Limit"" from OCHH A , "
                                    'sQuery += " OCRD B   Where ""Deposited""='N' and A.""CardCode""=B.""CardCode"" AND A.""CardCode""='" & oDataTable.GetValue("CardCode", 0) & "'  Group BY A.""CardCode"",B.""CreditLine"",""Balance"""

                                    sQuery = String.Empty
                                    sQuery = "Select T1.""Limit"" From"
                                    sQuery += " (Select (Sum(Ifnull (A.""CheckSum"",0))+B.""Balance"")As ""Limit"" ,B.""CardCode"""
                                    sQuery += " from  OCRD B  Left join OCHH A on A.""CardCode""=B.""CardCode"" and ""Deposited""='N' and ""Canceled""='N'"
                                    sQuery += " Group BY B.""CardCode"",B.""Balance"") T1 Where T1.""CardCode""='" & oDataTable.GetValue("CardCode", 0) & "'"

                                    Dim RstOverDue As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If RstOverDue.RecordCount > 0 Then
                                        oDBDSHeader.SetValue("U_Overdue", 0, RstOverDue.Fields.Item(0).Value)
                                        If oDataTable.GetValue("CreditLine", 0) < RstOverDue.Fields.Item(0).Value Then
                                            oApplication.MessageBox("Overdue Amount is higher,Please collect the payment")
                                        End If
                                    End If

                               

                                    oDBDSHeader.SetValue("U_PayTerms", 0, oDataTable.GetValue("GroupNum", 0)) 'SalesRst.Fields.Item("GroupNum").Value)
                                    Dim SalesEmpStr As String = "SELECT * FROM OSLP  WHERE ""SlpCode"" IN(SELECT ""SlpCode""  FROM OCRD Where ""CardCode"" ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "')"
                                    Dim SalesRst As SAPbobsCOM.Recordset = oGfun.DoQuery(SalesEmpStr)
                                    oDBDSHeader.SetValue("U_SlpCode", 0, SalesRst.Fields.Item("SlpCode").Value)
                                    'Dim Str As String = "SELECT  (ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','+ifnull(D.Name,''))BillTo"
                                    'Str += " FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode and a.BillToDef =b.Address "
                                    'Str += "  LEFT OUTER JOIN OCST C ON C.Code =b.State "
                                    'Str += "  LEFT OUTER JOIN OCRY D On D.Code =b.Country "
                                    'Str += "  Where A.CardCode ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and  b.AdresType  ='B'"

                                    Dim Str As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""BillTo"" "
                                    Str += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""BillToDef"" = b.""Address"" "
                                    Str += " LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" "
                                    Str += " WHERE A.""CardCode"" = '" & Trim(oDataTable.GetValue("CardCode", 0)) & "' AND b.""AdresType"" = 'B';"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

                                    'Dim Str1 As String = "SELECT  (ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','+ifnull(D.Name,''))ShipTo"
                                    'Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode and a.ShipToDef =b.Address "
                                    'Str1 += "  LEFT OUTER JOIN OCST C ON C.Code =b.State "
                                    'Str1 += "  LEFT OUTER JOIN OCRY D On D.Code =b.Country "
                                    'Str1 += "  Where A.CardCode ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and  b.AdresType  ='S'"

                                    Dim Str1 As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""ShipTo"" "
                                    Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""ShipToDef"" = b.""Address"" LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" "
                                    Str1 += " LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" WHERE A.""CardCode"" ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' AND b.""AdresType"" = 'S';"
                                    Dim Rst1 As SAPbobsCOM.Recordset = oGfun.DoQuery(Str1)

                                    oDBDSHeader.SetValue("U_Address2", 0, Rst.Fields.Item("BillTo").Value)
                                    oDBDSHeader.SetValue("U_Address", 0, Rst1.Fields.Item("ShipTo").Value)

                                    oGfun.setComboBoxValue(frmSaleOrder.Items.Item("c_billto").Specific, "SELECT  Distinct ""Address"",""Address"" FROM CRD1 Where ""CardCode""='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and ""AdresType""='B'")

                                    oGfun.setComboBoxValue(frmSaleOrder.Items.Item("c_shipto").Specific, "SELECT  Distinct ""Address"",""Address"" FROM CRD1 Where ""CardCode""='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and ""AdresType""='S'")

                                    ''oGfun.SetNewLine(oMatrix, oDBDSDetail)

                                    'Case "t_custname"
                                    '    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    '    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    '    oDBDSHeader.SetValue("U_CntCtCode", 0, oDataTable.GetValue("CntctPrsn", 0))
                                    '    'oGfun.SetNewLine(oMatrix, oDBDSDetail)

                                Case "35"
                                    oDBDSHeader.SetValue("U_OwnerCode", 0, Trim(oDataTable.GetValue("empID", 0)))
                                    oDBDSHeader.SetValue("U_OwnerName", 0, Trim(oDataTable.GetValue("lastName", 0)) & "," & Trim(oDataTable.GetValue("firstName", 0)))
                                    oDBDSHeader.SetValue("U_PreByCod", 0, Trim(oDataTable.GetValue("empID", 0)))
                                Case "t_pickwhs"
                                    oDBDSHeader.SetValue("U_PickWhs", 0, oDataTable.GetValue("WhsCode", 0))
                                Case "t_whscode"
                                    oDBDSHeader.SetValue("U_WhsCode", 0, oDataTable.GetValue("WhsCode", 0))
                                    oDBDSHeader.SetValue("U_WhsName", 0, oDataTable.GetValue("WhsName", 0))
                                    If oMatrix.VisualRowCount > 0 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(1).Specific.value <> "" Then
                                            'If oApplication.MessageBox("Do you want to chnage warehouse in row level ?", 1, "Ok", "Cancel") = 1 Then
                                            oMatrix.FlushToDataSource()
                                            For i As Integer = 1 To oMatrix.VisualRowCount
                                                oDBDSDetail.SetValue("U_WhsCode", i - 1, oDataTable.GetValue("WhsCode", 0))
                                                oDBDSDetail.SetValue("U_WhsName", i - 1, oDataTable.GetValue("WhsName", 0))
                                            Next
                                            oDBDSHeader.SetValue("U_WhsCode", 0, oDataTable.GetValue("WhsCode", 0))
                                            oDBDSHeader.SetValue("U_WhsName", 0, oDataTable.GetValue("WhsName", 0))
                                            oMatrix.LoadFromDataSource()
                                        End If
                                    End If

                                Case "Matrix"
                                    Select Case pVal.ColUID
                                        Case "itemcode"
                                            'frmSaleOrder.Freeze(True)
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_ItemCode", pVal.Row - 1, Trim(oDataTable.GetValue("ItemCode", 0)))
                                            oDBDSDetail.SetValue("U_Dscription", pVal.Row - 1, Trim(oDataTable.GetValue("ItemName", 0)))
                                            sQuery = String.Empty
                                            sQuery = "SELECT a.""DfltWH"",a.""VatGourpSa"",b.""Rate"" FROM OITM A LEFT JOIN OVTG B ON A.""VatGourpSa""=b.""Code"" WHERE ""ItemCode""='" & Trim(oDataTable.GetValue("ItemCode", 0)) & "'"
                                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If Rst.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_TaxCode", pVal.Row - 1, Rst.Fields.Item("VatGourpSa").Value)
                                                oDBDSDetail.SetValue("U_WhsCode", pVal.Row - 1, Rst.Fields.Item("DfltWH").Value)
                                            End If

                                            sQuery = String.Empty
                                            sQuery = "CALL ""@INSPL_GET_STOCK"" ('" & Trim(oDataTable.GetValue("ItemCode", 0)) & "')"
                                            Dim RstStock As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If RstStock.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_InStock", pVal.Row - 1, RstStock.Fields.Item(0).Value)
                                                oDBDSDetail.SetValue("U_Committed", pVal.Row - 1, RstStock.Fields.Item(1).Value)
                                                oDBDSDetail.SetValue("U_OnHand", pVal.Row - 1, RstStock.Fields.Item(2).Value)
                                            End If
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            'frmSaleOrder.Freeze(False)

                                        Case "itemname"
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_ItemCode", pVal.Row - 1, Trim(oDataTable.GetValue("ItemCode", 0)))
                                            oDBDSDetail.SetValue("U_Dscription", pVal.Row - 1, Trim(oDataTable.GetValue("ItemName", 0)))
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            'frmSaleOrder.Freeze(False)

                                        Case "whscode"
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_WhsCode", pVal.Row - 1, oDataTable.GetValue("WhsCode", 0))
                                            oDBDSDetail.SetValue("U_Location", pVal.Row - 1, oDataTable.GetValue("Location", 0))
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        Case "taxcode"
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_TaxCode", pVal.Row - 1, oDataTable.GetValue("Name", 0))
                                            ' oDBDSDetail.SetValue("U_FreeText", pVal.Row - 1, oDataTable.GetValue("Rate", 0))
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End Select
                            End Select
                        End If

                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        frmSaleOrder = oApplication.Forms.Item(SaleOrderNewFormID)
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            'Case "t_custcode"
                            '    If pVal.BeforeAction = False Then
                            '        Dim Str As String = "SELECT * FROM OCRD Where ""CardType"" ='C' AND ""validFor"" ='Y'"
                            '        oGfun.ChooseFromListFilteration(frmSaleOrder, "CAR_CFL", "CardCode", Str)
                            '    End If
                            'Case "t_custname"
                            '    If pVal.BeforeAction = False Then
                            '        Dim Str As String = "SELECT * FROM OCRD Where  ""CardType"" ='C' AND ""validFor"" ='Y'"
                            '        oGfun.ChooseFromListFilteration(frmSaleOrder, "CAR_CFL2", "CardCode", Str)
                            '    End If
                            'Case "t_find"
                            '    If pVal.BeforeAction = False Then
                            '        frmSaleOrder.Items.Item("t_find").Specific.value = ""
                            '    End If
                        End Select
                    Catch ex As Exception

                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            'Case "39"
                            '    If pVal.BeforeAction = False Then
                            '        Dim DiscntPrct As Double = 0.0, DiscntAmt As Double = 0.0, TotalBfrDis As Double = 0.0, Taxamount As Double = 0.0
                            '        TotalBfrDis = oDBDSHeader.GetValue("U_TotBefDcnt", 0)
                            '        DiscntPrct = oDBDSHeader.GetValue("U_DiscPrcnt", 0)
                            '        Taxamount = oDBDSHeader.GetValue("U_TaxAmount", 0)
                            '        DiscntAmt = Math.Round(CDbl(TotalBfrDis * DiscntPrct / 100), 2)
                            '        oDBDSHeader.SetValue("U_Discount", 0, DiscntAmt)
                            '        oDBDSHeader.SetValue("U_DocTotal1", 0, TotalBfrDis - DiscntAmt + Taxamount)
                            '        'Dim Round As Double = 0.0
                            '        'Round = oDBDSHeader.GetValue("U_DocTotal", 0)
                            '        'oDBDSHeader.SetValue("U_RoundDiff", 0, Round)
                            '    End If
                            Case "45"
                                If pVal.BeforeAction = False Then
                                    Dim DocTotal As Double = 0.0
                                    Dim RoundOff As Double = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
                                    Dim LineTotal As Double = CDbl(oDBDSHeader.GetValue("U_TotBefDcnt", 0))
                                    Dim Discount As Double = CDbl(oDBDSHeader.GetValue("U_Discount", 0))
                                    Dim TaxAmt As Double = CDbl(oDBDSHeader.GetValue("U_TaxAmount", 0))
                                    Dim Freight As Double = CDbl(oDBDSHeader.GetValue("U_Frieght", 0))

                                    DocTotal = LineTotal - Discount + RoundOff + Freight + TaxAmt
                                    oDBDSHeader.SetValue("U_DocTotal1", 0, DocTotal)


                                End If
                                'Case "et_remarks"
                                '    If pVal.BeforeAction = False Then

                                '        Dim DiscntPrct As Double = 0.0, DiscntAmt As Double = 0.0, TotalBfrDis As Double = 0.0, Taxamount As Double = 0.0
                                '        Dim RoundOff As Double = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
                                '        TotalBfrDis = oDBDSHeader.GetValue("U_TotBefDcnt", 0)
                                '        DiscntPrct = oDBDSHeader.GetValue("U_DiscPrcnt", 0)
                                '        Taxamount = oDBDSHeader.GetValue("U_TaxAmount", 0)
                                '        Taxamount = Math.Round(CDbl(Taxamount * DiscntPrct / 100), 2)
                                '        DiscntAmt = Math.Round(CDbl(TotalBfrDis * DiscntPrct / 100), 2)
                                '        oDBDSHeader.SetValue("U_Discount", 0, DiscntAmt)
                                '        oDBDSHeader.SetValue("U_TaxAmount", 0, Taxamount)
                                '        If DiscntPrct = 100 Then
                                '            oDBDSHeader.SetValue("U_DocTotal1", 0, 0)
                                '        Else
                                '            oDBDSHeader.SetValue("U_DocTotal1", 0, TotalBfrDis - DiscntAmt + Taxamount + RoundOff)
                                '        End If



                                '    End If
                                'Case "Matrix"
                                '    Select Case pVal.ColUID
                                '        Case "itemcode"
                                '            If pVal.BeforeAction = False Then
                                '                frmSaleOrder.Freeze(True)
                                '                'oGfun.SetNewLine(oMatrix, oDBDSDetail)
                                '                oGfun.SetNewLine(oMatrix, oDBDSDetail, pVal.Row, "itemcode")
                                '                frmSaleOrder.Freeze(False)
                                '            End If

                                'Case "qty"
                                '    If pVal.BeforeAction = True And pVal.ItemChanged = True Then
                                '        Me.MatrixLineCalculation(pVal.Row)
                                '        Me.HeaderTotal()
                                '    End If
                                'End Select
                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID


                            Case "39"
                                If pVal.BeforeAction = True And pVal.ItemChanged = True Then
                                    frmSaleOrder.Freeze(True)
                                    Dim Discount As Double = frmSaleOrder.Items.Item("39").Specific.value

                                    If Discount > 100 Then
                                        oApplication.StatusBar.SetText("Discount Percentage Should Not Be Greater Than 100...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        BubbleEvent = False
                                    End If
                                    frmSaleOrder.Freeze(False)
                                End If

                            Case "Matrix"
                                Select Case pVal.ColUID
                                    Case "itemcode"
                                        If pVal.BeforeAction = False Then
                                            oGfun.SetNewLine(oMatrix, oDBDSDetail, pVal.Row, "itemcode")
                                            Try
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 1, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 3, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 4, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 5, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 9, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 11, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 14, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 15, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 16, True)
                                                oMatrix.CommonSetting.SetCellEditable(pVal.Row + 1, 17, True)

                                            Catch ex As Exception

                                            End Try

                                        End If
                                    Case "discount"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then

                                            frmSaleOrder.Freeze(True)
                                            Dim Discount As Double = oMatrix.Columns.Item("discount").Cells.Item(pVal.Row).Specific.value
                                            If Discount > 100 Then
                                                oApplication.StatusBar.SetText("Discount Percentage Should Not Be Greater Than 100...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                BubbleEvent = False
                                            End If

                                            oMatrix.FlushToDataSource()
                                            Me.MatrixLineCalculation(pVal.Row)
                                            oMatrix.LoadFromDataSource()
                                            frmSaleOrder.Freeze(False)

                                            Me.HeaderTotal()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)

                                        End If
                                    Case "qty" ', "untprc", "discount", "et_remarks"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            Dim DiscntPrct As Double = 0.0, DiscntAmt As Double = 0.0, TotalBfrDis As Double = 0.0, Taxamount As Double = 0.0
                                            frmSaleOrder.Freeze(True)

                                            oMatrix.FlushToDataSource()
                                            Me.MatrixLineCalculation(pVal.Row)
                                            oMatrix.LoadFromDataSource()

                                            frmSaleOrder.Freeze(False)

                                            Me.HeaderTotal()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_KEY_DOWN
                    Try
                        Select Case pVal.CharPressed
                            Case "9"
                                Select Case pVal.ItemUID
                                    Case "t_find"
                                        frmSaleOrder.Freeze(True)
                                        If pVal.BeforeAction = False Then


                                            If Trim(oMatrix.Columns.Item("itemcode").Cells.Item(1).Specific.Value) <> "" Then
                                                Dim Bool As Boolean
                                                Dim Row_Clik As Integer
                                                For i As Integer = 1 To oMatrix.VisualRowCount
                                                    If Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.Value) <> "" Then
                                                        Dim ItemCode As String = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.Value)
                                                        ItemCode = ItemCode.ToUpper()
                                                        Dim sFindValue As String = Trim(frmSaleOrder.Items.Item("t_find").Specific.value)
                                                        sFindValue = sFindValue.ToUpper()
                                                        Bool = ItemCode.Contains(sFindValue)
                                                        If Bool = True Then
                                                            If sFindValue <> "" Then
                                                                oMatrix.AutoResizeColumns()
                                                                oMatrix.SelectRow(i, True, True)
                                                                oMatrix.AutoResizeColumns()
                                                                Row_Clik += i

                                                            Else
                                                                oMatrix.AutoResizeColumns()
                                                                oMatrix.SelectRow(i, False, False)
                                                                Row_Clik += i
                                                            End If
                                                        Else
                                                            oMatrix.AutoResizeColumns()
                                                            oMatrix.SelectRow(i, False, False)
                                                        End If
                                                    End If
                                                Next
                                                oMatrix.Columns.Item("qty").Cells.Item(Row_Clik).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            End If

                                        End If
                                        frmSaleOrder.Freeze(False)
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub

                                    Else

                                      

                                        'If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        '    'If oCompany.InTransaction = False Then oCompany.StartTransaction()
                                        '    If oDBDSHeader.GetValue("Status", 0).Trim = "O" Then
                                        '        If Me.TransactionManagement() = False And (frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                        '            'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                        '            BubbleEvent = False
                                        '            Exit Sub
                                        '        Else
                                        '            'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
                                        '        End If
                                        '    End If
                                        'End If
                                    End If
                                End If

                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try

                    'Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    '    Try
                    '        Select Case pVal.ItemUID
                    '            Case "Matrix"
                    '                If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                    '                    frmSaleOrder.EnableMenu("1293", False)
                    '                ElseIf frmSaleOrder.Mode <> SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                    '                    sQuery = String.Empty
                    '                    sQuery = "SELECT * FROM ORDR A,RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND ""CANCELED""='N' AND ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' AND ""U_BaseLine""='" & pVal.Row & "' AND ""U_BaseType""='ORDR'"
                    '                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    '                    If Rst.RecordCount Then
                    '                        frmSaleOrder.EnableMenu("1293", False)
                    '                    Else
                    '                        frmSaleOrder.EnableMenu("1293", True)
                    '                    End If
                    '                End If
                    '        End Select
                    '    Catch ex As Exception
                    '        oApplication.MessageBox(ex.Message)
                    '    Finally
                    '    End Try

                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "c_series"
                                If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    'Get the Serial Number Based On Series...
                                    Dim oCmbSerial As SAPbouiCOM.ComboBox = frmSaleOrder.Items.Item("c_series").Specific
                                    Dim strSerialCode As String = oCmbSerial.Selected.Value
                                    Dim strDocNum As Long = frmSaleOrder.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                                    oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                                End If
                            Case "c_billto"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    frmSaleOrder.Freeze(True)
                                    Dim BilTo As SAPbouiCOM.ComboBox = frmSaleOrder.Items.Item("c_billto").Specific
                                    Dim StrBilTo As String = BilTo.Selected.Value

                                    'Dim Str As String = "SELECT(ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','"
                                    'Str += " +ifnull(D.Name,''))BillTo FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode  "
                                    'Str += " LEFT OUTER JOIN OCST C ON C.Code =b.State   LEFT OUTER JOIN OCRY D On D.Code =b.Country  "
                                    'Str += " Where A.CardCode='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' and b.Address ='" & StrBilTo & "' and b.AdresType ='B'"

                                    Dim Str As String = "SELECT (ifnull(b.""Street"", '') || ',' || ifnull(b.""Block"", '') || ',' || ifnull(b.""City"", '') || ',' || ifnull(C.""Name"", '') || ',' || ifnull(D.""Name"", '')) AS ""BillTo"" "
                                    Str += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" "
                                    Str += " LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" WHERE A.""CardCode"" ='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' AND b.""Address"" = '" & StrBilTo & "' AND b.""AdresType"" = 'B';"

                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                                    oDBDSHeader.SetValue("U_Address2", 0, Rst.Fields.Item("BillTo").Value)
                                    frmSaleOrder.Freeze(False)
                                End If

                            Case "c_shipto"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    frmSaleOrder.Freeze(True)
                                    Dim ShipTo As SAPbouiCOM.ComboBox = frmSaleOrder.Items.Item("c_shipto").Specific
                                    Dim StrShipTo As String = ShipTo.Selected.Value

                                    'Dim Str As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""BillTo"" "
                                    'Str += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""BillToDef"" = b.""Address"" "
                                    'Str += " LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" "
                                    'Str += " WHERE A.""CardCode"" = '" & Trim(oDataTable.GetValue("CardCode", 0)) & "' AND b.""AdresType"" = 'B';"
                                    'Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

                                    'Dim Str1 As String = "SELECT  (ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','+ifnull(D.Name,''))ShipTo"
                                    'Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode and a.ShipToDef =b.Address "
                                    'Str1 += "  LEFT OUTER JOIN OCST C ON C.Code =b.State "
                                    'Str1 += "  LEFT OUTER JOIN OCRY D On D.Code =b.Country "
                                    'Str1 += "  Where A.CardCode ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and  b.AdresType  ='S'"

                                    Dim Str1 As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""ShipTo"" "
                                    Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""ShipToDef"" = b.""Address"" LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" "
                                    Str1 += " LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" WHERE A.""CardCode"" ='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' AND b.""AdresType"" = 'S' and b.""Address"" ='" & StrShipTo & "';"

                                    'Dim Str As String = "SELECT(ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','"
                                    'Str += " +ifnull(D.Name,''))ShipTo FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode  "
                                    'Str += " LEFT OUTER JOIN OCST C ON C.Code =b.State   LEFT OUTER JOIN OCRY D On D.Code =b.Country  "
                                    'Str += " Where A.CardCode='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' and b.Address ='" & StrShipTo & "' and b.AdresType ='S'"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str1)
                                    oDBDSHeader.SetValue("U_Address", 0, Rst.Fields.Item("ShipTo").Value)
                                    frmSaleOrder.Freeze(False)
                                End If
                            Case "Matrix"
                                Select Case pVal.ColUID
                                    Case "taxcode"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmSaleOrder.Freeze(True)

                                            oMatrix.FlushToDataSource()
                                            Me.MatrixLineCalculation(pVal.Row)
                                            oMatrix.LoadFromDataSource()
                                            frmSaleOrder.Freeze(False)

                                            Me.HeaderTotal()
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oGfun.StatusBarErrorMsg("Combo box Event Failed")
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "bt_item"
                                If pVal.BeforeAction = False Then
                                    Me.CreateMySimpleForm_ItemList()
                                End If
                            Case "b_cal"
                                If pVal.BeforeAction = False Then
                                    Me.Calculation()
                                End If
                            Case "IK_Frieght"
                                If pVal.BeforeAction = False Then
                                    oMatrix2.FlushToDataSource()
                                    For i As Integer = 1 To oMatrix2.VisualRowCount
                                        oDBDSDetail2.SetValue("U_TotBefDis", i - 1, oDBDSHeader.GetValue("U_TotBefDcnt", 0).Trim)
                                    Next
                                    oMatrix2.LoadFromDataSource()
                                    Me.LoadFrieghtChargesSubGrid(SubRowID)
                                End If

                            Case "b_copy"
                                If pVal.BeforeAction = False Then
                                    Me.CreateMySimpleForm_ORDR_SODetails()
                                End If
                            Case "b_Print"
                                If pVal.BeforeAction = False Then
                                    frmSaleOrder.Freeze(True)
                                    If oDBDSHeader.GetValue("U_POStatus", 0).Trim = "D" Then
                                        LoadReportProject1()
                                    ElseIf oDBDSHeader.GetValue("U_POStatus", 0).Trim = "P" Then
                                        LoadReportProject()
                                    End If
                                    frmSaleOrder.Freeze(False)
                                End If
                            Case "44"
                                If pVal.BeforeAction = False Then
                                    Dim RoundChk As SAPbouiCOM.CheckBox = frmSaleOrder.Items.Item("44").Specific
                                    If RoundChk.Checked = True Then
                                        frmSaleOrder.Items.Item("45").Enabled = True
                                    Else
                                        oDBDSHeader.SetValue("U_RoundOff", 0, 0.0)
                                        frmSaleOrder.Items.Item("45").Enabled = False
                                        Dim DocTotal As Double = 0.0
                                        Dim RoundOff As Double = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
                                        Dim LineTotal As Double = CDbl(oDBDSHeader.GetValue("U_TotBefDcnt", 0))
                                        Dim Discount As Double = CDbl(oDBDSHeader.GetValue("U_Discount", 0))
                                        Dim TaxAmt As Double = CDbl(oDBDSHeader.GetValue("U_TaxAmount", 0))
                                        Dim Freight As Double = CDbl(oDBDSHeader.GetValue("U_Frieght", 0))

                                        DocTotal = LineTotal - Discount + RoundOff + Freight + TaxAmt
                                        oDBDSHeader.SetValue("U_DocTotal1", 0, DocTotal)
                                    End If
                                End If
                            Case "1"
                                If pVal.ActionSuccess And frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If
                                If pVal.ActionSuccess = True Then
                                    If Trim(oDBDSHeader.GetValue("U_POEntry", 0)) = "" Then
                                        Dim Str As String = "SELECT * FROM ORDR  WHERE ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'  and ""U_BaseType""='ORDR'"
                                        Dim RST As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                                        If RST.RecordCount > 0 Then
                                            oDBDSHeader.SetValue("U_POEntry", 0, RST.Fields.Item("DocNum").Value)
                                        End If
                                    End If
                                    If Trim(oDBDSHeader.GetValue("U_POEntry", 0)) <> "" Then
                                        frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
                                    End If
                                End If
                                'If Trim(oDBDSHeader.GetValue("U_POEntry", 0)) <> "" Then
                                '    frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
                                'End If
                            Case "24"
                                If pVal.BeforeAction = False Then
                                    frmSaleOrder.Freeze(True)
                                    frmSaleOrder.PaneLevel = 1
                                    frmSaleOrder.Freeze(False)
                                End If
                            Case "25"
                                If pVal.BeforeAction = False Then
                                    frmSaleOrder.Freeze(True)
                                    frmSaleOrder.PaneLevel = 2
                                    frmSaleOrder.Freeze(False)
                                End If
                            Case "26"
                                If pVal.BeforeAction = False Then
                                    frmSaleOrder.Freeze(True)
                                    frmSaleOrder.PaneLevel = 3
                                    frmSaleOrder.Freeze(False)
                                End If



                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1281"
                    frmSaleOrder.ActiveItem = "t_docnum"
                Case "1292"
                    GlbRowID = oMatrix.VisualRowCount
                    oGfun.SetNewLine(oMatrix, oDBDSDetail, GlbRowID, "itemcode")
                Case "1293"
                    frmSaleOrder.Freeze(True)
                    oGfun.DeleteRow(oMatrix, oDBDSDetail)
                    'Me.MatrixLineCalculation(pVal.Row)
                    Me.HeaderTotal()

                    frmSaleOrder.Freeze(False)
                Case "1282"
                    Me.InitForm()
                Case "1284"
                    frmSaleOrder.Freeze(True)
                    Dim StrUpdate As String = "UPDATE ORDR SET ""CANCELED""='Y' , ""DocStatus""='C' from  ORDR where  ""U_BaseEntry""='" & DocEntry & "' AND ""U_BaseType""='ORDR' AND ""CANCELED""='N'"
                    Dim RsetUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(StrUpdate)
                    frmSaleOrder.Freeze(False)

                Case "1287"
                    If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                        'Get the Serial Number Based On Series...
                        Dim oCmbSerial As SAPbouiCOM.ComboBox = frmSaleOrder.Items.Item("c_series").Specific
                        Dim strSerialCode As String = oCmbSerial.Selected.Value
                        Dim strDocNum As Long = frmSaleOrder.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                        oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                    End If
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub


    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try

                        If BusinessObjectInfo.BeforeAction Then
                            oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemname", oDBDSDetail)
                        End If

                        If BusinessObjectInfo.ActionSuccess = True Then
                            'Dim Str As String = "SELECT * FROM ORDR  WHERE ""U_InvRefNo""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_InvType""='Sale Order' "
                            'Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                            'If Rst.RecordCount > 0 Then
                            '    'sQuery = String.Empty
                            '    'sQuery = "UPDATE A SET ""WhsCode""=B.""U_WhsCode"" FROM RDR1 A,""@INS_RDR1"" B WHERE CAST(A.""U_BaseEntry"" AS NVARCHAR(100))=B.""DocEntry"" AND CAST(A.""U_BaseLine"" AS NVARCHAR(100))=B.""LineId"" "
                            '    'sQuery += " AND A.""U_BaseType""='ORDR' AND B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                            '    'Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

                            '    'sQuery = String.Empty
                            '    'sQuery = "UPDATE A SET A.""U_WhsCode""=B.""U_WhsCode"" FROM ORDR A,""@INS_ORDR"" B WHERE CAST(A.""U_BaseEntry"" AS NVARCHAR(100))=B.""DocEntry"" "
                            '    'sQuery += " AND A.""U_BaseType""='ORDR' AND B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                            '    'Dim RstUpdate1 As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                            'End If

                            'Me.Posting_SaleOrder_TransactionTest(oDBDSHeader.GetValue("DocEntry", 0).Trim)

                            If oDBDSHeader.GetValue("Status", 0).Trim = "O" Then
                                If Me.TransactionManagement() = False And (frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                    'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                    BubbleEvent = False
                                    Exit Sub
                                Else
                                    'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                        BubbleEvent = False
                    Finally

                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    Try
                        If BusinessObjectInfo.ActionSuccess Then
                            frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                            For i As Integer = 1 To oMatrix.VisualRowCount
                                sQuery = "SELECT B.""LineStatus"" FROM ORDR A,RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND ""CANCELED""='N' AND  CAST(B.""U_BaseEntry"" AS INT)='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' "
                                sQuery += " AND  CAST(B.""U_BaseLine"" AS INT)='" & i.ToString & "'  AND B.""U_BaseType""='ORDR'"
                                Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                If Rst.RecordCount > 0 Then
                                    If Rst.Fields.Item("LineStatus").Value <> "O" Then
                                        oMatrix.CommonSetting.SetCellEditable(i, 1, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 3, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 4, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 5, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 9, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 11, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 14, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 15, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 16, False)
                                        oMatrix.CommonSetting.SetCellEditable(i, 17, False)
                                    Else
                                        oMatrix.CommonSetting.SetCellEditable(i, 1, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 3, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 4, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 5, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 9, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 11, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 14, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 15, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 16, True)
                                        oMatrix.CommonSetting.SetCellEditable(i, 17, True)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 1, False)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 3, False)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 4, False)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 5, False)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 9, False)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 11, False)
                                        'oMatrix.CommonSetting.SetCellEditable(i, 14, False)
                                    End If
                                    oMatrix.CommonSetting.SetCellEditable(i, 1, False)
                                Else
                                    oMatrix.CommonSetting.SetCellEditable(i, 1, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 3, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 4, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 5, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 9, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 11, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 14, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 15, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 16, True)
                                    oMatrix.CommonSetting.SetCellEditable(i, 17, True)
                                End If

                            Next
                            If frmSaleOrder.Items.Item("et_remarks").Specific.value.Replace(" ", "") <> "" Then
                                frmSaleOrder.Items.Item("et_remarks").Enabled = False
                            Else
                                frmSaleOrder.Items.Item("et_remarks").Enabled = True
                            End If
                        End If

                    Catch ex As Exception
                    End Try
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                        Case "Matrix"
                            GlbRowID = oMatrix.VisualRowCount
                            If EventInfo.Row = oMatrix.VisualRowCount Then
                                frmSaleOrder.EnableMenu("1293", False)
                            Else
                                If frmSaleOrder.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    frmSaleOrder.EnableMenu("1293", False)
                                ElseIf frmSaleOrder.Mode <> SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    sQuery = String.Empty
                                    'sQuery = "SELECT * FROM ORDR A,RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND ""CANCELED""='N' AND ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' AND ""U_BaseLine""='" & EventInfo.Row & "' AND ""U_BaseType""='ORDR'"

                                    sQuery = "SELECT * FROM ORDR A,RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND ""CANCELED""='N' AND  CAST(B.""U_BaseEntry"" AS INT)='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' "
                                    sQuery += " AND  CAST(B.""U_BaseLine"" AS INT)='" & EventInfo.Row & "'  AND B.""U_BaseType""='ORDR'"

                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If Rst.RecordCount > 0 Then
                                        frmSaleOrder.EnableMenu("1293", False)
                                    Else
                                        frmSaleOrder.EnableMenu("1293", True)
                                    End If
                                End If

                                'If oMatrix.Columns.Item("APEntry").Cells.Item(EventInfo.Row).Specific.value <> "" Then
                                '    frmSaleOrder.EnableMenu("1293", False)
                                'Else
                                '    frmSaleOrder.EnableMenu("1293", True)
                                'End If
                                'frmSaleOrder.EnableMenu("1293", True)
                            End If
                    End Select
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub MatrixLineCalculation(ByVal RowID As Integer)

        Try
            frmSaleOrder.Freeze(True)

            Dim ItemCode As String = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(RowID).Specific.Value)
            Dim WhsCode As String = Trim(oMatrix.Columns.Item("whscode").Cells.Item(RowID).Specific.Value)
            Dim UnitPrice As Double = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(RowID).Specific.Value)
            Dim Quantity As Double = CDbl(oMatrix.Columns.Item("qty").Cells.Item(RowID).Specific.Value)

            Dim TaxCode As String = ""
            If oMatrix.Columns.Item("taxcode").Cells.Item(RowID).Specific.Value.Equals("") = False Then
                Dim TaxCombo As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("taxcode").Cells.Item(RowID).Specific
                TaxCode = TaxCombo.Selected.Value
            End If            
            'Dim DisPert As Double = CDbl(oMatrix.Columns.Item("discount").Cells.Item(RowID).Specific.Value)
            Dim DisAmt As Double = 0.0 : Dim Amt As Double = 0.0
            Dim TaxPert As Double = 0.0 : Dim TaxAmt As Double = 0.0
            Dim LineTotal As Double = 0.0
            Dim DiscValue As Double = 0.0
            Amt = UnitPrice * Quantity
            'Dim Discount As Double = oDBDSHeader.GetValue("U_DiscPrcnt", 0).Trim
            'If Discount > 0 Then
            '    DiscValue = (Amt / 100) * Discount              
            'End If

            LineTotal = UnitPrice * Quantity
            If Amt = 0 Then
                oDBDSDetail.SetValue("U_TaxAmount", RowID - 1, 0)
                'oDBDSDetail.SetValue("U_DisVal", RowID - 1, 0)
                oDBDSDetail.SetValue("U_NetTotal", RowID - 1, 0)
                oDBDSDetail.SetValue("U_LineTotal", RowID - 1, 0)
            Else
                'If DisPert <> 0 Then
                'DisAmt = (Amt * CDbl(DisPert)) / 100
                'oDBDSDetail.SetValue("U_DisVal", RowID - 1, DisAmt)
                LineTotal = LineTotal
                'If
                If TaxCode <> "" Then
                    Dim TaxAmtStr As String = "SELECT * FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O' and ""Code""='" & TaxCode & "'"
                    Dim TaxRst As SAPbobsCOM.Recordset = oGfun.DoQuery(TaxAmtStr)
                    TaxAmt = ((Amt - DiscValue) * CDbl(TaxRst.Fields.Item("Rate").Value) / 100)
                    oDBDSDetail.SetValue("U_TaxAmount", RowID - 1, TaxAmt)
                    LineTotal = LineTotal + TaxAmt
                Else
                    oDBDSDetail.SetValue("U_TaxAmount", RowID - 1, 0)
                End If
                oDBDSDetail.SetValue("U_NetTotal", RowID - 1, LineTotal)
            End If



            frmSaleOrder.Freeze(False)

        Catch ex As Exception
            frmSaleOrder.Freeze(False)
            oApplication.StatusBar.SetText("Calculation Function Failed:", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try


    End Sub
    Sub HeaderTotal()
        Try
            frmSaleOrder.Freeze(True)
            Dim HeadTotal As Double = 0.0, TaxTotal As Double = 0.0, TaxTotal2 As Double = 0.0, Freigt As Double = 0.0
            Dim TotalBefDiscut As Double = 0.0
            oMatrix.FlushToDataSource()
            For i As Integer = 1 To oMatrix.VisualRowCount

                'Dim LineTotal As Double = CDbl(oMatrix.Columns.Item("NetTotal").Cells.Item(i).Specific.Value)
                'Dim TaxAmt As Double = CDbl(oMatrix.Columns.Item("TaxAmt").Cells.Item(i).Specific.Value)

                HeadTotal = HeadTotal + CDbl(oMatrix.Columns.Item("NetTotal").Cells.Item(i).Specific.Value)
                TaxTotal = TaxTotal + CDbl(oMatrix.Columns.Item("TaxAmt").Cells.Item(i).Specific.Value)
                TotalBefDiscut = TotalBefDiscut + CDbl(oMatrix.Columns.Item("NetTotal").Cells.Item(i).Specific.Value) - CDbl(oMatrix.Columns.Item("TaxAmt").Cells.Item(i).Specific.Value)
            Next


            For i As Integer = 1 To oMatrix2.VisualRowCount
                If oMatrix2.Columns.Item("ExpnsCode").Cells.Item(1).Specific.Value <> "" Then
                    If oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.Value <> "" Then
                        TaxTotal2 += CDbl(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.Value)
                        Freigt += CDbl(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.Value) - CDbl(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.Value)
                    End If
                End If
            Next

            Dim RoundOff As Double = oDBDSHeader.GetValue("U_RoundOff", 0)
            oDBDSHeader.SetValue("U_TotBefDcnt", 0, TotalBefDiscut)
            Dim DiscountP As Double = 0.0
            Dim Discount As Double = 0.0
            'DiscountP = oDBDSHeader.GetValue("U_DiscPrcnt", 0)
            'Discount = (TotalBefDiscut / 100) * DiscountP
            'oDBDSHeader.SetValue("U_Discount", 0, Discount)
            If Discount > 0 Then

            End If
            oDBDSHeader.SetValue("U_TaxAmount", 0, TaxTotal + TaxTotal2)
            oDBDSHeader.SetValue("U_TaxAmount1", 0, TaxTotal + TaxTotal2)
            oDBDSHeader.SetValue("U_DocTotal1", 0, TotalBefDiscut + TaxTotal + RoundOff)
            oDBDSHeader.SetValue("U_Frieght", 0, Freigt)
            Dim doctotal As Double = (TotalBefDiscut + TaxTotal + TaxTotal2 + RoundOff + oDBDSHeader.GetValue("U_Frieght", 0).Trim) - Discount
            'Dim finaldoctotal As Double = (doctotal / 100) * oDBDSHeader.GetValue("U_DiscPrcnt", 0)
            'oDBDSHeader.SetValue("U_DocTotal1", 0, finaldoctotal) 'TotalBefDiscut + TaxTotal + TaxTotal2 + RoundOff + oDBDSHeader.GetValue("U_Frieght", 0).Trim)
            oDBDSHeader.SetValue("U_DocTotal1", 0, doctotal)

            oMatrix.LoadFromDataSource()
            frmSaleOrder.Freeze(False)
        Catch ex As Exception
            frmSaleOrder.Freeze(False)
            oApplication.StatusBar.SetText("Header Calculation Failed:", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try
    End Sub
    Function TransactionManagement() As Boolean
        TransactionManagement = False
        Try
            Dim POSstatus As String = oDBDSHeader.GetValue("U_POStatus", 0).Trim ' frmSaleOrder.Items.Item("c_postaus").Specific
            Dim Status As String = POSstatus
            Dim rstPosted As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim rset1 As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            Dim StrSO As String = "SELECT * FROM ORDR  WHERE ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_BaseType""='ORDR' AND ""CANCELED""='N' "
            Dim RstSO As SAPbobsCOM.Recordset = oGfun.DoQuery(StrSO)

            If Status = "P" Or Status = "" Then
                Dim Str As String = "SELECT * FROM ORDR  WHERE ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_BaseType""='ORDR'  AND ""CANCELED""='N' "
                Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                If Rst.RecordCount = 0 Then
                    'If Me.Posting_SaleOrder_TransactionTest("0", "Add") = False Then Exit Function
                    If Me.SaleOrder() = False Then Exit Function
                Else
                    'Me.Posting_SaleOrder_TransactionTest(Rst.Fields.Item("DocEntry").Value, "Update")
                    SaleOrder_Update(Rst.Fields.Item("DocEntry").Value)
                End If
            Else
                Me.Posting_SaleOrder_TransactionTest(RstSO.Fields.Item("DocEntry").Value, "Update")
                SaleOrder_Update(RstSO.Fields.Item("DocEntry").Value)
            End If

            TransactionManagement = True
        Catch ex As Exception
            TransactionManagement = False
            oApplication.MessageBox("Transaction Management Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oApplication.MessageBox(ex.Message)
        End Try
    End Function
    Function SaleOrder() As Boolean
        Try

            SaleOrder = False
            Dim SaleOrderStatus As Boolean = False
            Dim oSaleOrder As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders)

            'DocDate
            Dim dtDate As Date
            Dim stDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim first As String = stDate.Insert(4, "/")
            Dim second As String = first.Insert(7, "/")
            dtDate = DateTime.Parse(second, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSaleOrder.DocDate = dtDate

            'DocDueDate
            Dim dtDueDate As Date
            Dim stDueDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim firstDue As String = stDueDate.Insert(4, "/")
            Dim secondDue As String = firstDue.Insert(7, "/")
            dtDueDate = DateTime.Parse(secondDue, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSaleOrder.DocDueDate = dtDueDate

            'TaxDate
            Dim dtTaxDate As Date
            Dim stTaxDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim firstTax As String = stTaxDate.Insert(4, "/")
            Dim secondTax As String = firstTax.Insert(7, "/")
            dtTaxDate = DateTime.Parse(secondTax, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSaleOrder.TaxDate = dtTaxDate

            oSaleOrder.CardCode = oDBDSHeader.GetValue("U_CardCode", 0).Trim
            oSaleOrder.DocType = SAPbobsCOM.BoDocumentTypes.dDocument_Items
            oSaleOrder.DiscountPercent = CDbl(oDBDSHeader.GetValue("U_DiscPrcnt", 0))
            oSaleOrder.NumAtCard = oDBDSHeader.GetValue("U_NumAtCard", 0).Trim
            If oDBDSHeader.GetValue("U_Rounding", 0).Trim = "Y" Then
                oSaleOrder.Rounding = SAPbobsCOM.BoYesNoEnum.tYES
                oSaleOrder.RoundingDiffAmount = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
            Else
                oSaleOrder.Rounding = SAPbobsCOM.BoYesNoEnum.tNO
                oSaleOrder.RoundingDiffAmount = 0.0
            End If

            oSaleOrder.ClosingRemarks = frmSaleOrder.Items.Item("et_remarks").Specific.value

            oSaleOrder.UserFields.Fields.Item("U_InvRefNo").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSaleOrder.UserFields.Fields.Item("U_InvType").Value = "Sale Order"
            oSaleOrder.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSaleOrder.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
            oSaleOrder.UserFields.Fields.Item("U_BaseType").Value = "ORDR".ToString
            oSaleOrder.UserFields.Fields.Item("U_WhsCode").Value = Trim(oDBDSHeader.GetValue("U_WhsCode", 0))
            oSaleOrder.UserFields.Fields.Item("U_SOList").Value = Trim(oDBDSHeader.GetValue("U_SSOEntry", 0))

            For i As Integer = 1 To oMatrix.VisualRowCount
                Dim ItemCode As String = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value)
                Dim ItemSts As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("lineSts").Cells.Item(i).Specific

                If ItemCode <> "" And ItemSts.Selected.Value <> "R" Then
                    oSaleOrder.Lines.ItemCode = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.Quantity = CDbl(oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.Price = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.UnitPrice = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.DiscountPercent = CDbl(oMatrix.Columns.Item("discount").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.VatGroup = Trim(oMatrix.Columns.Item("taxcode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.WarehouseCode = Trim(oMatrix.Columns.Item("whscode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseType").Value = "ORDR".ToString
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseLine").Value = i.ToString

                    oSaleOrder.Lines.UserFields.Fields.Item("U_CardCode").Value = Trim(oMatrix.Columns.Item("CustCode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.UserFields.Fields.Item("U_CardName").Value = Trim(oMatrix.Columns.Item("CustName").Cells.Item(i).Specific.value)

                    'Dim LineSts As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("lineSts").Cells.Item(i).Specific
                    'If LineSts.Selected.Value <> "O" Then
                    '    oSaleOrder.Lines.LineStatus = SAPbobsCOM.BoStatus.bost_Close
                    'End If

                    oSaleOrder.Lines.Add()
                End If
            Next
            For i As Integer = 1 To oMatrix2.VisualRowCount
                If Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value) <> "" Then
                    oSaleOrder.Expenses.ExpenseCode = Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value)
                    oSaleOrder.Expenses.TaxCode = Trim(oMatrix2.Columns.Item("VatGroup").Cells.Item(i).Specific.value)
                    oSaleOrder.Expenses.LineTotal = Trim(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value) - Trim(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.value)
                    oSaleOrder.Expenses.Remarks = Trim(oMatrix2.Columns.Item("Remarks").Cells.Item(i).Specific.value)
                    oSaleOrder.Expenses.Add()
                End If
            Next



            ' Dim AAAAA As String = oSaleOrder.GetAsXML()
            If oSaleOrder.Add = 0 Then
                SaleOrderStatus = True
            Else
                SaleOrderStatus = False
            End If

            If SaleOrderStatus Then
                SaleOrder = True
                sQuery = String.Empty
                sQuery = "UPDATE B SET B.""U_SOEntry""=A.""DocEntry"",B.""U_SONum""=A.""DocNum"" FROM ORDR A,""@INS_ORDR"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='ORDR' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                sQuery = String.Empty
                sQuery = "SELECT A.* FROM ORDR A,""@INS_ORDR"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='ORDR' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                If Rst.RecordCount > 0 Then
                    oDBDSHeader.SetValue("U_SOEntry", 0, Rst.Fields.Item("DocEntry").Value)
                    oDBDSHeader.SetValue("U_SONum", 0, Rst.Fields.Item("DocNum").Value)
                End If
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSaleOrder)
            Else
                oApplication.StatusBar.SetText("Failed to Post SaleOrder  " & oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                oApplication.MessageBox("Failed to Post SaleOrder  " & oCompany.GetLastErrorDescription)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSaleOrder)
            End If

        Catch ex As Exception
            SaleOrder = False
            oApplication.StatusBar.SetText("Failed to Post SaleOrder:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            oApplication.MessageBox("Failed to Post SaleOrder:" & ex.Message)
        Finally
        End Try
    End Function

    Function SaleOrder_Update(ByVal DocEntry As String) As Boolean
        Try

            SaleOrder_Update = False
            Dim SaleOrderStatus As Boolean = False
            Dim oSaleOrder As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders)
            oSaleOrder.GetByKey(DocEntry)

            oSaleOrder.DiscountPercent = CDbl(oDBDSHeader.GetValue("U_DiscPrcnt", 0))
            oSaleOrder.NumAtCard = oDBDSHeader.GetValue("U_NumAtCard", 0).Trim
            If oDBDSHeader.GetValue("U_Rounding", 0).Trim = "Y" Then
                oSaleOrder.Rounding = SAPbobsCOM.BoYesNoEnum.tYES
                oSaleOrder.RoundingDiffAmount = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
            Else
                oSaleOrder.Rounding = SAPbobsCOM.BoYesNoEnum.tNO
                oSaleOrder.RoundingDiffAmount = 0.0
            End If


            oSaleOrder.UserFields.Fields.Item("U_InvRefNo").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSaleOrder.UserFields.Fields.Item("U_InvType").Value = "Sale Order"
            oSaleOrder.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSaleOrder.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
            oSaleOrder.UserFields.Fields.Item("U_BaseType").Value = "ORDR".ToString
            oSaleOrder.UserFields.Fields.Item("U_WhsCode").Value = Trim(oDBDSHeader.GetValue("U_WhsCode", 0))
            oSaleOrder.ClosingRemarks = frmSaleOrder.Items.Item("et_remarks").Specific.value
            oSaleOrder.UserFields.Fields.Item("U_SOList").Value = Trim(oDBDSHeader.GetValue("U_SSOEntry", 0))

            Dim AddLine As Boolean = False

            For i As Integer = 1 To oMatrix.VisualRowCount
                sQuery = String.Empty
                sQuery = "SELECT B.* FROM ORDR A, RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND  A.""U_BaseType""='ORDR' AND A.""CANCELED""='N'"
                sQuery += " AND CAST(B.""U_BaseEntry"" AS INT)='" & Trim(oDBDSHeader.GetValue("DocEntry", 0)) & "' and CAST(B.""U_BaseLine"" AS INT)='" & i.ToString & "'"
                Dim RstChkSO As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                If RstChkSO.RecordCount = 0 Then
                    If AddLine = False Then
                        oSaleOrder.Lines.Add()
                        AddLine = True
                    End If
                    oSaleOrder.Lines.ItemCode = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.Quantity = CDbl(oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.Price = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.UnitPrice = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.DiscountPercent = CDbl(oMatrix.Columns.Item("discount").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.VatGroup = Trim(oMatrix.Columns.Item("taxcode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.WarehouseCode = Trim(oMatrix.Columns.Item("whscode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseType").Value = "ORDR".ToString
                    oSaleOrder.Lines.UserFields.Fields.Item("U_BaseLine").Value = i.ToString
                    oSaleOrder.Lines.UserFields.Fields.Item("U_CardCode").Value = Trim(oMatrix.Columns.Item("CustCode").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.UserFields.Fields.Item("U_CardName").Value = Trim(oMatrix.Columns.Item("CustName").Cells.Item(i).Specific.value)
                    oSaleOrder.Lines.Add()
                ElseIf RstChkSO.RecordCount > 0 Then
                    Dim LineSts As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("lineSts").Cells.Item(i).Specific
                    If LineSts.Selected.Value <> "O" Then
                        oSaleOrder.Lines.SetCurrentLine(i - 1)
                        oSaleOrder.Lines.LineStatus = SAPbobsCOM.BoStatus.bost_Close
                    Else
                        oSaleOrder.Lines.SetCurrentLine(i - 1)
                        oSaleOrder.Lines.ItemCode = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.Quantity = CDbl(oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.Price = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.UnitPrice = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.DiscountPercent = CDbl(oMatrix.Columns.Item("discount").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.VatGroup = Trim(oMatrix.Columns.Item("taxcode").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.WarehouseCode = Trim(oMatrix.Columns.Item("whscode").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
                        oSaleOrder.Lines.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
                        oSaleOrder.Lines.UserFields.Fields.Item("U_BaseType").Value = "ORDR".ToString
                        oSaleOrder.Lines.UserFields.Fields.Item("U_BaseLine").Value = i.ToString
                        oSaleOrder.Lines.UserFields.Fields.Item("U_CardCode").Value = Trim(oMatrix.Columns.Item("CustCode").Cells.Item(i).Specific.value)
                        oSaleOrder.Lines.UserFields.Fields.Item("U_CardName").Value = Trim(oMatrix.Columns.Item("CustName").Cells.Item(i).Specific.value)
                        'oSaleOrder.Lines.Add()
                    End If
                End If
            Next
         
            For i As Integer = 1 To oMatrix2.VisualRowCount
                If Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value) <> "" Then
                    Dim Add_Update As Boolean = False
                    For ExpLine As Integer = 0 To oSaleOrder.Expenses.Count - 1
                        oSaleOrder.Expenses.SetCurrentLine(ExpLine)
                        If Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value) = oSaleOrder.Expenses.ExpenseCode Then
                            oSaleOrder.Expenses.ExpenseCode = Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value)
                            oSaleOrder.Expenses.TaxCode = Trim(oMatrix2.Columns.Item("VatGroup").Cells.Item(i).Specific.value)
                            oSaleOrder.Expenses.LineTotal = Trim(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value) - Trim(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.value)
                            oSaleOrder.Expenses.Remarks = Trim(oMatrix2.Columns.Item("Remarks").Cells.Item(i).Specific.value)
                            oSaleOrder.Expenses.Add()
                            Add_Update = True
                        End If
                    Next
                    If Add_Update = False Then
                        oSaleOrder.Expenses.ExpenseCode = Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value)
                        oSaleOrder.Expenses.TaxCode = Trim(oMatrix2.Columns.Item("VatGroup").Cells.Item(i).Specific.value)
                        oSaleOrder.Expenses.LineTotal = Trim(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value) - Trim(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.value)
                        oSaleOrder.Expenses.Remarks = Trim(oMatrix2.Columns.Item("Remarks").Cells.Item(i).Specific.value)
                        oSaleOrder.Expenses.Add()
                    End If
                End If
            Next


            'Dim AAAAA As String = oSaleOrder.GetAsXML()
            If oSaleOrder.Update = 0 Then
                SaleOrderStatus = True
            Else
                SaleOrderStatus = False
            End If

            If SaleOrderStatus Then
                SaleOrder_Update = True
                sQuery = String.Empty
                sQuery = "UPDATE B SET B.""U_SOEntry""=A.""DocEntry"",B.""U_SONum""=A.""DocNum"" FROM ORDR A,""@INS_ORDR"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='ORDR' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                sQuery = String.Empty
                sQuery = "SELECT A.* FROM ORDR A,""@INS_ORDR"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='ORDR' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                If Rst.RecordCount > 0 Then
                    oDBDSHeader.SetValue("U_SOEntry", 0, Rst.Fields.Item("DocEntry").Value)
                    oDBDSHeader.SetValue("U_SONum", 0, Rst.Fields.Item("DocNum").Value)
                End If
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSaleOrder)
            Else
                oApplication.StatusBar.SetText("Failed to Post SaleOrder  " & oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                'MessageBox.Show(oCompany.GetLastErrorDescription, "Failed to Post SaleOrder", MessageBoxButtons.OKCancel, MessageBoxIcon.Error)
                oApplication.MessageBox("Failed to Post SaleOrder  " & oCompany.GetLastErrorDescription)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSaleOrder)
            End If

        Catch ex As Exception
            SaleOrder_Update = False
            oApplication.StatusBar.SetText("Failed to Post SaleOrder:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            oApplication.MessageBox("Failed to Post SaleOrder:" & ex.Message)
        Finally
        End Try
    End Function
    Public Sub New()

    End Sub


    Public Sub LoadReportProject()
        Try
            oApplication.Menus.Item("4873").Activate()
            Dim objcrystalform As SAPbouiCOM.Form
            Dim objcrystalinputform As SAPbouiCOM.Form
            objcrystalform = oApplication.Forms.GetForm("410000003", 1)
            objcrystalform.Items.Item("410000004").Specific.string = System.Windows.Forms.Application.StartupPath & "\Sale Order.rpt"
            objcrystalform.Items.Item("410000001").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform = oApplication.Forms.GetForm("410000100", 1)

            Dim oCmbSeries As SAPbouiCOM.EditText = objcrystalinputform.Items.Item("1000003").Specific
            oCmbSeries.Value = frmSaleOrder.Items.Item("t_docnum").Specific.string

            objcrystalinputform.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalform.Items.Item("410000002").Click(SAPbouiCOM.BoCellClickType.ct_Regular)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub LoadReportProject1()
        Try
            oApplication.Menus.Item("4873").Activate()
            Dim objcrystalform As SAPbouiCOM.Form
            Dim objcrystalinputform As SAPbouiCOM.Form
            objcrystalform = oApplication.Forms.GetForm("410000003", 1)
            objcrystalform.Items.Item("410000004").Specific.string = System.Windows.Forms.Application.StartupPath & "\Sale Order2.rpt"
            objcrystalform.Items.Item("410000001").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform = oApplication.Forms.GetForm("410000100", 1)

            Dim oCmbSeries As SAPbouiCOM.EditText = objcrystalinputform.Items.Item("1000003").Specific
            oCmbSeries.Value = frmSaleOrder.Items.Item("t_docnum").Specific.string

            objcrystalinputform.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalform.Items.Item("410000002").Click(SAPbouiCOM.BoCellClickType.ct_Regular)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Sub SchemeDetails_CreateMySimpleForm(ByVal ItemCode As String, ByVal Qty As Integer)
        Try
            'boolFilterItem = True

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)

            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim ocheckbox As SAPbouiCOM.CheckBox
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oEdit As SAPbouiCOM.EditText

            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SCM"
            CP.FormType = "203"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 

            oForm.Height = 300
            oForm.Width = 600
            oForm.Title = "Supplier Scheme Details"


            oForm.AutoManaged = True

            If oForm.Selected = True Then

            End If
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 20
            oItem.Top = 30
            oItem.Width = 550
            oItem.Height = 200
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")


            ' Add CANCEL Button 

            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 240
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            Dim Str As String = "     SELECT A.DocEntry ,A.U_SchmDescrt ,A.U_ValidFrom ,A.U_ValidTo ,B.U_ItemCode ,B.U_Qty1 QTY ,B.U_Discount1 DISCOUNT ,B.U_FOCQty1  FOCQty"
            Str += " FROM [@INS_OSSH] a INNER jOIN [@INS_SSH1] B ON A.DocEntry=B.DocEntry "
            Str += " WHERE A.U_SchmTyp = 'IL' AND A.U_Status = 'A' AND B.U_Qty1 <> 0 "
            Str += " AND '" & oDBDSHeader.GetValue("U_DocDate", 0).Trim & "' BETWEEN A.U_ValidFrom AND A.U_ValidTo AND B.U_ItemCode = '" & Trim(ItemCode) & "' AND B.U_Qty1 > '" & Qty & "'"
            Str += "  UNION ALL "
            Str += " SELECT A.DocEntry ,A.U_SchmDescrt ,A.U_ValidFrom ,A.U_ValidTo ,B.U_ItemCode ,B.U_Qty2 QTY ,B.U_Discount2 DISCOUNT ,B.U_FOCQty2 FOCQty "
            Str += " FROM [@INS_OSSH] a INNER jOIN [@INS_SSH1] B ON A.DocEntry=B.DocEntry "
            Str += "WHERE A.U_SchmTyp = 'IL' AND A.U_Status = 'A' AND B.U_Qty2 <> 0 "
            Str += " AND '" & oDBDSHeader.GetValue("U_DocDate", 0).Trim & "' BETWEEN A.U_ValidFrom AND A.U_ValidTo AND B.U_ItemCode = '" & Trim(ItemCode) & "' AND B.U_Qty2 > '" & Qty & "'"
            Str += "   UNION ALL "
            Str += " SELECT A.DocEntry ,A.U_SchmDescrt ,A.U_ValidFrom ,A.U_ValidTo ,B.U_ItemCode ,B.U_Qty3 QTY ,B.U_Discount3 DISCOUNT ,B.U_FOCQty3  FOCQty"
            Str += " FROM [@INS_OSSH] a INNER jOIN [@INS_SSH1] B ON A.DocEntry=B.DocEntry "
            Str += " WHERE A.U_SchmTyp = 'IL' AND A.U_Status = 'A' AND B.U_Qty3 <> 0 "
            Str += " AND '" & oDBDSHeader.GetValue("U_DocDate", 0).Trim & "' BETWEEN A.U_ValidFrom AND A.U_ValidTo AND B.U_ItemCode = '" & Trim(ItemCode) & "' AND B.U_Qty3 > '" & Qty & "'"


            oForm.DataSources.DataTables.Item(0).ExecuteQuery(Str)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()
            oGrid.Columns.Item(0).Editable = False
            oGrid.Columns.Item(1).Editable = False
            oGrid.Columns.Item(2).Editable = False
            oGrid.Columns.Item(3).Editable = False
            oGrid.Columns.Item(2).FontSize = 12
            oGrid.Columns.Item(3).FontSize = 12
            oGrid.Columns.Item(2).TextStyle = 1
            oGrid.Columns.Item(3).TextStyle = 1

            oGrid.Columns.Item(2).ForeColor = "876543"
            oGrid.Columns.Item(3).ForeColor = "584521"

            oGrid.AutoResizeColumns()

            oForm.Visible = True
        Catch ex As Exception
            oForm.Visible = True
            oApplication.StatusBar.SetText(" Transfer Of Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Sub CreateMySimpleForm_ItemList()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "ORDRItemList"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Item Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 70
            oItem.Width = 675
            oItem.Height = 200
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            ' Add OK Button 
            oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 160
            oItem.Top = 280
            oItem.Width = 70
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Clear & Add"

            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_itmgrp", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_itmgrp"
            oLabel = oItem.Specific
            oLabel.Caption = "Item Group"


            '----------------------------------------
            ''Item Group
            'oItem = oForm.Items.Add("U_DocNum", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155
            'oItem.Top = 10
            'oItem.Width = 74
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_DocNum", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_DocNum")
            'oItem.Enabled = True



            'Item Group
            oItem = oForm.Items.Add("ItmGrpCd", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10
            oItem.Width = 150
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpCd", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditBox.DataBind.SetBound(True, "", "U_ItmGrpCd")
            ' oItem.Enabled = False

            Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            ocfls = oForm.ChooseFromLists
            Dim ITMGRP_CFL As SAPbouiCOM.ChooseFromList
            Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            cflcrepa.MultiSelection = False
            cflcrepa.ObjectType = "OITM"
            cflcrepa.UniqueID = "ITMGRP_CFL"
            ITMGRP_CFL = ocfls.Add(cflcrepa)
            oEditBox.ChooseFromListUID = "ITMGRP_CFL"
            oEditBox.ChooseFromListAlias = "U_ItmGrpCode"


            ''Item Group
            'oItem = oForm.Items.Add("ItmGrpCd", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155 + 76
            'oItem.Top = 10
            'oItem.Width = 74
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpCd", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_ItmGrpCd")
            'oItem.Enabled = False
            '----------------------------------------


            'Item Group
            oItem = oForm.Items.Add("ItmGrpNm", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 310
            oItem.Top = 10
            oItem.Width = 200
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpNm", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditBox.DataBind.SetBound(True, "", "U_ItmGrpNm")
            oItem.Enabled = False



            'oItem = oForm.Items.Add("lk_grp", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
            'oItem.Left = oForm.Items.Item("t_itmgrp").Left - 13
            'oItem.Width = 10
            'oItem.Height = oForm.Items.Item("t_itmgrp").Height
            'oItem.Top = oForm.Items.Item("t_itmgrp").Top
            'oForm.Items.Item("lk_grp").LinkTo = "t_itmcode"

            'Item Group
            oItem = oForm.Items.Add("t_minprc", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10 + 16
            oItem.Width = 74
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_MinPrice", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_MinPrice")
            oItem.Enabled = False

            'Item Group
            oItem = oForm.Items.Add("t_maxprc", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155 + 76
            oItem.Top = 10 + 16
            oItem.Width = 74
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_MaxPrice", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_MaxPrice")
            oItem.Enabled = False

            'Vat Group
            oItem = oForm.Items.Add("l_MMPrice", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10 + 16
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_tax"
            oLabel = oItem.Specific
            oLabel.Caption = "Min Price / Max Price"


            'Item Group
            oItem = oForm.Items.Add("l_unitprc", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10 + 16 + 16
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_minprc"
            oLabel = oItem.Specific
            oLabel.Caption = "Unit Price"
            'Item Group
            oItem = oForm.Items.Add("UnitPrice", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10 + 16 + 16
            oItem.Width = 150
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_UnitPr", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_UnitPr")
            oItem.Enabled = True

            'oGfun.SetComboBoxValueRefresh(oForm.Items.Item("t_tax").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='O' AND ""Inactive""='N'")

            ''Item Group
            'oItem = oForm.Items.Add("t_remark", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155
            'oItem.Top = 10
            'oItem.Width = 125
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_remark", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_remark")
            'oItem.Visible = False

            'sQuery = String.Empty

            ''sQuery = "[@INSPL_AR_ItemList] '" & oDBDSHeader.GetValue("U_JobEntry", 0).Trim & "' ,'" & oDBDSHeader.GetValue("CardCode", 0).Trim & "','" & oDBDSHeader.GetValue("U_BLNo", 0).Trim & "'"
            'sQuery = "CALL ""@INSPL_SO_ItemList"" ('" & oDBDSHeader.GetValue("U_DocEntry", 0).Trim & "')"
            'oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            'oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            'oGrid.AutoResizeColumns()
            'oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
            'For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
            '    If i = 0 Then
            '        oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
            '    ElseIf i = 4 Then
            '        oGrid.Columns.Item(i).Editable = True
            '    Else
            '        oGrid.Columns.Item(i).Editable = False
            '    End If
            'Next

            'oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_ItemList(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then
                            Select Case pVal.ItemUID
                                Case "ItmGrpCd"

                                    'Dim Str As String = oForm.ActiveItem
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific

                                    oForm.Items.Item("ItmGrpNm").Enabled = True
                                    oForm.Items.Item("t_maxprc").Enabled = True
                                    oForm.Items.Item("t_minprc").Enabled = True

                                    ' oForm.Items.Item("ItmGrpCd").Enabled = True

                                    Try
                                        Txt2 = oForm.Items.Item("ItmGrpNm").Specific
                                        Txt2.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                    Catch ex As Exception

                                    End Try

                                    Try
                                        Txt2 = oForm.Items.Item("ItmGrpNm").Specific
                                        Txt2.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                    Catch ex As Exception

                                    End Try



                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_SO_GET_PRICE"" ('" & oDataTable.GetValue("DocEntry", 0) & "','" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "')"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If Rst.RecordCount > 0 Then
                                        Try
                                            Txt2 = oForm.Items.Item("t_minprc").Specific
                                            Txt2.Value = Rst.Fields.Item(0).Value
                                        Catch ex As Exception

                                        End Try
                                        Try
                                            Txt2 = oForm.Items.Item("t_maxprc").Specific
                                            Txt2.Value = Rst.Fields.Item(1).Value
                                        Catch ex As Exception

                                        End Try

                                        Try
                                            Txt2 = oForm.Items.Item("UnitPrice").Specific
                                            Txt2.Value = Rst.Fields.Item(2).Value
                                        Catch ex As Exception

                                        End Try
                                    End If

                                    Try
                                        Txt3 = oForm.Items.Item("ItmGrpCd").Specific
                                        Txt3.Value = Trim(oDataTable.GetValue("U_ItmGrpCode", 0))
                                    Catch ex As Exception

                                    End Try
                                    oForm.Items.Item("ItmGrpNm").Enabled = False
                                    oForm.Items.Item("t_maxprc").Enabled = False
                                    oForm.Items.Item("t_minprc").Enabled = False

                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_SO_ItemList"" ('" & oDataTable.GetValue("DocEntry", 0) & "')"
                                    oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
                                    oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
                                    oGrid.AutoResizeColumns()
                                    oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
                                    For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                                        If i = 0 Then
                                            oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                                        ElseIf i = oGrid.DataTable.Columns.Count - 1 Then
                                            oGrid.Columns.Item(i).Editable = True
                                            Dim ColQty As SAPbouiCOM.EditTextColumn
                                            ColQty = oGrid.Columns.Item(oGrid.Columns.Item(i).TitleObject.Caption)
                                            ColQty.ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
                                        Else
                                            oGrid.Columns.Item(i).Editable = False
                                        End If
                                    Next
                                    oGrid.AutoResizeColumns()
                            End Select
                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) > CDbl(oForm.Items.Item("t_maxprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        oForm.Items.Item("UnitPrice").Specific.value = CDbl(oForm.Items.Item("UnitPrice").Specific.value)
                                        Exit Sub
                                    End If
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) < CDbl(oForm.Items.Item("t_minprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not less than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        oForm.Items.Item("UnitPrice").Specific.value = CDbl(oForm.Items.Item("UnitPrice").Specific.value)
                                        Exit Sub
                                    End If

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0

                                    'oDBDSDetail.Clear()
                                    'oMatrix.Clear()
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    If oMatrix.VisualRowCount = 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(1).Specific.value = "" Then
                                            oDBDSDetail.Clear()
                                            oMatrix.Clear()
                                            RowID = 0
                                        End If
                                    ElseIf oMatrix.VisualRowCount > 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(oMatrix.VisualRowCount).Specific.value = "" Then
                                            oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemcode", oDBDSDetail)
                                            RowID = oMatrix.VisualRowCount
                                        End If
                                    End If

                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & RowID + 1, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

                                            oDBDSDetail.InsertRecord(oDBDSDetail.Size)
                                            oDBDSDetail.Offset = RowID
                                            oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, RowID + 1)

                                            oDBDSDetail.SetValue("U_ItemCode", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Dscription", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemName").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Quantity", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_UnitPrice", oDBDSDetail.Offset, oForm.Items.Item("UnitPrice").Specific.value)
                                            'oDBDSDetail.SetValue("U_Discount", oDBDSDetail.Offset, oDBDSHeader.GetValue("U_DiscPrcnt", 0).Trim)
                                            'Dim Amt1 As Double = oForm.Items.Item("UnitPrice").Specific.value * oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                            'Dim Val As Double = 0.0
                                            'Val = (Amt1 / 100) * oDBDSHeader.GetValue("U_DiscPrcnt", 0).Trim
                                            'oDBDSDetail.SetValue("U_DisVal", oDBDSDetail.Offset, Val)
                                            sQuery = String.Empty
                                            sQuery = "CALL ""@INSPL_GET_STOCK"" ('" & oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value & "')"
                                            Dim RstStock As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If RstStock.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_InStock", oDBDSDetail.Offset, RstStock.Fields.Item(0).Value)
                                                oDBDSDetail.SetValue("U_Committed", oDBDSDetail.Offset, RstStock.Fields.Item(1).Value)
                                                oDBDSDetail.SetValue("U_OnHand", oDBDSDetail.Offset, RstStock.Fields.Item(2).Value)
                                            End If
                                            sQuery = String.Empty
                                            sQuery = "SELECT a.""DfltWH"",a.""VatGourpSa"",b.""Rate"",c.""WhsName"" FROM OITM A LEFT JOIN OVTG B ON A.""VatGourpSa""=b.""Code""  Left join OWHS c on a.""DfltWH""=c.""WhsCode"" WHERE ""ItemCode""='" & oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value & "'"
                                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If Rst.RecordCount > 0 Then
                                                Dim TaxAmt As Double = 0.0
                                                Dim Amt As Double = oForm.Items.Item("UnitPrice").Specific.value * oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                                oDBDSDetail.SetValue("U_TaxCode", oDBDSDetail.Offset, Rst.Fields.Item("VatGourpSa").Value)
                                                oDBDSDetail.SetValue("U_WhsCode", oDBDSDetail.Offset, Rst.Fields.Item("DfltWH").Value)
                                                oDBDSDetail.SetValue("U_WhsName", oDBDSDetail.Offset, Rst.Fields.Item("WhsName").Value)
                                                TaxAmt = ((Amt) * CDbl(Rst.Fields.Item("Rate").Value) / 100)
                                                oDBDSDetail.SetValue("U_TaxAmount", oDBDSDetail.Offset, CDbl(TaxAmt))
                                                oDBDSDetail.SetValue("U_NetTotal", oDBDSDetail.Offset, CDbl(Amt) + CDbl(TaxAmt))
                                            Else
                                                Dim Amt As Double = oForm.Items.Item("UnitPrice").Specific.value * oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                                oDBDSDetail.SetValue("U_NetTotal", oDBDSDetail.Offset, Amt)
                                            End If

                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()
                                    oMatrix.LoadFromDataSource()
                                    'Me.Calculation()
                                    Me.HeaderTotal()

                                    'Dim totalbeforedisc As Double = oDBDSHeader.GetValue("U_TotBefDcnt", 0)
                                    'Dim round As Double = oDBDSHeader.GetValue("U_RoundOff", 0)
                                    'Dim Frieght As Double = oDBDSHeader.GetValue("U_Frieght", 0)
                                    'Dim DicntPrnct As Double = oDBDSHeader.GetValue("U_DiscPrcnt", 0)
                                    'Dim Tax As Double = oDBDSHeader.GetValue("U_TaxAmount", 0)




                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)


                                End If

                            Case "Clear"
                                If pVal.BeforeAction = False Then

                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) > CDbl(oForm.Items.Item("t_maxprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        Exit Sub
                                    End If
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) < CDbl(oForm.Items.Item("t_minprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not less than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        Exit Sub
                                    End If

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0
                                    ''frmSaleOrder.Freeze(True)
                                    'oMatrix.Clear()
                                    'oMatrix.AddRow()
                                    'Dim RowID As Integer = 1
                                    ''Dim DocTyp As SAPbouiCOM.ComboBox = frmSaleOrder.Items.Item("3").Specific
                                    ''DocTyp.Select("I", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                    'For i As Integer = 1 To oGrid.Rows.Count
                                    '    If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                    '        oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                    '        oMatrix.Columns.Item("itemcode").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value
                                    '        oMatrix.Columns.Item("qty").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                    '        oMatrix.Columns.Item("untprc").Cells.Item(RowID).Specific.value = oForm.Items.Item("UnitPrice").Specific.value 'oGrid.DataTable.Columns.Item("UnitPrice").Cells.Item(i - 1).Value
                                    '        'If oForm.Items.Item("t_tax").Specific.value <> "" Then
                                    '        '    Dim MainTaxCode As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
                                    '        '    Dim SubTaxCode As SAPbouiCOM.ComboBox = oForm.Items.Item("t_tax").Specific
                                    '        '    MainTaxCode.Select(SubTaxCode.Selected.Value, SAPbouiCOM.BoSearchKey.psk_ByValue)
                                    '        'End If
                                    '        RowID += 1
                                    '    End If
                                    'Next
                                    'oForm.Close()
                                    'oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                    'frmSaleOrder = oForm
                                    ''frmSaleOrder.Freeze(False)



                                    oDBDSDetail.Clear()
                                    oMatrix.Clear()
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    If oMatrix.VisualRowCount = 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(RowID).Specific.value = "" Then
                                            RowID = 0
                                        End If
                                    ElseIf oMatrix.VisualRowCount > 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(oMatrix.VisualRowCount).Specific.value = "" Then
                                            oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemcode", oDBDSDetail)
                                            RowID = oMatrix.VisualRowCount
                                        End If
                                    End If
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

                                            oDBDSDetail.InsertRecord(oDBDSDetail.Size)
                                            oDBDSDetail.Offset = RowID
                                            oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, RowID + 1)

                                            oDBDSDetail.SetValue("U_ItemCode", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Dscription", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemName").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Quantity", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_UnitPrice", oDBDSDetail.Offset, oForm.Items.Item("UnitPrice").Specific.value)
                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()

                                    'Me.Calculation()
                                    oMatrix.LoadFromDataSource()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)


                                End If
                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID
                                    Case "Quantity"
                                        If pVal.BeforeAction = False Then

                                            If oGrid.DataTable.Columns.Item("Quantity").Cells.Item(pVal.Row).Value > 0 Then
                                                oGrid.DataTable.Columns.Item("Select").Cells.Item(pVal.Row).Value = "Y"
                                            Else
                                                oGrid.DataTable.Columns.Item("Select").Cells.Item(pVal.Row).Value = "N"
                                            End If
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub
    Sub Calculation()
        Try
            Dim TotCBMQty As Double = 0.0
            Dim TotCartonQty As Double = 0.0

            For i As Integer = 1 To oMatrix.VisualRowCount
                If oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value <> "" Then
                    sQuery = String.Empty
                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value & "'"
                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    Dim CBMQty As Double = Rst.Fields.Item("U_CBM").Value
                    Dim CartonQty As Double = Rst.Fields.Item("U_SCartQty").Value
                    If CBMQty > 0 And CartonQty > 0 Then
                        TotCBMQty += CBMQty * oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value
                        TotCartonQty += oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value / CartonQty
                    End If
                    'TotCartonQty += oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value / CartonQty
                End If
            Next

            oDBDSHeader.SetValue("U_TotalCBM", 0, TotCBMQty)
            oDBDSHeader.SetValue("U_TotCartQty", 0, TotCartonQty)

            'frmSaleOrder.Items.Item("t_cbm").Enabled = True
            'frmSaleOrder.Items.Item("t_carton").Enabled = True
            'frmSaleOrder.Items.Item("t_cbm").Specific.value = TotCBMQty
            'frmSaleOrder.Items.Item("t_carton").Specific.value = TotCartonQty
            'frmSaleOrder.Items.Item("et_remarks").Specific.value = frmSaleOrder.Items.Item("et_remarks").Specific.value
            'frmSaleOrder.Items.Item("t_cbm").Enabled = False
            'frmSaleOrder.Items.Item("t_carton").Enabled = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("Calculation Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    'Sub CreateMySimpleForm_SODetails()
    '    Try

    '        Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
    '        Dim oItem As SAPbouiCOM.Item
    '        Dim oGrid As SAPbouiCOM.Grid
    '        Dim oButton As SAPbouiCOM.Button
    '        Dim oEdit As SAPbouiCOM.EditText
    '        Dim oCombo As SAPbouiCOM.ComboBox
    '        Dim oLabel As SAPbouiCOM.StaticText
    '        CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
    '        CP.UniqueID = "ORDRDetails"
    '        CP.FormType = "200"

    '        oForm = oApplication.Forms.AddEx(CP)
    '        ' Set form width and height 
    '        oForm.Height = 340
    '        oForm.Width = 700
    '        oForm.Title = "Sale Order Details"
    '        '' Add a Grid item to the form 
    '        oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
    '        ' Set the grid dimentions and position 
    '        oItem.Left = 5
    '        oItem.Top = 10
    '        oItem.Width = 675
    '        oItem.Height = 260
    '        ' Set the grid data 
    '        oGrid = oItem.Specific
    '        oForm.DataSources.DataTables.Add("MyDataTable")

    '        ' Add OK Button 
    '        oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
    '        oItem.Left = 20
    '        oItem.Top = 280
    '        oItem.Width = 65
    '        oItem.Height = 20
    '        oButton = oItem.Specific
    '        oButton.Caption = "Add"
    '        ' Add CANCEL Button 
    '        oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
    '        oItem.Left = 90
    '        oItem.Top = 280
    '        oItem.Width = 65
    '        oItem.Height = 20
    '        oButton = oItem.Specific

    '        '' Add OK Button 
    '        'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
    '        'oItem.Left = 160
    '        'oItem.Top = 280
    '        'oItem.Width = 70
    '        'oItem.Height = 20
    '        'oButton = oItem.Specific
    '        'oButton.Caption = "Clear & Add"

    '        sQuery = String.Empty
    '        sQuery = "CALL ""@INSPL_GET_SO_DETAILS""  ('" & oDBDSHeader.GetValue("U_PickWhs", 0).Trim & "')"
    '        oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
    '        oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

    '        For i As Integer = 0 To oGrid.Columns.Count - 1
    '            If i = 0 Then
    '                oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
    '            Else
    '                oGrid.Columns.Item(i).Editable = False
    '            End If
    '        Next

    '        oGrid.AutoResizeColumns()
    '        oForm.Visible = True

    '    Catch ex As Exception
    '        oForm.Visible = True

    '        oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '    Finally
    '    End Try
    'End Sub
    'Sub ItemEvent_SODetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
    '    Try
    '        Select Case pVal.EventType

    '            Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
    '                Try
    '                    Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
    '                    Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
    '                    Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
    '                    Dim oDataTable As SAPbouiCOM.DataTable
    '                    Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
    '                    oDataTable = oCFLE.SelectedObjects
    '                    Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
    '                    If Not oDataTable Is Nothing Then

    '                    End If
    '                Catch ex As Exception
    '                    ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                Finally
    '                End Try


    '            Case SAPbouiCOM.BoEventTypes.et_CLICK
    '                Try
    '                    Select Case pVal.ItemUID
    '                        Case "ok"
    '                            If pVal.BeforeAction = False Then
    '                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
    '                                Dim RowID As Integer = oMatrix.VisualRowCount
    '                                Dim DocEntryList As String = String.Empty
    '                                Dim DocCount As Integer = 0
    '                                oMatrix.Clear()
    '                                oMatrix.AddRow()

    '                                'For i As Integer = 1 To oGrid.Rows.Count
    '                                '    If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
    '                                '        If DocCount = 0 Then
    '                                '            DocEntryList = "|" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "|"
    '                                '        Else
    '                                '            DocEntryList = DocEntryList & "," & "|" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "|"
    '                                '        End If
    '                                '        DocCount += 1
    '                                '    End If
    '                                'Next

    '                                For i As Integer = 1 To oGrid.Rows.Count
    '                                    If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
    '                                        If DocCount = 0 Then
    '                                            DocEntryList = "'" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "'"
    '                                        Else
    '                                            DocEntryList = DocEntryList & "," & "'" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & "'"
    '                                        End If
    '                                        DocCount += 1
    '                                    End If
    '                                Next

    '                                sQuery = String.Empty
    '                                'sQuery = "CALL ""@INSPL_GET_SO_ITEM_DETAILS"" ('" & DocEntryList & "')"
    '                                sQuery = " SELECT ""ItemCode"",""Dscription"",""WhsCode"",""Price"",""VatGroup"",SUM(""Quantity"") ""Quantity"" FROM   RDR1 "
    '                                sQuery += " WHERE CAST(""DocEntry"" AS NVARCHAR(100)) IN (" & DocEntryList & ")"
    '                                sQuery += " GROUP BY  ""ItemCode"",""Dscription"",""WhsCode"",""Price"",""VatGroup"";"
    '                                RowID = 1
    '                                Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
    '                                If Rst.RecordCount > 0 Then
    '                                    Rst.MoveFirst()
    '                                    For j As Integer = 1 To Rst.RecordCount
    '                                        oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = Rst.Fields.Item("ItemCode").Value
    '                                        oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = Rst.Fields.Item("Quantity").Value
    '                                        oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = Rst.Fields.Item("Price").Value
    '                                        oMatrix.Columns.Item("24").Cells.Item(RowID).Specific.value = Rst.Fields.Item("WhsCode").Value

    '                                        Dim TaxCode As String = Rst.Fields.Item("VatGroup").Value
    '                                        Dim Combo As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
    '                                        Combo.Select(Rst.Fields.Item("VatGroup").Value, SAPbouiCOM.BoSearchKey.psk_ByValue)

    '                                        Rst.MoveNext()
    '                                        RowID += 1
    '                                    Next
    '                                End If

    '                                frmSaleOrder.Items.Item("t_sso").Enabled = True
    '                                frmSaleOrder.Items.Item("t_sso").Specific.value = DocEntryList
    '                                frmSaleOrder.Items.Item("16").Specific.value = frmSaleOrder.Items.Item("16").Specific.value
    '                                frmSaleOrder.Items.Item("t_sso").Enabled = False
    '                                oForm.Close()
    '                                oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
    '                                'frmSaleOrder = oForm
    '                            End If

    '                        Case "Clear"
    '                            If pVal.BeforeAction = False Then
    '                                Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
    '                                Dim CardCode As String = String.Empty
    '                                Dim CardCount As Integer = 0
    '                                oMatrix.Clear()
    '                                oMatrix.AddRow()
    '                                Dim RowID As Integer = 1
    '                                For i As Integer = 1 To oGrid.Rows.Count
    '                                    If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
    '                                        oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                                        oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value
    '                                        oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
    '                                        oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = oForm.Items.Item("UnitPrice").Specific.value 'oGrid.DataTable.Columns.Item("UnitPrice").Cells.Item(i - 1).Value
    '                                        RowID += 1
    '                                    End If
    '                                Next
    '                                oForm.Close()
    '                                oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
    '                                frmSaleOrder = oForm
    '                            End If
    '                    End Select
    '                Catch ex As Exception
    '                    frmSaleOrder.Freeze(False)
    '                    oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                Finally
    '                End Try
    '            Case SAPbouiCOM.BoEventTypes.et_VALIDATE
    '                Try
    '                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
    '                    Select Case pVal.ItemUID
    '                        Case "MyGrid"
    '                            Select Case pVal.ColUID

    '                            End Select
    '                    End Select
    '                Catch ex As Exception
    '                    oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                    oForm.Freeze(False)
    '                End Try

    '            Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
    '                Try
    '                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
    '                    Select Case pVal.ItemUID

    '                    End Select

    '                Catch ex As Exception
    '                    oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                    oForm.Freeze(False)
    '                End Try


    '            Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
    '                Try
    '                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
    '                    Select Case pVal.ItemUID
    '                        'Case "lk_grp"
    '                        '    If pVal.BeforeAction = False Then
    '                        '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
    '                        '    End If
    '                    End Select

    '                Catch ex As Exception
    '                    oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                    oForm.Freeze(False)
    '                End Try

    '        End Select
    '    Catch ex As Exception
    '        oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '        oForm.Freeze(False)
    '    End Try
    'End Sub

    Function Posting_SaleOrder_TransactionTest(ByVal SoDocEntry As Integer, ByVal Add_Update As String) As Boolean
        Posting_SaleOrder_TransactionTest = False
        Try
            Dim Flag As Boolean = False
            Dim lineItem As Boolean = False
            Dim ErrCode As Long
            Dim ErrCode1 As Long

            Dim RowLine As Integer = 1
            Dim ErrMsg As String = ""
            Dim boolRowAdded As Boolean = False

            Dim objSalesInvoice As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders)

            If Add_Update = "Update" Then
                objSalesInvoice.GetByKey(SoDocEntry)
            End If

            Dim HeaderTag, XMLHeader, XMLDetails, XMLDetails1, FooterTag, XMLData As String
            HeaderTag = ""
            XMLHeader = ""
            XMLDetails = ""
            XMLDetails1 = ""
            FooterTag = ""
            XMLData = ""

            '// Header and footer xml tag
            HeaderTag = "<BOM><BO><AdmInfo><Object>17</Object><Version>2</Version></AdmInfo>"
            FooterTag = "</BO></BOM>"

            '// Get XML Data from tables
            XMLHeader = XML_1_Header()
            XMLDetails = XML_2_LineItems()
            XMLDetails1 = XML_3_DocumentsAdditionalExpenses()

            '// Concat one file
            XMLData = HeaderTag + XMLHeader + XMLDetails + XMLDetails1 + FooterTag

            '//Convert XML File
            Dim PostingXMLFile As New XmlDocument
            PostingXMLFile.LoadXml(XMLData)
            '//Save XML file
            PostingXMLFile.Save(Path.Combine(Environment.CurrentDirectory, "SalesOrder.xml"))
            Dim XMLFilePath As String = Path.Combine(Environment.CurrentDirectory, "SalesOrder.xml")

            '//Sales Order POsting Object
            objSalesInvoice.Browser.ReadXml(XMLFilePath, 0)


            If Add_Update = "Update" Then
                ErrCode = objSalesInvoice.Update
            ElseIf Add_Update = "Add" Then
                ErrCode = objSalesInvoice.Add
            End If



            If ErrCode <> 0 Then
                oCompany.GetLastError(ErrCode, ErrMsg)
            Else
                sQuery = String.Empty
                sQuery = "UPDATE B SET B.""U_SOEntry""=A.""DocEntry"",B.""U_SONum""=A.""DocNum"" FROM ORDR A,""@INS_ORDR"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='ORDR' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                sQuery = String.Empty
                sQuery = "SELECT A.* FROM ORDR A,""@INS_ORDR"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='ORDR' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                If Rst.RecordCount > 0 Then
                    oDBDSHeader.SetValue("U_SOEntry", 0, Rst.Fields.Item("DocEntry").Value)
                    oDBDSHeader.SetValue("U_SONum", 0, Rst.Fields.Item("DocNum").Value)
                End If
                oApplication.StatusBar.SetText(" Sales Order Created Successfully.........", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            End If

            Posting_SaleOrder_TransactionTest = True
        Catch ex As Exception
            Posting_SaleOrder_TransactionTest = False
            Return False
        Finally
        End Try
    End Function
    Function XML_1_Header() As String
        Try
            Dim rsetArinvHead As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim DCArinvHead As String = "Select 'I'  ""DocType"", ""U_CardCode"" ""CardCode"",TO_NVARCHAR(""U_DocDate"", 'YYYYMMDD')  ""DocDate"", "
            DCArinvHead += " TO_NVARCHAR(""U_DocDate"", 'YYYYMMDD')  ""DocDueDate"",TO_NVARCHAR(""U_DocDate"", 'YYYYMMDD') ""TaxDate"" ,"
            DCArinvHead += " ""U_DiscPrcnt"" ""DiscountPercent"",""U_NumAtCard"" ""NumAtCard"",IFNULL(""U_Rounding"",'N') ""Rounding"",IFNULL(""U_RoundOff"",0) ""RoundingDiffAmount"","
            DCArinvHead += " 'Sale Order' ""U_InvType"",""DocEntry"" ""U_InvRefNo"",""DocEntry"" ""U_BaseEntry"","
            DCArinvHead += " ""DocNum"" ""U_BaseNum"",'ORDR' ""U_BaseType"",""U_WhsCode"" ""U_WhsCode"" "
            DCArinvHead += " from ""@INS_ORDR"" where ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"

            rsetArinvHead.DoQuery(DCArinvHead)
            Dim TranDelDataTable As New DataTable
            Dim DataSet As New DataSet
            TranDelDataTable = oGfun.ConvertRecordset(rsetArinvHead)
            DataSet.Tables.Add(TranDelDataTable.Copy)
            DataSet.DataSetName = "Documents"
            DataSet.Tables(0).TableName = "row"
            Return DataSet.GetXml
        Catch ex As Exception
            oApplication.StatusBar.SetText("Header Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Return False
        End Try
    End Function

    Function XML_2_LineItems() As String
        Try

            Dim rsetArinvHead As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim DCArinvHead As String = " Select '-1' ""BaseType"", ""U_ItemCode"" ""ItemCode""," '""AcctCode"" ""AccountCode"","
            'DCArinvHead += " ""Project"" ""ProjectCode"",""LocCode"" ""LocationCode"","
            'DCArinvHead += " ""U_UOM"" ""U_UOM"", "
            DCArinvHead += " ""U_Quantity"" ""Quantity"","
            DCArinvHead += "  ""U_UnitPrice"" ""UnitPrice"",""U_UnitPrice"" ""Price"",""U_WhsCode"" ""WarehouseCode"",""U_TaxCode"" ""TaxCode"","
            'DCArinvHead += " ""LineTotal"" ""LineTotal"""
            DCArinvHead += " ""DocEntry"" ""U_BaseEntry"" , '" & oDBDSHeader.GetValue("DocNum", 0).Trim & "' ""U_BaseNum"",'ORDR' ""U_BaseType"",""LineId"" ""U_BaseLine"","
            DCArinvHead += " CASE WHEN ""U_LineStatus""='C' THEN 'C' ELSE '' END ""LineStatus"" from ""@INS_RDR1"" where ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"

            rsetArinvHead.DoQuery(DCArinvHead)
            Dim TranDelDataTable As New DataTable
            Dim DataSet As New DataSet
            TranDelDataTable = oGfun.ConvertRecordset(rsetArinvHead)
            DataSet.Tables.Add(TranDelDataTable.Copy)
            DataSet.DataSetName = "Document_Lines"
            DataSet.Tables(0).TableName = "row"
            Return DataSet.GetXml


            Return DataSet.GetXml
        Catch ex As Exception
            'Dim strFile As String = String.Format("C:\Users\Ramesh\Desktop\P2P\ErrorLog.txt", ex.Message & "-" & DateTime.Now.ToString)
            'Dim strFile As String = String.Format("C:\addon\ErrorLog.txt", ex.Message & "-" & DateTime.Now.ToString)
            oApplication.StatusBar.SetText("LineItems Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Return False
        End Try
    End Function

    Function XML_3_DocumentsAdditionalExpenses() As String
        Try

            Dim rsetArinvHead As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim DCArinvHead As String = " Select ""U_ExpnsCode"" ""ExpenseCode"", (""U_GrsAmnt""-""U_TotVatAmt"") ""LineTotal"","
            ' DCArinvHead += " ""U_Remarks"" ""Comments"","
            DCArinvHead += "  ""U_VatGroup"" ""TaxCode"" "
            DCArinvHead += " from ""@INS_FRC2"" where ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"

            rsetArinvHead.DoQuery(DCArinvHead)
            Dim TranDelDataTable As New DataTable
            Dim DataSet As New DataSet
            TranDelDataTable = oGfun.ConvertRecordset(rsetArinvHead)
            DataSet.Tables.Add(TranDelDataTable.Copy)
            DataSet.DataSetName = "DocumentsAdditionalExpenses"
            DataSet.Tables(0).TableName = "row"
            Return DataSet.GetXml


            Return DataSet.GetXml
        Catch ex As Exception

            oApplication.StatusBar.SetText("Expenses Failed : " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Return False
        End Try
    End Function


    Sub CreateMySimpleForm_ORDR_SODetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "ORDRSODetails"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Sale Order Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 675
            oItem.Height = 260
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"

            sQuery = String.Empty
            sQuery = "CALL ""@INSPL_GET_SO_DETAILS""  ('" & oDBDSHeader.GetValue("U_PickWhs", 0).Trim & "')"
            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_SODetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then

                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    Dim DocEntryList As String = String.Empty
                                    Dim DocCount As Integer = 0
                                    'oMatrix.Clear()
                                    'oDBDSDetail1.Clear()
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            If DocCount = 0 Then
                                                DocEntryList = "" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & ""
                                            Else
                                                DocEntryList = DocEntryList & "," & "" & oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value & ""
                                            End If
                                            DocCount += 1
                                        End If
                                    Next
                                    DocEntryList = DocEntryList & ",0"

                                    oDBDSDetail.Clear()
                                    oMatrix.Clear()

                                    'sQuery = String.Empty
                                    'sQuery = " SELECT B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"",A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"","
                                    'sQuery += " SUM(A.""Quantity"") ""Quantity"" FROM  RDR1 A, ORDR B WHERE A.""DocEntry""=B.""DocEntry"" AND CAST(A.""DocEntry"" AS NVARCHAR(100)) IN (" & DocEntryList & ")"
                                    'sQuery += " GROUP BY  A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"",B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"";"

                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_GET_SO_ITEM_DETAILS"" (" & DocEntryList & ")"

                                    'sQuery = " SELECT B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"",A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"","
                                    'sQuery += " SUM(A.""Quantity"") ""Quantity"" FROM   RDR1 A,  ORDR B WHERE A.""DocEntry""=B.""DocEntry"" AND CAST(A.""DocEntry"" AS NVARCHAR(100)) IN (" & DocEntryList & ")"
                                    'sQuery += " GROUP BY  A.""ItemCode"",A.""Dscription"",A.""WhsCode"",A.""Price"",A.""VatGroup"",B.""DocNum"",A.""DocEntry"",A.""LineNum"",B.""CardCode"",B.""CardName"";"

                                    Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If rset.RecordCount > 0 Then
                                        rset.MoveFirst()
                                        For i As Integer = 1 To rset.RecordCount
                                            oApplication.StatusBar.SetText("Please wait system importing data to LIne " & i & " OutOf " & rset.RecordCount, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oDBDSDetail.InsertRecord(oDBDSDetail.Size)
                                            oDBDSDetail.Offset = oDBDSDetail.Size - 1
                                            oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, oDBDSDetail.Size)
                                            oDBDSDetail.SetValue("U_ItemCode", oDBDSDetail.Offset, rset.Fields.Item("ItemCode").Value)
                                            oDBDSDetail.SetValue("U_Dscription", oDBDSDetail.Offset, rset.Fields.Item("Dscription").Value)
                                            oDBDSDetail.SetValue("U_Quantity", oDBDSDetail.Offset, rset.Fields.Item("Quantity").Value)
                                            oDBDSDetail.SetValue("U_UnitPrice", oDBDSDetail.Offset, rset.Fields.Item("Price").Value)
                                            oDBDSDetail.SetValue("U_WhsCode", oDBDSDetail.Offset, rset.Fields.Item("WhsCode").Value)
                                            oDBDSDetail.SetValue("U_TaxCode", oDBDSDetail.Offset, rset.Fields.Item("VatGroup").Value)
                                            oDBDSDetail.SetValue("U_BaseEntry", oDBDSDetail.Offset, rset.Fields.Item("DocEntry").Value)
                                            oDBDSDetail.SetValue("U_BaseNum", oDBDSDetail.Offset, rset.Fields.Item("DocNum").Value)
                                            oDBDSDetail.SetValue("U_BaseLine", oDBDSDetail.Offset, rset.Fields.Item("LineNum").Value)
                                            oDBDSDetail.SetValue("U_BaseType", oDBDSDetail.Offset, "SBMDUBAILIVE".ToString)
                                            oDBDSDetail.SetValue("U_CustCode", oDBDSDetail.Offset, rset.Fields.Item("CardCode").Value)
                                            oDBDSDetail.SetValue("U_CustName", oDBDSDetail.Offset, rset.Fields.Item("CardName").Value)


                                            sQuery = String.Empty
                                            sQuery = "CALL ""@INSPL_GET_STOCK"" ('" & rset.Fields.Item("ItemCode").Value & "')"
                                            Dim RstStock As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If RstStock.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_InStock", oDBDSDetail.Offset, RstStock.Fields.Item(0).Value)
                                                oDBDSDetail.SetValue("U_Committed", oDBDSDetail.Offset, RstStock.Fields.Item(1).Value)
                                                oDBDSDetail.SetValue("U_OnHand", oDBDSDetail.Offset, RstStock.Fields.Item(2).Value)
                                            End If

                                            sQuery = String.Empty
                                            sQuery = "SELECT ""Rate"" FROM OVTG WHERE  ""Code""='" & rset.Fields.Item("VatGroup").Value & "'"
                                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If Rst.RecordCount > 0 Then
                                                Dim TaxAmt As Double = 0.0
                                                Dim Amt As Double = rset.Fields.Item("Price").Value * rset.Fields.Item("Quantity").Value
                                                TaxAmt = (Amt * CDbl(Rst.Fields.Item("Rate").Value) / 100)
                                                oDBDSDetail.SetValue("U_TaxAmount", oDBDSDetail.Offset, CDbl(TaxAmt))
                                                oDBDSDetail.SetValue("U_NetTotal", oDBDSDetail.Offset, CDbl(Amt) + CDbl(TaxAmt))
                                            Else
                                                Dim Amt As Double = rset.Fields.Item("Price").Value * rset.Fields.Item("Quantity").Value
                                                oDBDSDetail.SetValue("U_NetTotal", oDBDSDetail.Offset, Amt)
                                            End If

                                            rset.MoveNext()
                                        Next
                                        oMatrix.LoadFromDataSource()
                                    End If

                                    oDBDSHeader.SetValue("U_SSOEntry", 0, DocEntryList.Trim)
                                    'RowID = 1
                                    'If Rst.RecordCount > 0 Then
                                    '    Rst.MoveFirst()
                                    '    For j As Integer = 1 To Rst.RecordCount
                                    '        oMatrix.Columns.Item("1").Cells.Item(RowID).Specific.value = Rst.Fields.Item("ItemCode").Value
                                    '        oMatrix.Columns.Item("11").Cells.Item(RowID).Specific.value = Rst.Fields.Item("Quantity").Value
                                    '        oMatrix.Columns.Item("14").Cells.Item(RowID).Specific.value = Rst.Fields.Item("Price").Value
                                    '        'oMatrix.Columns.Item("24").Cells.Item(RowID).Specific.value = Rst.Fields.Item("WhsCode").Value

                                    '        Dim TaxCode As String = Rst.Fields.Item("VatGroup").Value
                                    '        Dim Combo As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
                                    '        Combo.Select(Rst.Fields.Item("VatGroup").Value, SAPbouiCOM.BoSearchKey.psk_ByValue)

                                    '        oMatrix.Columns.Item("U_BaseNum").Cells.Item(RowID).Specific.value = Rst.Fields.Item("DocNum").Value
                                    '        oMatrix.Columns.Item("U_BaseEntry").Cells.Item(RowID).Specific.value = Rst.Fields.Item("DocEntry").Value
                                    '        oMatrix.Columns.Item("U_BaseLine").Cells.Item(RowID).Specific.value = Rst.Fields.Item("LineNum").Value
                                    '        oMatrix.Columns.Item("U_BaseType").Cells.Item(RowID).Specific.value = "SBMDUBAILIVE"
                                    '        oMatrix.Columns.Item("U_CardCode").Cells.Item(RowID).Specific.value = Rst.Fields.Item("CardCode").Value
                                    '        oMatrix.Columns.Item("U_CardName").Cells.Item(RowID).Specific.value = Rst.Fields.Item("CardName").Value
                                    '        Rst.MoveNext()
                                    '        RowID += 1
                                    '    Next
                                    'End If

                                    'frmSalesOrder.Items.Item("t_sso").Enabled = True
                                    'frmSalesOrder.Items.Item("t_sso").Specific.value = DocEntryList
                                    'frmSalesOrder.Items.Item("16").Specific.value = frmSalesOrder.Items.Item("16").Specific.value
                                    'frmSalesOrder.Items.Item("t_sso").Enabled = False
                                    oForm.Close()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    'frmSalesOrder = oForm
                                End If


                        End Select
                    Catch ex As Exception
                        frmSaleOrder.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID

                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub
End Class
