﻿using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

using System.Security.Cryptography;
using System.Text;

using System.Xml;
using System.Xml.Linq;

namespace Shared
{
	public class Logw
	{

		public static string exefolder;
		public static string LMessage;
		public static string firm;
		public static string sqlConnectionString;
		public static config cnf;
		public static string tkey = "Yh2k7QSu4l8CZg5p6X3Pna9L0Miy4D3Bvt0JVr87UcOj69Kqw5R2Nmf4FWs03Hdx";
		public static string Issuer = "JWTAuthenticationServer";
		public static string Audience = "JWTServicePostmanClient";

		public static SymmetricSecurityKey getTKey()
		{
			SymmetricSecurityKey _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tkey));
			return _key;
		}
		public static void getSettings()
		{
			try
			{
				exefolder = AppDomain.CurrentDomain.BaseDirectory;

				StreamReader r = new StreamReader(exefolder + @"\config.json");

				string json = r.ReadToEnd();
				cnf = JsonConvert.DeserializeObject<config>(json);
				cnf.Password = Decrypt(cnf.Password, true);
				cnf.DbPassword = Decrypt(cnf.DbPassword, true);

				sqlConnectionString = $"Server={cnf.DbServer};Database={cnf.DbName};Uid={cnf.DbUserName};Pwd={cnf.DbPassword};Encrypt=False";


			}
			catch (Exception er)
			{
				Logw.Log(er);
			}
		}
		public static string saveXml(XmlDocument XmlData, string folder, string xmlname)
		{
			string fname = xmlname;
			try
			{
				string path = AppDomain.CurrentDomain.BaseDirectory;
				
				path = path + folder;
				if (!Directory.Exists(path))
					Directory.CreateDirectory(path);
				fname = path + @"\" + fname;
				var sr = File.CreateText(fname);
				TextWriter w = (TextWriter)sr;
				w.WriteLine(XmlData.InnerXml);
				w.Flush();
				w.Close();
				return fname;

			}
			catch (Exception errt)
			{
				Console.WriteLine(errt.Message);

			}
			return fname;
		}
		public static string RemoveXml(string folder, string xmlname)
		{
			string fname = xmlname;
			try
			{
				string path = AppDomain.CurrentDomain.BaseDirectory;

				path = path + folder;
				if (!Directory.Exists(path))
					Directory.CreateDirectory(path);
				fname = path + @"\" + fname;
				File.Delete(fname);
				return fname;

			}
			catch (Exception errt)
			{
				

			}
			return fname;
		}
		public static void Log(string message)
		{
			try
			{

				string path = AppDomain.CurrentDomain.BaseDirectory;
				if (!Directory.Exists(path))
					Directory.CreateDirectory(path);

				string flname = path + @"\info.log";

				var sr = File.AppendText(flname);
				TextWriter w = (TextWriter)sr;
				w.WriteLine(message);
				w.Flush();
				w.Close();
				//////////

			}
			catch (Exception errt)
			{
				Console.WriteLine(errt.Message);

			}
			Console.WriteLine(message);

		}

		public static void Log(Exception ex)
		{
			try
			{


				string path = AppDomain.CurrentDomain.BaseDirectory;


				
				//if (!Directory.Exists(path))
				//	Directory.CreateDirectory(path);

				string flname = path + @"\Error.log";

				var sr = File.AppendText(flname);
				TextWriter w = (TextWriter)sr;
				w.WriteLine("Error=" + ex.Message + "\n\t" + DateTime.Now.ToString("yyyyMMdd HH-mm") + "\n\tSource = " + ex.StackTrace);
				w.Flush();
				w.Close();




			}
			catch (Exception errt)
			{
				Console.WriteLine(errt.Message);

			}

		}
		public static string Decrypt(string cipherString, bool useHashing)
		{
			try
			{
				byte[] keyArray;
				//get the byte code of the string

				byte[] toEncryptArray = Convert.FromBase64String(cipherString);

				//  System.Configuration.AppSettingsReader settingsReader =
				//                                    new AppSettingsReader();
				//Get your key from config file to open the lock!
				string key = "Linux123#"; //(string)settingsReader.GetValue("SecurityKey",
										  //                   typeof(String));

				if (useHashing)
				{
					//if hashing was used get the hash code with regards to your key
					MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
					keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
					//release any resource held by the MD5CryptoServiceProvider

					hashmd5.Clear();
				}
				else
				{
					//if hashing was not implemented get the byte code of the key
					keyArray = UTF8Encoding.UTF8.GetBytes(key);
				}

				TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
				//set the secret key for the tripleDES algorithm
				tdes.Key = keyArray;

				tdes.Mode = CipherMode.ECB;

				tdes.Padding = PaddingMode.PKCS7;

				ICryptoTransform cTransform = tdes.CreateDecryptor();
				byte[] resultArray = cTransform.TransformFinalBlock(
									 toEncryptArray, 0, toEncryptArray.Length);
				//Release resources held by TripleDes Encryptor                
				tdes.Clear();
				//return the Clear decrypted TEXT
				return UTF8Encoding.UTF8.GetString(resultArray);
			}
			catch (Exception er)
			{

			}
			return cipherString;
		}


	}

}
