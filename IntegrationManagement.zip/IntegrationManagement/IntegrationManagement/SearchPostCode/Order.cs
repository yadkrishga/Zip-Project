﻿using SAPbouiCOM;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchPostCode
{
	public class Order : IBForm
	{
		Form oForm;
		public Order()
        {
			//try
			//{
			//	TableCreate.CreateUserFields("ORDR", "GA_PostCode", "Post Code", SAPbobsCOM.BoFieldTypes.db_Alpha, 10, SAPbobsCOM.BoFldSubTypes.st_None);
			//} catch { }	
			oForm = ProgData.B1Application.Forms.ActiveForm;
			EditText edt =  (EditText) oForm.Items.Add("pstcode", SAPbouiCOM.BoFormItemTypes.it_EDIT).Specific;
			Item itm =  oForm.Items.Item("4");
			edt.Item.LinkTo = "4";
			edt.Item.Left = itm.Left + itm.Width + 50;
			edt.Item.Top = itm.Top;
			StaticText label = (StaticText)oForm.Items.Add("lbl1", SAPbouiCOM.BoFormItemTypes.it_STATIC).Specific;
			label.Item.LinkTo = "4";
			label.Item.Left = edt.Item.Left + edt.Item.Width + 15;
			label.Item.Top = edt.Item.Top;
			label.Caption = "PostCode for Search";
			edt.Item.Click();
			itm = oForm.Items.Item("80");
			Button btn = (Button)oForm.Items.Add("sel", SAPbouiCOM.BoFormItemTypes.it_BUTTON).Specific;
		
			btn.Item.Width = itm.Width;
			btn.Item.Height = itm.Height;
			btn.Item.Top = edt.Item.Top;
			btn.Item.Left = edt.Item.Left + edt.Item.Width;
			btn.Type = ((Button)itm.Specific).Type;
			btn.Image = ((Button)itm.Specific).Image;
			
			ProgData.Forms.Add(oForm.UniqueID, this);
		}
		private void getlist()
		{
			string postcode = ((EditText)oForm.Items.Item("pstcode").Specific).Value;
			AddressList addrlst = new AddressList(postcode);

		}
		public void EventAll(ItemEvent pVal)
		{
			if (pVal.BeforeAction==false && pVal.ItemUID == "sel" && pVal.EventType == BoEventTypes.et_CLICK)
			{
				getlist();
			}
		}

		public void Menu(ref MenuEvent pVal)
		{
			throw new NotImplementedException();
		}
	}
}
