﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class SpecialPrices:IEntity
	{
		public string ItemCode { get; set; }      //"E101A0099001",
		public string CardCode { get; set; }      //"M000004",
		public string Price { get; set; }      //100.0,
		public string Currency { get; set; }      //"TRY",
		public string DiscountPercent { get; set; }      //0.0,
		public string PriceListNum { get; set; }      //0,
		public string AutoUpdate { get; set; }      //"tNO",
		public string SourcePrice { get; set; }      //"sc_PrimaryCurrency",
		public string Valid { get; set; }      //"tYES",
		public string ValidFrom { get; set; }      //null,
		public string ValidTo { get; set; }      //null,
		//public string SpecialPriceDataAreas { get; set; }      //[]

	}
}
