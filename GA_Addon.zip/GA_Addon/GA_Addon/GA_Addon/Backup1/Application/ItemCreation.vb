Imports System
Imports System.Xml

Public Class ItemCreation
    Dim frmItemCreation As SAPbouiCOM.Form
    Dim oMatrix1, oMatrix2, oMatrix3 As SAPbouiCOM.Matrix
    Dim oDBDSHeader, oDBDSDetail1, oDBDSDetail2, oDBDSDetail3 As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "OITM"
    Dim NoofFridays As Double = 0.0
    Dim NoofSaturdays As Double = 0.0
    Dim NoofTodays As Double = 0.0
    Dim DeleteRowITEMUID As String = ""
    Dim RowCtrl1 As SAPbouiCOM.CommonSetting

    Sub LoadItemCreation()
        Try

            oGfun.LoadXML(frmItemCreation, ItemCreationFormID, ItemCreationXML)
            frmItemCreation = oApplication.Forms.Item(ItemCreationFormID)
            oDBDSHeader = frmItemCreation.DataSources.DBDataSources.Item("@INS_OITM")
            oDBDSDetail1 = frmItemCreation.DataSources.DBDataSources.Item("@INS_ITM1")
            oDBDSDetail2 = frmItemCreation.DataSources.DBDataSources.Item("@INS_ITM2")
            oDBDSDetail3 = frmItemCreation.DataSources.DBDataSources.Item("@INS_ITM3")
            oMatrix1 = frmItemCreation.Items.Item("Matrix1").Specific
            oMatrix2 = frmItemCreation.Items.Item("Matrix2").Specific
            oMatrix3 = frmItemCreation.Items.Item("Matrix3").Specific

            'oMatrix.Columns.Item("Amount").ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto

            oMatrix1.AutoResizeColumns()
            oMatrix2.AutoResizeColumns()
            oMatrix3.AutoResizeColumns()

            Me.InitForm()
            Me.DefineModesForFields()


            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_desig").Specific, "SELECT ""posID"" , ""name"" FROM OHPS")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_qulif").Specific, "Select ""Code"",""U_Name"" from ""@INS_OQUL"" ")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_div").Specific, "Select ""Code"",""Name"" from OUBR")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_Desg").Specific, "SELECT ""posID"" , ""name"" FROM OHPS")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_Divisi").Specific, "Select ""Code"",""Name"" from OUBR")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_loc").Specific, "SELECT ""Code"" , ""Location"" FROM OLCT")
            'oGfun.setComboBoxValue(frmItemCreation.Items.Item("t_Depart").Specific, "Select ""Code"", ""Name"" from OUDP")



        Catch ex As Exception
            oGfun.StatusBarErrorMsg("Load ItemCreation Application Failed : " & ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try


            frmItemCreation.Freeze(True)
            oGfun.LoadComboBoxSeries(frmItemCreation.Items.Item("c_series").Specific, UDOID, "", "")
            oGfun.LoadDocumentDate(frmItemCreation.Items.Item("t_docdate").Specific)
            'oDBDSHeader.SetValue("Code", 0, oGfun.GetCodeGeneration("@INS_OITM"))
            oGfun.SetNewLine(oMatrix1, oDBDSDetail1)
            'frmItemCreation.PaneLevel = 1
            frmItemCreation.Items.Item("f_gen").Click(SAPbouiCOM.BoCellClickType.ct_Regular)


            '----------------------------------
            'oApplication.StatusBar.SetText("Please wait....Color/Size details filling....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oMatrix1.Clear()
            oDBDSDetail1.Clear()
            sQuery = String.Empty
            sQuery = "SELECT * FROM ""@INS_OCSM"" ORDER BY ""U_SortID"" ASC"
            Dim RstColor As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            If RstColor.RecordCount > 0 Then
                RstColor.MoveFirst()
                For i As Integer = 0 To RstColor.RecordCount - 1
                    oDBDSDetail1.InsertRecord(oDBDSDetail1.Size)
                    oDBDSDetail1.SetValue("LineID", i, i + 1)
                    oDBDSDetail1.SetValue("U_Code1", i, RstColor.Fields.Item("Code").Value)
                    oDBDSDetail1.SetValue("U_Code", i, RstColor.Fields.Item("U_Code").Value)
                    oDBDSDetail1.SetValue("U_Name", i, RstColor.Fields.Item("U_Name").Value)
                    RstColor.MoveNext()
                Next
            End If
            oMatrix1.LoadFromDataSource()
            'oApplication.StatusBar.SetText("Color/Size details filled....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            '----------------------------------
            'oApplication.StatusBar.SetText("Please wait....Properties details filling....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oMatrix2.Clear()
            oDBDSDetail2.Clear()
            sQuery = String.Empty
            sQuery = " SELECT ""ItmsTypCod"",""ItmsGrpNam"" FROM OITG"
            Dim RstProperty As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            If RstProperty.RecordCount > 0 Then
                RstProperty.MoveFirst()
                For i As Integer = 0 To RstProperty.RecordCount - 1
                    oDBDSDetail2.InsertRecord(oDBDSDetail2.Size)
                    oDBDSDetail2.SetValue("LineID", i, i + 1)
                    oDBDSDetail2.SetValue("U_PropCode", i, RstProperty.Fields.Item("ItmsTypCod").Value)
                    oDBDSDetail2.SetValue("U_PropName", i, RstProperty.Fields.Item("ItmsGrpNam").Value)
                    oDBDSDetail2.SetValue("U_Select", i, "N")
                    RstProperty.MoveNext()
                Next
            End If
            oMatrix2.LoadFromDataSource()
            'oApplication.StatusBar.SetText("Properties details filled....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            '----------------------------------

            frmItemCreation.Items.Item("saluomM").Visible = True
            frmItemCreation.Items.Item("puruom1").Visible = True
            'frmItemCreation.Items.Item("saluom").Visible = True
            'frmItemCreation.Items.Item("puruom").Visible = True
           

            oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_SAPGrp").Specific, " SELECT ""ItmsGrpCod"",""ItmsGrpNam""  FROM OITB")
            oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("PurVat").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='I'")
            oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("SalVat").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='O'")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("saluom").Specific, "SELECT ""UomEntry"",""UomName"" FROM OUOM")
            'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("puruom").Specific, "SELECT ""UomEntry"",""UomName"" FROM OUOM")
            oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_uomGrp").Specific, "SELECT ""UgpEntry"",""UgpName"" FROM OUGP")
            oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("Item_27").Specific, " SELECT ""FirmCode"",""FirmName"" FROM OMRC")
            oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("Item_39").Specific, " SELECT ""Code"",""Name"" FROM ""@CATEGORY"" ")

            frmItemCreation.Items.Item("f_gen").Click(SAPbouiCOM.BoCellClickType.ct_Regular)

            'oDBDSHeader.SetValue("U_VSAppCode", 0, "VS" & oDBDSHeader.GetValue("Code", 0).Trim)
            'frmItemCreation.Freeze(False)
            'Dim Str As String = "Select ""U_PPAccess"" from OUSR Where ""USERID""='" & oCompany.UserSignature & "'"
            'Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
            'If rset.Fields.Item("U_PPAccess").Value = "1" Then
            '    frmItemCreation.Items.Item("f_gen").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            '    frmItemCreation.ActiveItem = "t_passno"
            '    Me.USER1()
            'ElseIf rset.Fields.Item("U_PPAccess").Value = "2" Then
            '    frmItemCreation.Items.Item("f_visa").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            '    frmItemCreation.ActiveItem = "t_AODate"
            '    Me.USER2()
            'ElseIf rset.Fields.Item("U_PPAccess").Value = "3" Then
            '    frmItemCreation.Items.Item("f_gen").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            '    frmItemCreation.ActiveItem = "t_passno"
            '    Me.USER3()
            'End If

            frmItemCreation.Freeze(False)

        Catch ex As Exception
            oApplication.StatusBar.SetText("InitForm Method Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            frmItemCreation.Freeze(False)
        Finally
        End Try
    End Sub
    Sub DefineModesForFields()
        Try

            'frmItemCreation.Items.Item("t_code").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Add
            'frmItemCreation.Items.Item("t_code").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            'frmItemCreation.Items.Item("t_code").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            'frmItemCreation.Items.Item("t_vscode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Add
            'frmItemCreation.Items.Item("t_vscode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)   ' Update
            'frmItemCreation.Items.Item("t_vscode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)    ' Find

            frmItemCreation.Items.Item("t_docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmItemCreation.Items.Item("t_docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmItemCreation.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmItemCreation.Items.Item("t_docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmItemCreation.Items.Item("t_docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)


        Catch ex As Exception
            oApplication.StatusBar.SetText("DefineModesForFields Method Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Function ValidateAll() As Boolean
        Try

            'Dim Code As String = oCompany.UserSignature
            'Dim Str As String = "Select ""U_PPAccess"" from OUSR Where ""USERID""='" & Code & "'"
            'Dim rset As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

            ''frmItemCreation.Items.Item("t_passno").Enabled = True
            ''frmItemCreation.Items.Item("t_passno").Enabled = False

            'If rset.Fields.Item("U_PPAccess").Value = "1" Then
            '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then
            '        If frmItemCreation.Items.Item("t_passno").Specific.value.Equals("") Then
            '            oApplication.StatusBar.SetText("Passport No Should Not be left Empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            '            frmItemCreation.Items.Item("t_passno").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            '            Return False
            '        End If
            '    End If

            'ElseIf rset.Fields.Item("U_PPAccess").Value = "2" Then
            '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then
            '        If frmItemCreation.Items.Item("t_AODate").Specific.value.Equals("") Then
            '            oApplication.StatusBar.SetText("AOTypeDt No Should Not be left Empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            '            frmItemCreation.Items.Item("t_AODate").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            '            Return False
            '        End If
            '    End If
            'ElseIf rset.Fields.Item("U_PPAccess").Value = "3" Then
            '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then
            '        If frmItemCreation.Items.Item("t_passno").Specific.value.Equals("") Then
            '            oApplication.StatusBar.SetText("Passport No Should Not be left Empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            '            frmItemCreation.Items.Item("t_passno").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            '            Return False
            '        End If
            '    End If
            'End If
            ValidateAll = True
        Catch ex As Exception
            oApplication.StatusBar.SetText("Validate Function Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            ValidateAll = False
        Finally
        End Try
    End Function
    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False And frmItemCreation.Mode <> SAPbouiCOM.BoFormMode.fm_FIND_MODE Then
                            If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                            Select Case pVal.ItemUID
                                'Case "t_throug"
                                '    oDBDSHeader.SetValue("U_AgentCod", 0, Trim(oDataTable.GetValue("U_Code1", 0)))
                                '    oDBDSHeader.SetValue("U_AgentName", 0, Trim(oDataTable.GetValue("U_Name", 0)))
                                '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                'Case "t_LangName"
                                '    oDBDSHeader.SetValue("U_LangCode", 0, Trim(oDataTable.GetValue("Code", 0)))
                                '    oDBDSHeader.SetValue("U_LangName", 0, Trim(oDataTable.GetValue("Name", 0)))
                                '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                'Case "t_empname"
                                '    oDBDSHeader.SetValue("U_EmpID", 0, Trim(oDataTable.GetValue("empID", 0)))
                                '    oDBDSHeader.SetValue("U_EmpName", 0, Trim(oDataTable.GetValue("lastName", 0)) & "," & Trim(oDataTable.GetValue("firstName", 0)))
                                '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                Case "t_count"
                                    oDBDSHeader.SetValue("U_OrgCountCod", 0, Trim(oDataTable.GetValue("Code", 0)))
                                    oDBDSHeader.SetValue("U_OrgCountNam", 0, Trim(oDataTable.GetValue("Name", 0)))
                                    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE

                                Case "Item_29"
                                    oDBDSHeader.SetValue("U_HSCode", 0, Trim(oDataTable.GetValue("U_Code", 0)))
                                    oDBDSHeader.SetValue("U_HSName", 0, Trim(oDataTable.GetValue("U_Name", 0)))
                                    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE

                                    'Case "t_visdes1"
                                    '    oDBDSHeader.SetValue("U_VisaDesCod", 0, Trim(oDataTable.GetValue("Code", 0)))
                                    '    oDBDSHeader.SetValue("U_VisaDesNam", 0, Trim(oDataTable.GetValue("U_Name", 0)))
                                    '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                    'Case "t_appbynam"
                                    '    oDBDSHeader.SetValue("U_AppByCode", 0, Trim(oDataTable.GetValue("empID", 0)))
                                    '    oDBDSHeader.SetValue("U_AppByName", 0, Trim(oDataTable.GetValue("lastName", 0)) & "," & Trim(oDataTable.GetValue("firstName", 0)))
                                    '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                    'Case "t_issbynam"
                                    '    oDBDSHeader.SetValue("U_IssByCode", 0, Trim(oDataTable.GetValue("empID", 0)))
                                    '    oDBDSHeader.SetValue("U_IssByName", 0, Trim(oDataTable.GetValue("lastName", 0)) & "," & Trim(oDataTable.GetValue("firstName", 0)))
                                    '    If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                                Case "Matrix1"
                                    Select Case pVal.ColUID
                                        Case "code"
                                            If frmItemCreation.Mode <> SAPbouiCOM.BoFormMode.fm_FIND_MODE Then
                                                oMatrix1.FlushToDataSource()
                                                oDBDSDetail1.SetValue("U_Code1", pVal.Row - 1, Trim(oDataTable.GetValue("Code", 0)))
                                                oDBDSDetail1.SetValue("U_Code", pVal.Row - 1, Trim(oDataTable.GetValue("U_Code", 0)))
                                                oDBDSDetail1.SetValue("U_Name", pVal.Row - 1, Trim(oDataTable.GetValue("U_Name", 0)))
                                                oMatrix1.LoadFromDataSource()
                                                oMatrix1.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                                oGfun.SetNewLine(oMatrix1, oDBDSDetail1)
                                            End If
                                    End Select
                            End Select
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                    Try
                        Select Case pVal.ItemUID

                        End Select


                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Got Focus event Failed : " & ex.Message)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID
                            Case "t_Length", "t_Width", "t_Height"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    Dim Length As Double = frmItemCreation.Items.Item("t_Length").Specific.value
                                    Dim Width As Double = frmItemCreation.Items.Item("t_Width").Specific.value
                                    Dim Height As Double = frmItemCreation.Items.Item("t_Height").Specific.value
                                    oDBDSHeader.SetValue("U_SCalCBM", 0, Length * Width * Height)
                                End If
                            Case "t_Length1", "t_Width1", "t_Height1"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    Dim Length As Double = frmItemCreation.Items.Item("t_Length1").Specific.value
                                    Dim Width As Double = frmItemCreation.Items.Item("t_Width1").Specific.value
                                    Dim Height As Double = frmItemCreation.Items.Item("t_Height1").Specific.value
                                    oDBDSHeader.SetValue("U_PCalCBM", 0, Length * Width * Height)
                                End If
                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarErrorMsg("Item Validate event Failed : " & ex.Message)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            'Case "Matrix"
                            '    Select Case pVal.ColUID
                            '        Case "PayCode"
                            '            If pVal.BeforeAction = False Then
                            '                oGfun.DoOpenLinkedObjectForm("OPYE", "OPYE", "t_paycode", oDBDSDetail1.GetValue("U_PayElCode", pVal.Row - 1))
                            '            End If
                            '    End Select

                        End Select
                    Catch ex As Exception
                        oGfun.StatusBarWarningMsg("Item Pressed Event Failed: " & ex.Message())
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "c_series"
                                If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    'Get the Serial Number Based On Series...
                                    Dim oCmbSerial As SAPbouiCOM.ComboBox = frmItemCreation.Items.Item("c_series").Specific
                                    Dim strSerialCode As String = oCmbSerial.Selected.Value
                                    Dim strDocNum As Long = frmItemCreation.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                                    oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                                End If
                            Case "t_uomGrp"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    Dim oCmbUomGrp As SAPbouiCOM.ComboBox = frmItemCreation.Items.Item("t_uomGrp").Specific
                                    Dim strSerialCode As String = oCmbUomGrp.Selected.Value
                                    If strSerialCode = "-1" Then
                                        frmItemCreation.Items.Item("saluomM").Visible = True
                                        frmItemCreation.Items.Item("puruom1").Visible = True
                                        'frmItemCreation.Items.Item("saluom").Visible = False
                                        'frmItemCreation.Items.Item("puruom").Visible = False
                                        oDBDSHeader.SetValue("U_UnitOfSal", 0, "")
                                        oDBDSHeader.SetValue("U_UnitOfPur", 0, "")
                                        oDBDSHeader.SetValue("U_UnitOfSalM", 0, "")
                                        oDBDSHeader.SetValue("U_UnitOfPurM", 0, "")
                                        frmItemCreation.PaneLevel = 1
                                    Else
                                        frmItemCreation.Items.Item("saluomM").Visible = True
                                        frmItemCreation.Items.Item("puruom1").Visible = True
                                        'frmItemCreation.Items.Item("saluom").Visible = False
                                        'frmItemCreation.Items.Item("puruom").Visible = False
                                        'frmItemCreation.Items.Item("saluomM").Visible = False
                                        'frmItemCreation.Items.Item("puruom1").Visible = False
                                        'frmItemCreation.Items.Item("saluom").Visible = True
                                        'frmItemCreation.Items.Item("puruom").Visible = True
                                        oDBDSHeader.SetValue("U_UnitOfSalM", 0, "")
                                        oDBDSHeader.SetValue("U_UnitOfPurM", 0, "")
                                        oDBDSHeader.SetValue("U_UnitOfSal", 0, "")
                                        oDBDSHeader.SetValue("U_UnitOfPur", 0, "")
                                        'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("saluom").Specific, "SELECT A.""UomEntry"",B.""UomName""  FROM UGP1 A, OUOM B WHERE A.""UomEntry""=B.""UomEntry"" AND ""UgpEntry""='" & strSerialCode & "'")
                                        'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("puruom").Specific, "SELECT A.""UomEntry"",B.""UomName""  FROM UGP1 A, OUOM B WHERE A.""UomEntry""=B.""UomEntry"" AND ""UgpEntry""='" & strSerialCode & "'")
                                        frmItemCreation.PaneLevel = 1
                                    End If
                                End If
                            Case "SalVat"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    Dim oCmbSalVat As SAPbouiCOM.ComboBox = frmItemCreation.Items.Item("SalVat").Specific
                                    Dim strSalVat As String = oCmbSalVat.Selected.Value
                                    sQuery = String.Empty
                                    sQuery = "SELECT * FROM OVTG WHERE ""Category""='O' AND ""Code""='" & strSalVat & "'"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If Rst.RecordCount > 0 Then
                                        oDBDSHeader.SetValue("U_SVatRate", 0, Rst.Fields.Item("Rate").Value)
                                    Else
                                        oDBDSHeader.SetValue("U_SVatRate", 0, 0)
                                    End If
                                End If
                            Case "PurVat"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    Dim oCmbSalVat As SAPbouiCOM.ComboBox = frmItemCreation.Items.Item("PurVat").Specific
                                    Dim strSalVat As String = oCmbSalVat.Selected.Value
                                    sQuery = String.Empty
                                    sQuery = "SELECT * FROM OVTG WHERE ""Category""='I' AND ""Code""='" & strSalVat & "'"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If Rst.RecordCount > 0 Then
                                        oDBDSHeader.SetValue("U_PVatRate", 0, Rst.Fields.Item("Rate").Value)
                                    Else
                                        oDBDSHeader.SetValue("U_PVatRate", 0, 0)
                                    End If
                                End If

                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Combo Select Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            'Case "Matrix"
                            '    Select Case pVal.ColUID
                            '        Case "PayCode"
                            '            If pVal.BeforeAction = False Then
                            '                oGfun.SetNewLine(oMatrix, oDBDSDetail1, pVal.Row, pVal.ColUID)
                            '            End If
                            '    End Select
                        End Select
                    Catch ex As Exception
                        frmItemCreation.Freeze(False)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub
                                    Else
                                        'oDBDSHeader.SetValue("U_VSAppCode", 0, "VS" & oDBDSHeader.GetValue("Code", 0).Trim)
                                    End If
                                End If

                            Case "b_browse"
                                If pVal.BeforeAction Then If frmItemCreation.Items.Item(pVal.ItemUID).Enabled = False Then BubbleEvent = False
                                If pVal.ActionSuccess Then
                                    If oGfun.SetAttachMentFile(frmItemCreation, oDBDSHeader, oMatrix3, oDBDSDetail3) = False Then
                                        BubbleEvent = False
                                    End If
                                End If
                            Case "b_display"
                                If pVal.BeforeAction Then If frmItemCreation.Items.Item(pVal.ItemUID).Enabled = False Then BubbleEvent = False
                                If pVal.ActionSuccess Then oGfun.OpenAttachment(oMatrix3, oDBDSDetail3, pVal.Row)

                            Case "b_delete"
                                If pVal.BeforeAction Then If frmItemCreation.Items.Item(pVal.ItemUID).Enabled = False Then BubbleEvent = False
                                If pVal.ActionSuccess Then
                                    oGfun.DeleteRowAttachment(frmItemCreation, oMatrix3, oDBDSDetail3, oMatrix3.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_RowOrder))
                                End If
                            Case "Matrix3"
                                If pVal.BeforeAction = False And pVal.Row > 0 Then
                                    If oMatrix3.IsRowSelected(pVal.Row) Then
                                        frmItemCreation.Items.Item("b_display").Enabled = True
                                        frmItemCreation.Items.Item("b_delete").Enabled = True
                                    End If
                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "p_img"
                                If oDBDSHeader.GetValue("U_Pict", 0).Trim <> "" Then
                                    frmItemCreation.Items.Item("p_pict").Click(SAPbouiCOM.BoCellClickType.ct_Double)
                                    BubbleEvent = False
                                Else
                                    BubbleEvent = False
                                End If
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.ActionSuccess And frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If
                            Case "f_gen"
                                If pVal.BeforeAction = False Then
                                    frmItemCreation.Freeze(True)
                                    frmItemCreation.PaneLevel = 1
                                    frmItemCreation.Items.Item("f_gen").AffectsFormMode = False
                                    'frmItemCreation.Settings.MatrixUID = "Matrix"
                                    frmItemCreation.Freeze(False)
                                End If
                                'Case "f_rec"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 2
                                '        frmItemCreation.Items.Item("f_rec").AffectsFormMode = False
                                '        frmItemCreation.Freeze(False)
                                '    End If

                                'Case "f_sal"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 3
                                '        frmItemCreation.Items.Item("f_sal").AffectsFormMode = False
                                '        frmItemCreation.Settings.MatrixUID = "Matrix"
                                '        oMatrix.AutoResizeColumns()
                                '        frmItemCreation.Freeze(False)
                                '    End If
                            Case "f_pro"
                                If pVal.BeforeAction = False Then
                                    frmItemCreation.Freeze(True)
                                    frmItemCreation.PaneLevel = 4
                                    frmItemCreation.Items.Item("f_pro").AffectsFormMode = False
                                    oMatrix2.AutoResizeColumns()
                                    frmItemCreation.Freeze(False)
                                End If
                                'Case "f_visa"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 5
                                '        frmItemCreation.Items.Item("f_visa").AffectsFormMode = False
                                '        frmItemCreation.Freeze(False)
                                '    End If
                                'Case "f_wp"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 6
                                '        frmItemCreation.Items.Item("f_wp").AffectsFormMode = False
                                '        frmItemCreation.Freeze(False)
                                '    End If
                                'Case "f_med"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 7
                                '        frmItemCreation.Items.Item("f_med").AffectsFormMode = False
                                '        frmItemCreation.Freeze(False)
                                '    End If
                                'Case "f_user"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 8
                                '        frmItemCreation.Items.Item("f_user").AffectsFormMode = False
                                '        frmItemCreation.Freeze(False)
                                '    End If
                                'Case "f_att"
                                '    If pVal.BeforeAction = False Then
                                '        frmItemCreation.Freeze(True)
                                '        frmItemCreation.PaneLevel = 9
                                '        frmItemCreation.Items.Item("f_att").AffectsFormMode = False
                                '        frmItemCreation.Settings.MatrixUID = "Matrix2"
                                '        frmItemCreation.Freeze(False)
                                '    End If
                            Case "1000003"
                                If pVal.BeforeAction = False Then
                                    If oDBDSHeader.GetValue("U_Pict", 0).Trim = "" Then
                                        frmItemCreation.Items.Item("p_pict").Click(SAPbouiCOM.BoCellClickType.ct_Double)
                                    End If
                                    'Dim strpath As String = oGfun.FindFile()
                                    ' frmItemCreation.Items.Item("p_picture").Enabled = True
                                    'If strpath = "" Then Return
                                    Dim oPic As SAPbouiCOM.PictureBox = frmItemCreation.Items.Item("p_img").Specific
                                    oPic.Picture = oDBDSHeader.GetValue("U_Pict", 0).Trim

                                    'frmItemCreation.Items.Item("p_picture").Enabled = False
                                End If
                            Case "148"
                                If pVal.BeforeAction = False Then
                                    Dim oPic As SAPbouiCOM.PictureBox = frmItemCreation.Items.Item("p_img").Specific
                                    oPic.Picture = ""
                                    oDBDSHeader.SetValue("U_Pict", 0, "")
                                End If

                                'Case "b_addimg"
                                '    If pVal.BeforeAction = True Then
                                '        Dim oPictureBox As SAPbouiCOM.PictureBox = frmItemCreation.Items.Item("p_picture").Specific
                                '        Dim strFileName As String = oGfun.FindFile()
                                '        If oGfun.FileOpen(strFileName) = False Then Exit Sub
                                '        If strFileName.Equals("") = False Then

                                '            oPictureBox.Picture = strFileName

                                '        Else
                                '            oPictureBox.Picture = String.Empty
                                '        End If
                                '        'frmCostingSheet.Items.Item("t_path").Click(SAPbouiCOM.BoCellClickType.ct_Double)
                                '    End If
                                'Case "b_rmvimg"
                                '    If pVal.BeforeAction = True Then
                                '        Dim oPictureBox As SAPbouiCOM.PictureBox = frmItemCreation.Items.Item("p_picture").Specific
                                '        oPictureBox.Picture = String.Empty
                                '        frmItemCreation.Items.Item("t_Pict").Specific.value = ""
                                '    End If
                        End Select


                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Pressed Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
            End Select

        Catch ex As Exception
            oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
        ' End Select 


    End Sub
    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1281"
                    frmItemCreation.ActiveItem = "t_passno"
                Case "1282"
                    If pVal.BeforeAction = False Then Me.InitForm()
                    'Case "1282"
                    '    Me.InitForm()
                Case "1293"
                    oGfun.DeleteRow(oMatrix1, oDBDSDetail1)


            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Menu Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try
                        If BusinessObjectInfo.BeforeAction Then
                            If Me.ValidateAll() = False Then
                                System.Media.SystemSounds.Asterisk.Play()
                                BubbleEvent = False
                                Exit Sub
                            End If

                            'oGfun.DeleteEmptyRowInFormDataEvent(oMatrix1, "PayCode", oDBDSDetail1)
                        End If
                        If BusinessObjectInfo.ActionSuccess Then
                            For i As Integer = 1 To oMatrix1.VisualRowCount
                                Dim Chk As SAPbouiCOM.CheckBox = oMatrix1.Columns.Item("Select").Cells.Item(i).Specific
                                If Chk.Checked = True Then
                                    sQuery = String.Empty
                                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", i - 1).Trim & "'"
                                    Dim RstChk As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If RstChk.RecordCount = 0 And oDBDSDetail1.GetValue("U_Code", i - 1).Trim <> "" Then
                                        oApplication.StatusBar.SetText("Please wait... Line ID : " & i & " Posting....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.PostItemMaster(i)
                                    ElseIf oDBDSDetail1.GetValue("U_Code", i - 1).Trim <> "" And RstChk.RecordCount > 0 Then
                                        oApplication.StatusBar.SetText("Please wait... Line ID : " & i & " Updating....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                        Me.Post_Update_ItemMaster(i)
                                    End If
                                End If
                            Next
                            oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                        End If
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Form Data Add ,Update Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        BubbleEvent = False
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    If BusinessObjectInfo.ActionSuccess Then
                        frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                        Try
                            If BusinessObjectInfo.ActionSuccess Then

                                'oDBDSHeader.SetValue("U_LogPosting", 0, "O")
                                'oDBDSHeader.SetValue("U_CusPosting", 0, "O")

                                Dim PaneNo As Integer = frmItemCreation.PaneLevel

                                Dim oCmbUomGrp As SAPbouiCOM.ComboBox = frmItemCreation.Items.Item("t_uomGrp").Specific
                                Dim strSerialCode As String = oCmbUomGrp.Selected.Value
                                If strSerialCode = "-1" Then
                                    frmItemCreation.Items.Item("saluomM").Visible = True
                                    frmItemCreation.Items.Item("puruom1").Visible = True
                                    'frmItemCreation.Items.Item("saluom").Visible = False
                                    '   frmItemCreation.Items.Item("puruom").Visible = False
                                Else
                                    frmItemCreation.Items.Item("saluomM").Visible = False
                                    frmItemCreation.Items.Item("puruom1").Visible = False
                                    'frmItemCreation.Items.Item("saluom").Visible = True
                                    ' frmItemCreation.Items.Item("puruom").Visible = True
                                End If
                                If frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE Then frmItemCreation.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE

                                'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_SAPGrp").Specific, " SELECT ""ItmsGrpCod"",""ItmsGrpNam""  FROM OITB")
                                'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("PurVat").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='I'")
                                'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("SalVat").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='O'")
                                ''oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("saluom").Specific, "SELECT ""UomEntry"",""UomName"" FROM OUOM")
                                ''oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("puruom").Specific, "SELECT ""UomEntry"",""UomName"" FROM OUOM")
                                ''oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("saluomM").Specific, "SELECT A.""UomEntry"",B.""UomName""  FROM UGP1 A, OUOM B WHERE A.""UomEntry""=B.""UomEntry"" AND ""UgpEntry""='" & strSerialCode & "'")
                                '' oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("puruom1").Specific, "SELECT A.""UomEntry"",B.""UomName""  FROM UGP1 A, OUOM B WHERE A.""UomEntry""=B.""UomEntry"" AND ""UgpEntry""='" & strSerialCode & "'")
                                'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("t_uomGrp").Specific, "SELECT ""UgpEntry"",""UgpName"" FROM OUGP")
                                'oGfun.SetComboBoxValueRefresh(frmItemCreation.Items.Item("Item_27").Specific, " SELECT ""FirmCode"",""FirmName"" FROM OMRC")


                                'If PaneNo = 1 Then
                                '    frmItemCreation.Items.Item("f_gen").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                'ElseIf PaneNo = 2 Then
                                '    frmItemCreation.Items.Item("f_sale").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                'ElseIf PaneNo = 3 Then
                                '    frmItemCreation.Items.Item("f_pur").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                'ElseIf PaneNo = 4 Then
                                '    frmItemCreation.Items.Item("f_pro").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                'ElseIf PaneNo = 5 Then
                                '    frmItemCreation.Items.Item("f_att").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                'End If

                            End If

                        Catch ex As Exception

                        End Try
                    End If
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Form Data Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    If frmItemCreation.Mode <> SAPbouiCOM.BoFormMode.fm_FIND_MODE And EventInfo.BeforeAction = True Then
                        DeleteRowITEMUID = EventInfo.ItemUID
                        Select Case EventInfo.ItemUID
                            Case "Matrix"
                                If EventInfo.Row = oMatrix1.VisualRowCount Then
                                    frmItemCreation.EnableMenu("1293", False)
                                Else
                                    frmItemCreation.EnableMenu("1293", True)
                                End If
                        End Select

                    End If
            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Right Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
 
    Sub PostItemMaster(ByVal RowID As Integer)

        Try
            Dim oPostItem As SAPbobsCOM.Items
            oPostItem = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
            Dim ItemCode As String = oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim
            Dim ItemName As String = oDBDSHeader.GetValue("U_ItmGrpName", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Name", RowID - 1).Trim
            Dim ItemGroup As String = oDBDSHeader.GetValue("U_SAPItmGrpCod", 0).Trim
            Dim FrgnName As String = oDBDSHeader.GetValue("U_ForgName", 0).Trim

            oPostItem.ItemCode = ItemCode.Trim
            'Set Value to other fields
            oPostItem.ItemName = ItemName.Trim
            oPostItem.ItemsGroupCode = ItemGroup.Trim
            oPostItem.ForeignName = FrgnName.Trim
            If oDBDSHeader.GetValue("U_SaleItem", 0).Trim = "Y" Then
                oPostItem.SalesItem = SAPbobsCOM.BoYesNoEnum.tYES
            Else
                oPostItem.SalesItem = SAPbobsCOM.BoYesNoEnum.tNO
            End If
            If oDBDSHeader.GetValue("U_InvItem", 0).Trim = "Y" Then
                oPostItem.InventoryItem = SAPbobsCOM.BoYesNoEnum.tYES
            Else
                oPostItem.InventoryItem = SAPbobsCOM.BoYesNoEnum.tNO
            End If

            If oDBDSHeader.GetValue("U_PurItem", 0).Trim = "Y" Then
                oPostItem.PurchaseItem = SAPbobsCOM.BoYesNoEnum.tYES
            Else
                oPostItem.PurchaseItem = SAPbobsCOM.BoYesNoEnum.tNO
            End If
            If oDBDSHeader.GetValue("U_UOMGroup", 0).Trim <> "" Then
                oPostItem.UoMGroupEntry = oDBDSHeader.GetValue("U_UOMGroup", 0).Trim
            End If
            If oDBDSHeader.GetValue("U_UnitOfSalM", 0).Trim <> "" Then
                oPostItem.SalesUnit = oDBDSHeader.GetValue("U_UnitOfSalM", 0).Trim
            End If
            If oDBDSHeader.GetValue("U_UnitOfPurM", 0).Trim <> "" Then
                oPostItem.PurchaseUnit = oDBDSHeader.GetValue("U_UnitOfPurM", 0).Trim
            End If

            oPostItem.SalesUnitLength = oDBDSHeader.GetValue("U_SLength", 0).Trim
            oPostItem.SalesUnitWidth = oDBDSHeader.GetValue("U_SWidth", 0).Trim
            oPostItem.SalesUnitHeight = oDBDSHeader.GetValue("U_SHeight", 0).Trim
            oPostItem.SalesUnitVolume = oDBDSHeader.GetValue("U_SCalCBM", 0).Trim

            oPostItem.PurchaseUnitLength = oDBDSHeader.GetValue("U_PLength", 0).Trim
            oPostItem.PurchaseUnitWeight = oDBDSHeader.GetValue("U_PWidth", 0).Trim
            oPostItem.PurchaseUnitHeight = oDBDSHeader.GetValue("U_PHeight", 0).Trim
            oPostItem.PurchaseUnitVolume = oDBDSHeader.GetValue("U_PCalCBM", 0).Trim

            oPostItem.Manufacturer = oDBDSHeader.GetValue("U_Manufact", 0).Trim

            If oDBDSHeader.GetValue("U_Hazardous", 0).Trim = "Y" Then
                oPostItem.UserFields.Fields.Item("U_Hazardous").Value = oDBDSHeader.GetValue("U_Hazardous", 0).Trim
            Else
                oPostItem.UserFields.Fields.Item("U_Hazardous").Value = "N"
            End If

            oPostItem.UserFields.Fields.Item("U_MinSalPrc").Value = oDBDSHeader.GetValue("U_MinSalPrc", 0).Trim
            oPostItem.UserFields.Fields.Item("U_MaxSalPrc").Value = oDBDSHeader.GetValue("U_MaxSalPrc", 0).Trim
            oPostItem.UserFields.Fields.Item("U_OrgCountCod").Value = oDBDSHeader.GetValue("U_OrgCountCod", 0).Trim
            oPostItem.UserFields.Fields.Item("U_OrgCountNam").Value = oDBDSHeader.GetValue("U_OrgCountNam", 0).Trim
            oPostItem.UserFields.Fields.Item("U_Category").Value = oDBDSHeader.GetValue("U_Category", 0).Trim
            oPostItem.UserFields.Fields.Item("U_SCartQty").Value = oDBDSHeader.GetValue("U_SCartQty", 0).Trim
            oPostItem.UserFields.Fields.Item("U_PCartQty").Value = oDBDSHeader.GetValue("U_PCartQty", 0).Trim

            oPostItem.UserFields.Fields.Item("U_Itemgrp").Value = oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim
            oPostItem.UserFields.Fields.Item("U_Itemgrpname").Value = oDBDSHeader.GetValue("U_ItmGrpName", 0).Trim

            oPostItem.UserFields.Fields.Item("U_HsCode").Value = oDBDSHeader.GetValue("U_HSCode", 0).Trim
            oPostItem.UserFields.Fields.Item("U_HsName").Value = oDBDSHeader.GetValue("U_HSName", 0).Trim
            oPostItem.UserFields.Fields.Item("U_Size").Value = oDBDSDetail1.GetValue("U_Code1", RowID - 1).Trim


            For i As Integer = 1 To oMatrix2.VisualRowCount
                If oDBDSDetail2.GetValue("U_Select", i - 1).Trim = "Y" Then
                    oPostItem.Properties(oDBDSDetail2.GetValue("U_PropCode", i - 1).Trim) = SAPbobsCOM.BoYesNoEnum.tYES
                Else
                    oPostItem.Properties(oDBDSDetail2.GetValue("U_PropCode", i - 1).Trim) = SAPbobsCOM.BoYesNoEnum.tNO
                End If
            Next
            oPostItem.Picture = System.IO.Path.GetFileName(oDBDSHeader.GetValue("U_Image", 0).Trim)


            ErrCode = oPostItem.Add()
            If ErrCode = 0 Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oPostItem)
                oMatrix1.FlushToDataSource()
                oDBDSDetail1.SetValue("U_ItemCode", RowID - 1, oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim)
                oMatrix1.LoadFromDataSource()
                oMatrix1.AutoResizeColumns()
                sQuery = String.Empty
                sQuery = "UPDATE ""@INS_ITM1"" SET ""U_ItemCode""='" & oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim & "' WHERE ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""LineId""='" & RowID & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                Dim squery1 As String = "Update OITM set ""FirmCode""='" & oDBDSHeader.GetValue("U_Manufact", 0).Trim & "' where ""ItemCode""='" & oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim & "'"
                oGfun.DoQuery(squery1)
            Else
                oCompany.GetLastError(ErrCode, ErrMsg)
                oApplication.StatusBar.SetText("Fail to Post ItemCode:" & ErrCode & "-" & ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                oApplication.MessageBox("Fail to Post ItemCode:" & ErrCode & "-" & ErrMsg)
            End If

        Catch ex As Exception
            oApplication.StatusBar.SetText("Fail to Post ItemCode Function:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oApplication.MessageBox("Fail to Post ItemCode Function:" & ex.Message)
        End Try
       
    End Sub

    Sub Post_Update_ItemMaster(ByVal RowID As Integer)
        Try
            Dim oPostItem As SAPbobsCOM.Items
            oPostItem = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
            Dim ItemCode As String = oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim
            Dim ItemName As String = oDBDSHeader.GetValue("U_ItmGrpName", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Name", RowID - 1).Trim
            Dim ItemGroup As String = oDBDSHeader.GetValue("U_SAPItmGrpCod", 0).Trim
            Dim FrgnName As String = oDBDSHeader.GetValue("U_ForgName", 0).Trim

            'oPostItem.ItemCode = ItemCode.Trim
            oPostItem.GetByKey(ItemCode.Trim)

            'Set Value to other fields
            oPostItem.ItemName = ItemName.Trim
            oPostItem.ItemsGroupCode = ItemGroup.Trim
            oPostItem.ForeignName = FrgnName.Trim
            If oDBDSHeader.GetValue("U_SaleItem", 0).Trim = "Y" Then
                oPostItem.SalesItem = SAPbobsCOM.BoYesNoEnum.tYES
            Else
                oPostItem.SalesItem = SAPbobsCOM.BoYesNoEnum.tNO
            End If
            If oDBDSHeader.GetValue("U_InvItem", 0).Trim = "Y" Then
                oPostItem.InventoryItem = SAPbobsCOM.BoYesNoEnum.tYES
            Else
                oPostItem.InventoryItem = SAPbobsCOM.BoYesNoEnum.tNO
            End If

            If oDBDSHeader.GetValue("U_PurItem", 0).Trim = "Y" Then
                oPostItem.PurchaseItem = SAPbobsCOM.BoYesNoEnum.tYES
            Else
                oPostItem.PurchaseItem = SAPbobsCOM.BoYesNoEnum.tNO
            End If
            If oDBDSHeader.GetValue("U_UOMGroup", 0).Trim <> "" Then
                oPostItem.UoMGroupEntry = oDBDSHeader.GetValue("U_UOMGroup", 0).Trim
            End If
            If oDBDSHeader.GetValue("U_UnitOfSalM", 0).Trim <> "" Then
                oPostItem.SalesUnit = oDBDSHeader.GetValue("U_UnitOfSalM", 0).Trim
            End If
            If oDBDSHeader.GetValue("U_UnitOfPurM", 0).Trim <> "" Then
                oPostItem.PurchaseUnit = oDBDSHeader.GetValue("U_UnitOfPurM", 0).Trim
            End If

            oPostItem.SalesUnitLength = oDBDSHeader.GetValue("U_SLength", 0).Trim
            oPostItem.SalesUnitWidth = oDBDSHeader.GetValue("U_SWidth", 0).Trim
            oPostItem.SalesUnitHeight = oDBDSHeader.GetValue("U_SHeight", 0).Trim
            oPostItem.SalesUnitVolume = oDBDSHeader.GetValue("U_SCalCBM", 0).Trim

            oPostItem.PurchaseUnitLength = oDBDSHeader.GetValue("U_PLength", 0).Trim
            oPostItem.PurchaseUnitWeight = oDBDSHeader.GetValue("U_PWidth", 0).Trim
            oPostItem.PurchaseUnitHeight = oDBDSHeader.GetValue("U_PHeight", 0).Trim
            oPostItem.PurchaseUnitVolume = oDBDSHeader.GetValue("U_PCalCBM", 0).Trim
            'Dim manufact As SAPbouiCOM.ComboBox = frmItemCreation.Items.Item("Item_27").Specific
            'Dim manufacture As Integer = manufact.Selected.Value
            'oPostItem.Manufacturer = manufacture          
            If oDBDSHeader.GetValue("U_Hazardous", 0).Trim = "Y" Then
                oPostItem.UserFields.Fields.Item("U_Hazardous").Value = oDBDSHeader.GetValue("U_Hazardous", 0).Trim
            Else
                oPostItem.UserFields.Fields.Item("U_Hazardous").Value = "N"
            End If

            oPostItem.UserFields.Fields.Item("U_MinSalPrc").Value = oDBDSHeader.GetValue("U_MinSalPrc", 0).Trim
            oPostItem.UserFields.Fields.Item("U_MaxSalPrc").Value = oDBDSHeader.GetValue("U_MaxSalPrc", 0).Trim
            oPostItem.UserFields.Fields.Item("U_OrgCountCod").Value = oDBDSHeader.GetValue("U_OrgCountCod", 0).Trim
            oPostItem.UserFields.Fields.Item("U_OrgCountNam").Value = oDBDSHeader.GetValue("U_OrgCountNam", 0).Trim
            oPostItem.UserFields.Fields.Item("U_Category").Value = oDBDSHeader.GetValue("U_Category", 0).Trim
            oPostItem.UserFields.Fields.Item("U_SCartQty").Value = oDBDSHeader.GetValue("U_SCartQty", 0).Trim
            oPostItem.UserFields.Fields.Item("U_PCartQty").Value = oDBDSHeader.GetValue("U_PCartQty", 0).Trim

            oPostItem.UserFields.Fields.Item("U_Itemgrp").Value = oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim
            oPostItem.UserFields.Fields.Item("U_Itemgrpname").Value = oDBDSHeader.GetValue("U_ItmGrpName", 0).Trim

            oPostItem.UserFields.Fields.Item("U_HsCode").Value = oDBDSHeader.GetValue("U_HSCode", 0).Trim
            oPostItem.UserFields.Fields.Item("U_HsName").Value = oDBDSHeader.GetValue("U_HSName", 0).Trim
            oPostItem.UserFields.Fields.Item("U_Size").Value = oDBDSDetail1.GetValue("U_Code1", RowID - 1).Trim

            For i As Integer = 1 To oMatrix2.VisualRowCount
                If oDBDSDetail2.GetValue("U_Select", i - 1).Trim = "Y" Then
                    oPostItem.Properties(oDBDSDetail2.GetValue("U_PropCode", i - 1).Trim) = SAPbobsCOM.BoYesNoEnum.tYES
                Else
                    oPostItem.Properties(oDBDSDetail2.GetValue("U_PropCode", i - 1).Trim) = SAPbobsCOM.BoYesNoEnum.tNO
                End If
            Next
            oPostItem.Picture = System.IO.Path.GetFileName(oDBDSHeader.GetValue("U_Image", 0).Trim)

            ErrCode = oPostItem.Update()
            If ErrCode = 0 Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oPostItem)
                Dim squery As String = "Update OITM set ""FirmCode""='" & oDBDSHeader.GetValue("U_Manufact", 0).Trim & "' where ""ItemCode""='" & ItemCode & "'"
                oGfun.DoQuery(squery)
                oMatrix1.FlushToDataSource()
                oDBDSDetail1.SetValue("U_ItemCode", RowID - 1, oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim)
                oMatrix1.LoadFromDataSource()
                oMatrix1.AutoResizeColumns()
                squery = String.Empty
                squery = "UPDATE ""@INS_ITM1"" SET ""U_ItemCode""='" & oDBDSHeader.GetValue("U_ItmGrpCode", 0).Trim & "-" & oDBDSDetail1.GetValue("U_Code", RowID - 1).Trim & "' WHERE ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""LineId""='" & RowID & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(squery)
            Else
                oCompany.GetLastError(ErrCode, ErrMsg)
                oApplication.StatusBar.SetText("Fail to Post ItemCode:" & ErrCode & "-" & ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                oApplication.MessageBox("Fail to Post ItemCode:" & ErrCode & "-" & ErrMsg)
            End If
        Catch ex As Exception
            oApplication.StatusBar.SetText("Fail to Post ItemCode Function:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oApplication.MessageBox("Fail to Post ItemCode Function:" & ex.Message)
        End Try
    End Sub
End Class






