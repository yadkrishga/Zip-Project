﻿using Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SAPProc
{
	public interface ISapB1
	{
		string CreateOrder(Param1 param);
	
		UserInfo Finduser(UserInfo user);
	}
}
