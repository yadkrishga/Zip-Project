﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SAPbobsCOM;
using SAPbouiCOM;
using Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SalesIntegration
{
	public class IntegrationTrans : IBForm
	{
		Form oForm;
		public Grid Grid0, Grid1;
		int SelRow, lnkrow;
		DataTable dt0, dt1;

		bool renk, linked;
		HttpClient client;
		int install, goldix, ix1;
		string baseaddress;
		string datesept;
		BoDateTemplate datetemplate;
		string strdatetemplate;
		public IntegrationTrans()
		{

			AdminInfo adminInfo = ProgData.B1Company.GetCompanyService().GetAdminInfo();
		    datesept = adminInfo.DateSeparator;
			datetemplate = adminInfo.DateTemplate;
			strdatetemplate =  Enum.GetName(typeof(SAPbobsCOM.BoDateTemplate), datetemplate);
			strdatetemplate = strdatetemplate.Replace("dt_", "");
		}
		public int findFormSeq(string ftype)
		{
			int fnum = 0;
			IEnumerator forms = ProgData.B1Application.Forms.GetEnumerator();
			Form bForm = null;

#pragma warning disable CS0168 // Variable is declared but never used
			try
			{
				forms.Reset();
				while (forms.MoveNext())
				{
#pragma warning disable CS0168 // Variable is declared but never used
					try
					{
						bForm = (SAPbouiCOM.Form)forms.Current;
					}
					catch (Exception err)
					{
						continue;
					}
#pragma warning restore CS0168 // Variable is declared but never used
					if (bForm.UniqueID.Length >= ftype.Length && bForm.UniqueID.Substring(0, ftype.Length) == ftype)
					{
						string scnt = bForm.UniqueID.Substring(ftype.Length, bForm.UniqueID.Length - ftype.Length);
						int icnt = Convert.ToInt32(scnt);
						if (fnum < icnt)
							fnum = icnt;


					}
				}



			}
			catch (Exception et)
			{


			}
#pragma warning restore CS0168 // Variable is declared but never used
			fnum++;
			return fnum;



		}
		private static bool RemoteSSLTLSCertificateValidate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors ssl)
		{
			//accept
			return true;
		}
		public void CreateForm()
		{
			try
			{
				string srf = string.Empty;
				System.Xml.XmlDocument oXMLDoc;
				install = 0;

				oXMLDoc = new System.Xml.XmlDocument();

				oXMLDoc.Load(Logger.exeFolder + @"\trans.xml");

				string uid = oXMLDoc.SelectSingleNode("/application/forms/action/form | /Application/forms/action/form").Attributes["uid"].Value;
				uid = uid + Guid.NewGuid().ToString().Substring(0, 6);
				oXMLDoc.SelectSingleNode("/application/forms/action/form | /Application/forms/action/form").Attributes["uid"].Value = uid;

				srf = oXMLDoc.InnerXml;
				// ProgData.B1Application.LoadBatchActions(ref srf);

				// oForm = ProgData.B1Application.Forms.Item(uid);
				SAPbouiCOM.FormCreationParams oCP = null;
				oCP = ((SAPbouiCOM.FormCreationParams)(ProgData.B1Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)));
				oCP.XmlData = oXMLDoc.InnerXml;//load the form with XML 


				oForm = ProgData.B1Application.Forms.AddEx(oCP);

				ProgData.Forms.Add(oForm.UniqueID, this);


				//oForm.AutoManaged = true;
				oForm.Visible = true;
				oForm.EnableMenu("1282", true);
				oForm.EnableMenu("1288", true);
				oForm.EnableMenu("1289", true);
				oForm.EnableMenu("1290", true);
				oForm.EnableMenu("1291", true);
				oForm.EnableMenu("4869", true);
				//oForm.EnableMenu("1293", true);
				SAPbouiCOM.ComboBox cbx = (SAPbouiCOM.ComboBox)oForm.Items.Item("stcbx").Specific;
				Grid0 = (Grid)oForm.Items.Item("Grid0").Specific;
				Grid1 = (Grid)oForm.Items.Item("Grid1").Specific;

				dt0 = oForm.DataSources.DataTables.Item("DT0");
				dt1 = oForm.DataSources.DataTables.Item("DT1");
				cbx.Select("F", BoSearchKey.psk_ByValue);
				cbx.ExpandType = BoExpandType.et_DescriptionOnly;
				cbx.Item.DisplayDesc = true;
				string Value1 = DateTime.Today.ToString("yyyyMMdd");
				Value1 = Value1.Substring(0, Value1.Length - 2) + "01";
				string Value2 = DateTime.Today.ToString("yyyyMMdd");
				UserDataSource ds1 = oForm.DataSources.UserDataSources.Item("UD_3");
				UserDataSource ds2 = oForm.DataSources.UserDataSources.Item("UD_4");
				ds1.ValueEx = Value1;
				ds2.ValueEx = Value2;
				SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				string qry = $"Select CAST(A.empID as VARCHAR(20)),isNull(firstName,'')+isNull(middleName,'')+' '+isNull(lastName,'')  FROM OHEM A WHERE ISNULL(U_GA_EDIUser,'N')='Y'";
				rs.DoQuery(qry);
				cbx = (SAPbouiCOM.ComboBox)oForm.Items.Item("owncbx").Specific;
				cbx.ExpandType = BoExpandType.et_DescriptionOnly;
				while (!rs.EoF)
				{
					cbx.ValidValues.Add(rs.Fields.Item(0).Value.ToString(), rs.Fields.Item(1).Value.ToString());

					rs.MoveNext();
				}
				cbx.Select("A");
				ServicePointManager.ServerCertificateValidationCallback += RemoteSSLTLSCertificateValidate;
				renk = true;
				this.conjfilter();
				install = 1;
			}
			catch (Exception err)
			{
				Logger.Log(err);
			}
		}
		private string getDatefilter(string val,string min="Y")
		{
			DateTime dt = DateTime.MinValue;
			if ( min!="Y")
            {
				dt = DateTime.MaxValue;
            }
            
			string y = "";
			string ret = "";

			try
			{
				dt = DateTime.ParseExact(val, "yyyyMMdd", CultureInfo.InvariantCulture);

			}
			catch (Exception ex)
			{
				dt = DateTime.MinValue;
				if (min != "Y")
				{
					dt = DateTime.MaxValue;
				}
			}

			if (dt.Year == 1)
				y = "1900";
			else
				y = dt.Year.ToString();
			string month = dt.Month.ToString();
			if (month.Length == 1)
				month = "0" + month;
			string day = dt.Day.ToString();
			if (day.Length == 1)
				day = "0" + day;
			ret = y + "-" + month + "-" + day;
			return ret;

		}
		private void dateControl(ItemEvent pVal)
		{
		
			string Value1 = "", Value2 = "";
			
			DateTime dt = DateTime.MinValue;
			DateTime dt2 = DateTime.MaxValue;
			if (pVal.ItemUID == "itEdt2" || pVal.ItemUID == "impedt2")
			{
				
				EditText edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt1").Specific;
				EditText edt2 = (SAPbouiCOM.EditText)oForm.Items.Item(pVal.ItemUID).Specific;
				if (pVal.ItemUID == "impedt2")
				{
					edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("impedt1").Specific;
				}
				Value1 = "";
				Value2 = "";
				Value1 = edt1.Value;
				Value2 = edt2.Value;
				try
				{
					dt = DateTime.ParseExact(Value1, "yyyyMMdd", CultureInfo.InvariantCulture);

				}
				catch (Exception ex)
				{
					dt = DateTime.MinValue;

				}
				try
				{
					dt2 = DateTime.ParseExact(Value2, "yyyyMMdd", CultureInfo.InvariantCulture);

				}
				catch (Exception ex)
				{
					dt2 = DateTime.MaxValue;

				}

				if (dt > dt2)
				{
					ProgData.B1Application.StatusBar.SetText("Can't be less than the first date", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
					dt = dt2.AddDays(-1);

					
				}
			}
			if (pVal.ItemUID == "itEdt1" || pVal.ItemUID == "impedt1")
			{
				EditText edt1 = (SAPbouiCOM.EditText)oForm.Items.Item(pVal.ItemUID).Specific;
				EditText edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt2").Specific;
				if (pVal.ItemUID == "impedt1")
				{
					edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("impedt2").Specific;
				}
				Value1 = "";
				Value2 = "";
				Value1 = edt1.Value;
				Value2 = edt2.Value;
				try
				{
					dt = DateTime.ParseExact(Value1, "yyyyMMdd", CultureInfo.InvariantCulture);

				}
				catch (Exception ex)
				{
					dt = DateTime.MinValue;

				}
				try
				{
					dt2 = DateTime.ParseExact(Value2, "yyyyMMdd", CultureInfo.InvariantCulture);

				}
				catch (Exception ex)
				{
					dt2 = DateTime.MaxValue;

				}

				if (dt > dt2)
				{
					ProgData.B1Application.StatusBar.SetText("Can't be great than the second date", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
					dt2 = dt.AddDays(1);

				}
			}



			string y = "";
			if (dt.Year == 1)
				y = "1900";
			else
				y = dt.Year.ToString();


			string month = dt.Month.ToString();
			if (month.Length == 1)
				month = "0" + month;
			string day = dt.Day.ToString();
			if (day.Length == 1)
				day = "0" + day;
			string y2 = "";
			if (dt2.Year == 1)
				y2 = "1900";
			else
				y2 = dt2.Year.ToString();


			string month2 = dt2.Month.ToString();
			if (month2.Length == 1)
				month2 = "0" + month2;
			string day2 = dt2.Day.ToString();
			if (day2.Length == 1)
				day2 = "0" + day2;
			string dsname = "";
			string dsname2 = "";
			if (pVal.ItemUID == "itEdt2" || pVal.ItemUID == "itEdt1")
			{
				dsname = "UD_3";
				dsname2 = "UD_4";
			}
			else
			{
				dsname = "UD_9";
				dsname2 = "UD_10";
			}
			UserDataSource ds1 = oForm.DataSources.UserDataSources.Item(dsname);
			ds1.ValueEx = y + month + day;
			UserDataSource ds2 = oForm.DataSources.UserDataSources.Item(dsname2);
			ds2.ValueEx = y2 + month2 + day2;
			conjfilter();
		}
		private void conjfilter()
		{
			try
			{
				string filter = "";
				string Value1 = "", Value2 = "";
				SAPbouiCOM.ComboBox cbx = (SAPbouiCOM.ComboBox)oForm.Items.Item("stcbx").Specific;
				Value1 = cbx.Value;
				if (Value1 == "A" || Value1 == "")
					Value1 = "";
				else
					filter = $" Status = '{Value1}'";
				if (Value1 == "S" ||(Value1 == "A" || Value1 == ""))
				{
					filter += $"  ISNULL(b.CANCELED,'N') = 'N' and ISNULL(b.DocStatus,'O')<>'C' ";
				}
				//DocDate
				EditText edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt1").Specific;
				EditText edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt2").Specific;

				UserDataSource ds1 = oForm.DataSources.UserDataSources.Item("UD_3");
				UserDataSource ds2 = oForm.DataSources.UserDataSources.Item("UD_4");
				Value1 = "";
				Value2 = "";
				Value1 = edt1.Value;
				Value2 = edt2.Value;
				
				if (Value1.Length > 6 || Value2.Length > 6)
				{
					Value1 = getDatefilter(Value1);
					Value2 = getDatefilter(Value2,"N");
					string dtfilter = $" (\"OrderDate\" BETWEEN '{Value1}' AND '{Value2}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}
			
				
				// CustCode
				Value1 = "";
				Value2 = "";
				edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt3").Specific;
				edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt4").Specific;

				ds1 = oForm.DataSources.UserDataSources.Item("UD_0");
				ds2 = oForm.DataSources.UserDataSources.Item("UD_1");
				Value1 = ds1.Value;
				Value2 = ds2.Value;
				if (Value1.Length > 0 || Value2.Length > 0)
				{


					string dtfilter = $" (\"Customer\" BETWEEN '{Value1}' AND '{Value2}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}
				// XMLFile
				edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt5").Specific;
				edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("itEdt6").Specific;

				ds1 = oForm.DataSources.UserDataSources.Item("UD_5");
				ds2 = oForm.DataSources.UserDataSources.Item("UD_6");
				Value1 = "";
				Value2 = "";
				Value1 = ds1.Value;
				Value2 = ds2.Value;
				if (Value1.Length > 0 || Value2.Length > 0)
				{



					string dtfilter = $" (\"XMLFile\" BETWEEN '{Value1}' AND '{Value2}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}
				Value1 = "";
				cbx = (SAPbouiCOM.ComboBox)oForm.Items.Item("owncbx").Specific;
				Value1 = cbx.Value;
				if (Value1 == "A" || Value1 == "")
					Value1 = "";
				if (Value1.Length > 0)
				{



					string dtfilter = $" (B.\"OwnerCode\" = '{Value1}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}

				//ImportDate
				Value1 = "";
				Value2 = "";
				edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("impedt1").Specific;
				edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("impedt2").Specific;

				UserDataSource ds9 = oForm.DataSources.UserDataSources.Item("UD_9");
				UserDataSource ds10 = oForm.DataSources.UserDataSources.Item("UD_10");
				Value1 = edt1.Value;
				Value2 = edt2.Value;
				if (Value1.Length > 6 || Value2.Length > 6)
				{
					Value1 = getDatefilter(Value1);
					Value2 = getDatefilter(Value2);
					string dtfilter = $" (\"ImportDate\" BETWEEN '{Value1}' AND '{Value2}')";
					if (dtfilter.Length > 0)
					{
						if (filter.Length > 0)
							filter += " AND " + dtfilter;
						else
							filter = dtfilter;
					}
				}
				////APP_Date
				//Value1 = "";
				//Value2 = "";
				//edt1 = (SAPbouiCOM.EditText)oForm.Items.Item("resedt1").Specific;
				//edt2 = (SAPbouiCOM.EditText)oForm.Items.Item("resedt2").Specific;

				//UserDataSource ds11 = oForm.DataSources.UserDataSources.Item("UD_11");
				//UserDataSource ds12 = oForm.DataSources.UserDataSources.Item("UD_12");
				//Value1 = edt1.Value;
				//Value2 = edt2.Value;
				//if (Value1.Length > 6 || Value2.Length > 6)
				//{
				//	Value1 = getDatefilter(Value1);
				//	Value2 = getDatefilter(Value2);
				//	string dtfilter = $" (\"App_Date\" BETWEEN '{Value1}' AND '{Value2}')";
				//	if (dtfilter.Length > 0)
				//	{
				//		if (filter.Length > 0)
				//			filter += " AND " + dtfilter;
				//		else
				//			filter = dtfilter;
				//	}
				//}
				////reject
				//Value1 = "";
				//cbx = (SAPbouiCOM.ComboBox)oForm.Items.Item("arcbx").Specific;
				//Value1 = cbx.Value;

				//if (Value1.Length > 0)
				//{



				//	string dtfilter = $" (\"AR\" = '{Value1}')";
				//	if (dtfilter.Length > 0)
				//	{
				//		if (filter.Length > 0)
				//			filter += " AND " + dtfilter;
				//		else
				//			filter = dtfilter;
				//	}
				//}
				Bind(filter);
			}
			catch (Exception ex)
			{
				Logger.Log(ex);
			}

		}
		private async Task renklendir(int startrow = 1, int say = 99999)
		{
			int errcolor = 252 | (221 << 4) | (130 << 8);

			//int color = 255 | (255 << 8) | (255 << 16);
#pragma warning disable CS0219 // Variable is assigned but its value is never used
			string pId = "";
#pragma warning restore CS0219 // Variable is assigned but its value is never used
			int ix = 0;
			DataTable dt = Grid0.DataTable;
			if (startrow > dt.Rows.Count)
				startrow = 1;
			if (startrow < 1)
				startrow = 1;
			string h = "";
			int row;
			if (!renk)
				return;
			try
			{
				for (int rownum = startrow; rownum <= Grid0.Rows.Count; rownum++)
				{
					if (!renk)
						break;
					h = "ROW";
					row = rownum - 1;

					if (row < 0)
						row = 1;
					if (row > dt.Rows.Count - 1)
						row = rownum - 1;

					// Grid0.CommonSetting.SetCellEditable(row, hataliCol, false);
					h = "Status";
					if (dt.GetValue("Status", row).ToString() == "F")
					{

						Grid0.CommonSetting.SetRowBackColor(rownum, errcolor);

						Grid0.CommonSetting.SetRowEditable(rownum, false);
						Grid0.CommonSetting.SetCellEditable(rownum, ix1 + 1, true);

					}
					else
					{
						Grid0.CommonSetting.SetRowBackColor(rownum, -1);
						Grid0.CommonSetting.SetRowEditable(rownum, false);
						//if (goldix > 0 && !String.IsNullOrEmpty(dt.GetValue("DocRef", row).ToString()))
						//{
						//	SAPbouiCOM.GridColumn oColumn = Grid0.Columns.Item(goldix);
						//	(oColumn as EditTextColumn).LinkedObjectType = "17";
						//	(oColumn as EditTextColumn).LinkPressedAfter += IntegrationTrans_LinkPressedAfter;
						//}

					}
					ix++;
					if (ix > say)
						break;

				}
			}
			catch (Exception e)
			{
				Logger.Log(new Exception(e.Message + "**" + h));
			}
			Task t = Task.Delay(50);
			await t;
		}

		private void IntegrationTrans_LinkPressedAfter(object sboObject, SBOItemEventArg pVal)
		{
			linked = true;
			lnkrow = pVal.Row;
		}
		private void refresh(int Row)
		{
			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			string docref = dt0.GetValue("DocRef", Row).ToString();

			string qry = $"select ISNULL((SELECT isNull(firstName,'')+isNull(middleName,'')+' '+isNull(lastName,'') as UserName FROM OHEM O INNER JOIN OUSR U on U.userId = O.userId And U.USER_CODE=AppUser),AppUser) as UserName from [TComm_Header] where DocRef = '{docref}'";
			try
			{
				rs.DoQuery(qry);
				string name = rs.Fields.Item(0).Value.ToString();
				dt0.SetValue("UserName", Row, name);


			}
			catch (Exception e)
			{
				Logger.Log(e);
			}
		}
		//		private void ItemCostList_LinkPressedBefore(object sboObject, SBOItemEventArg pVal, out bool BubbleEvent)
		//		{
		//			BubbleEvent = true;
		//#pragma warning disable CS0168 // Variable is declared but never used
		//			try
		//			{
		//				GridColumn oColumn = Grid0.Columns.Item(pVal.ColUID);

		//			}
		//			catch (Exception e)
		//			{

		//			}
		//#pragma warning restore CS0168 // Variable is declared but never used
		//		}

		private void Bind(string filter = "", string fld = "")
		{
			SAPbobsCOM.Recordset rs2 = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

			string sql2 = $"Select MAX(CONVERT(VARCHAR(5000),U_HQry))[HQry]   from [@G_MNG] ";
			rs2.DoQuery(sql2);
			goldix = -1;
			string sql = "";
			string Sel = oForm.DataSources.UserDataSources.Item("UD_8").Value;
			if (Sel == "")
				Sel = "N";
			{
				//sql = "select ROW_NUMBER() OVER(ORDER BY DocRef) AS ROW,'{Sel}' as Sel,CustomerPoNumber,Customer,CustomerName,OrderDate,RequestedShipDate,Branch ";
				//sql += ",ShipAddress1,ShipAddress2,ShipAddress3,ShipPostalCode,Status,Message,DocRef,ImportDate ";
				//sql += " from T_HEADERVW ";
				sql = $"select  ROW_NUMBER() OVER(ORDER BY OrderDate Desc) AS ROW,Case Status WHEN 'F' THEN '{Sel}' ELSE 'N' END as Sel ,";
						sql += " ISNULL((SELECT isNull(firstName,'')+isNull(middleName,'')+' '+isNull(lastName,'') as \"User Name\" FROM OHEM O INNER JOIN ORDR U on U.OwnerCode = O.empID WHERE U.DocEntry=A.DocRef),'') as \"User Name\" , A.DocRef,  ";
				sql +="A.CardCode as \"Customer Code\", A.CustomerPoNumber,A.Customer as \"Xml Customer Code\",A.CustomerName as \"Customer Name\",A.OrderDate as \"Order Date\",A.RequestedShipDate as \"Requested Ship Date\",A.Branch,";
				sql += $"A.ShipAddress1 as \"Ship Address1\",ShipAddress2  as \"Ship Address2\",ShipAddress3  as \"Ship Address3\",ShipPostalCode as \"Ship Postal Code\",A.Status,(A.Message)as [Message],(SELECT DocNum FROM ORDR WHERE DocEntry =A.[DocRef])[Document Number],ImportDate as \"Created Date\",Convert(nvarchar(10),ImportTime) as \"Created Time\", ";
			


				sql += "  XMLFile,XMLFolder FROM [TComm_Header] A LEFT JOIN ORDR b On A.DocRef=CAST(B.DocEntry as VARCHAR(20)) ";
				if (rs2.Fields.Item(0).Value.ToString().Trim() != "")
				{
					sql = rs2.Fields.Item(0).Value.ToString();
				}
				if (filter.Length > 0)
				{
					sql += " WHERE " + filter;

					string bag = "";

				}
				sql += " ORDER BY OrderDate desc";
			}
			try
			{
				oForm.Freeze(true);

				dt0.ExecuteQuery(sql);
				Grid0.DataTable = dt0;


				int ix = 0;


				SAPbouiCOM.GridColumn oColumn = Grid0.Columns.Item(ix);
				oColumn.TitleObject.Caption = "#";
				oColumn.TitleObject.Sortable = true;
				oColumn.RightJustified = true;	
				oColumn.Editable = false;
				ix1 = -1;

				for (int i = 0; i < Grid0.Columns.Count; i++)
				{
					oColumn = Grid0.Columns.Item(i);
					if (oColumn.UniqueID == "Sel" )
					{
						oColumn.Editable = true;
						oColumn.TitleObject.Sortable = true;
						if (oColumn.UniqueID == "Sel")
						{
							ix1 = i;
							oColumn.Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
						}



						oColumn.Editable = true;
					}
					else
						oColumn.Editable = false;
					if (oColumn.UniqueID == "Customer Code")
					{
						oColumn.TitleObject.Caption = "Customer Code";
						
						oColumn = Grid0.Columns.Item(i);
						(oColumn as EditTextColumn).LinkedObjectType = "2";
						(oColumn as EditTextColumn).LinkPressedAfter += IntegrationTrans_LinkPressedAfter;
					} else
					if (oColumn.UniqueID == "CustomerPONumber")
					{
						oColumn.TitleObject.Caption = "Customer PO Number";
					} else
					if (oColumn.UniqueID == "XMLFile")
					{
						oColumn.TitleObject.Caption = "XML File Name";
					} else
					if (oColumn.UniqueID == "XMLFolder")
					{
						oColumn.TitleObject.Caption = "XML Folder";
					} else
					if (oColumn.UniqueID == "DocRef")
					{
						goldix = i;
						oColumn = Grid0.Columns.Item(goldix);
						(oColumn as EditTextColumn).LinkedObjectType = "17";
						(oColumn as EditTextColumn).LinkPressedAfter += IntegrationTrans_LinkPressedAfter;
					}

				}
				oColumn = Grid0.Columns.Item(Grid0.Columns.Count - 1);
				oColumn.Visible = false;

				Grid0.SelectionMode = BoMatrixSelect.ms_Single;
				if (dt0.Rows.Count > 0)
				{
					SubBind(dt0.GetValue("CustomerPoNumber", 0).ToString());
				}
				else
					SubBind("xxxxx");
				renk = true;
				var task = Task.Run(async () => await renklendir(1));

			}
			catch (Exception e)
			{
				Logger.Log(new Exception(e.Message + sql));
			}
			oForm.Freeze(false);
		}
		private void SubBind(string PoNumber)
		{
			SAPbobsCOM.Recordset rs2 = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			string sql2 = $"Select MAX(CONVERT(VARCHAR(5000),U_LQry))[LQry]   from [@G_MNG] ";
			rs2.DoQuery(sql2);
			PoNumber = PoNumber.Trim();

			//ROW_NUMBER() OVER(ORDER BY DocRef) AS ROW,
			string sql = $"select CustomerPoLine as \"Customer PO Line\",Case Status WHEN 'N' THEN 'Stock' ELSE 'Expense' END as Status,  A.StockCode   as \"Stock Code\",A.StockDescription as \"Description\",A.OrderQty as \"Quantity\",A.Price,A.Comment,A.Message";
			sql += $" FROM [TComm_Lines] A ";
			if (rs2.Fields.Item(0).Value.ToString().Trim()!= "")
			{
				sql = rs2.Fields.Item(0).Value.ToString();
			}
			sql+=$" WHERE CustomerPoNumber = '{PoNumber}' ORDER BY CustomerPoLine";



			try
			{

				dt1.ExecuteQuery(sql);
				Grid1.DataTable = dt1;


				int ix = 0;


				SAPbouiCOM.GridColumn oColumn = Grid1.Columns.Item(ix);


				for (int i = 0; i < Grid1.Columns.Count; i++)
				{
					oColumn = Grid1.Columns.Item(i);

					oColumn.Editable = false;
					if (oColumn.UniqueID == "Quantity" || oColumn.UniqueID == "Price" || oColumn.UniqueID == "Customer PO Line")
					{
						oColumn.RightJustified = true;
					}
					else
						if (oColumn.UniqueID == "Stock Code")
					{
						
						oColumn = Grid1.Columns.Item(i);
						(oColumn as EditTextColumn).LinkedObjectType = "4";
						(oColumn as EditTextColumn).LinkPressedAfter += IntegrationTrans_LinkPressedAfter;
					}
					
					
				}



			}
			catch (Exception e)
			{
				Logger.Log(new Exception(e.Message + sql));
			}

		}

		private void SelectedGrid0(ItemEvent pVal)
		{

			try
			{
				int row = pVal.Row;
				if (pVal.Row > -1)
				{
					SelRow = pVal.Row;
					SubBind(dt0.GetValue("CustomerPoNumber", SelRow).ToString());
				}


			}
			catch (Exception e)
			{
				Logger.Log(new Exception());
			}
#pragma warning restore CS0168 // Variable is declared but never used
		}

		private void Chk_PressedAfter(object sboObject, SBOItemEventArg pVal)
		{
			Bind();
		}
		private bool lncontrol(string ponumber)
		{
			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

			string sql = $"select A.Message ,Status";
			sql += $" FROM [TComm_Lines] A WHERE CustomerPoNumber = '{ponumber}' AND Message >'' ORDER BY CustomerPoLine";
			bool priceerror = true;
			try
			{

				rs.DoQuery(sql);
				while (!rs.EoF)
				{
						if (rs.Fields.Item("Message").Value.ToString().IndexOf("different Price") < 0)
						priceerror = priceerror && false;
					else
						priceerror = priceerror && true;
					rs.MoveNext();
				}


			}
			catch (Exception ex)
			{ }
			return priceerror;
		}
		private void DeleteRow()
		{
			try
			{
				SAPbouiCOM.Grid Grid0 = (Grid)oForm.Items.Item("Grid0").Specific;

				for (int i = 0; i < dt0.Rows.Count; i++)
				{
					DataTable dt = Grid0.DataTable;
					if (dt0.GetValue("Sel", i).ToString() == "Y" && dt0.GetValue("Status", i).ToString() == "F")
					{

						
							string PONo = dt.GetValue("CustomerPoNumber", i).ToString();
							string fname = dt.GetValue("XMLFile", i).ToString();
							string filename = dt.GetValue("XMLFolder", i).ToString();
							string Basepath = filename.Substring(0, filename.IndexOf(@"\F") + 1);
							string path = Basepath;
							string folder = "A";
							path = path + folder;
							if (!Directory.Exists(path))
								Directory.CreateDirectory(path);
							string newFile = path + @"\" + fname;
							try
							{
								File.Move(filename, newFile);
							}
							catch (Exception e)
							{
								Logger.Log(e);
							}
							SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
							rs.DoQuery("Delete FROM [TComm_Lines] WHERE [CustomerPoNumber] ='" + PONo + "' and [Status]='F'");
							rs.DoQuery("Delete FROM [TComm_Header] WHERE [CustomerPoNumber] ='" + PONo + "' and [Status]='F'");
							ProgData.B1Application.StatusBar.SetText($"Successfully deleted row with PO No:'" + PONo + "'", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
						}
					}
						oForm.Items.Item("refbtn").Click(BoCellClickType.ct_Regular);
					
				
			}
			catch (Exception e)
			{
				Logger.Log(e);
			}
		}
		private void process()
		{
			string ret = "";
			Param1 p = null;
			try
			{

				ConnectApi();
				SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				rs.DoQuery("select U_APIUser,U_APIpssw from [@G_MNG]");
				string usr = rs.Fields.Item(0).Value.ToString();
				string passw = rs.Fields.Item(1).Value.ToString();
				passw = Logger.Decrypt(passw, true);
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < dt0.Rows.Count; i++)
				{

					if (dt0.GetValue("Sel", i).ToString() == "Y" && dt0.GetValue("Status", i).ToString() == "F")
					{
						string ponumber = dt0.GetValue("CustomerPoNumber", i).ToString();

						ProgData.B1Application.StatusBar.SetText($"CustomerPoNumber {ponumber} in process", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);


						string filename = dt0.GetValue("XMLFolder", i).ToString();
						string fname = dt0.GetValue("XMLFile", i).ToString();
						//string filename = folder + fname;

						XmlDocument doc = new XmlDocument();

						doc.Load(filename);

						p = new Param1();
						p.xmlName = fname;
						p.xmlDoc = doc.InnerXml;
						p.userId = usr;
						p.password = passw;
						bool pr = lncontrol(ponumber);
						
						if (pr && dt0.GetValue("Message",i).ToString().IndexOf("there is error in lines")>-1)
							p.source = "addon"; else
							p.source = "";
						
						XmlNode headernode = doc.SelectSingleNode("SalesOrders/Orders/OrderHeader");

						string xmlponumber = headernode.SelectSingleNode("CustomerPoNumber").InnerText;
						if (!ponumber.Equals(xmlponumber))
						{
							ProgData.B1Application.MessageBox("The ponumber in the xml is different from the ponumber of this record");
							return;
						}

						string path = @"SalesOrder";
						ret = this.Send(path, p).GetAwaiter().GetResult();
						updateHeader(i);
						updateOrdr(i);
						Logger.Log(ret);
						sb.AppendLine($"CustomerPoNumber {ponumber}....{ret}"+'\r'+'\n');


					}
				}
				ProgData.B1Application.MessageBox(sb.ToString()); ;
				conjfilter();
				dt0.Rows.Offset = SelRow;
				Grid0.Columns.Item(0).Click(SelRow);

			}
			catch (Exception e)
			{
				Logger.Log(e);
			}
		}
		private void updateOrdr(int row)
		{
			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			string ponumber = dt0.GetValue("CustomerPoNumber", row).ToString();
			string Usercode = "";
			string docentry = "";
			string qry = $"select DocRef from [TComm_Header] where CustomerPoNumber = '{ponumber}'";
			try
			{
				rs.DoQuery(qry);
				docentry = rs.Fields.Item(0).Value.ToString();
				//if (Convert.ToInt32(docentry) > 0)
				//{
				//	qry = $"Select empID FROM OUSR A INNER JOIN OHEM B ON A.UserId = B.UserId Where A.USERID = {ProgData.B1Company.UserSignature}";
				//	rs.DoQuery(qry);
				//	Usercode = rs.Fields.Item(0).Value.ToString();
				//	qry = $"UPDATE ORDR Set OwnerCode= {Usercode} WHERE DocEntry = {docentry} ";
				//	rs.DoQuery(qry);
				//}
			}
			catch (Exception e)
			{
				Logger.Log(e);
			}

		}
		private void updateHeader(int row)
		{
			DbUtility dbutil = new DbUtility();

			SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
			string qry = $"Select USER_CODE FROM OUSR Where USERID = {ProgData.B1Company.UserSignature}";
			string Usercode = "";
			string AR = "";// dt0.GetValue("Reject",row).ToString();
			string ponumber = dt0.GetValue("CustomerPoNumber", row).ToString();
			try

			{
				rs.DoQuery(qry);
				Usercode = rs.Fields.Item(0).Value.ToString();

			}
			catch { }

			dbutil.UpdateHeader(Usercode, AR, "", ponumber);
		}
		private async Task<string> Send(string path, Param1 p)
		{
			string json = "";
			string hata = "**";
			string res = "";
			try
			{

				json = JsonConvert.SerializeObject(p);

				var request = new HttpRequestMessage(HttpMethod.Post, path);

				client.DefaultRequestHeaders.Host = client.BaseAddress.Host;
				request.Headers.Host = client.BaseAddress.Host;


				using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
				{

					request.Content = stringContent;


					using (var response = await client
						.SendAsync(request, HttpCompletionOption.ResponseHeadersRead)
						.ConfigureAwait(false))
					{

						res = await response.Content.ReadAsStringAsync();
						if (response.StatusCode != HttpStatusCode.OK)
						{
							throw new Exception(res);
						}

					}
				}
			}

			catch (Exception er)
			{
				Logger.Log(new Exception(er.Message + "**" + hata + "--" + path + "--" + res + " **** " + json));
			}
			return res;
		}

		private void ConnectApi()
		{

#pragma warning disable CS0168 // Variable is declared but never used
			try
			{
				Dictionary<string, string> ayar = new Dictionary<string, string>();
				client = new HttpClient();


				string Folder = AppDomain.CurrentDomain.BaseDirectory;
				using (StreamReader r = new StreamReader(Folder + @"\process.config"))
				{
					string pconfig = "";
					while (r.Peek() >= 0)
					{
						pconfig = r.ReadLine();
						string[] conf = pconfig.Split('=');
						if (conf.Length > 1)
							ayar.Add(conf[0], conf[1]);

					}





				}
				//   var webapi = System.Con,figuration.ConfigurationManager.AppSettings["WebApi"];
				baseaddress = ayar["WebApi"];
				client.BaseAddress = new Uri(baseaddress);
				client.DefaultRequestHeaders.Accept.Clear();
				client.DefaultRequestHeaders.Accept.Add(
				   new MediaTypeWithQualityHeaderValue("application/json"));

				ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

			}
			catch (Exception e)
			{

			}
#pragma warning restore CS0168 // Variable is declared but never used

		}
		private void changeselect()
		{
			oForm.Freeze(true);
			CheckBox cbx = (CheckBox)oForm.Items.Item("Item_34").Specific;
			string sel = "Y";
			if (cbx.Checked)
				sel = "N";
			try
			{
				for (int i = 0; i < dt0.Rows.Count; i++)
				{
					if (dt0.GetValue("Status", i).ToString() == "F")
						dt0.SetValue("Sel", i, sel);

				}
			} catch (Exception e) { 
				Logger.Log(e);
			}
			oForm.Freeze(false);


		}
		public void EventAll(ItemEvent pVal)
		{
			if (install == 0)
				return;


			{
				if (linked && pVal.EventType == BoEventTypes.et_FORM_ACTIVATE)
				{
					linked = false;
					//refresh(lnkrow);
				}

				if (pVal.BeforeAction == false && (pVal.ItemUID == "itEdt2" || pVal.ItemUID == "impedt1" || pVal.ItemUID == "impedt2"
					 || pVal.ItemUID == "itEdt1") && pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
				{
					linked = false;
					dateControl(pVal);
				}
				else
					if (pVal.BeforeAction == false && pVal.ItemUID == "Grid0" && pVal.EventType == BoEventTypes.et_CLICK)
				{
					renk = true;
					SelectedGrid0(pVal);
				}
				else
				//	if (pVal.BeforeAction == false && pVal.ItemUID == "Grid0" && pVal.EventType == BoEventTypes.et_VALIDATE && pVal.ColUID == "Reject")
				//{
				//	updateHeader(pVal.Row-1);
				//}
				//else
				if (pVal.BeforeAction == false && pVal.ItemUID == "dbtn" && pVal.EventType == BoEventTypes.et_CLICK)
				{
					DeleteRow();
				}
				else
				if (pVal.BeforeAction == false && pVal.ItemUID == "pbtn" && pVal.EventType == BoEventTypes.et_CLICK)
				{
					process();
				}
				else
				if (pVal.EventType == BoEventTypes.et_CLICK)
				{
					if (pVal.BeforeAction == false && pVal.ItemUID == "Item_34")

					{
						renk = false;
						changeselect();
					}
					else
					if (pVal.BeforeAction == false && pVal.ItemUID == "refbtn")
						
						{
							renk = true;
							conjfilter();
						}
				}
				else
					if (pVal.BeforeAction == false && pVal.EventType == BoEventTypes.et_FORM_RESIZE)
				{
					renk = false;
					Grid1.Item.Top = Grid0.Item.Top + Grid0.Item.Height;
					if ((Grid1.Item.Top + Grid1.Item.Height) >= oForm.Items.Item("pbtn").Top)
					{
						int h = (Grid1.Item.Top + Grid1.Item.Height) - oForm.Items.Item("pbtn").Top;
						Grid0.Item.Height = Grid0.Item.Height - h / 2;
						Grid1.Item.Height = Grid1.Item.Height - h / 2;
						Grid1.Item.Top = Grid0.Item.Top + Grid0.Item.Height;
					}
					else
						if ((Grid1.Item.Top + Grid1.Item.Height + 20) < oForm.Items.Item("pbtn").Top)
					{
						int h = oForm.Items.Item("pbtn").Top - (Grid1.Item.Top + Grid1.Item.Height + 20);
						Grid0.Item.Height = Grid0.Item.Height + h / 2;
						Grid1.Item.Height = Grid1.Item.Height + h / 2;
						Grid1.Item.Top = Grid0.Item.Top + Grid0.Item.Height;
					}

				}
			}





		}

		public void Menu(ref MenuEvent pVal)
		{
			throw new NotImplementedException();
		}
	}
}
