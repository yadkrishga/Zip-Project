Public Class SalesInvoice

    Dim frmSalesInvoice As SAPbouiCOM.Form
    Dim oMatrix, oMatrix1, oMatrix2, oMatSub As SAPbouiCOM.Matrix
    Dim oDBDSHeader, oDBDSDetail, oDBDSDetail1, oDBDSHeaderReq, oDBDSDetail2, oDBDSSubDetail2 As SAPbouiCOM.DBDataSource
    Dim UDOID As String = "OINV1"
    Dim sPaySlipSourcePath As String = ""
    Dim sPaySlipFileExt As String = ".pdf"
    Dim DeleteRowITEMUID As String = ""
    Dim boolFilterItem As Boolean = False
    Dim FinalTAmount As Double = 0.0
    Dim GlobalFinalTAmount As Double = 0.0
    Dim TaXcode As String
    Dim row As String
    Dim SubRowID As Integer
    Dim DocEntry As Double = 0
    Dim Createform As Boolean = True
    Dim GlbRowID As Integer = 0

    Dim ApprovalRemarks As String = ""

    Sub LoadSalesInvoice()
        Try
            oGfun.LoadXML(frmSalesInvoice, SalesInvoiceFormID, SalesInvoiceXML)
            frmSalesInvoice = oApplication.Forms.Item(SalesInvoiceFormID)
            oMatrix = frmSalesInvoice.Items.Item("Matrix1").Specific
            oMatrix2 = frmSalesInvoice.Items.Item("Matrix2").Specific
            oDBDSHeader = frmSalesInvoice.DataSources.DBDataSources.Item(0)
            oDBDSDetail = frmSalesInvoice.DataSources.DBDataSources.Item(1)
            oDBDSDetail2 = frmSalesInvoice.DataSources.DBDataSources.Item(2)
            Me.InitForm()
            'oGfun.LoadExchangeRate()
            Me.DefineModesForFields()
            oMatrix.AutoResizeColumns()
            oMatrix.CommonSetting.EnableArrowKey = True

            oMatrix2.AutoResizeColumns()
            oMatrix2.CommonSetting.EnableArrowKey = True
            'CheckUser()

        Catch ex As Exception
            oApplication.StatusBar.SetText("LoadSalesInvoice", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub

    Sub DefineModesForFields()
        Try
            frmSalesInvoice.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSalesInvoice.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSalesInvoice.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSalesInvoice.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSalesInvoice.Items.Item("t_Docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSalesInvoice.Items.Item("t_Docnum").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSalesInvoice.Items.Item("t_Docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSalesInvoice.Items.Item("c_series").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSalesInvoice.Items.Item("t_Docdate").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            'frmSalesInvoice.Items.Item("c_postaus").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            'frmSalesInvoice.Items.Item("bt_item").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSalesInvoice.Items.Item("t_Whscode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
            frmSalesInvoice.Items.Item("t_Whscode").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)

            frmSalesInvoice.Items.Item("b_Copy").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 4, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
            frmSalesInvoice.Items.Item("b_Copy").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub InitForm()
        Try
            frmSalesInvoice.Freeze(True)
            Createform = True

            frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE
            oGfun.SetNewLine(oMatrix, oDBDSDetail)
            oGfun.SetNewLine(oMatrix2, oDBDSDetail2)
            oGfun.LoadComboBoxSeries(frmSalesInvoice.Items.Item("c_series").Specific, UDOID, "", "")
            oGfun.LoadDocumentDate(frmSalesInvoice.Items.Item("t_Docdate").Specific)

            frmSalesInvoice.PaneLevel = 1
            frmSalesInvoice.ActiveItem = "t_Whscode"

            frmSalesInvoice.Freeze(False)
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            frmSalesInvoice.Freeze(False)
        Finally
        End Try
    End Sub

    Function ValidateAll() As Boolean
        Try


            'frmSalesInvoice.Items.Item("t_find").Specific.value = ""
            If frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Then

                If frmSalesInvoice.Items.Item("t_Whscode").Specific.value.Equals("") Then
                    oApplication.StatusBar.SetText("Whs Code Should Not be left Empty", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                    frmSalesInvoice.Items.Item("t_Whscode").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                    Return False
                End If
            End If

           
            ValidateAll = True
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
            ValidateAll = False
        Finally
        End Try
    End Function
    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try

            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        If Not oDataTable Is Nothing And pVal.BeforeAction = False Then
                            Select Case pVal.ItemUID

                                Case "t_custcode", "t_custname"
                                    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    oDBDSHeader.SetValue("U_CntCtCode", 0, oDataTable.GetValue("CntctPrsn", 0))
                                    oDBDSHeader.SetValue("U_PayToCode", 0, oDataTable.GetValue("BillToDef", 0))
                                    oDBDSHeader.SetValue("U_ShipToCode", 0, oDataTable.GetValue("ShipToDef", 0))

                                    oDBDSHeader.SetValue("U_CreditLimit", 0, oDataTable.GetValue("CreditLine", 0))
                                    oDBDSHeader.SetValue("U_Balance", 0, oDataTable.GetValue("Balance", 0))
                                    sQuery = String.Empty
                                    sQuery = "SELECT Sum(T0.""Debit""- T0.""Credit"")  FROM JDT1 T0 WHERE T0.""DueDate"" < CURRENT_DATE and T0.""Account"" <> T0.""ShortName"" and T0.""ShortName""='" & oDataTable.GetValue("CardCode", 0) & "'"
                                    Dim RstOverDue As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If RstOverDue.RecordCount > 0 Then
                                        oDBDSHeader.SetValue("U_Overdue", 0, RstOverDue.Fields.Item(0).Value)
                                    End If
                                    oDBDSHeader.SetValue("U_PayTerms", 0, oDataTable.GetValue("GroupNum", 0)) 'SalesRst.Fields.Item("GroupNum").Value)
                                    Dim SalesEmpStr As String = "SELECT * FROM OSLP  WHERE ""SlpCode"" IN(SELECT ""SlpCode""  FROM OCRD Where ""CardCode"" ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "')"
                                    Dim SalesRst As SAPbobsCOM.Recordset = oGfun.DoQuery(SalesEmpStr)
                                    oDBDSHeader.SetValue("U_SlpCode", 0, SalesRst.Fields.Item("SlpCode").Value)
                                    'Dim Str As String = "SELECT  (ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','+ifnull(D.Name,''))BillTo"
                                    'Str += " FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode and a.BillToDef =b.Address "
                                    'Str += "  LEFT OUTER JOIN OCST C ON C.Code =b.State "
                                    'Str += "  LEFT OUTER JOIN OCRY D On D.Code =b.Country "
                                    'Str += "  Where A.CardCode ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and  b.AdresType  ='B'"

                                    Dim Str As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""BillTo"" "
                                    Str += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""BillToDef"" = b.""Address"" "
                                    Str += " LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" "
                                    Str += " WHERE A.""CardCode"" = '" & Trim(oDataTable.GetValue("CardCode", 0)) & "' AND b.""AdresType"" = 'B';"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

                                    'Dim Str1 As String = "SELECT  (ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','+ifnull(D.Name,''))ShipTo"
                                    'Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode and a.ShipToDef =b.Address "
                                    'Str1 += "  LEFT OUTER JOIN OCST C ON C.Code =b.State "
                                    'Str1 += "  LEFT OUTER JOIN OCRY D On D.Code =b.Country "
                                    'Str1 += "  Where A.CardCode ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and  b.AdresType  ='S'"

                                    Dim Str1 As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""ShipTo"" "
                                    Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""ShipToDef"" = b.""Address"" LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" "
                                    Str1 += " LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" WHERE A.""CardCode"" ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' AND b.""AdresType"" = 'S';"
                                    Dim Rst1 As SAPbobsCOM.Recordset = oGfun.DoQuery(Str1)

                                    oDBDSHeader.SetValue("U_Address2", 0, Rst.Fields.Item("BillTo").Value)
                                    oDBDSHeader.SetValue("U_Address", 0, Rst1.Fields.Item("ShipTo").Value)

                                    oGfun.setComboBoxValue(frmSalesInvoice.Items.Item("c_billto").Specific, "SELECT  Distinct ""Address"",""Address"" FROM CRD1 Where ""CardCode""='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and ""AdresType""='B'")

                                    oGfun.setComboBoxValue(frmSalesInvoice.Items.Item("c_shipto").Specific, "SELECT  Distinct ""Address"",""Address"" FROM CRD1 Where ""CardCode""='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and ""AdresType""='S'")

                                    ''oGfun.SetNewLine(oMatrix, oDBDSDetail)

                                    'Case "t_custname"
                                    '    oDBDSHeader.SetValue("U_CardCode", 0, oDataTable.GetValue("CardCode", 0))
                                    '    oDBDSHeader.SetValue("U_CardName", 0, oDataTable.GetValue("CardName", 0))
                                    '    oDBDSHeader.SetValue("U_CntCtCode", 0, oDataTable.GetValue("CntctPrsn", 0))
                                    '    'oGfun.SetNewLine(oMatrix, oDBDSDetail)

                                Case "35"
                                    oDBDSHeader.SetValue("U_OwnerCode", 0, Trim(oDataTable.GetValue("empID", 0)))
                                    oDBDSHeader.SetValue("U_OwnerName", 0, Trim(oDataTable.GetValue("lastName", 0)) & "," & Trim(oDataTable.GetValue("firstName", 0)))
                                    oDBDSHeader.SetValue("U_PreByCod", 0, Trim(oDataTable.GetValue("empID", 0)))
                                Case "t_pickwhs"
                                    oDBDSHeader.SetValue("U_PickWhs", 0, oDataTable.GetValue("WhsCode", 0))
                                Case "t_Whscode"
                                    oDBDSHeader.SetValue("U_WhsCode", 0, oDataTable.GetValue("WhsCode", 0))
                                    oDBDSHeader.SetValue("U_WhsName", 0, oDataTable.GetValue("WhsName", 0))

                                Case "Matrix"
                                    Select Case pVal.ColUID
                                        Case "itemcode"
                                            'frmSalesInvoice.Freeze(True)
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_ItemCode", pVal.Row - 1, Trim(oDataTable.GetValue("ItemCode", 0)))
                                            oDBDSDetail.SetValue("U_Dscription", pVal.Row - 1, Trim(oDataTable.GetValue("ItemName", 0)))
                                            sQuery = String.Empty
                                            sQuery = "SELECT a.""DfltWH"",a.""VatGourpSa"",b.""Rate"" FROM OITM A LEFT JOIN OVTG B ON A.""VatGourpSa""=b.""Code"" WHERE ""ItemCode""='" & Trim(oDataTable.GetValue("ItemCode", 0)) & "'"
                                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If Rst.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_TaxCode", oDBDSDetail.Offset, Rst.Fields.Item("VatGourpSa").Value)
                                                oDBDSDetail.SetValue("U_WhsCode", oDBDSDetail.Offset, Rst.Fields.Item("DfltWH").Value)
                                            End If

                                            sQuery = String.Empty
                                            sQuery = "CALL ""@INSPL_GET_STOCK"" ('" & Trim(oDataTable.GetValue("ItemCode", 0)) & "')"
                                            Dim RstStock As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If RstStock.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_InStock", oDBDSDetail.Offset, RstStock.Fields.Item(0).Value)
                                                oDBDSDetail.SetValue("U_Committed", oDBDSDetail.Offset, RstStock.Fields.Item(1).Value)
                                                oDBDSDetail.SetValue("U_OnHand", oDBDSDetail.Offset, RstStock.Fields.Item(2).Value)
                                            End If
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            'frmSalesInvoice.Freeze(False)

                                        Case "itemname"
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_ItemCode", pVal.Row - 1, Trim(oDataTable.GetValue("ItemCode", 0)))
                                            oDBDSDetail.SetValue("U_Dscription", pVal.Row - 1, Trim(oDataTable.GetValue("ItemName", 0)))
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            'frmSalesInvoice.Freeze(False)

                                        Case "whscode"
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_WhsCode", pVal.Row - 1, oDataTable.GetValue("WhsCode", 0))
                                            oDBDSDetail.SetValue("U_Location", pVal.Row - 1, oDataTable.GetValue("Location", 0))
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        Case "taxcode"
                                            oMatrix.FlushToDataSource()
                                            oDBDSDetail.SetValue("U_TaxCode", pVal.Row - 1, oDataTable.GetValue("Name", 0))
                                            ' oDBDSDetail.SetValue("U_FreeText", pVal.Row - 1, oDataTable.GetValue("Rate", 0))
                                            oMatrix.LoadFromDataSource()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                    End Select
                            End Select
                        End If

                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        frmSalesInvoice = oApplication.Forms.Item(SalesInvoiceFormID)
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("FORM ACTIVATE Event Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            'Case "t_custcode"
                            '    If pVal.BeforeAction = False Then
                            '        Dim Str As String = "SELECT * FROM OCRD Where ""CardType"" ='C' AND ""validFor"" ='Y'"
                            '        oGfun.ChooseFromListFilteration(frmSalesInvoice, "CAR_CFL", "CardCode", Str)
                            '    End If
                            'Case "t_custname"
                            '    If pVal.BeforeAction = False Then
                            '        Dim Str As String = "SELECT * FROM OCRD Where  ""CardType"" ='C' AND ""validFor"" ='Y'"
                            '        oGfun.ChooseFromListFilteration(frmSalesInvoice, "CAR_CFL2", "CardCode", Str)
                            '    End If
                            'Case "t_find"
                            '    If pVal.BeforeAction = False Then
                            '        frmSalesInvoice.Items.Item("t_find").Specific.value = ""
                            '    End If
                        End Select
                    Catch ex As Exception

                    End Try
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Select Case pVal.ItemUID
                            Case "39"
                                If pVal.BeforeAction = False Then
                                    Dim DiscntPrct As Double = 0.0, DiscntAmt As Double = 0.0, TotalBfrDis As Double = 0.0, Taxamount As Double = 0.0
                                    TotalBfrDis = oDBDSHeader.GetValue("U_TotBefDcnt", 0)
                                    DiscntPrct = oDBDSHeader.GetValue("U_DiscPrcnt", 0)
                                    Taxamount = oDBDSHeader.GetValue("U_TaxAmount", 0)
                                    DiscntAmt = Math.Round(CDbl(TotalBfrDis * DiscntPrct / 100), 2)
                                    oDBDSHeader.SetValue("U_Discount", 0, DiscntAmt)
                                    oDBDSHeader.SetValue("U_DocTotal1", 0, TotalBfrDis - DiscntAmt + Taxamount)
                                    'Dim Round As Double = 0.0
                                    'Round = oDBDSHeader.GetValue("U_DocTotal", 0)
                                    'oDBDSHeader.SetValue("U_RoundDiff", 0, Round)
                                End If
                            Case "45"
                                If pVal.BeforeAction = False Then
                                    Dim DocTotal As Double = 0.0
                                    Dim RoundOff As Double = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
                                    Dim LineTotal As Double = CDbl(oDBDSHeader.GetValue("U_TotBefDcnt", 0))
                                    Dim Discount As Double = CDbl(oDBDSHeader.GetValue("U_Discount", 0))
                                    Dim TaxAmt As Double = CDbl(oDBDSHeader.GetValue("U_TaxAmount", 0))
                                    Dim Freight As Double = CDbl(oDBDSHeader.GetValue("U_Frieght", 0))

                                    DocTotal = LineTotal - Discount + RoundOff + Freight + TaxAmt
                                    oDBDSHeader.SetValue("U_DocTotal1", 0, DocTotal)


                                End If


                                'Case "Matrix"
                                '    Select Case pVal.ColUID
                                '        Case "itemcode"
                                '            If pVal.BeforeAction = False Then
                                '                frmSalesInvoice.Freeze(True)
                                '                'oGfun.SetNewLine(oMatrix, oDBDSDetail)
                                '                oGfun.SetNewLine(oMatrix, oDBDSDetail, pVal.Row, "itemcode")
                                '                frmSalesInvoice.Freeze(False)
                                '            End If

                                'Case "qty"
                                '    If pVal.BeforeAction = True And pVal.ItemChanged = True Then
                                '        Me.MatrixLineCalculation(pVal.Row)
                                '        Me.HeaderTotal()
                                '    End If
                                'End Select
                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Select Case pVal.ItemUID


                            Case "39"
                                If pVal.BeforeAction = True And pVal.ItemChanged = True Then
                                    frmSalesInvoice.Freeze(True)
                                    Dim Discount As Double = frmSalesInvoice.Items.Item("39").Specific.value

                                    If Discount > 100 Then
                                        oApplication.StatusBar.SetText("Discount Percentage Should Not Be Greater Than 100...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        BubbleEvent = False
                                    End If
                                    frmSalesInvoice.Freeze(False)
                                End If

                            Case "Matrix"
                                Select Case pVal.ColUID
                                    Case "itemcode"
                                        If pVal.BeforeAction = False Then
                                            oGfun.SetNewLine(oMatrix, oDBDSDetail, pVal.Row, "itemcode")
                                        End If
                                    Case "discount"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then

                                            frmSalesInvoice.Freeze(True)
                                            Dim Discount As Double = oMatrix.Columns.Item("discount").Cells.Item(pVal.Row).Specific.value
                                            If Discount > 100 Then
                                                oApplication.StatusBar.SetText("Discount Percentage Should Not Be Greater Than 100...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                                BubbleEvent = False
                                            End If

                                            oMatrix.FlushToDataSource()
                                            Me.MatrixLineCalculation(pVal.Row)
                                            oMatrix.LoadFromDataSource()
                                            frmSalesInvoice.Freeze(False)

                                            Me.HeaderTotal()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)

                                        End If
                                    Case "qty", "untprc", "discount"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmSalesInvoice.Freeze(True)

                                            oMatrix.FlushToDataSource()
                                            Me.MatrixLineCalculation(pVal.Row)
                                            oMatrix.LoadFromDataSource()
                                            frmSalesInvoice.Freeze(False)

                                            Me.HeaderTotal()
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        frmSalesInvoice.Freeze(False)
                        oApplication.MessageBox(ex.Message)
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_KEY_DOWN
                    Try
                        Select Case pVal.CharPressed
                            Case "9"
                                Select Case pVal.ItemUID
                                    Case "t_find"
                                        frmSalesInvoice.Freeze(True)
                                        If pVal.BeforeAction = False Then


                                            If Trim(oMatrix.Columns.Item("itemcode").Cells.Item(1).Specific.Value) <> "" Then
                                                Dim Bool As Boolean
                                                Dim Row_Clik As Integer
                                                For i As Integer = 1 To oMatrix.VisualRowCount
                                                    If Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.Value) <> "" Then
                                                        Dim ItemCode As String = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.Value)
                                                        ItemCode = ItemCode.ToUpper()
                                                        Dim sFindValue As String = Trim(frmSalesInvoice.Items.Item("t_find").Specific.value)
                                                        sFindValue = sFindValue.ToUpper()
                                                        Bool = ItemCode.Contains(sFindValue)
                                                        If Bool = True Then
                                                            If sFindValue <> "" Then
                                                                oMatrix.AutoResizeColumns()
                                                                oMatrix.SelectRow(i, True, True)
                                                                oMatrix.AutoResizeColumns()
                                                                Row_Clik += i

                                                            Else
                                                                oMatrix.AutoResizeColumns()
                                                                oMatrix.SelectRow(i, False, False)
                                                                Row_Clik += i
                                                            End If
                                                        Else
                                                            oMatrix.AutoResizeColumns()
                                                            oMatrix.SelectRow(i, False, False)
                                                        End If
                                                    End If
                                                Next
                                                oMatrix.Columns.Item("qty").Cells.Item(Row_Clik).Click(SAPbouiCOM.BoCellClickType.ct_Regular)
                                            End If

                                        End If
                                        frmSalesInvoice.Freeze(False)
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "1"
                                If pVal.BeforeAction = True And (frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Or frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE) Then
                                    If Me.ValidateAll() = False Then
                                        System.Media.SystemSounds.Asterisk.Play()
                                        BubbleEvent = False
                                        Exit Sub

                                    Else

                                        'If frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE Or frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                        '    'If oCompany.InTransaction = False Then oCompany.StartTransaction()
                                        '    If oDBDSHeader.GetValue("Status", 0).Trim = "O" Then
                                        '        If Me.TransactionManagement() = False And (frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                        '            'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                        '            BubbleEvent = False
                                        '            Exit Sub
                                        '        Else
                                        '            'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
                                        '        End If
                                        '    End If
                                        'End If
                                    End If
                                End If

                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                    Try
                        Select Case pVal.ItemUID
                            Case "c_series"
                                If frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                                    'Get the Serial Number Based On Series...
                                    Dim oCmbSerial As SAPbouiCOM.ComboBox = frmSalesInvoice.Items.Item("c_series").Specific
                                    Dim strSerialCode As String = oCmbSerial.Selected.Value
                                    Dim strDocNum As Long = frmSalesInvoice.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                                    oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                                End If
                            Case "c_billto"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    frmSalesInvoice.Freeze(True)
                                    Dim BilTo As SAPbouiCOM.ComboBox = frmSalesInvoice.Items.Item("c_billto").Specific
                                    Dim StrBilTo As String = BilTo.Selected.Value

                                    'Dim Str As String = "SELECT(ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','"
                                    'Str += " +ifnull(D.Name,''))BillTo FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode  "
                                    'Str += " LEFT OUTER JOIN OCST C ON C.Code =b.State   LEFT OUTER JOIN OCRY D On D.Code =b.Country  "
                                    'Str += " Where A.CardCode='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' and b.Address ='" & StrBilTo & "' and b.AdresType ='B'"

                                    Dim Str As String = "SELECT (ifnull(b.""Street"", '') || ',' || ifnull(b.""Block"", '') || ',' || ifnull(b.""City"", '') || ',' || ifnull(C.""Name"", '') || ',' || ifnull(D.""Name"", '')) AS ""BillTo"" "
                                    Str += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" "
                                    Str += " LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" WHERE A.""CardCode"" ='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' AND b.""Address"" = '" & StrBilTo & "' AND b.""AdresType"" = 'B';"

                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                                    oDBDSHeader.SetValue("U_Address2", 0, Rst.Fields.Item("BillTo").Value)
                                    frmSalesInvoice.Freeze(False)
                                End If

                            Case "c_shipto"
                                If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                    frmSalesInvoice.Freeze(True)
                                    Dim ShipTo As SAPbouiCOM.ComboBox = frmSalesInvoice.Items.Item("c_shipto").Specific
                                    Dim StrShipTo As String = ShipTo.Selected.Value

                                    'Dim Str As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""BillTo"" "
                                    'Str += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""BillToDef"" = b.""Address"" "
                                    'Str += " LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" "
                                    'Str += " WHERE A.""CardCode"" = '" & Trim(oDataTable.GetValue("CardCode", 0)) & "' AND b.""AdresType"" = 'B';"
                                    'Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)

                                    'Dim Str1 As String = "SELECT  (ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','+ifnull(D.Name,''))ShipTo"
                                    'Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode and a.ShipToDef =b.Address "
                                    'Str1 += "  LEFT OUTER JOIN OCST C ON C.Code =b.State "
                                    'Str1 += "  LEFT OUTER JOIN OCRY D On D.Code =b.Country "
                                    'Str1 += "  Where A.CardCode ='" & Trim(oDataTable.GetValue("CardCode", 0)) & "' and  b.AdresType  ='S'"

                                    Dim Str1 As String = "SELECT (IFNULL(b.""Street"", '') || ',' || IFNULL(b.""Block"", '') || ',' || IFNULL(b.""City"", '') || ',' || IFNULL(C.""Name"", '') || ',' || IFNULL(D.""Name"", '')) AS ""ShipTo"" "
                                    Str1 += " FROM OCRD A INNER JOIN CRD1 B ON A.""CardCode"" = b.""CardCode"" AND a.""ShipToDef"" = b.""Address"" LEFT OUTER JOIN OCST C ON C.""Code"" = b.""State"" "
                                    Str1 += " LEFT OUTER JOIN OCRY D ON D.""Code"" = b.""Country"" WHERE A.""CardCode"" ='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' AND b.""AdresType"" = 'S' and b.""Address"" ='" & StrShipTo & "';"

                                    'Dim Str As String = "SELECT(ifnull(b.Street,'')+',' + ifnull(b.Block,'')+',' +ifnull(b.City,'')+','+ifnull(C.Name ,'')+','"
                                    'Str += " +ifnull(D.Name,''))ShipTo FROM OCRD A INNER JOIN CRD1 B ON A.CardCode =b.CardCode  "
                                    'Str += " LEFT OUTER JOIN OCST C ON C.Code =b.State   LEFT OUTER JOIN OCRY D On D.Code =b.Country  "
                                    'Str += " Where A.CardCode='" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "' and b.Address ='" & StrShipTo & "' and b.AdresType ='S'"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str1)
                                    oDBDSHeader.SetValue("U_Address", 0, Rst.Fields.Item("ShipTo").Value)
                                    frmSalesInvoice.Freeze(False)
                                End If
                            Case "Matrix"
                                Select Case pVal.ColUID
                                    Case "taxcode"
                                        If pVal.BeforeAction = False And pVal.ItemChanged = True Then
                                            frmSalesInvoice.Freeze(True)

                                            oMatrix.FlushToDataSource()
                                            Me.MatrixLineCalculation(pVal.Row)
                                            oMatrix.LoadFromDataSource()
                                            frmSalesInvoice.Freeze(False)

                                            Me.HeaderTotal()
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        frmSalesInvoice.Freeze(False)
                        oGfun.StatusBarErrorMsg("Combo box Event Failed")
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Select Case pVal.ItemUID
                            'Case "bt_item"
                            '    If pVal.BeforeAction = False Then
                            '        Me.CreateMySimpleForm_ItemList()
                            '    End If
                            'Case "b_cal"
                            '    If pVal.BeforeAction = False Then
                            '        Me.Calculation()

                            '    End If
                            Case "b_crby"
                                If pVal.BeforeAction = False Then
                                    Me.CreateMySimpleForm_SOCeated()
                                End If

                            Case "b_Copy"
                                If pVal.BeforeAction = False Then
                                    Me.CreateMySimpleForm_SODetails()
                                End If
                            Case "b_Print"
                                If pVal.BeforeAction = False Then
                                    frmSalesInvoice.Freeze(True)
                                    If oDBDSHeader.GetValue("U_POStatus", 0).Trim = "D" Then
                                        LoadReportProject1()
                                    ElseIf oDBDSHeader.GetValue("U_POStatus", 0).Trim = "P" Then
                                        LoadReportProject()
                                    End If
                                    frmSalesInvoice.Freeze(False)
                                End If
                            Case "44"
                                If pVal.BeforeAction = False Then
                                    Dim RoundChk As SAPbouiCOM.CheckBox = frmSalesInvoice.Items.Item("44").Specific
                                    If RoundChk.Checked = True Then
                                        frmSalesInvoice.Items.Item("45").Enabled = True
                                    Else
                                        oDBDSHeader.SetValue("U_RoundOff", 0, 0.0)
                                        frmSalesInvoice.Items.Item("45").Enabled = False
                                        Dim DocTotal As Double = 0.0
                                        Dim RoundOff As Double = CDbl(oDBDSHeader.GetValue("U_RoundOff", 0))
                                        Dim LineTotal As Double = CDbl(oDBDSHeader.GetValue("U_TotBefDcnt", 0))
                                        Dim Discount As Double = CDbl(oDBDSHeader.GetValue("U_Discount", 0))
                                        Dim TaxAmt As Double = CDbl(oDBDSHeader.GetValue("U_TaxAmount", 0))
                                        Dim Freight As Double = CDbl(oDBDSHeader.GetValue("U_Frieght", 0))

                                        DocTotal = LineTotal - Discount + RoundOff + Freight + TaxAmt
                                        oDBDSHeader.SetValue("U_DocTotal1", 0, DocTotal)
                                    End If
                                End If
                            Case "1"
                                If pVal.ActionSuccess And frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE Then
                                    Me.InitForm()
                                End If
                              
                            Case "24"
                                If pVal.BeforeAction = False Then
                                    frmSalesInvoice.Freeze(True)
                                    frmSalesInvoice.PaneLevel = 1
                                    frmSalesInvoice.Freeze(False)
                                End If
                            Case "25"
                                If pVal.BeforeAction = False Then
                                    frmSalesInvoice.Freeze(True)
                                    frmSalesInvoice.PaneLevel = 2
                                    frmSalesInvoice.Freeze(False)
                                End If
                            Case "26"
                                If pVal.BeforeAction = False Then
                                    frmSalesInvoice.Freeze(True)
                                    frmSalesInvoice.PaneLevel = 3
                                    frmSalesInvoice.Freeze(False)
                                End If



                        End Select
                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                    Finally
                    End Try
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.MenuUID
                Case "1281"
                    frmSalesInvoice.ActiveItem = "t_Docnum"
                Case "1292"
                    'oGfun.SetNewLine(oMatrix, oDBDSDetail, GlbRowID, "itemcode")
                Case "1293"
                    frmSalesInvoice.Freeze(True)
                    'oGfun.DeleteRow(oMatrix, oDBDSDetail)
                    ''Me.MatrixLineCalculation(pVal.Row)
                    'Me.HeaderTotal()

                    frmSalesInvoice.Freeze(False)
                Case "1282"
                    Me.InitForm()
                Case "1284"
                    'frmSalesInvoice.Freeze(True)
                    'Dim StrUpdate As String = " update OINV set ""CANCELED""='Y' , ""DocStatus""='C' from  OINV where  ""U_InvRefNo""='" & DocEntry & "'"
                    'Dim RsetUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(StrUpdate)
                    'frmSalesInvoice.Freeze(False)

                Case "1287"
                    If frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE And pVal.BeforeAction = False Then
                        'Get the Serial Number Based On Series...
                        Dim oCmbSerial As SAPbouiCOM.ComboBox = frmSalesInvoice.Items.Item("c_series").Specific
                        Dim strSerialCode As String = oCmbSerial.Selected.Value
                        Dim strDocNum As Long = frmSalesInvoice.BusinessObject.GetNextSerialNumber(strSerialCode, UDOID)
                        oDBDSHeader.SetValue("DocNum", 0, strDocNum)
                    End If
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub


    Sub FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case BusinessObjectInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD, SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                    Try

                        If BusinessObjectInfo.BeforeAction Then
                            'oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemcode", oDBDSDetail)
                        End If
                        If BusinessObjectInfo.ActionSuccess = True Then
                            'Dim Str As String = "SELECT * FROM OINV  WHERE U_InvRefNo='" & oDBDSHeader.GetValue("DocNum", 0).Trim & "'  and U_InvType='Sale Order'"
                            'Dim RST As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                            'If RST.RecordCount > 0 Then
                            '    oDBDSHeader.SetValue("U_POEntry", 0, RST.Fields.Item("DocNum").Value)
                            'End If
                            If oDBDSHeader.GetValue("Status", 0).Trim = "O" Then
                                If Me.TransactionManagement() = False And (frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE) Then
                                    'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
                                    BubbleEvent = False
                                    Exit Sub
                                Else
                                    'If oCompany.InTransaction Then oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        oApplication.MessageBox(ex.Message)
                        BubbleEvent = False
                    Finally

                    End Try
                Case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD
                    Try
                        If BusinessObjectInfo.ActionSuccess Then
                            Dim Str As String = "SELECT * FROM OINV  WHERE ""U_InvRefNo""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_InvType""='Sale Order' "
                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                            If Rst.RecordCount = 0 Or oDBDSHeader.GetValue("U_PickWhs", 0).Trim = "" Then
                                frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                            Else
                                frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
                            End If
                        End If
                        '    oGfun.SetNewLine(oMatrix, oDBDSDetail)



                        '    If BusinessObjectInfo.ActionSuccess = True Then
                        '        Dim Str As String = "SELECT * FROM OINV  WHERE ""U_InvRefNo""='" & oDBDSHeader.GetValue("DocNum", 0).Trim & "'  and ""U_InvType""='Sale Order'"
                        '        Dim RST As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                        '        If RST.RecordCount > 0 Then
                        '            oDBDSHeader.SetValue("U_POEntry", 0, RST.Fields.Item("DocNum").Value)
                        '        End If
                        '    End If

                        '    DocEntry = oDBDSHeader.GetValue("DocEntry", 0).Trim
                        '    If oDBDSHeader.GetValue("U_POStatus", 0).Trim = "P" And oDBDSHeader.GetValue("U_POEntry", 0).Trim <> "" Then
                        '        Dim Str As String = "SELECT * FROM OINV  WHERE ""U_InvRefNo""='" & oDBDSHeader.GetValue("DocNum", 0).Trim & "' and ""U_InvType""='Sale Order' "
                        '        Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(Str)
                        '        If Rst.RecordCount <> 0 Then
                        '            frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE
                        '            frmSalesInvoice.Items.Item("b_Print").Visible = True
                        '            '   frmSalesInvoice.Items.Item("b_Print1").Visible = True
                        '            frmSalesInvoice.Items.Item("b_Print").Enabled = True
                        '            'frmSalesInvoice.Items.Item("b_Print1").Enabled = True
                        '            frmSalesInvoice.Items.Item("bt_post").Visible = False
                        '            frmSalesInvoice.Items.Item("bt_item").Visible = False
                        '        Else
                        '            frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                        '            frmSalesInvoice.Items.Item("b_Print").Visible = True
                        '            '   frmSalesInvoice.Items.Item("b_Print1").Visible = True
                        '            frmSalesInvoice.Items.Item("bt_item").Visible = True
                        '            frmSalesInvoice.Items.Item("bt_post").Visible = False
                        '        End If
                        '    Else
                        '        frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE
                        '        frmSalesInvoice.Items.Item("b_Print").Visible = True
                        '        ' frmSalesInvoice.Items.Item("b_Print1").Visible = True
                        '        frmSalesInvoice.Items.Item("bt_item").Visible = True
                        '        frmSalesInvoice.Items.Item("bt_post").Visible = False
                        '    End If
                        '    If oDBDSHeader.GetValue("U_Status", 0).Trim = "A" Then
                        '        frmSalesInvoice.Items.Item("c_postaus").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_True)
                        '        frmSalesInvoice.Items.Item("Matrix").Enabled = False
                        '        frmSalesInvoice.Items.Item("bt_item").Visible = False
                        '    Else
                        '        frmSalesInvoice.Items.Item("c_postaus").SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False)
                        '        frmSalesInvoice.Items.Item("Matrix").Enabled = True
                        '        frmSalesInvoice.Items.Item("bt_item").Visible = True
                        '        ' frmSalesInvoice.Items.Item("b_Print").Enabled = True
                        '    End If
                        '    'oMatrix.AutoResizeColumns()
                        'End If
                        'frmSalesInvoice.State = SAPbouiCOM.BoFormStateEnum.fs_Maximized
                    Catch ex As Exception
                    End Try
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
    Sub RightClickEvent(ByRef EventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean)
        Try
            Select Case EventInfo.EventType
                Case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK
                    DeleteRowITEMUID = EventInfo.ItemUID
                    Select Case EventInfo.ItemUID
                        Case "Matrix"
                            GlbRowID = oMatrix.VisualRowCount
                            If EventInfo.Row = oMatrix.VisualRowCount Then
                                frmSalesInvoice.EnableMenu("1293", False)
                            Else
                                frmSalesInvoice.EnableMenu("1293", True)
                            End If
                    End Select
            End Select
        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub

    Sub MatrixLineCalculation(ByVal RowID As Integer)

        Try
            frmSalesInvoice.Freeze(True)

            Dim ItemCode As String = Trim(oMatrix.Columns.Item("itemcode").Cells.Item(RowID).Specific.Value)
            Dim WhsCode As String = Trim(oMatrix.Columns.Item("whscode").Cells.Item(RowID).Specific.Value)
            Dim UnitPrice As Double = CDbl(oMatrix.Columns.Item("untprc").Cells.Item(RowID).Specific.Value)
            Dim Quantity As Double = CDbl(oMatrix.Columns.Item("qty").Cells.Item(RowID).Specific.Value)

            Dim TaxCode As String = ""
            If oMatrix.Columns.Item("taxcode").Cells.Item(RowID).Specific.Value.Equals("") = False Then
                Dim TaxCombo As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("taxcode").Cells.Item(RowID).Specific
                TaxCode = TaxCombo.Selected.Value
            End If
            Dim DisPert As Double = CDbl(oMatrix.Columns.Item("discount").Cells.Item(RowID).Specific.Value)
            Dim DisAmt As Double = 0.0 : Dim Amt As Double = 0.0
            Dim TaxPert As Double = 0.0 : Dim TaxAmt As Double = 0.0
            Dim LineTotal As Double = 0.0
            Amt = UnitPrice * Quantity
            LineTotal = UnitPrice * Quantity
            If Amt = 0 Then
                oDBDSDetail.SetValue("U_TaxAmount", RowID - 1, 0)
                oDBDSDetail.SetValue("U_DisVal", RowID - 1, 0)
                oDBDSDetail.SetValue("U_NetTotal", RowID - 1, 0)
                oDBDSDetail.SetValue("U_LineTotal", RowID - 1, 0)
            Else
                If DisPert <> 0 Then
                    DisAmt = (Amt * CDbl(DisPert)) / 100
                    oDBDSDetail.SetValue("U_DisVal", RowID - 1, DisAmt)
                    LineTotal = LineTotal - DisAmt
                End If
                If TaxCode <> "" Then
                    Dim TaxAmtStr As String = "SELECT * FROM OVTG WHERE ""Inactive""='N' AND ""Category""='O' and ""Code""='" & TaxCode & "'"
                    Dim TaxRst As SAPbobsCOM.Recordset = oGfun.DoQuery(TaxAmtStr)
                    TaxAmt = (Amt * CDbl(TaxRst.Fields.Item("Rate").Value) / 100)
                    oDBDSDetail.SetValue("U_TaxAmount", RowID - 1, TaxAmt)
                    LineTotal = LineTotal + TaxAmt
                Else
                    oDBDSDetail.SetValue("U_TaxAmount", RowID - 1, 0)
                End If
                oDBDSDetail.SetValue("U_NetTotal", RowID - 1, LineTotal)
            End If

            frmSalesInvoice.Freeze(False)

        Catch ex As Exception
            frmSalesInvoice.Freeze(False)
            oApplication.StatusBar.SetText("Calculation Function Failed:", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try


    End Sub
    Sub HeaderTotal()
        Try
            frmSalesInvoice.Freeze(True)
            Dim HeadTotal As Double = 0.0, TaxTotal As Double = 0.0, TaxTotal2 As Double = 0.0
            oMatrix.FlushToDataSource()
            For i As Integer = 1 To oMatrix.VisualRowCount

                Dim LineTotal As Double = CDbl(oMatrix.Columns.Item("NetTotal").Cells.Item(i).Specific.Value)
                Dim TaxAmt As Double = CDbl(oMatrix.Columns.Item("TaxAmt").Cells.Item(i).Specific.Value)

                HeadTotal = HeadTotal + CDbl(oMatrix.Columns.Item("NetTotal").Cells.Item(i).Specific.Value)
                TaxTotal = TaxTotal + CDbl(oMatrix.Columns.Item("TaxAmt").Cells.Item(i).Specific.Value)
            Next


            For i As Integer = 1 To oMatrix2.VisualRowCount
                If oMatrix2.Columns.Item("ExpnsCode").Cells.Item(1).Specific.Value <> "" Then
                    If oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.Value <> "" Then
                        TaxTotal2 += CDbl(oMatrix2.Columns.Item("TotVatAmt").Cells.Item(i).Specific.Value)
                    End If
                End If
            Next

            Dim RoundOff As Double = oDBDSHeader.GetValue("U_RoundOff", 0)
            oDBDSHeader.SetValue("U_TotBefDcnt", 0, HeadTotal)
            oDBDSHeader.SetValue("U_TaxAmount", 0, TaxTotal + TaxTotal2)
            oDBDSHeader.SetValue("U_DocTotal1", 0, HeadTotal + TaxTotal + RoundOff)
            'oDBDSHeader.SetValue("U_Frieght", 0, Freigt)
            oDBDSHeader.SetValue("U_DocTotal1", 0, HeadTotal + TaxTotal + RoundOff + oDBDSHeader.GetValue("U_Frieght", 0).Trim)

            oMatrix.LoadFromDataSource()
            frmSalesInvoice.Freeze(False)
        Catch ex As Exception
            frmSalesInvoice.Freeze(False)
            oApplication.StatusBar.SetText("Header Calculation Failed:", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try
    End Sub
    'Function TransactionManagement() As Boolean
    '    TransactionManagement = False
    '    Try

    '        Dim rstChk As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
    '        Dim rstSO As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
    '        Dim rstDraft As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
    '        sQuery = String.Empty
    '        sQuery = "SELECT * FROM ""@INS_INV1"" WHERE IFNULL(""U_InvEntry"",'')='' AND ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
    '        rstChk.DoQuery(sQuery)
    '        If rstChk.RecordCount > 0 Then
    '            rstChk.MoveFirst()
    '            For i As Integer = 1 To rstChk.RecordCount
    '                sQuery = String.Empty
    '                sQuery = "SELECT  * FROM OINV WHERE ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_BaseLine""='" & rstChk.Fields.Item("LineId").Value & "' and ""U_BaseType""='OINV' and ""CANCELED""='N'"
    '                rstSO.DoQuery(sQuery)

    '                sQuery = String.Empty
    '                sQuery = "SELECT  * FROM ODRF WHERE ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_BaseLine""='" & rstChk.Fields.Item("LineId").Value & "' and ""U_BaseType""='OINV' and ""CANCELED""='N'"
    '                rstDraft.DoQuery(sQuery)

    '                If rstSO.RecordCount = 0 And rstSO.RecordCount = 0 Then
    '                    Me.SalesInvoice(rstChk.Fields.Item("U_SOEntry").Value, rstChk.Fields.Item("LineId").Value)
    '                End If
    '                rstChk.MoveNext()
    '            Next
    '        End If
    '        TransactionManagement = True
    '    Catch ex As Exception
    '        TransactionManagement = False
    '        oApplication.MessageBox("Transaction Management Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '        oApplication.MessageBox(ex.Message)
    '    End Try
    'End Function
    Function SalesInvoice(ByVal DocEntry As String, ByVal LineID As String) As Boolean
        Try

            SalesInvoice = False
            Dim SalesInvoiceStatus As Boolean = False
            Dim oSalesInvoice As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInvoices)

            sQuery = String.Empty
            sQuery = "SELECT A.""CardCode"",A.""DiscPrcnt"" ""DiscPrcntHead"",A.""NumAtCard"",A.""RoundDif"",A.""Rounding"",B.* FROM ORDR A,RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND A.""DocEntry""='" & DocEntry & "'"
            Dim RstSO As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            RstSO.MoveFirst()

            'DocDate
            Dim dtDate As Date
            Dim stDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim first As String = stDate.Insert(4, "/")
            Dim second As String = first.Insert(7, "/")
            dtDate = DateTime.Parse(second, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSalesInvoice.DocDate = dtDate

            ''DocDueDate
            'Dim dtDueDate As Date
            'Dim stDueDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            'Dim firstDue As String = stDueDate.Insert(4, "/")
            'Dim secondDue As String = firstDue.Insert(7, "/")
            'dtDueDate = DateTime.Parse(secondDue, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            'oSalesInvoice.DocDueDate = dtDueDate

            'TaxDate
            Dim dtTaxDate As Date
            Dim stTaxDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim firstTax As String = stTaxDate.Insert(4, "/")
            Dim secondTax As String = firstTax.Insert(7, "/")
            dtTaxDate = DateTime.Parse(secondTax, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSalesInvoice.TaxDate = dtTaxDate

            oSalesInvoice.CardCode = RstSO.Fields.Item("CardCode").Value 'oDBDSHeader.GetValue("U_CardCode", 0).Trim
            oSalesInvoice.DocType = SAPbobsCOM.BoDocumentTypes.dDocument_Items
            oSalesInvoice.DiscountPercent = CDbl(RstSO.Fields.Item("DiscPrcntHead").Value)
            oSalesInvoice.NumAtCard = RstSO.Fields.Item("NumAtCard").Value 'oDBDSHeader.GetValue("U_NumAtCard", 0).Trim
            If RstSO.Fields.Item("Rounding").Value = "Y" Then
                oSalesInvoice.Rounding = SAPbobsCOM.BoYesNoEnum.tYES
                oSalesInvoice.RoundingDiffAmount = CDbl(RstSO.Fields.Item("RoundDif").Value)
            Else
                oSalesInvoice.Rounding = SAPbobsCOM.BoYesNoEnum.tNO
                oSalesInvoice.RoundingDiffAmount = 0.0
            End If


            oSalesInvoice.UserFields.Fields.Item("U_InvRefNo").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSalesInvoice.UserFields.Fields.Item("U_InvType").Value = "Sale Invoice"
            oSalesInvoice.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSalesInvoice.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
            oSalesInvoice.UserFields.Fields.Item("U_BaseLine").Value = LineID.ToString  ' Trim(RstSO.Fields.Item("LineNum").Value) ' Trim(oDBDSHeader.GetValue("LineNum", 0))
            oSalesInvoice.UserFields.Fields.Item("U_BaseType").Value = "OINV"


            For i As Integer = 1 To RstSO.RecordCount

                oSalesInvoice.Lines.ItemCode = RstSO.Fields.Item("ItemCode").Value ' Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.Quantity = CDbl(RstSO.Fields.Item("Quantity").Value)
                oSalesInvoice.Lines.Price = CDbl(RstSO.Fields.Item("Price").Value) ' CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                ' oSalesInvoice.Lines.UnitPrice = CDbl(RstSO.Fields.Item("Price").Value) ' CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.DiscountPercent = CDbl(RstSO.Fields.Item("DiscPrcnt").Value) ' CDbl(oMatrix.Columns.Item("DiscPrcnt").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.TaxCode = RstSO.Fields.Item("TaxCode").Value 'Trim(oMatrix.Columns.Item("taxcode").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.WarehouseCode = RstSO.Fields.Item("WhsCode").Value 'Trim(oMatrix.Columns.Item("whscode").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.LocationCode = Trim(oMatrix.Columns.Item("location").Cells.Item(i).Specific.value)

                oSalesInvoice.Lines.BaseEntry = Trim(RstSO.Fields.Item("DocEntry").Value)
                oSalesInvoice.Lines.BaseType = 17
                oSalesInvoice.Lines.BaseLine = Trim(RstSO.Fields.Item("LineNum").Value)

                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseType").Value = "OINV"
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseLine").Value = Trim(RstSO.Fields.Item("LineNum").Value)

                'oSalesInvoice.Lines.CostingCode = "DUBAI"
                ' oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseCardCd").Value = Trim(oDBDSHeader.GetValue("U_CardCode", 0).Trim)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_DocNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0).Trim)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_DocEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0).Trim)

                'oSalesInvoice.Lines.UserFields.Fields.Item("U_NDP").Value = CDbl(oMatrix.Columns.Item("NDP").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_MRP").Value = CDbl(oMatrix.Columns.Item("MRP").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_NetCost").Value = CDbl(oMatrix.Columns.Item("NetCost").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_NDPVAL").Value = CDbl(oMatrix.Columns.Item("NDPVAL").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_NETVAl").Value = CDbl(oMatrix.Columns.Item("NETVAl").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_MRPVAL").Value = CDbl(oMatrix.Columns.Item("MRPVAL").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_EDPercnt").Value = CDbl(oMatrix.Columns.Item("EDPercnt").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_EDVal").Value = CDbl(oMatrix.Columns.Item("EDVal").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_InsPercnt").Value = CDbl(oMatrix.Columns.Item("InsPercnt").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_InsVal").Value = CDbl(oMatrix.Columns.Item("InsVal").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_NDPValAftDis").Value = CDbl(oMatrix.Columns.Item("NDPValADis").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_AbatementRate").Value = CDbl(oMatrix.Columns.Item("AbatmntRat").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_MRPValAftABT").Value = CDbl(oMatrix.Columns.Item("MRPValAABT").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_NetTotal").Value = CDbl(oMatrix.Columns.Item("NetTotal").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_DisPercnt").Value = CDbl(oMatrix.Columns.Item("discount").Cells.Item(i).Specific.value)
                'oSalesInvoice.Lines.UserFields.Fields.Item("U_DisVal").Value = CDbl(oMatrix.Columns.Item("disval").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.Add()
                RstSO.MoveNext()
            Next

            sQuery = String.Empty
            sQuery = "SELECT * FROM RDR3 WHERE ""DocEntry""='" & DocEntry & "'"
            Dim rstFregt As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            If rstFregt.RecordCount > 0 Then
                rstFregt.MoveFirst()
                For i As Integer = 1 To rstFregt.RecordCount
                    oSalesInvoice.Expenses.ExpenseCode = rstFregt.Fields.Item("ExpnsCode").Value 'Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value)
                    oSalesInvoice.Expenses.TaxCode = rstFregt.Fields.Item("TaxCode").Value 'Trim(oMatrix2.Columns.Item("VatGroup").Cells.Item(i).Specific.value)
                    oSalesInvoice.Expenses.LineTotal = CDbl(rstFregt.Fields.Item("LineTotal").Value) 'Trim(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value)
                    oSalesInvoice.Expenses.Add()
                    rstFregt.MoveNext()
                Next
            End If
            'For i As Integer = 1 To oMatrix2.VisualRowCount
            '    If Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value) <> "" Then
            '        oSalesInvoice.Expenses.ExpenseCode = Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value)
            '        oSalesInvoice.Expenses.TaxCode = Trim(oMatrix2.Columns.Item("VatGroup").Cells.Item(i).Specific.value)
            '        '   oSalesInvoice.Expenses.DistributionMethod = Trim(oMatrix.Columns.Item("DistrbMthd").Cells.Item(i).Specific.value)
            '        oSalesInvoice.Expenses.LineTotal = Trim(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value)
            '        oSalesInvoice.Expenses.Add()
            '    End If
            'Next

            ' ''Freight Code determination
            'If CDbl(frmSalesInvoice.Items.Item("43").Specific.value) > 0 Then
            '    Dim rset As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            '    Dim strqry As String = "Select ExpnsCode from OEXD where UPPER(ExpnsName)='Packing & Forwarding'"
            '    rset.DoQuery(strqry)
            '    oSalesInvoice.Lines.Expenses.ExpenseCode = rset.Fields.Item(0).Value
            '    Dim ss1 As Double = CDbl(frmSalesInvoice.Items.Item("43").Specific.value)
            '    oSalesInvoice.Lines.Expenses.LineTotal = CDbl(frmSalesInvoice.Items.Item("43").Specific.value)
            '    Dim strqry1 As String = "Select Code,Rate from OSTC where freight='Y'"
            '    rset.DoQuery(strqry1)
            '    oSalesInvoice.Lines.Expenses.TaxCode = rset.Fields.Item(0).Value
            'End If

            If oSalesInvoice.Add = 0 Then
                SalesInvoiceStatus = True
            Else
                SalesInvoiceStatus = False
            End If

            If SalesInvoiceStatus Then
                SalesInvoice = True
                sQuery = String.Empty
                sQuery = "UPDATE B SET B.""U_InvEntry""=A.""DocEntry"",B.""U_InvNo""=A.""DocNum"",""U_Status""='I' FROM OINV A,""@INS_INV1"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" and  A.""U_BaseLine""=B.""LineId""  AND A.""U_BaseType""='OINV' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and B.""LineId""='" & LineID & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE

                'sQuery = String.Empty
                'sQuery = "SELECT A.* FROM OINV A,""@INS_INV1"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" AND A.""U_BaseType""='OINV' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
                'Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                'If Rst.RecordCount > 0 Then
                '    oDBDSHeader.SetValue("U_SOEntry", 0, Rst.Fields.Item("DocEntry").Value)
                '    oDBDSHeader.SetValue("U_SONum", 0, Rst.Fields.Item("DocNum").Value)
                'End If
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSalesInvoice)
            Else
                oApplication.StatusBar.SetText("Failed to Post SalesInvoice  " & oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                oApplication.MessageBox("Failed to Post SalesInvoice  " & oCompany.GetLastErrorDescription, 1)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSalesInvoice)
            End If

        Catch ex As Exception
            SalesInvoice = False
            oApplication.StatusBar.SetText("Failed to Post SalesInvoice:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function
    Public Sub New()

    End Sub


    Public Sub LoadReportProject()
        Try
            oApplication.Menus.Item("4873").Activate()
            Dim objcrystalform As SAPbouiCOM.Form
            Dim objcrystalinputform As SAPbouiCOM.Form
            objcrystalform = oApplication.Forms.GetForm("410000003", 1)
            objcrystalform.Items.Item("410000004").Specific.string = System.Windows.Forms.Application.StartupPath & "\Sale Order.rpt"
            objcrystalform.Items.Item("410000001").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform = oApplication.Forms.GetForm("410000100", 1)

            Dim oCmbSeries As SAPbouiCOM.EditText = objcrystalinputform.Items.Item("1000003").Specific
            oCmbSeries.Value = frmSalesInvoice.Items.Item("t_docnum").Specific.string

            objcrystalinputform.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalform.Items.Item("410000002").Click(SAPbouiCOM.BoCellClickType.ct_Regular)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub LoadReportProject1()
        Try
            oApplication.Menus.Item("4873").Activate()
            Dim objcrystalform As SAPbouiCOM.Form
            Dim objcrystalinputform As SAPbouiCOM.Form
            objcrystalform = oApplication.Forms.GetForm("410000003", 1)
            objcrystalform.Items.Item("410000004").Specific.string = System.Windows.Forms.Application.StartupPath & "\Sale Order2.rpt"
            objcrystalform.Items.Item("410000001").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform = oApplication.Forms.GetForm("410000100", 1)

            Dim oCmbSeries As SAPbouiCOM.EditText = objcrystalinputform.Items.Item("1000003").Specific
            oCmbSeries.Value = frmSalesInvoice.Items.Item("t_docnum").Specific.string

            objcrystalinputform.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalinputform.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular)
            objcrystalform.Items.Item("410000002").Click(SAPbouiCOM.BoCellClickType.ct_Regular)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Sub SchemeDetails_CreateMySimpleForm(ByVal ItemCode As String, ByVal Qty As Integer)
        Try
            'boolFilterItem = True

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)

            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim ocheckbox As SAPbouiCOM.CheckBox
            Dim oLabel As SAPbouiCOM.StaticText
            Dim oEdit As SAPbouiCOM.EditText

            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "SCM"
            CP.FormType = "203"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 

            oForm.Height = 300
            oForm.Width = 600
            oForm.Title = "Supplier Scheme Details"


            oForm.AutoManaged = True

            If oForm.Selected = True Then

            End If
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 20
            oItem.Top = 30
            oItem.Width = 550
            oItem.Height = 200
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")


            ' Add CANCEL Button 

            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 240
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            Dim Str As String = "     SELECT A.DocEntry ,A.U_SchmDescrt ,A.U_ValidFrom ,A.U_ValidTo ,B.U_ItemCode ,B.U_Qty1 QTY ,B.U_Discount1 DISCOUNT ,B.U_FOCQty1  FOCQty"
            Str += " FROM [@INS_OSSH] a INNER jOIN [@INS_SSH1] B ON A.DocEntry=B.DocEntry "
            Str += " WHERE A.U_SchmTyp = 'IL' AND A.U_Status = 'A' AND B.U_Qty1 <> 0 "
            Str += " AND '" & oDBDSHeader.GetValue("U_DocDate", 0).Trim & "' BETWEEN A.U_ValidFrom AND A.U_ValidTo AND B.U_ItemCode = '" & Trim(ItemCode) & "' AND B.U_Qty1 > '" & Qty & "'"
            Str += "  UNION ALL "
            Str += " SELECT A.DocEntry ,A.U_SchmDescrt ,A.U_ValidFrom ,A.U_ValidTo ,B.U_ItemCode ,B.U_Qty2 QTY ,B.U_Discount2 DISCOUNT ,B.U_FOCQty2 FOCQty "
            Str += " FROM [@INS_OSSH] a INNER jOIN [@INS_SSH1] B ON A.DocEntry=B.DocEntry "
            Str += "WHERE A.U_SchmTyp = 'IL' AND A.U_Status = 'A' AND B.U_Qty2 <> 0 "
            Str += " AND '" & oDBDSHeader.GetValue("U_DocDate", 0).Trim & "' BETWEEN A.U_ValidFrom AND A.U_ValidTo AND B.U_ItemCode = '" & Trim(ItemCode) & "' AND B.U_Qty2 > '" & Qty & "'"
            Str += "   UNION ALL "
            Str += " SELECT A.DocEntry ,A.U_SchmDescrt ,A.U_ValidFrom ,A.U_ValidTo ,B.U_ItemCode ,B.U_Qty3 QTY ,B.U_Discount3 DISCOUNT ,B.U_FOCQty3  FOCQty"
            Str += " FROM [@INS_OSSH] a INNER jOIN [@INS_SSH1] B ON A.DocEntry=B.DocEntry "
            Str += " WHERE A.U_SchmTyp = 'IL' AND A.U_Status = 'A' AND B.U_Qty3 <> 0 "
            Str += " AND '" & oDBDSHeader.GetValue("U_DocDate", 0).Trim & "' BETWEEN A.U_ValidFrom AND A.U_ValidTo AND B.U_ItemCode = '" & Trim(ItemCode) & "' AND B.U_Qty3 > '" & Qty & "'"


            oForm.DataSources.DataTables.Item(0).ExecuteQuery(Str)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            oGrid.AutoResizeColumns()
            oGrid.Columns.Item(0).Editable = False
            oGrid.Columns.Item(1).Editable = False
            oGrid.Columns.Item(2).Editable = False
            oGrid.Columns.Item(3).Editable = False
            oGrid.Columns.Item(2).FontSize = 12
            oGrid.Columns.Item(3).FontSize = 12
            oGrid.Columns.Item(2).TextStyle = 1
            oGrid.Columns.Item(3).TextStyle = 1

            oGrid.Columns.Item(2).ForeColor = "876543"
            oGrid.Columns.Item(3).ForeColor = "584521"

            oGrid.AutoResizeColumns()

            oForm.Visible = True
        Catch ex As Exception
            oForm.Visible = True
            oApplication.StatusBar.SetText(" Transfer Of Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub


    Sub CreateMySimpleForm_ItemList()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "OINVItemList"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Item Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 70
            oItem.Width = 675
            oItem.Height = 200
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            ' Add OK Button 
            oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 160
            oItem.Top = 280
            oItem.Width = 70
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Clear & Add"

            Dim oEditBox As SAPbouiCOM.EditText
            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Dim oLabel As SAPbouiCOM.StaticText

            'Item Group
            oItem = oForm.Items.Add("l_itmgrp", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_itmgrp"
            oLabel = oItem.Specific
            oLabel.Caption = "Item Group"


            '----------------------------------------
            ''Item Group
            'oItem = oForm.Items.Add("U_DocNum", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155
            'oItem.Top = 10
            'oItem.Width = 74
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_DocNum", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_DocNum")
            'oItem.Enabled = True



            'Item Group
            oItem = oForm.Items.Add("ItmGrpCd", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10
            oItem.Width = 150
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpCd", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditBox.DataBind.SetBound(True, "", "U_ItmGrpCd")
            ' oItem.Enabled = False

            Dim ocfls As SAPbouiCOM.ChooseFromListCollection
            ocfls = oForm.ChooseFromLists
            Dim ITMGRP_CFL As SAPbouiCOM.ChooseFromList
            Dim cflcrepa As SAPbouiCOM.ChooseFromListCreationParams
            cflcrepa = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)
            cflcrepa.MultiSelection = False
            cflcrepa.ObjectType = "OITM"
            cflcrepa.UniqueID = "ITMGRP_CFL"
            ITMGRP_CFL = ocfls.Add(cflcrepa)
            oEditBox.ChooseFromListUID = "ITMGRP_CFL"
            oEditBox.ChooseFromListAlias = "U_ItmGrpCode"


            ''Item Group
            'oItem = oForm.Items.Add("ItmGrpCd", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155 + 76
            'oItem.Top = 10
            'oItem.Width = 74
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpCd", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_ItmGrpCd")
            'oItem.Enabled = False
            '----------------------------------------


            'Item Group
            oItem = oForm.Items.Add("ItmGrpNm", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 310
            oItem.Top = 10
            oItem.Width = 200
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_ItmGrpNm", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEditBox.DataBind.SetBound(True, "", "U_ItmGrpNm")
            oItem.Enabled = False



            'oItem = oForm.Items.Add("lk_grp", SAPbouiCOM.BoFormItemTypes.it_LINKED_BUTTON)
            'oItem.Left = oForm.Items.Item("t_itmgrp").Left - 13
            'oItem.Width = 10
            'oItem.Height = oForm.Items.Item("t_itmgrp").Height
            'oItem.Top = oForm.Items.Item("t_itmgrp").Top
            'oForm.Items.Item("lk_grp").LinkTo = "t_itmcode"

            'Item Group
            oItem = oForm.Items.Add("t_minprc", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10 + 16
            oItem.Width = 74
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_MinPrice", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_MinPrice")
            oItem.Enabled = False

            'Item Group
            oItem = oForm.Items.Add("t_maxprc", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155 + 76
            oItem.Top = 10 + 16
            oItem.Width = 74
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_MaxPrice", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_MaxPrice")
            oItem.Enabled = False

            'Vat Group
            oItem = oForm.Items.Add("l_MMPrice", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10 + 16
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_tax"
            oLabel = oItem.Specific
            oLabel.Caption = "Min Price / Max Price"


            'Item Group
            oItem = oForm.Items.Add("l_unitprc", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10 + 16 + 16
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_minprc"
            oLabel = oItem.Specific
            oLabel.Caption = "Unit Price"
            'Item Group
            oItem = oForm.Items.Add("UnitPrice", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10 + 16 + 16
            oItem.Width = 150
            oItem.Height = 15
            oEditBox = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_UnitPr", SAPbouiCOM.BoDataType.dt_QUANTITY)
            oEditBox.DataBind.SetBound(True, "", "U_UnitPr")
            oItem.Enabled = True

            'oGfun.SetComboBoxValueRefresh(oForm.Items.Item("t_tax").Specific, "SELECT ""Code"",""Name"" FROM OVTG WHERE ""Category""='O' AND ""Inactive""='N'")

            ''Item Group
            'oItem = oForm.Items.Add("t_remark", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            'oItem.Left = 155
            'oItem.Top = 10
            'oItem.Width = 125
            'oItem.Height = 15
            'oEditBox = oItem.Specific
            'oUserdatasource = oForm.DataSources.UserDataSources.Add("U_remark", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            'oEditBox.DataBind.SetBound(True, "", "U_remark")
            'oItem.Visible = False

            'sQuery = String.Empty

            ''sQuery = "[@INSPL_AR_ItemList] '" & oDBDSHeader.GetValue("U_JobEntry", 0).Trim & "' ,'" & oDBDSHeader.GetValue("CardCode", 0).Trim & "','" & oDBDSHeader.GetValue("U_BLNo", 0).Trim & "'"
            'sQuery = "CALL ""@INSPL_SO_ItemList"" ('" & oDBDSHeader.GetValue("U_DocEntry", 0).Trim & "')"
            'oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            'oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
            'oGrid.AutoResizeColumns()
            'oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
            'For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
            '    If i = 0 Then
            '        oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
            '    ElseIf i = 4 Then
            '        oGrid.Columns.Item(i).Editable = True
            '    Else
            '        oGrid.Columns.Item(i).Editable = False
            '    End If
            'Next

            'oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_ItemList(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then
                            Select Case pVal.ItemUID
                                Case "ItmGrpCd"

                                    'Dim Str As String = oForm.ActiveItem
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific

                                    oForm.Items.Item("ItmGrpNm").Enabled = True
                                    oForm.Items.Item("t_maxprc").Enabled = True
                                    oForm.Items.Item("t_minprc").Enabled = True

                                    ' oForm.Items.Item("ItmGrpCd").Enabled = True

                                    Try
                                        Txt2 = oForm.Items.Item("ItmGrpNm").Specific
                                        Txt2.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                    Catch ex As Exception

                                    End Try

                                    Try
                                        Txt2 = oForm.Items.Item("ItmGrpNm").Specific
                                        Txt2.Value = Trim(oDataTable.GetValue("U_ItmGrpName", 0))
                                    Catch ex As Exception

                                    End Try



                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_SO_GET_PRICE"" ('" & oDataTable.GetValue("DocEntry", 0) & "','" & oDBDSHeader.GetValue("U_CardCode", 0).Trim & "')"
                                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                    If Rst.RecordCount > 0 Then
                                        Try
                                            Txt2 = oForm.Items.Item("t_minprc").Specific
                                            Txt2.Value = Rst.Fields.Item(0).Value
                                        Catch ex As Exception

                                        End Try
                                        Try
                                            Txt2 = oForm.Items.Item("t_maxprc").Specific
                                            Txt2.Value = Rst.Fields.Item(1).Value
                                        Catch ex As Exception

                                        End Try

                                        Try
                                            Txt2 = oForm.Items.Item("UnitPrice").Specific
                                            Txt2.Value = Rst.Fields.Item(2).Value
                                        Catch ex As Exception

                                        End Try
                                    End If

                                    Try
                                        Txt3 = oForm.Items.Item("ItmGrpCd").Specific
                                        Txt3.Value = Trim(oDataTable.GetValue("U_ItmGrpCode", 0))
                                    Catch ex As Exception

                                    End Try
                                    oForm.Items.Item("ItmGrpNm").Enabled = False
                                    oForm.Items.Item("t_maxprc").Enabled = False
                                    oForm.Items.Item("t_minprc").Enabled = False

                                    sQuery = String.Empty
                                    sQuery = "CALL ""@INSPL_SO_ItemList"" ('" & oDataTable.GetValue("DocEntry", 0) & "')"
                                    oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
                                    oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")
                                    oGrid.AutoResizeColumns()
                                    oGrid.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single
                                    For i As Integer = 0 To oGrid.DataTable.Columns.Count - 1
                                        If i = 0 Then
                                            oGrid.Columns.Item(i).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                                        ElseIf i = oGrid.DataTable.Columns.Count - 1 Then
                                            oGrid.Columns.Item(i).Editable = True
                                            Dim ColQty As SAPbouiCOM.EditTextColumn
                                            ColQty = oGrid.Columns.Item(oGrid.Columns.Item(i).TitleObject.Caption)
                                            ColQty.ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
                                        Else
                                            oGrid.Columns.Item(i).Editable = False
                                        End If
                                    Next
                                    oGrid.AutoResizeColumns()
                            End Select
                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) > CDbl(oForm.Items.Item("t_maxprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        oForm.Items.Item("UnitPrice").Specific.value = CDbl(oForm.Items.Item("UnitPrice").Specific.value)
                                        Exit Sub
                                    End If
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) < CDbl(oForm.Items.Item("t_minprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not less than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        oForm.Items.Item("UnitPrice").Specific.value = CDbl(oForm.Items.Item("UnitPrice").Specific.value)
                                        Exit Sub
                                    End If

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0

                                    'oDBDSDetail.Clear()
                                    'oMatrix.Clear()
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    If oMatrix.VisualRowCount = 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(1).Specific.value = "" Then
                                            oDBDSDetail.Clear()
                                            oMatrix.Clear()
                                            RowID = 0
                                        End If
                                    ElseIf oMatrix.VisualRowCount > 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(oMatrix.VisualRowCount).Specific.value = "" Then
                                            oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemcode", oDBDSDetail)
                                            RowID = oMatrix.VisualRowCount
                                        End If
                                    End If

                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & RowID + 1, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

                                            oDBDSDetail.InsertRecord(oDBDSDetail.Size)
                                            oDBDSDetail.Offset = RowID
                                            oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, RowID + 1)

                                            oDBDSDetail.SetValue("U_ItemCode", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Dscription", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemName").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Quantity", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_UnitPrice", oDBDSDetail.Offset, oForm.Items.Item("UnitPrice").Specific.value)
                                            oDBDSDetail.SetValue("U_Status", oDBDSDetail.Offset, "P")

                                            sQuery = String.Empty
                                            sQuery = "CALL ""@INSPL_GET_STOCK"" ('" & oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value & "')"
                                            Dim RstStock As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If RstStock.RecordCount > 0 Then
                                                oDBDSDetail.SetValue("U_InStock", oDBDSDetail.Offset, RstStock.Fields.Item(0).Value)
                                                oDBDSDetail.SetValue("U_Committed", oDBDSDetail.Offset, RstStock.Fields.Item(1).Value)
                                                oDBDSDetail.SetValue("U_OnHand", oDBDSDetail.Offset, RstStock.Fields.Item(2).Value)
                                            End If

                                            sQuery = String.Empty
                                            sQuery = "SELECT a.""DfltWH"",a.""VatGourpSa"",b.""Rate"" FROM OITM A LEFT JOIN OVTG B ON A.""VatGourpSa""=b.""Code"" WHERE ""ItemCode""='" & oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value & "'"
                                            Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                                            If Rst.RecordCount > 0 Then
                                                Dim TaxAmt As Double = 0.0
                                                Dim Amt As Double = oForm.Items.Item("UnitPrice").Specific.value * oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                                oDBDSDetail.SetValue("U_TaxCode", oDBDSDetail.Offset, Rst.Fields.Item("VatGourpSa").Value)
                                                oDBDSDetail.SetValue("U_WhsCode", oDBDSDetail.Offset, Rst.Fields.Item("DfltWH").Value)
                                                TaxAmt = (Amt * CDbl(Rst.Fields.Item("Rate").Value) / 100)
                                                oDBDSDetail.SetValue("U_TaxAmount", oDBDSDetail.Offset, CDbl(TaxAmt))
                                                oDBDSDetail.SetValue("U_NetTotal", oDBDSDetail.Offset, CDbl(Amt) + CDbl(TaxAmt))
                                            Else
                                                Dim Amt As Double = oForm.Items.Item("UnitPrice").Specific.value * oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                                oDBDSDetail.SetValue("U_NetTotal", oDBDSDetail.Offset, Amt)
                                            End If

                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()

                                    oMatrix.LoadFromDataSource()
                                    'Me.Calculation()
                                    Me.HeaderTotal()

                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)


                                End If

                            Case "Clear"
                                If pVal.BeforeAction = False Then

                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) > CDbl(oForm.Items.Item("t_maxprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not greater than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        Exit Sub
                                    End If
                                    If CDbl(oForm.Items.Item("UnitPrice").Specific.value) < CDbl(oForm.Items.Item("t_minprc").Specific.value) Then
                                        oApplication.StatusBar.SetText("Unit price should not less than Maximum price............", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                                        Exit Sub
                                    End If

                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                                    Dim CardCode As String = String.Empty
                                    Dim CardCount As Integer = 0
                                    ''frmSalesInvoice.Freeze(True)
                                    'oMatrix.Clear()
                                    'oMatrix.AddRow()
                                    'Dim RowID As Integer = 1
                                    ''Dim DocTyp As SAPbouiCOM.ComboBox = frmSalesInvoice.Items.Item("3").Specific
                                    ''DocTyp.Select("I", SAPbouiCOM.BoSearchKey.psk_ByValue)
                                    'For i As Integer = 1 To oGrid.Rows.Count
                                    '    If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                    '        oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                    '        oMatrix.Columns.Item("itemcode").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value
                                    '        oMatrix.Columns.Item("qty").Cells.Item(RowID).Specific.value = oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value
                                    '        oMatrix.Columns.Item("untprc").Cells.Item(RowID).Specific.value = oForm.Items.Item("UnitPrice").Specific.value 'oGrid.DataTable.Columns.Item("UnitPrice").Cells.Item(i - 1).Value
                                    '        'If oForm.Items.Item("t_tax").Specific.value <> "" Then
                                    '        '    Dim MainTaxCode As SAPbouiCOM.ComboBox = oMatrix.Columns.Item("18").Cells.Item(RowID).Specific
                                    '        '    Dim SubTaxCode As SAPbouiCOM.ComboBox = oForm.Items.Item("t_tax").Specific
                                    '        '    MainTaxCode.Select(SubTaxCode.Selected.Value, SAPbouiCOM.BoSearchKey.psk_ByValue)
                                    '        'End If
                                    '        RowID += 1
                                    '    End If
                                    'Next
                                    'oForm.Close()
                                    'oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                    'frmSalesInvoice = oForm
                                    ''frmSalesInvoice.Freeze(False)



                                    oDBDSDetail.Clear()
                                    oMatrix.Clear()
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    If oMatrix.VisualRowCount = 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(RowID).Specific.value = "" Then
                                            RowID = 0
                                        End If
                                    ElseIf oMatrix.VisualRowCount > 1 Then
                                        If oMatrix.Columns.Item("itemcode").Cells.Item(oMatrix.VisualRowCount).Specific.value = "" Then
                                            oGfun.DeleteEmptyRowInFormDataEvent(oMatrix, "itemcode", oDBDSDetail)
                                            RowID = oMatrix.VisualRowCount
                                        End If
                                    End If
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oApplication.StatusBar.SetText("Please wait.. System filling Line : " & i, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

                                            oDBDSDetail.InsertRecord(oDBDSDetail.Size)
                                            oDBDSDetail.Offset = RowID
                                            oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, RowID + 1)

                                            oDBDSDetail.SetValue("U_ItemCode", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemCode").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Dscription", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("ItemName").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_Quantity", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("Quantity").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_UnitPrice", oDBDSDetail.Offset, oForm.Items.Item("UnitPrice").Specific.value)
                                            RowID += 1
                                        End If
                                    Next
                                    oForm.Close()

                                    'Me.Calculation()
                                    oMatrix.LoadFromDataSource()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)


                                End If
                        End Select
                    Catch ex As Exception
                        frmSalesInvoice.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID
                                    Case "Quantity"
                                        If pVal.BeforeAction = False Then

                                            If oGrid.DataTable.Columns.Item("Quantity").Cells.Item(pVal.Row).Value > 0 Then
                                                oGrid.DataTable.Columns.Item("Select").Cells.Item(pVal.Row).Value = "Y"
                                            Else
                                                oGrid.DataTable.Columns.Item("Select").Cells.Item(pVal.Row).Value = "N"
                                            End If
                                        End If
                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub
    Sub Calculation()
        Try
            Dim TotCBMQty As Double = 0.0
            Dim TotCartonQty As Double = 0.0

            For i As Integer = 1 To oMatrix.VisualRowCount
                If oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value <> "" Then
                    sQuery = String.Empty
                    sQuery = "SELECT * FROM OITM WHERE ""ItemCode""='" & oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value & "'"
                    Dim Rst As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                    Dim CBMQty As Double = Rst.Fields.Item("U_CBM").Value
                    Dim CartonQty As Double = Rst.Fields.Item("U_CartQty").Value
                    If CBMQty > 0 And CartonQty > 0 Then
                        TotCBMQty += CBMQty * oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value
                        TotCartonQty += CBMQty * oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value / CartonQty
                    End If
                    'TotCartonQty += oMatrix.Columns.Item("qty").Cells.Item(i).Specific.value / CartonQty
                End If
            Next

            oDBDSHeader.SetValue("U_TotalCBM", 0, TotCBMQty)
            oDBDSHeader.SetValue("U_TotCartQty", 0, TotCartonQty)

            'frmSalesInvoice.Items.Item("t_cbm").Enabled = True
            'frmSalesInvoice.Items.Item("t_carton").Enabled = True
            'frmSalesInvoice.Items.Item("t_cbm").Specific.value = TotCBMQty
            'frmSalesInvoice.Items.Item("t_carton").Specific.value = TotCartonQty
            'frmSalesInvoice.Items.Item("et_remarks").Specific.value = frmSalesInvoice.Items.Item("et_remarks").Specific.value
            'frmSalesInvoice.Items.Item("t_cbm").Enabled = False
            'frmSalesInvoice.Items.Item("t_carton").Enabled = False

        Catch ex As Exception
            oApplication.StatusBar.SetText("Calculation Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub CreateMySimpleForm_SODetails()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "OINVDetails"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 700
            oForm.Title = "Sale Order Details"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGrid1", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 30
            oItem.Width = 675
            oItem.Height = 230
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            'Item Group
            oItem = oForm.Items.Add("l_search", SAPbouiCOM.BoFormItemTypes.it_STATIC)
            oItem.Left = 10
            oItem.Top = 10
            oItem.Width = 140
            oItem.Height = 15
            oItem.LinkTo = "t_itmgrp"
            oLabel = oItem.Specific
            oLabel.Caption = "Documnet No."

            Dim oUserdatasource As SAPbouiCOM.UserDataSource
            'Item Group
            oItem = oForm.Items.Add("t_search", SAPbouiCOM.BoFormItemTypes.it_EDIT)
            oItem.Left = 155
            oItem.Top = 10
            oItem.Width = 150
            oItem.Height = 15
            oEdit = oItem.Specific
            oUserdatasource = oForm.DataSources.UserDataSources.Add("U_search", SAPbouiCOM.BoDataType.dt_SHORT_TEXT)
            oEdit.DataBind.SetBound(True, "", "U_search")

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"

            sQuery = String.Empty
            sQuery = "SELECT '' ""Select"" ,B.""DocNum"",B.""DocEntry"",B.""CardCode"",B.""CardName"" FROM ""@INS_ORDR"" A,ORDR B WHERE A.""DocEntry""=B.""U_BaseEntry""  AND B.""U_BaseType""='ORDR'"
            sQuery += " AND B.""CANCELED""='N' AND b.""DocStatus""='O' AND B.""DocEntry"" NOT IN (SELECT DISTINCT IFNULL(""U_SOEntry"",0) FROM ""@INS_INV1"") AND A.""UserSign"" IN (" & oDBDSHeader.GetValue("U_CreatedBy", 0).Trim & ") AND A.""U_WhsCode""='" & oDBDSHeader.GetValue("U_WhsCode", 0).Trim & "' ORDER BY B.""DocNum"",B.""DocEntry"" "

            'sQuery = String.Empty
            'sQuery = "SELECT '' ""Select"" ,B.""DocNum"",B.""DocEntry"",B.""CardCode"",B.""CardName"" FROM ""@INS_ORDR"" A,ORDR B WHERE A.""DocEntry""=B.""U_BaseEntry""  AND B.""U_BaseType""='ORDR'"
            '' sQuery += " AND B.""CANCELED""='N' AND B.""DocEntry"" NOT IN (SELECT DISTINCT IFNULL(""U_SOEntry"",0) FROM ""@INS_INV1"") AND A.""UserSign"" IN (" & oDBDSHeader.GetValue("U_CreatedBy", 0).Trim & ") AND A.""U_WhsCode""='" & oDBDSHeader.GetValue("U_WhsCode", 0).Trim & "'"

            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                    oGrid.Columns.Item(i).TitleObject.Sortable = True
                Else
                    oGrid.Columns.Item(i).Editable = False
                    oGrid.Columns.Item(i).TitleObject.Sortable = True
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_SODetails(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then

                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    Dim DocEntryList As String = String.Empty
                                    Dim DocCount As Integer = 0

                                    oMatrix.FlushToDataSource()
                                    oMatrix.Clear()
                                    oDBDSDetail.Clear()

                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            oDBDSDetail.InsertRecord(oDBDSDetail.Size)
                                            oDBDSDetail.Offset = (oDBDSDetail.Size - 1)
                                            oApplication.StatusBar.SetText("Please wait system is filling So details", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, oDBDSDetail.Size)
                                            oDBDSDetail.SetValue("U_SONo", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("DocNum").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_SOEntry", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("DocEntry").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_CardCode", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("CardCode").Cells.Item(i - 1).Value)
                                            oDBDSDetail.SetValue("U_CardName", oDBDSDetail.Offset, oGrid.DataTable.Columns.Item("CardName").Cells.Item(i - 1).Value)
                                        End If
                                    Next
 
                                    oForm.Close()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oMatrix.LoadFromDataSource()
                                End If

                        End Select
                    Catch ex As Exception
                        frmSalesInvoice.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID

                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            Case "t_search"
                                If pVal.BeforeAction = False And oForm.Items.Item("t_search").Specific.value <> "" Then
                                    Dim DocNum As String = oForm.Items.Item("t_search").Specific.value
                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("DocNum").Cells.Item(i - 1).Value = DocNum Then
                                            oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value = "Y"
                                            oForm.Items.Item("t_search").Specific.value = ""
                                            Exit For
                                        End If
                                    Next
                                End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGrid1").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub




    Sub CreateMySimpleForm_SOCeated()
        Try

            Dim CP As SAPbouiCOM.FormCreationParams = oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams)
            Dim oItem As SAPbouiCOM.Item
            Dim oGrid As SAPbouiCOM.Grid
            Dim oButton As SAPbouiCOM.Button
            Dim oEdit As SAPbouiCOM.EditText
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oLabel As SAPbouiCOM.StaticText
            CP.BorderStyle = SAPbouiCOM.BoFormBorderStyle.fbs_Sizable
            CP.UniqueID = "OINVCreated"
            CP.FormType = "200"

            oForm = oApplication.Forms.AddEx(CP)
            ' Set form width and height 
            oForm.Height = 340
            oForm.Width = 425
            oForm.Title = "SO Creator"
            '' Add a Grid item to the form 
            oItem = oForm.Items.Add("MyGridC", SAPbouiCOM.BoFormItemTypes.it_GRID)
            ' Set the grid dimentions and position 
            oItem.Left = 5
            oItem.Top = 10
            oItem.Width = 400
            oItem.Height = 260
            ' Set the grid data 
            oGrid = oItem.Specific
            oForm.DataSources.DataTables.Add("MyDataTable")

            ' Add OK Button 
            oItem = oForm.Items.Add("ok", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 20
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific
            oButton.Caption = "Add"
            ' Add CANCEL Button 
            oItem = oForm.Items.Add("2", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem.Left = 90
            oItem.Top = 280
            oItem.Width = 65
            oItem.Height = 20
            oButton = oItem.Specific

            '' Add OK Button 
            'oItem = oForm.Items.Add("Clear", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            'oItem.Left = 160
            'oItem.Top = 280
            'oItem.Width = 70
            'oItem.Height = 20
            'oButton = oItem.Specific
            'oButton.Caption = "Clear & Add"
            Dim WhsCode As String = "--"
            If oDBDSHeader.GetValue("U_WhsCode", 0).Trim <> "" Then
                WhsCode = oDBDSHeader.GetValue("U_WhsCode", 0).Trim
            End If
            sQuery = String.Empty
            sQuery = "CALL ""@INSPL_GET_SO_CREATOR""  ('" & WhsCode & "')"
            oForm.DataSources.DataTables.Item(0).ExecuteQuery(sQuery)
            oGrid.DataTable = oForm.DataSources.DataTables.Item("MyDataTable")

            For i As Integer = 0 To oGrid.Columns.Count - 1
                If i = 0 Then
                    oGrid.Columns.Item(i).Type = SAPbouiCOM.BoFormSizeableItemTypes.fsit_CHECK_BOX
                Else
                    oGrid.Columns.Item(i).Editable = False
                End If
            Next

            oGrid.AutoResizeColumns()
            oForm.Visible = True

        Catch ex As Exception
            oForm.Visible = True

            oApplication.StatusBar.SetText("Load Items Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Sub
    Sub ItemEvent_SOCeated(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType

                Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                    Try
                        Dim rsetItem As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim rsetMaxSeq As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
                        Dim oDataTable As SAPbouiCOM.DataTable
                        Dim oCFLE As SAPbouiCOM.ChooseFromListEvent = pVal
                        oDataTable = oCFLE.SelectedObjects
                        Dim Txt1, Txt3, Txt2 As SAPbouiCOM.EditText
                        If Not oDataTable Is Nothing Then

                        End If
                    Catch ex As Exception
                        ' oApplication.StatusBar.SetText("Choose From List Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_CLICK
                    Try
                        Select Case pVal.ItemUID
                            Case "ok"
                                If pVal.BeforeAction = False Then
                                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGridC").Specific
                                    Dim RowID As Integer = oMatrix.VisualRowCount
                                    Dim UserIDList As String = String.Empty
                                    Dim UserNameList As String = String.Empty
                                    Dim DocCount As Integer = 0
                                    oMatrix.Clear()
                                    oDBDSDetail.Clear()
                                    oMatrix.AddRow()

                                    For i As Integer = 1 To oGrid.Rows.Count
                                        If oGrid.DataTable.Columns.Item("Select").Cells.Item(i - 1).Value.Equals("Y") Then
                                            If DocCount = 0 Then
                                                UserIDList = "'" & oGrid.DataTable.Columns.Item("UserID").Cells.Item(i - 1).Value & "'"
                                                UserNameList = "'" & oGrid.DataTable.Columns.Item("Name").Cells.Item(i - 1).Value & "'"
                                            Else
                                                UserIDList = UserIDList & "," & "'" & oGrid.DataTable.Columns.Item("UserID").Cells.Item(i - 1).Value & "'"
                                                UserNameList = UserNameList & "," & "'" & oGrid.DataTable.Columns.Item("Name").Cells.Item(i - 1).Value & "'"
                                            End If
                                            DocCount += 1
                                        End If
                                    Next
                                    oDBDSHeader.SetValue("U_CreatedBy", 0, UserIDList)
                                    oDBDSHeader.SetValue("U_CreatedByNm", 0, UserNameList)
                                    oForm.Close()
                                    oApplication.StatusBar.SetText("Operation Completed....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                End If
                           
                        End Select
                    Catch ex As Exception
                        frmSalesInvoice.Freeze(False)
                        oApplication.StatusBar.SetText("Click Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                    Finally
                    End Try
                Case SAPbouiCOM.BoEventTypes.et_VALIDATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGridC").Specific
                        Select Case pVal.ItemUID
                            Case "MyGrid"
                                Select Case pVal.ColUID

                                End Select
                        End Select
                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

                Case SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGridC").Specific
                        Select Case pVal.ItemUID

                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try


                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    Try
                        Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item("MyGridC").Specific
                        Select Case pVal.ItemUID
                            'Case "lk_grp"
                            '    If pVal.BeforeAction = False Then
                            '        oGfun.DoOpenLinkedObjectForm("OITM", "OITM", "t_docentry", oForm.Items.Item("t_itmcode").Specific.value)
                            '    End If
                        End Select

                    Catch ex As Exception
                        oApplication.StatusBar.SetText("Item Press Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                        oForm.Freeze(False)
                    End Try

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText("Item Event Failed:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oForm.Freeze(False)
        End Try
    End Sub
    Function TransactionManagement() As Boolean
        TransactionManagement = False
        Try


            Dim rstChk As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim rstSO As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            Dim rstDraft As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            sQuery = String.Empty
            sQuery = "SELECT * FROM ""@INS_INV1"" WHERE  IFNULL(""U_InvEntry"",'')='' AND ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
            'sQuery = "SELECT * FROM ""@INS_INV1"" WHERE   ""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "'"
            rstChk.DoQuery(sQuery)
            If rstChk.RecordCount > 0 Then
                rstChk.MoveFirst()
                For i As Integer = 1 To rstChk.RecordCount
                    ApprovalRemarks = ""

                    sQuery = String.Empty
                    sQuery = "SELECT  * FROM OINV WHERE  ""CANCELED""='N' AND ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_BaseLine""='" & rstChk.Fields.Item("LineId").Value & "' and ""U_BaseType""='OINV' and ""CANCELED""='N'"
                    rstSO.DoQuery(sQuery)

                    sQuery = String.Empty
                    sQuery = "SELECT  * FROM ODRF WHERE ""U_BaseEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and ""U_BaseLine""='" & rstChk.Fields.Item("LineId").Value & "' and ""U_BaseType""='OINV' and ""CANCELED""='N'"
                    rstDraft.DoQuery(sQuery)

                    If rstSO.RecordCount = 0 And rstDraft.RecordCount = 0 Then

                        'If rstSO.RecordCount = 0 Then

                        sQuery = String.Empty
                        sQuery = "SELECT * FROM ORDR   WHERE ""DocEntry""='" & rstChk.Fields.Item("U_SOEntry").Value & "'"
                        Dim RstSOChk As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                        Dim FreightAmt As Double = 0.0
                        sQuery = String.Empty

                        sQuery = "SELECT SUM(""LineTotal"") ""LineTotal"" FROM  RDR3 A inner join OEXD B ON A.""ExpnsCode""=B.""ExpnsCode"" WHERE A.""DocEntry""='" & rstChk.Fields.Item("U_SOEntry").Value & "' and B.""ExpnsName""='DISC'"
                        ''sQuery = "CALL ""@INSPL_FREIGHTAMOUNT""('" & rstChk.Fields.Item("U_SOEntry").Value & "')"
                        Dim RstFreight As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                        If RstFreight.RecordCount > 0 Then
                            FreightAmt = Math.Abs(Convert.ToDouble(RstFreight.Fields.Item(0).Value))
                        Else
                            FreightAmt = 0
                        End If

                        Dim DAmt As Double = 0.0
                        sQuery = String.Empty

                        sQuery = "SELECT SUM(A.""LineTotal"")*MAX(c.""Discount"")/100 as ""LineTotal"" FROM  RDR1 A INNER JOIN ORDR B ON A.""DocEntry""=B.""DocEntry"" inner join OCRD c ON b.""CardCode""=c.""CardCode""   WHERE A.""DocEntry""='" & rstChk.Fields.Item("U_SOEntry").Value & "'"
                        'sQuery = "CALL ""@INSPL_DISCOUNTAMOUNT""('" & rstChk.Fields.Item("U_SOEntry").Value & "')"
                        Dim RstF As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                        If RstF.RecordCount > 0 Then
                            DAmt = RstF.Fields.Item(0).Value
                        Else
                            DAmt = 0
                        End If

                        If FreightAmt < 0 Then
                            If ApprovalRemarks = "" Then
                                ApprovalRemarks = "Freight"
                            Else
                                ApprovalRemarks = ApprovalRemarks & "," & "Freight"
                            End If
                        End If

                        ''---Overdue
                        sQuery = String.Empty
                        sQuery = "Select * From (SELECT Sum(T0.""BalDueDeb""- T0.""BalDueCred"") AS ""Balance"""
                        sQuery += " FROM JDT1 T0 ,OCRD T1 WHERE T1.""CardCode"" = T0.""ShortName"" "
                        sQuery += " and T0.""DueDate"" <CURRENT_DATE and T1.""CardType""='C' and T1.""CardCode""='" & RstSOChk.Fields.Item("CardCode").Value & "'"
                        sQuery += " group by T0.""ShortName"",T1.""CardName"") T1 Where T1.""Balance"">0"
                        Dim RstOverdue As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                        If RstOverdue.RecordCount > 0 Then
                            If ApprovalRemarks = "" Then
                                ApprovalRemarks = "Overdue"
                            Else
                                ApprovalRemarks = ApprovalRemarks & "," & "Overdue"
                            End If
                        End If
                        ''---Invoice Credit
                        sQuery = String.Empty
                        sQuery = " Select * From (Select B.""CardCode"",Sum(Ifnull (A.""CheckSum"",0))As ""PDCBAL"",B.""CreditLine"","
                        sQuery += " (B.""CreditLine""-(Sum(Ifnull (A.""CheckSum"",0))+B.""Balance""))As ""Limit"" "
                        sQuery += " from OCRD B  Left join OCHH A on A.""CardCode""=B.""CardCode"" and ""Deposited""='N' and ""Canceled""='N'"
                        sQuery += " Group BY B.""CardCode"",B.""CreditLine"",""Balance"") T1 Where T1.""CardCode""='" & RstSOChk.Fields.Item("CardCode").Value & "'"
                        sQuery += " and '" & RstSOChk.Fields.Item("DocTotal").Value & "'>T1.""Limit"""
                        Dim RstInvCredit As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
                        If RstInvCredit.RecordCount > 0 Then
                            If ApprovalRemarks = "" Then
                                ApprovalRemarks = "Credit"
                            Else
                                ApprovalRemarks = ApprovalRemarks & "," & "Credit"
                            End If
                        End If

                        If FreightAmt > DAmt Or RstOverdue.RecordCount > 0 Or RstInvCredit.RecordCount > 0 Then
                            Me.SalesInvoice_Draft(rstChk.Fields.Item("U_SOEntry").Value, rstChk.Fields.Item("LineId").Value)
                        Else
                            Me.SalesInvoice(rstChk.Fields.Item("U_SOEntry").Value, rstChk.Fields.Item("LineId").Value)
                        End If
                    End If
                    rstChk.MoveNext()
                Next
            End If
            TransactionManagement = True
        Catch ex As Exception
            TransactionManagement = False
            oApplication.MessageBox("Transaction Management Failed: " & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            oApplication.MessageBox(ex.Message)
        End Try
    End Function
    Function SalesInvoice_Draft(ByVal DocEntry As String, ByVal LineID As String) As Boolean
        Try

            'Enable Approval Procedure flags
            'Dim oAdminInfo As SAPbobsCOM.AdminInfo = oCompany.GetCompanyService().GetAdminInfo()
            'oAdminInfo.EnableApprovalProcedureInDI = SAPbobsCOM.BoYesNoEnum.tYES
            'oAdminInfo.DocConfirmation = SAPbobsCOM.BoYesNoEnum.tYES
            'oCompany.GetCompanyService().UpdateAdminInfo(oAdminInfo)


            SalesInvoice_Draft = False
            Dim SalesInvoiceStatus As Boolean = False
            Dim oSalesInvoice As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts)

            sQuery = String.Empty
            sQuery = "SELECT A.""CardCode"",A.""DiscPrcnt"" ""DiscPrcntHead"",A.""NumAtCard"",A.""RoundDif"",A.""Rounding"",B.* FROM ORDR A,RDR1 B WHERE A.""DocEntry""=B.""DocEntry"" AND A.""DocEntry""='" & DocEntry & "'"
            Dim RstSO As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            RstSO.MoveFirst()

            oSalesInvoice.DocObjectCode = SAPbobsCOM.BoObjectTypes.oInvoices
            'DocDate
            Dim dtDate As Date
            Dim stDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim first As String = stDate.Insert(4, "/")
            Dim second As String = first.Insert(7, "/")
            dtDate = DateTime.Parse(second, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSalesInvoice.DocDate = dtDate



            'TaxDate
            Dim dtTaxDate As Date
            Dim stTaxDate As String = oDBDSHeader.GetValue("U_DocDate", 0).Trim
            Dim firstTax As String = stTaxDate.Insert(4, "/")
            Dim secondTax As String = firstTax.Insert(7, "/")
            dtTaxDate = DateTime.Parse(secondTax, Globalization.CultureInfo.CreateSpecificCulture("en-CA"))
            oSalesInvoice.TaxDate = dtTaxDate

            oSalesInvoice.CardCode = RstSO.Fields.Item("CardCode").Value 'oDBDSHeader.GetValue("U_CardCode", 0).Trim
            oSalesInvoice.DocType = SAPbobsCOM.BoDocumentTypes.dDocument_Items
            oSalesInvoice.DiscountPercent = CDbl(RstSO.Fields.Item("DiscPrcntHead").Value)
            oSalesInvoice.NumAtCard = RstSO.Fields.Item("NumAtCard").Value 'oDBDSHeader.GetValue("U_NumAtCard", 0).Trim
            If RstSO.Fields.Item("Rounding").Value = "Y" Then
                oSalesInvoice.Rounding = SAPbobsCOM.BoYesNoEnum.tYES
                oSalesInvoice.RoundingDiffAmount = CDbl(RstSO.Fields.Item("RoundDif").Value)
            Else
                oSalesInvoice.Rounding = SAPbobsCOM.BoYesNoEnum.tNO
                oSalesInvoice.RoundingDiffAmount = 0.0
            End If



            oSalesInvoice.UserFields.Fields.Item("U_InvRefNo").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSalesInvoice.UserFields.Fields.Item("U_InvType").Value = "Sale Invoice"
            oSalesInvoice.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
            oSalesInvoice.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
            oSalesInvoice.UserFields.Fields.Item("U_BaseLine").Value = LineID.ToString  ' Trim(RstSO.Fields.Item("LineNum").Value) ' Trim(oDBDSHeader.GetValue("LineNum", 0))
            oSalesInvoice.UserFields.Fields.Item("U_BaseType").Value = "OINV"


            For i As Integer = 1 To RstSO.RecordCount
                oSalesInvoice.Lines.ItemCode = RstSO.Fields.Item("ItemCode").Value ' Trim(oMatrix.Columns.Item("itemcode").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.Quantity = CDbl(RstSO.Fields.Item("Quantity").Value)
                oSalesInvoice.Lines.Price = CDbl(RstSO.Fields.Item("Price").Value) ' CDbl(oMatrix.Columns.Item("untprc").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.DiscountPercent = CDbl(RstSO.Fields.Item("DiscPrcnt").Value) ' CDbl(oMatrix.Columns.Item("DiscPrcnt").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.TaxCode = RstSO.Fields.Item("TaxCode").Value 'Trim(oMatrix.Columns.Item("taxcode").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.WarehouseCode = RstSO.Fields.Item("WhsCode").Value 'Trim(oMatrix.Columns.Item("whscode").Cells.Item(i).Specific.value)
                oSalesInvoice.Lines.BaseEntry = Trim(RstSO.Fields.Item("DocEntry").Value)
                oSalesInvoice.Lines.BaseType = 17
                oSalesInvoice.Lines.BaseLine = Trim(RstSO.Fields.Item("LineNum").Value)
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseEntry").Value = Trim(oDBDSHeader.GetValue("DocEntry", 0))
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseNum").Value = Trim(oDBDSHeader.GetValue("DocNum", 0))
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseType").Value = "OINV"
                oSalesInvoice.Lines.UserFields.Fields.Item("U_BaseLine").Value = Trim(RstSO.Fields.Item("LineNum").Value)
                oSalesInvoice.Lines.Add()
                RstSO.MoveNext()
            Next

            sQuery = String.Empty
            sQuery = "SELECT * FROM RDR3 WHERE ""DocEntry""='" & DocEntry & "'"
            Dim rstFregt As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)
            If rstFregt.RecordCount > 0 Then
                rstFregt.MoveFirst()
                For i As Integer = 1 To rstFregt.RecordCount
                    oSalesInvoice.Expenses.ExpenseCode = rstFregt.Fields.Item("ExpnsCode").Value 'Trim(oMatrix2.Columns.Item("ExpnsCode").Cells.Item(i).Specific.value)
                    oSalesInvoice.Expenses.TaxCode = rstFregt.Fields.Item("TaxCode").Value 'Trim(oMatrix2.Columns.Item("VatGroup").Cells.Item(i).Specific.value)
                    oSalesInvoice.Expenses.LineTotal = CDbl(rstFregt.Fields.Item("LineTotal").Value) 'Trim(oMatrix2.Columns.Item("GrsAmnt").Cells.Item(i).Specific.value)
                    oSalesInvoice.Expenses.Add()
                    rstFregt.MoveNext()
                Next
            End If


            If oSalesInvoice.Add = 0 Then
                SalesInvoiceStatus = True
            Else
                SalesInvoiceStatus = False
            End If

            If SalesInvoiceStatus Then
                SalesInvoice_Draft = True
                'sQuery = String.Empty
                'sQuery = "UPDATE B SET B.""U_InvEntry""=A.""DocEntry"",B.""U_InvNo""=A.""DocNum"" FROM ODRF A,""@INS_INV1"" B WHERE A.""U_BaseEntry""=B.""DocEntry"" and  A.""U_BaseLine""=B.""LineId""  AND A.""U_BaseType""='OINV' and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and B.""LineId""='" & LineID & "'"
                'Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                sQuery = String.Empty
                sQuery = "UPDATE A SET A.""U_Approval""='P',A.""U_AppRemarks""='" & ApprovalRemarks.ToString & "' FROM ODRF A,""@INS_INV1"" B "
                sQuery += " WHERE IFNULL(A.""U_BaseEntry"",'')=B.""DocEntry"" and  IFNULL(A.""U_BaseLine"",'')=B.""LineId""  AND IFNULL(A.""U_BaseType"",'')='OINV' "
                sQuery += " and B.""DocEntry""='" & oDBDSHeader.GetValue("DocEntry", 0).Trim & "' and B.""LineId""='" & LineID & "'"
                Dim RstUpdate As SAPbobsCOM.Recordset = oGfun.DoQuery(sQuery)

                frmSalesInvoice.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE

                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSalesInvoice)
            Else
                oApplication.StatusBar.SetText("Failed to Post SalesInvoice_Draft  " & oCompany.GetLastErrorDescription, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                oApplication.MessageBox("Failed to Post SalesInvoice_Draft  " & oCompany.GetLastErrorDescription, 1)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oSalesInvoice)
            End If

        Catch ex As Exception
            SalesInvoice_Draft = False
            oApplication.StatusBar.SetText("Failed to Post SalesInvoice_Draft:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
        End Try
    End Function
End Class
