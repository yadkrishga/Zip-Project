﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class LineExt
	{
		public string CustomerPoNumber { get; set; }
		public string linenum { get; set; }
		public string Messages { get; set; }
	}
}
