﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class TransmissionHeader
	{
		public string TransmissionReference { get; set; }
		public string Version { get; set; }
		public string SenderCode { get; set; }
		public string ReceiverCode { get; set; }
		public string DatePrepared { get; set; }
		public string TimePrepared { get; set; }
		public string CustInvCounter { get; set; }
	}
}
