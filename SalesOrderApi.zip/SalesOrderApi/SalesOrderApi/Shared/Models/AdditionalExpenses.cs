﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class AdditionalExpenses
	{
		public string Name { get; set; }
		public string RevenuesAccount { get; set; }
		public string OutputVATGroup { get; set; }
		public string InputVATGroup { get; set; }
		public string ExpensCode { get; set; }
	}
		 
}
