﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
	public class AddressCont
	{
		public Infos infos { get; set; }
		public List<Address> Addresses { get; set; }
	}
	public class Infos
	{
		public string Postcode { get; set; }      // null,
		public string InCode { get; set; }      // null,
		public string OutCode { get; set; }      // null,
		public double Latitude { get; set; }      // 0.0,
		public double Longitude { get; set; }      // 0.0,
		public string District { get; set; }      // null,
		public string Region { get; set; }      // null,
		public string Country { get; set; }      // null,
		public string DistrictId { get; set; }      // null
	}
	public class Address
	{
		public Raw Raw { get; set; }

		public Format Formatted { get; set; }
		public string[] Printable { get; set; }
		public string OneLine { get; set; }
	}
	public class Raw
	{	
          public string UDPRN { get; set; }      // "55867531",
		public string Postcode { get; set; }      // "L23 1AF",
		public string PostTown { get; set; }      // "LIVERPOOL",
		public string DependentLocality { get; set; }      // "",
		public string DoubleDependentLocality { get; set; }      // "",
		public string Thoroughfare { get; set; }      // "Thorn Tree Drive",
		public string DependentThoroughfare { get; set; }      // "",
		public string BuildingNumber { get; set; }      // "2",
		public string BuildingName { get; set; }      // "",
		public string SubBuildingName { get; set; }      // "",
		public string POBox { get; set; }      // "",
		public string DepartmentName { get; set; }      // "",
		public string OrganisationName { get; set; }      // "",
		public string PostcodeType { get; set; }      // "S",
		public string OrganisationIndicator { get; set; }      // "",
		public string DeliveryPointSuffix { get; set; }      // "1A"
	}
	public class Format
	{
		public string[] Lines { get; set; }      // [

		public string Town { get; set; }      // "LIVERPOOL",
		public string Postcode { get; set; }      // "L23 1AF"
	}

	
}
