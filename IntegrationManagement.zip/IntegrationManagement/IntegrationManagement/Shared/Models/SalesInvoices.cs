﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
	public class SalesInvoices
	{
		 public TransmissionHeader TransmissionHeader { get; set; }	
		  public SalesInvoice SalesInvoice  { get; set; }
 	}
	public class SalesInvoice
	{
		public string SalesInvoiceNumber { get; set; }
		public string DocumentType { get; set; }
		public InvoiceHeader InvoiceHeader { get; set; }
		public List<InvoiceDetail>  InvoiceDetail { get; set; }
		public InvoiceTotal InvoiceTotal { get; set; }
	}
	public class InvoiceTotal
	{
		public string TotalNetAmount { get; set; }      // 169.36</TotalNetAmount { get; set; }      //
		public string TotalSalesTax { get; set; }      // 28.23</TotalSalesTax { get; set; }      //
		public string TotalInvDiscAmount { get; set; }      // 0.00</TotalInvDiscAmount { get; set; }      //
		public string TotalInvAmountExclTax { get; set; }      // 141.13</TotalInvAmountExclTax { get; set; }      //
		public string TotalTermsDiscountAmount { get; set; }      // 0.00</TotalTermsDiscountAmount { get; set; }      //
		public string TotalForeignNetAmount { get; set; }      // 169.36</TotalForeignNetAmount { get; set; }      //
		public string TotalForeignSalesTax { get; set; }      // 28.23</TotalForeignSalesTax { get; set; }      //
		public string TotalForeignInvDiscAmount { get; set; }      // 0.00</TotalForeignInvDiscAmount { get; set; }      //
		public string TotalForeignInvAmountExclTax { get; set; }      // 141.13</TotalForeignInvAmountExclTax { get; set; }      //
		public string TotalForeignTermsDiscountAmount { get; set; }      // 0.00</TotalForeignTermsDiscountAmount { get; set; }      //
		public string TotalMass { get; set; }      // 42.099476</TotalMass { get; set; }      //
		public string TotalVolume { get; set; }      // 0.000000</TotalVolume { get; set; }      //
		public string TotalQuantity { get; set; }
	}
	public  class InvoiceHeader
	{
		public string CompanyName { get; set; }
		public string CompanyAddress1 { get; set; }
		public string CompanyAddress2 { get; set; }
		public string CompanyAddress3 { get; set; }
		public string CompanyTaxRegNumber { get; set; }
		public string CompanyRegNumber { get; set; }
		public string CompanyTaxNo { get; set; }
		public string CustomerPoNumber { get; set; }      //369245310</CustomerPoNumber { get; set; }      //
		public string CustomerPoDate { get; set; }      //2023-02-20</CustomerPoDate { get; set; }      //
		public string Customer { get; set; }      //TP3692</Customer { get; set; }      //
		public string CustomerName { get; set; }      //BRAMPTON TP</CustomerName { get; set; }      //
		public string ShipAddress1 { get; set; }      //TRAVIS PERKINS TRADING CO. LTD</ShipAddress1 { get; set; }      //
		public string ShipAddress2 { get; set; }      //TOWNFOOT INDUSTRIAL ESTATE</ShipAddress2 { get; set; }      //
		public string ShipAddress3 { get; set; }
		public string ShipAddress4 { get; set; }      //BRAMPTON</ShipAddress4 { get; set; }      //
		public string ShipAddress5 { get; set; }
		public string ShipPostalCode { get; set; }      //CA8 1SW</ShipPostalCode { get; set; }      //
		public string InvoiceCustomerName { get; set; }      //TRAVIS PERKINS TRADING CO. LTD</InvoiceCustomerName { get; set; }      //
		public string InvoiceAddress1 { get; set; }      //PURCHASE LEDGER</InvoiceAddress1 { get; set; }      //
		public string InvoiceAddress2 { get; set; }      //LODGE WAY HOUSE</InvoiceAddress2 { get; set; }      //
		public string InvoiceAddress3 { get; set; }      //LODGE WAY</InvoiceAddress3 { get; set; }      //
		public string InvoiceAddress4 { get; set; }      //HARLESTONE ROAD</InvoiceAddress4 { get; set; }      //
		public string InvoiceAddress5 { get; set; }      //NORTHAMPTON</InvoiceAddress5 { get; set; }      //
		public string InvoicePostalCode { get; set; }      //NN5 7UG</InvoicePostalCode { get; set; }      //
		public string SalesPersonName { get; set; }      //GARY EDGAR</SalesPersonName { get; set; }      //
		public string Currency { get; set; }      //ST</Currency { get; set; }      //
		public string CurrencyName { get; set; }      //Pound Sterling</CurrencyName { get; set; }      //
		public string CurrencyRate { get; set; }      // 1.000000</CurrencyRate { get; set; }      //
		public string DeliveryNoteNumber { get; set; }      //S36458</DeliveryNoteNumber { get; set; }      //
		public string DeliveryNote { get; set; }
		public string DispatchNote { get; set; }
		public string DispatchDate { get; set; }      //2023-02-22</DispatchDate { get; set; }      //
		public string PodReference { get; set; }
		public string PodDate { get; set; }
		public string SalesOrder { get; set; }      //S36458</SalesOrder { get; set; }      //
		public string TaxState { get; set; }
		public string TaxCountyZipCode { get; set; }
		public string ExtendedTaxCode { get; set; }
		public string InvoiceTermsDescription { get; set; }      //NETT</InvoiceTermsDescription { get; set; }      //
		public string DiscountDueDate { get; set; }      //2023-02-24</DiscountDueDate { get; set; }      //
		public string InvoiceDate { get; set; }      //2023-02-24</InvoiceDate { get; set; }      //
		public string ShipDate { get; set; }      //2023-02-22</ShipDate { get; set; }      //
		public string DiscPct { get; set; }      // 00.00</DiscPct { get; set; }      //
		public string DueDays { get; set; }      // 0</DueDays { get; set; }      //
		public string DiscDays { get; set; }      // 0</DiscDays { get; set; }      //
		public string InvoiceDueDate { get; set; }      //2023-02-24</InvoiceDueDate { get; set; }      //
		public string SpecialInstructions { get; set; }
		public string MultiShipCode { get; set; }
		public string ShippingInstrs { get; set; }      //S</ShippingInstrs { get; set; }      //
		public string TelexNo { get; set; }
		public string OrderType { get; set; }
		public string OrderDate { get; set; }      //2023-02-20</OrderDate { get; set; }      //
	}
    public class InvoiceDetail
	{
		public MerchandiseLine MerchandiseLine { get; set; }	
		public CommentLine CommentLine { get; set; }	
	}
	public class CommentLine
	{
		public string DetailLineNumber { get; set; }
		public string Comment { get; set; }
	}
	public class MerchandiseLine
	{
		public string DetailLineNumber { get; set; }      // 2</DetailLineNumber { get; set; }      //
		public string StockCode { get; set; }      //SESINPIN200</StockCode { get; set; }      //
		public string CustomerPartNumber { get; set; }      //
		public string StockDescription { get; set; }      //Stainless ES Ind 200 UV</StockDescription { get; set; }      //
		public string StockDrawingNumber { get; set; }      //413203</StockDrawingNumber { get; set; }      //
		public string StockLongDescription { get; set; }      //Stainless ES Ind 200 UV</StockLongDescription { get; set; }      //
		public string StockAltKey1 { get; set; }      //
		public string StockAltKey2 { get; set; }      //Y</StockAltKey2 { get; set; }      //
		public string ShipQty { get; set; }      // 1.000</ShipQty { get; set; }      //
		public string StockingUom { get; set; }      //EA</StockingUom { get; set; }      //
		public string OrderUom { get; set; }      //EA</OrderUom { get; set; }      //
		public string OrderQty { get; set; }      // 1.000</OrderQty { get; set; }      //
		public string BackorderQty { get; set; }      // 0.000</BackorderQty { get; set; }      //
		public string StockedQtyToShip { get; set; }      // 1.000</StockedQtyToShip { get; set; }      //
		public string UnitPrice { get; set; }      // 389.22000</UnitPrice { get; set; }      //
		public string UnitPriceExDisc { get; set; }      // 389.22000</UnitPriceExDisc { get; set; }      //
		public string OrderUnitPrice { get; set; }      // 389.22000</OrderUnitPrice { get; set; }      //
		public string OrderUnitPriceIncDisc { get; set; }      // 389.22000</OrderUnitPriceIncDisc { get; set; }      //
		public string PriceUom { get; set; }      //EA</PriceUom { get; set; }      //
		public string PricingContractNumber { get; set; }      //
		public string CustomerRetailPrice { get; set; }      // 0.00000</CustomerRetailPrice { get; set; }      //
		public string SalesTaxPercent { get; set; }      // 20.00</SalesTaxPercent { get; set; }      //
		public string SalesTaxCode { get; set; }      //A</SalesTaxCode { get; set; }      //
		public string SalesTaxValue { get; set; }      // 77.84</SalesTaxValue { get; set; }      //
		public string LineDiscountValue { get; set; }      // 0.00</LineDiscountValue { get; set; }      //
		public string NetValueIncTax { get; set; }      // 467.06</NetValueIncTax { get; set; }      //
		public string NetValueExcTax { get; set; }      // 389.22</NetValueExcTax { get; set; }      //
		public string ForeignSalesTaxValue { get; set; }      // 77.84</ForeignSalesTaxValue { get; set; }      //
		public string ForeignLineDiscountValue { get; set; }      // 0.00</ForeignLineDiscountValue { get; set; }      //
		public string ForeignNetValueIncTax { get; set; }      // 467.06</ForeignNetValueIncTax { get; set; }      //
		public string SoPriceUomFact { get; set; }      // 1.00</SoPriceUomFact { get; set; }      //
		public string SoPriceUomMulDiv { get; set; }
		public CommentLine CommentLine { get;set; }
	}

}
