﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
	public static class TableCreate
	{
		public static int RetVal;
		public static int ErrCode;
		public static string ErrMsg = "";

		public static bool CreateTable(string TableName, string TableDesc, SAPbobsCOM.BoUTBTableType TableType)
		{
			bool functionReturnValue = false;
			functionReturnValue = false;

			try
			{
				if (!TableCreate.TableExists(TableName))
				{

					SAPbobsCOM.UserTablesMD v_UserTableMD = default(SAPbobsCOM.UserTablesMD);

					ProgData.B1Application.StatusBar.SetText("Creating Table " + TableName + " ...................", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
					v_UserTableMD = (SAPbobsCOM.UserTablesMD)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables);
					v_UserTableMD.TableName = TableName;
					v_UserTableMD.TableDescription = TableDesc;
					v_UserTableMD.TableType = TableType;
					GC.Collect();
					RetVal = v_UserTableMD.Add();
					if (RetVal != 0)
					{
						ProgData.B1Company.GetLastError(out ErrCode, out ErrMsg);

						v_UserTableMD = null;
						GC.Collect();
						return false;
					}
					else
					{
						System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserTableMD);
						v_UserTableMD = null;
						GC.Collect();
						return true;
					}
				}
				else
				{
					GC.Collect();
					return false;
				}
			}
			catch (Exception ex)
			{
				Logger.Log(ex);
			}
			return functionReturnValue;
		}

		public static bool TableExists(string TableName)
		{

			SAPbobsCOM.UserTablesMD oTables = default(SAPbobsCOM.UserTablesMD);
			bool oFlag = false;
			oTables = (SAPbobsCOM.UserTablesMD)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables);
			oFlag = oTables.GetByKey(TableName);

			System.Runtime.InteropServices.Marshal.ReleaseComObject(oTables);
			oTables = null;
			GC.Collect();
			return oFlag;

		}
		public static void AddUDO(string UDOCode, string UDOName, string[,] ChildTables, string TableName, SAPbobsCOM.BoUDOObjType UDOType, string[,] FormField, string[,] FindField)
		{
			try
			{
				SAPbobsCOM.UserObjectsMD oUserObjectMD = null;
				oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));

				int RetVal = -1;
				var updated = false;

				if (UDOExists(UDOCode))
				{
					oUserObjectMD.GetByKey(UDOCode);

					for (Int16 i = 0; i <= ChildTables.GetLength(0) - 1; i++)
					{
						if (i >= oUserObjectMD.ChildTables.Count)
						{
							oUserObjectMD.ChildTables.Add();
							oUserObjectMD.ChildTables.TableName = ChildTables[i, 0];
							updated = true;
						}
					}

					for (Int16 i = 0; i <= FormField.GetLength(0) - 1; i++)
					{
						if (i >= oUserObjectMD.FormColumns.Count)
						{
							oUserObjectMD.FormColumns.Add();
							oUserObjectMD.FormColumns.FormColumnAlias = FormField[i, 0];
							oUserObjectMD.FormColumns.FormColumnDescription = FormField[i, 1];
							updated = true;
						}
					}

					for (Int16 i = 0; i <= FindField.GetLength(0) - 1; i++)
					{
						if (i >= oUserObjectMD.FindColumns.Count)
						{
							oUserObjectMD.FindColumns.Add();
							oUserObjectMD.FindColumns.ColumnAlias = FindField[i, 0];
							oUserObjectMD.FindColumns.ColumnDescription = FindField[i, 1];
							updated = true;
						}
					}

					if (updated)
						RetVal = oUserObjectMD.Update();

				}
				else
				{
					oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
					oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES;

					oUserObjectMD.CanCreateDefaultForm = UDOCode == "ObTblCol" ? SAPbobsCOM.BoYesNoEnum.tYES : SAPbobsCOM.BoYesNoEnum.tNO;
					oUserObjectMD.EnableEnhancedForm = SAPbobsCOM.BoYesNoEnum.tNO;

					oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES;
					oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
					oUserObjectMD.CanYearTransfer = SAPbobsCOM.BoYesNoEnum.tYES;
					oUserObjectMD.Code = UDOCode;
					oUserObjectMD.Name = UDOName;

					//if (ChildTable != "")
					//{
					//    oUserObjectMD.ChildTables.TableName = ChildTable;
					//    oUserObjectMD.ChildTables.Add();

					//    oUserObjectMD.ChildTables.TableName = ChildTable2;
					//    oUserObjectMD.ChildTables.Add();

					//}

					oUserObjectMD.ObjectType = UDOType;
					oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
					oUserObjectMD.TableName = TableName;
					//  oUserObjectMD.FormColumns.SonNumber = 1;
					for (Int16 i = 0; i <= FormField.GetLength(0) - 1; i++)
					{
						oUserObjectMD.FormColumns.FormColumnAlias = FormField[i, 0];

						oUserObjectMD.FormColumns.FormColumnDescription = FormField[i, 1];
						if (FormField[i, 0] == "DocEntry")
							oUserObjectMD.FormColumns.Editable = SAPbobsCOM.BoYesNoEnum.tNO;
						else
							oUserObjectMD.FormColumns.Editable = SAPbobsCOM.BoYesNoEnum.tYES;
						oUserObjectMD.FormColumns.Add();

					}
					for (Int16 i = 0; i <= FindField.GetLength(0) - 1; i++)
					{
						oUserObjectMD.FindColumns.ColumnAlias = FindField[i, 0];
						oUserObjectMD.FindColumns.ColumnDescription = FindField[i, 1];

						oUserObjectMD.FindColumns.Add();

					}

					for (Int16 i = 0; i <= ChildTables.GetLength(0) - 1; i++)
					{
						oUserObjectMD.ChildTables.TableName = ChildTables[i, 0];
						oUserObjectMD.ChildTables.Add();

					}


					/*        for (Int16 i = 0; i <= ChildField.GetLength(0) - 1; i++)
                            {
                                oUserObjectMD.EnhancedFormColumns.ColumnAlias = ChildField[i, 0];
                                oUserObjectMD.EnhancedFormColumns.ColumnDescription = ChildField[i, 1];
                                oUserObjectMD.EnhancedFormColumns.ChildNumber = 1;
                                oUserObjectMD.EnhancedFormColumns.ColumnIsUsed = SAPbobsCOM.BoYesNoEnum.tYES;
                                oUserObjectMD.EnhancedFormColumns.Editable = SAPbobsCOM.BoYesNoEnum.tYES;
                                oUserObjectMD.EnhancedFormColumns.ChildNumber = 1;
                                oUserObjectMD.EnhancedFormColumns.Add();


                            }
                            */
					RetVal = oUserObjectMD.Add();
				}

				//SAPbobsCOM.UserObjectsMD oUserObjectMD = null;
				//oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(Main.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));


				string ErrMsg = "";

				// check for errors in the process
				if (RetVal != 0 && RetVal != -1)
				{

					ProgData.B1Company.GetLastError(out RetVal, out ErrMsg);
					ProgData.B1Application.StatusBar.SetText(ErrMsg);

				}
				else
				{
					ProgData.B1Application.StatusBar.SetText("UDO: " + oUserObjectMD.Name + " eklendi", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
				}
				System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
				oUserObjectMD = null;
				GC.Collect();
			}
			catch (Exception ex)
			{
				ProgData.B1Application.StatusBar.SetText(" UDO hata : " + ex.ToString(), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
			}
		}

		public static void AddRecordDatabases()
		{

			SAPbobsCOM.GeneralService oGeneralService = null;

			SAPbobsCOM.GeneralData oGeneralData = null;
			SAPbobsCOM.GeneralData oChild = null;
			SAPbobsCOM.GeneralDataCollection oChildren = null;
			SAPbobsCOM.GeneralDataParams oGeneralParams = null;
			SAPbobsCOM.CompanyService oCompanyService = null;
			bool newrec = true;
			try
			{
				oCompanyService = ProgData.B1Company.GetCompanyService();
				// Get GeneralService (oCmpSrv is the CompanyService)
				oGeneralService = oCompanyService.GetGeneralService("ObDtbs");
				try
				{
					oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);

					oGeneralParams.SetProperty("DocEntry", "1");
					oGeneralData = oGeneralService.GetByParams(oGeneralParams);
				}
				catch (Exception)
				{
					ProgData.B1Company.GetLastError(out RetVal, out ErrMsg);
				}
				newrec = false;
				if (oGeneralData == null)
				{
					newrec = true;
					oGeneralData = ((SAPbobsCOM.GeneralData)(oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData)));
				}



				oChildren = oGeneralData.Child("B_CD1_DTBS");

				if (oChildren.Count == 0)
				{
					oChild = oChildren.Add();


					oChild.SetProperty("U_DbName", ProgData.B1Company.CompanyDB);

					oChild = oChildren.Add();
				}



				if (newrec)

					oGeneralParams = oGeneralService.Add(oGeneralData);
				else
					oGeneralService.Update(oGeneralData);


				System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralService);
				oGeneralService = null;
				GC.Collect();

				System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralData);
				oGeneralData = null;
				GC.Collect();

				System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralParams);
				oGeneralParams = null;
				GC.Collect();

				System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompanyService);
				oCompanyService = null;
				GC.Collect();

			}
			catch (Exception)
			{
				ProgData.B1Company.GetLastError(out RetVal, out ErrMsg);
				ProgData.B1Application.StatusBar.SetText(ErrMsg);

				//System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralService);
				//oGeneralService = null;
				//GC.Collect();

				//System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralData);
				//oGeneralData = null;
				//GC.Collect();

				//System.Runtime.InteropServices.Marshal.ReleaseComObject(oGeneralParams);
				//oGeneralParams = null;
				//GC.Collect();

				//System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompanyService);
				//oCompanyService = null;
				//GC.Collect();

				if (ProgData.B1Company.InTransaction)
					ProgData.B1Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack);



			}
		}
		public static bool CreateUserFields(string TableName, string FieldName, string FieldDescription, SAPbobsCOM.BoFieldTypes type, long size = 0, SAPbobsCOM.BoFldSubTypes subType = SAPbobsCOM.BoFldSubTypes.st_None, string LinkedTable = "", string DefaultValue = "", Dictionary<string, string> ValidValues = null)
		{
			try
			{
				if (TableName.StartsWith("@") == true)
				{

					SAPbobsCOM.UserFieldsMD v_UserField = null;
					v_UserField = default(SAPbobsCOM.UserFieldsMD);
					v_UserField = (SAPbobsCOM.UserFieldsMD)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields);
					v_UserField.TableName = TableName;
					v_UserField.Name = FieldName;
					v_UserField.Description = FieldDescription;
					v_UserField.Type = type;


					if (type != SAPbobsCOM.BoFieldTypes.db_Date)
					{
						if (size != 0)
						{
							if (type == SAPbobsCOM.BoFieldTypes.db_Numeric)
							{
								v_UserField.EditSize = 11;
							}
							else
							{
								v_UserField.Size = (int)size;
							}


						}
					}
					if (subType != SAPbobsCOM.BoFldSubTypes.st_None)
					{
						v_UserField.SubType = subType;
					}
					if (!string.IsNullOrEmpty(LinkedTable))
						v_UserField.LinkedTable = LinkedTable;
					if (!string.IsNullOrEmpty(DefaultValue))
						v_UserField.DefaultValue = DefaultValue;
					//  GC.Collect();
					RetVal = v_UserField.Add();
					if (RetVal != 0)
					{
						ProgData.B1Company.GetLastError(out ErrCode, out ErrMsg);

						//ProgData.B1Application.StatusBar.SetText("Failed to add UserField masterid" + ErrCode + " " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
						System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
						v_UserField = null;
						GC.Collect();

						return false;
					}
					else
					{


						ProgData.B1Application.StatusBar.SetText("[" + TableName + "] - " + FieldName + " added successfully!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
						System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
						v_UserField = null;
						GC.Collect();

						return true;
					}

				}

				if (TableName.StartsWith("@") == false)
				{

					SAPbobsCOM.UserFieldsMD v_UserField = (SAPbobsCOM.UserFieldsMD)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields);
					v_UserField.TableName = TableName;
					v_UserField.Name = FieldName;
					v_UserField.Description = FieldDescription;
					v_UserField.Type = type;

					if (type != SAPbobsCOM.BoFieldTypes.db_Date)
					{
						if (size != 0)
						{
							if (type == SAPbobsCOM.BoFieldTypes.db_Numeric)
							{
								//   v_UserField.EditSize = 11;
							}
							else
							{
								v_UserField.Size = (int)size;
								v_UserField.EditSize = (int)size;
							}

						}
					}
					if (subType != SAPbobsCOM.BoFldSubTypes.st_None)
					{
						v_UserField.SubType = subType;
					}
					if (!string.IsNullOrEmpty(LinkedTable))
					{
						v_UserField.LinkedTable = LinkedTable;
						v_UserField.Type = SAPbobsCOM.BoFieldTypes.db_Alpha;


					}
					GC.Collect();

					RetVal = v_UserField.Add();
					if (RetVal != 0)
					{
						ProgData.B1Company.GetLastError(out ErrCode, out ErrMsg);
						ProgData.B1Application.StatusBar.SetText("Failed to add UserField " + FieldName + " - " + ErrCode.ToString() + " " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
						System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
						v_UserField = null;
						GC.Collect();

						return false;
					}
					else
					{
						ProgData.B1Application.StatusBar.SetText(" & TableName & - " + FieldName + " added successfully!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
						System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
						v_UserField = null;
						GC.Collect();

						return true;
					}



				}
			}
			catch (Exception ex)
			{
				Logger.Log(ex);
			}
			return true;
		}
		public static bool UDFExists(string TableName, string FieldID)
		{
			try
			{
				SAPbobsCOM.Recordset rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				bool oFlag = true;
				dynamic aa = "Select 1 from \"CUFD\" Where \"TableID\"='" + TableName.Trim() + "' and \"AliasID\"='" + FieldID.Trim() + "'";
				rs.DoQuery("Select 1 from \"CUFD\" Where \"TableID\"='" + TableName.Trim() + "' and \"AliasID\"='" + FieldID.Trim() + "'");
				if (rs.EoF)
					oFlag = false;
				System.Runtime.InteropServices.Marshal.ReleaseComObject(rs);
				rs = null;
				GC.Collect();
				return oFlag;

			}
			catch (Exception ex)
			{
				ProgData.B1Application.StatusBar.SetText(ex.Message);
			}
			return true;
		}

		public static bool UDOExists(string code)
		{

			GC.Collect();
			SAPbobsCOM.UserObjectsMD v_udoMD = default(SAPbobsCOM.UserObjectsMD);
			v_udoMD = (SAPbobsCOM.UserObjectsMD)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD);
			bool v_ReturnCode = false;
			v_ReturnCode = v_udoMD.GetByKey(code);
			System.Runtime.InteropServices.Marshal.ReleaseComObject(v_udoMD);
			v_udoMD = null;
			GC.Collect();
			return v_ReturnCode;
		}
		public static int getFieldID(string tableName, string aliasName)
		{
			string sqlClause;

			int fieldID = 0;

			SAPbobsCOM.Recordset rs;


			try
			{
				sqlClause = "Select \"FieldID\" from CUFD Where CUFD.\"TableID\"=\'" + tableName + "\' and CUFD.\"AliasID\"=\'" + aliasName + "\'";


				rs = (SAPbobsCOM.Recordset)ProgData.B1Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

				rs.DoQuery(sqlClause);

				fieldID = Convert.ToInt32(rs.Fields.Item(0).Value);

				System.Runtime.InteropServices.Marshal.ReleaseComObject(rs);
				rs = null;
				GC.Collect();


				return fieldID;
			}
			catch (Exception e)
			{
				ProgData.B1Application.SetStatusBarMessage(aliasName + " alanı için fieldID bulunamadı. " + e.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);

				rs = null;
				GC.Collect();
				return 0;
			}

		}

	}

}
