﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
	public class Param1 
	{
		public string userId { get; set; }
		public string password { get; set; }
		public string xmlName { get; set; }
		public string xmlDoc { get; set; }
		public string source { get; set; }


	}
}
