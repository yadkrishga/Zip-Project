﻿
#Region " Copyright © 2015 Genisys Group. All Rights Reserved. "
'   Class Description   : 
'   Author              : Yadav Krishnan
'   Date                :
'   Update Description  : Code Maintainability
'   Update Author       : Akhil P
'   Update Date         : 8-OCT-2015
#End Region

Public Class clsImport

#Region " Declaration "

    Dim objForm As SAPbouiCOM.Form
    Dim oEditBrowse As SAPbouiCOM.EditText
    Dim strFileName As String
    Dim oRecordSet As SAPbobsCOM.Recordset
#End Region

#Region " Events "
#Region " Menu events "

    ''' <summary>
    ''' Receiving Menu Events 
    ''' </summary>
    Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Try
            If (pVal.MenuUID = "OIMP" And pVal.BeforeAction = False) Then

            End If
        Catch ex As Exception
        End Try
    End Sub
#End Region
    Sub ImportExcelLoad()
        oGfun.LoadXML(objForm, ImportFormID, ImportXML)
        Me.initializeForm()
    End Sub
#Region " Item event "
    ''' <summary>
    ''' Receiving Item events
    ''' </summary>
    Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.EventType
                Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                    If (pVal.ItemUID = "btnBrowse" And pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                        Me.fillopen()
                    End If
                    If (pVal.ItemUID = "btnImport" And strFileName <> "" And pVal.BeforeAction = False And pVal.ActionSuccess = True) Then
                        Me.FetchExcel()
                    End If
                Case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS

            End Select
        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        End Try
    End Sub
#End Region
#End Region

#Region " Initialize Form "

    ''' <summary>
    ''' Initializing Form
    ''' </summary>
    ''' <remarks></remarks>
    Sub initializeForm()
        Try
            objForm = oApplication.Forms.ActiveForm
            objForm.Freeze(True)
            objForm.Freeze(False)
        Catch ex As Exception
            oApplication.StatusBar.SetText(ex.Message)
        Finally
            objForm.Freeze(False)
        End Try
    End Sub
#End Region

#Region " WindowWrapper Class "
    Public Class WindowWrapper
        Implements System.Windows.Forms.IWin32Window
        Private _hwnd As IntPtr

        Public Sub New(ByVal handle As IntPtr)
            _hwnd = handle
        End Sub

        Public ReadOnly Property Handle() As System.IntPtr Implements System.Windows.Forms.IWin32Window.Handle
            Get
                Return _hwnd
            End Get
        End Property
    End Class
#End Region

#Region " Fetch Data From Excel File   "

    ''' <summary>
    ''' Fetching data from excel file 
    ''' </summary>
    ''' <remarks></remarks>
    Sub FetchExcel()
        Try
            Dim MyConnection As System.Data.OleDb.OleDbConnection
            Dim DtSetHead As System.Data.DataSet
            Dim DtSetLine As System.Data.DataSet
            Dim DtSetLine2 As System.Data.DataSet
            Dim DtSetLine3 As System.Data.DataSet

            Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
            Dim iErrorCodes As Integer = 0
            Dim sErrorMsg As String = ""
            Dim ItemCode As String = ""
            Dim Qty As Double = 0
            Dim strQry As String = ""
            Dim oDocGeneralService As SAPbobsCOM.GeneralService
            Dim oDocGeneralData As SAPbobsCOM.GeneralData
            Dim oDocLinesCollection As SAPbobsCOM.GeneralDataCollection
            Dim oDocLineGeneralData As SAPbobsCOM.GeneralData
            Dim oRecordset As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; Data Source='" + strFileName + "'; Extended Properties=Excel 8.0;")
            MyCommand = New System.Data.OleDb.OleDbDataAdapter("select  DocNum,U_DocDate,U_ItmGrpCode,U_ItmGrpName,U_ForgName,U_SAPItmGrpCod,U_InvItem,U_SaleItem,U_PurItem,U_UOMGroup,U_Hazardous,U_Manufact,U_HSCode,U_HSName,U_MinSalPrc,U_MaxSalPrc,U_OrgCountCod,U_OrgCountNam,U_Category,U_Image,U_Pict,U_UnitOfSal,U_UnitOfSalM,U_SCartQty,U_SalVat,U_SVatRate,U_SCalCMB,U_SLHWInCM,U_UnitOfPur,U_UnitOfPurM,U_PCartQty,U_PurVat,U_PVatRate,U_PCalCMB,U_PLHWInCM,U_SLength,U_SWidth,U_SHeight,U_SCalCBM,U_PLength,U_PWidth,U_PHeight,U_PCalCBM from [Sheet1$]  ", MyConnection)
            MyCommand.TableMappings.Add("Table", "TestTable")
            DtSetHead = New System.Data.DataSet
            MyCommand.Fill(DtSetHead)
            oRecordset = ((oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)))
            Dim i As Integer
            Dim j As Integer
            For i = 0 To DtSetHead.Tables(0).Rows.Count - 1
                oCompanySrv = oCompany.GetCompanyService
                oDocGeneralService = oCompanySrv.GetGeneralService("OITM")
                oDocGeneralData = oDocGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData)
                oDocGeneralData.SetProperty("U_DocDate", DtSetHead.Tables(0).Rows(i)("U_DocDate").ToString())
                oDocGeneralData.SetProperty("U_ItmGrpCode", DtSetHead.Tables(0).Rows(i)("U_ItmGrpCode").ToString())
                oDocGeneralData.SetProperty("U_ItmGrpName", DtSetHead.Tables(0).Rows(i)("U_ItmGrpName").ToString())
                oDocGeneralData.SetProperty("U_ForgName", DtSetHead.Tables(0).Rows(i)("U_ForgName").ToString())
                oDocGeneralData.SetProperty("U_SAPItmGrpCod", DtSetHead.Tables(0).Rows(i)("U_SAPItmGrpCod").ToString())
                oDocGeneralData.SetProperty("U_InvItem", DtSetHead.Tables(0).Rows(i)("U_InvItem").ToString())
                oDocGeneralData.SetProperty("U_SaleItem", DtSetHead.Tables(0).Rows(i)("U_SaleItem").ToString())
                oDocGeneralData.SetProperty("U_PurItem", DtSetHead.Tables(0).Rows(i)("U_PurItem").ToString())

                oDocGeneralData.SetProperty("U_UOMGroup", DtSetHead.Tables(0).Rows(i)("U_UOMGroup").ToString())
                oDocGeneralData.SetProperty("U_Hazardous", DtSetHead.Tables(0).Rows(i)("U_Hazardous").ToString())
                oDocGeneralData.SetProperty("U_Manufact", DtSetHead.Tables(0).Rows(i)("U_Manufact").ToString())
                oDocGeneralData.SetProperty("U_HSCode", DtSetHead.Tables(0).Rows(i)("U_HSCode").ToString())
                oDocGeneralData.SetProperty("U_HSName", DtSetHead.Tables(0).Rows(i)("U_HSName").ToString())
                oDocGeneralData.SetProperty("U_MinSalPrc", DtSetHead.Tables(0).Rows(i)("U_MinSalPrc").ToString())
                oDocGeneralData.SetProperty("U_MaxSalPrc", DtSetHead.Tables(0).Rows(i)("U_MaxSalPrc").ToString())
                oDocGeneralData.SetProperty("U_OrgCountCod", DtSetHead.Tables(0).Rows(i)("U_OrgCountCod").ToString())

                oDocGeneralData.SetProperty("U_OrgCountNam", DtSetHead.Tables(0).Rows(i)("U_OrgCountNam").ToString())
                oDocGeneralData.SetProperty("U_Category", DtSetHead.Tables(0).Rows(i)("U_Category").ToString())
                oDocGeneralData.SetProperty("U_Image", DtSetHead.Tables(0).Rows(i)("U_Image").ToString())
                oDocGeneralData.SetProperty("U_Pict", DtSetHead.Tables(0).Rows(i)("U_Pict").ToString())
                oDocGeneralData.SetProperty("U_UnitOfSal", DtSetHead.Tables(0).Rows(i)("U_UnitOfSal").ToString())
                oDocGeneralData.SetProperty("U_UnitOfSalM", DtSetHead.Tables(0).Rows(i)("U_UnitOfSalM").ToString())
                oDocGeneralData.SetProperty("U_SCartQty", DtSetHead.Tables(0).Rows(i)("U_SCartQty").ToString())
                oDocGeneralData.SetProperty("U_SalVat", DtSetHead.Tables(0).Rows(i)("U_SalVat").ToString())

                oDocGeneralData.SetProperty("U_SVatRate", DtSetHead.Tables(0).Rows(i)("U_SVatRate").ToString())
                'oDocGeneralData.SetProperty("U_SCalCMB", DtSetHead.Tables(0).Rows(i)("U_SCalCMB").ToString())
                'oDocGeneralData.SetProperty("U_SLHWInCM", DtSetHead.Tables(0).Rows(i)("U_SLHWInCM").ToString())
                oDocGeneralData.SetProperty("U_UnitOfPur", DtSetHead.Tables(0).Rows(i)("U_UnitOfPur").ToString())
                oDocGeneralData.SetProperty("U_UnitOfPurM", DtSetHead.Tables(0).Rows(i)("U_UnitOfPurM").ToString())
                oDocGeneralData.SetProperty("U_PCartQty", DtSetHead.Tables(0).Rows(i)("U_PCartQty").ToString())
                oDocGeneralData.SetProperty("U_PurVat", DtSetHead.Tables(0).Rows(i)("U_PurVat").ToString())
                oDocGeneralData.SetProperty("U_PVatRate", DtSetHead.Tables(0).Rows(i)("U_PVatRate").ToString())

                'oDocGeneralData.SetProperty("U_PCalCMB", DtSetHead.Tables(0).Rows(i)("U_PCalCMB").ToString())
                'oDocGeneralData.SetProperty("U_PLHWInCM", DtSetHead.Tables(0).Rows(i)("U_PLHWInCM").ToString())
                oDocGeneralData.SetProperty("U_SLength", DtSetHead.Tables(0).Rows(i)("U_SLength").ToString())
                oDocGeneralData.SetProperty("U_SWidth", DtSetHead.Tables(0).Rows(i)("U_SWidth").ToString())
                oDocGeneralData.SetProperty("U_SHeight", DtSetHead.Tables(0).Rows(i)("U_SHeight").ToString())
                ' oDocGeneralData.SetProperty("U_SCalCBM", DtSetHead.Tables(0).Rows(i)("U_SCalCBM").ToString())
                oDocGeneralData.SetProperty("U_PLength", DtSetHead.Tables(0).Rows(i)("U_PLength").ToString())
                oDocGeneralData.SetProperty("U_PWidth", DtSetHead.Tables(0).Rows(i)("U_PWidth").ToString())

                oDocGeneralData.SetProperty("U_PHeight", DtSetHead.Tables(0).Rows(i)("U_PHeight").ToString())
                'oDocGeneralData.SetProperty("U_PCalCBM", DtSetHead.Tables(0).Rows(i)("U_PCalCBM").ToString())

                Try

                    MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; Data Source='" + strFileName + "'; Extended Properties=Excel 8.0;")
                    MyCommand = New System.Data.OleDb.OleDbDataAdapter("select * from [Sheet2$] where  DocNum =" + DtSetHead.Tables(0).Rows(i)("DocNum").ToString(), MyConnection)
                    MyCommand.TableMappings.Add("Table", "TestTable")
                    DtSetLine = New System.Data.DataSet
                    MyCommand.Fill(DtSetLine)
                    For j = 0 To DtSetLine.Tables(0).Rows.Count - 1
                        oDocLinesCollection = oDocGeneralData.Child("INS_ITM1")
                        oDocLineGeneralData = oDocLinesCollection.Add()
                       
                        oDocLineGeneralData.SetProperty("U_Code1", DtSetLine.Tables(0).Rows(j)("U_Code1").ToString())
                        oDocLineGeneralData.SetProperty("U_Code", DtSetLine.Tables(0).Rows(j)("U_Code").ToString())
                        oDocLineGeneralData.SetProperty("U_Name", DtSetLine.Tables(0).Rows(j)("U_Name").ToString())
                        oDocLineGeneralData.SetProperty("U_Select", DtSetLine.Tables(0).Rows(j)("U_Select").ToString())


                    Next
                    DtSetLine.Reset()
                Catch ex As Exception

                End Try

                Try


                    MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; Data Source='" + strFileName + "'; Extended Properties=Excel 8.0;")
                    MyCommand = New System.Data.OleDb.OleDbDataAdapter("select U_PropCode,U_PropName,U_Select from [Sheet3$] where  DocNum =" + DtSetHead.Tables(0).Rows(i)("DocNum").ToString(), MyConnection)
                    MyCommand.TableMappings.Add("Table", "TestTable")
                    DtSetLine2 = New System.Data.DataSet
                    MyCommand.Fill(DtSetLine2)
                    For j = 0 To DtSetLine2.Tables(0).Rows.Count - 1
                        oDocLinesCollection = oDocGeneralData.Child("INS_ITM2")
                        oDocLineGeneralData = oDocLinesCollection.Add()

                        oDocLineGeneralData.SetProperty("U_PropCode", DtSetLine2.Tables(0).Rows(j)("U_PropCode").ToString())
                        oDocLineGeneralData.SetProperty("U_PropName", DtSetLine2.Tables(0).Rows(j)("U_PropName").ToString())
                        oDocLineGeneralData.SetProperty("U_Select", DtSetLine2.Tables(0).Rows(j)("U_Select").ToString().Trim())


                    Next
                    DtSetLine2.Reset()
                Catch ex As Exception

                End Try

                Try

                    MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; Data Source='" + strFileName + "'; Extended Properties=Excel 8.0;")
                    MyCommand = New System.Data.OleDb.OleDbDataAdapter("select * from [Sheet4$] where  DocNum =" + DtSetHead.Tables(0).Rows(i)("DocNum").ToString(), MyConnection)
                    MyCommand.TableMappings.Add("Table", "TestTable")
                    DtSetLine3 = New System.Data.DataSet
                    MyCommand.Fill(DtSetLine3)
                    For j = 0 To DtSetLine3.Tables(0).Rows.Count - 1
                        oDocLinesCollection = oDocGeneralData.Child("INS_ITM3")
                        oDocLineGeneralData = oDocLinesCollection.Add()

                        oDocLineGeneralData.SetProperty("U_TrgtPath", DtSetLine3.Tables(0).Rows(j)("U_TrgtPath").ToString())
                        oDocLineGeneralData.SetProperty("U_ScrPath", DtSetLine3.Tables(0).Rows(j)("U_ScrPath").ToString())
                        oDocLineGeneralData.SetProperty("U_FileName", DtSetLine3.Tables(0).Rows(j)("U_FileName").ToString())
                        oDocLineGeneralData.SetProperty("U_FileExt", DtSetLine3.Tables(0).Rows(j)("U_FileExt").ToString())
                        oDocLineGeneralData.SetProperty("U_Date", DtSetLine3.Tables(0).Rows(j)("U_Date").ToString())



                    Next
                    DtSetLine3.Reset()
                Catch ex As Exception

                End Try
                oDocGeneralService.Add(oDocGeneralData)
            Next
        System.Threading.Thread.Sleep(2000)
        MsgBox("Excel Imported Successfully")
        MyConnection.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region " Dialog Box Open "
    ''' <summary>
    ''' Opening Dialog box to Browse Excel file
    ''' </summary>
    ''' <remarks></remarks>
    Sub fillopen()
        Dim mythr As New System.Threading.Thread(AddressOf ShowFileDialog)
        mythr.SetApartmentState(Threading.ApartmentState.STA)
        mythr.Start()
        mythr.Join()
    End Sub

    ''' <summary>
    ''' Opening Dialog Box
    ''' </summary>
    Private Sub ShowFileDialog()
        Dim oDialogBox As New OpenFileDialog
        Dim strMdbFilePath As String

        Dim oProcesses() As Process
        Dim strSelectedFilepath As String
        Try
            'Form.Freeze(True)
            objForm = oApplication.Forms.ActiveForm
            oProcesses = Process.GetProcessesByName("SAP Business One")
            If oProcesses.Length <> 0 Then

                Dim MyWindow As New WindowWrapper(oProcesses(0).MainWindowHandle)
                oDialogBox.Filter = "Excel Worksheets|*.xl*"
                If oDialogBox.ShowDialog(MyWindow) = DialogResult.OK Then
                    strMdbFilePath = oDialogBox.FileName
                    strSelectedFilepath = oDialogBox.FileName
                    oEditBrowse = objForm.Items.Item("edtBrowse").Specific
                    oEditBrowse.Value = oDialogBox.FileName.ToString()
                    strFileName = oDialogBox.FileName.ToString()
                Else
                End If

            End If

        Catch ex As Exception
            oApplication.MessageBox(ex.Message)
        Finally
        End Try
    End Sub
#End Region

End Class
