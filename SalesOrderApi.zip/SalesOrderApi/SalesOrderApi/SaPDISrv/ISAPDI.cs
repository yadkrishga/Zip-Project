﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaPDISrv
{
	public interface ISAPDI
	{
			string CreateOrder(string Xmlvalue, string XmlName);

			UserInfo Finduser(UserInfo user);
		
	}
}
